builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/captures/smolvla/smolvla_session/stages/action_decode/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<1x50x32xf32>) -> tensor<1x50x32xf32> {
    func.return %0 : tensor<1x50x32xf32>
  }
}