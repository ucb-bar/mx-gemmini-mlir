/* Generated. */
extern void _mlir_ciface_merlin_stage_2_action_decode(void*,void*);
void merlin_stage_2_invoke(void **d) { _mlir_ciface_merlin_stage_2_action_decode(d[0],d[1]); }
