/* Generated multi-program stage adapter. */
#include <stddef.h>
#include "merlin_model.h"
#include "model_gen.h"
#include "model_io.h"
extern void merlin_stage_1_invoke(void **);
static merlin_descriptor_t DESCS[MERLIN_N_ARGS];
static int original_input_arg(int arg) {
  switch (arg) {
    case 352: return 0;
    case 353: return 1;
    case 361: return 2;
    case 362: return 3;
    case 370: return 4;
    case 371: return 5;
    case 379: return 6;
    case 380: return 7;
    case 388: return 8;
    case 389: return 9;
    case 397: return 10;
    case 398: return 11;
    case 406: return 12;
    case 407: return 13;
    case 415: return 14;
    case 416: return 15;
    case 424: return 16;
    case 425: return 17;
    case 433: return 18;
    case 434: return 19;
    case 442: return 20;
    case 443: return 21;
    case 451: return 22;
    case 452: return 23;
    case 460: return 24;
    case 461: return 25;
    case 469: return 26;
    case 470: return 27;
    case 478: return 28;
    case 479: return 29;
    case 487: return 30;
    case 488: return 31;
    case 489: return 32;
    case 493: return 33;
    case 495: return 34;
    case 497: return 35;
    case 499: return 36;
    case 500: return 37;
    case 501: return 38;
    case 502: return 39;
    case 503: return 40;
    case 504: return 41;
    case 505: return 42;
    case 506: return 43;
    case 507: return 44;
    case 508: return 45;
    default: return -1;
  }
}
static size_t arg_bytes(const merlin_arg_t *arg) {
  size_t n = (size_t)arg->elem_size;
  for (int i = 0; i < arg->rank; i++) n *= (size_t)arg->dims[i];
  return n;
}
void merlin_stage_1_reset(void) { merlin_reset_session(); }
int merlin_stage_1_run(const void *weights, long step, int validate) {
  merlin_prepare_step(step);
  merlin_run_multi_with(MERLIN_ARGS, MERLIN_N_ARGS, weights, MERLIN_INPUT_PTR,
                        MERLIN_OUTPUT_PTR, DESCS, merlin_stage_1_invoke);
#if MERLIN_N_STATE_PAIRS > 0
  if (merlin_commit_state(MERLIN_ARGS, MERLIN_N_ARGS, MERLIN_INPUT_PTR, MERLIN_OUTPUT_PTR,
                          MERLIN_N_STATE_PAIRS, MERLIN_STATE_INPUT_ARGS,
                          MERLIN_STATE_OUTPUT_INDICES) != 0) return -1;
#endif
  if (validate) merlin_validate_step(step);
  return 0;
}
void *merlin_stage_1_input(int arg) {
  arg = original_input_arg(arg);
  return arg >= 0 && arg < MERLIN_N_ARGS && MERLIN_ARGS[arg].kind == MERLIN_INPUT
      ? MERLIN_INPUT_PTR[arg] : 0;
}
size_t merlin_stage_1_input_bytes(int arg) {
  arg = original_input_arg(arg);
  return arg >= 0 && arg < MERLIN_N_ARGS && MERLIN_ARGS[arg].kind == MERLIN_INPUT
      ? arg_bytes(&MERLIN_ARGS[arg]) : 0;
}
static int output_arg(int wanted) {
  int seen = 0;
  for (int arg = 0; arg < MERLIN_N_ARGS; arg++)
    if (MERLIN_ARGS[arg].kind == MERLIN_OUTPUT && seen++ == wanted) return arg;
  return -1;
}
void *merlin_stage_1_output(int output) {
  return output >= 0 && output < MERLIN_N_OUTPUTS ? MERLIN_OUTPUT_PTR[output] : 0;
}
size_t merlin_stage_1_output_bytes(int output) {
  int arg = output_arg(output); return arg >= 0 ? arg_bytes(&MERLIN_ARGS[arg]) : 0;
}
long merlin_stage_1_quality_steps(void) { return merlin_quality_steps(); }
long merlin_stage_1_quality_min_cos_ppm(void) { return merlin_quality_min_cos_ppm(); }
long merlin_stage_1_quality_max_rel_ppm(void) { return merlin_quality_max_rel_ppm(); }
long merlin_stage_1_quality_top1(void) { return merlin_quality_top1(); }
long merlin_stage_1_correctness_steps(void) { return merlin_correctness_steps(); }
long merlin_stage_1_correctness_min_cos_ppm(void) { return merlin_correctness_min_cos_ppm(); }
long merlin_stage_1_correctness_max_rel_ppm(void) { return merlin_correctness_max_rel_ppm(); }
long merlin_stage_1_correctness_top1(void) { return merlin_correctness_top1(); }
size_t merlin_stage_1_output_elems(int output) {
  int arg = output_arg(output); if (arg < 0) return 0;
  size_t n = 1; for (int i = 0; i < MERLIN_ARGS[arg].rank; i++) n *= MERLIN_ARGS[arg].dims[i];
  return n;
}
long merlin_stage_1_output_lastdim(int output) {
  int arg = output_arg(output); return arg >= 0 && MERLIN_ARGS[arg].rank > 0
      ? MERLIN_ARGS[arg].dims[MERLIN_ARGS[arg].rank - 1] : 1;
}
