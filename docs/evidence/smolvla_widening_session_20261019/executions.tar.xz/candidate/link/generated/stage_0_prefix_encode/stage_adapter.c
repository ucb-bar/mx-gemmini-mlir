/* Generated multi-program stage adapter. */
#include <stddef.h>
#include "merlin_model.h"
#include "model_gen.h"
#include "model_io.h"
extern void merlin_invoke(void **);
static merlin_descriptor_t DESCS[MERLIN_N_ARGS];
static int original_input_arg(int arg) {
  switch (arg) {
    case 0: return 0;
    case 1: return 1;
    case 2: return 2;
    case 4: return 3;
    case 6: return 4;
    case 8: return 5;
    case 10: return 6;
    case 11: return 7;
    case 12: return 8;
    case 14: return 9;
    case 16: return 10;
    case 17: return 11;
    case 18: return 12;
    case 20: return 13;
    case 22: return 14;
    case 24: return 15;
    case 26: return 16;
    case 27: return 17;
    case 28: return 18;
    case 30: return 19;
    case 32: return 20;
    case 33: return 21;
    case 34: return 22;
    case 36: return 23;
    case 38: return 24;
    case 40: return 25;
    case 42: return 26;
    case 43: return 27;
    case 44: return 28;
    case 46: return 29;
    case 48: return 30;
    case 49: return 31;
    case 50: return 32;
    case 52: return 33;
    case 54: return 34;
    case 56: return 35;
    case 58: return 36;
    case 59: return 37;
    case 60: return 38;
    case 62: return 39;
    case 64: return 40;
    case 65: return 41;
    case 66: return 42;
    case 68: return 43;
    case 70: return 44;
    case 72: return 45;
    case 74: return 46;
    case 75: return 47;
    case 76: return 48;
    case 78: return 49;
    case 80: return 50;
    case 81: return 51;
    case 82: return 52;
    case 84: return 53;
    case 86: return 54;
    case 88: return 55;
    case 90: return 56;
    case 91: return 57;
    case 92: return 58;
    case 94: return 59;
    case 96: return 60;
    case 97: return 61;
    case 98: return 62;
    case 100: return 63;
    case 102: return 64;
    case 104: return 65;
    case 106: return 66;
    case 107: return 67;
    case 108: return 68;
    case 110: return 69;
    case 112: return 70;
    case 113: return 71;
    case 114: return 72;
    case 116: return 73;
    case 118: return 74;
    case 120: return 75;
    case 122: return 76;
    case 123: return 77;
    case 124: return 78;
    case 126: return 79;
    case 128: return 80;
    case 129: return 81;
    case 130: return 82;
    case 132: return 83;
    case 134: return 84;
    case 136: return 85;
    case 138: return 86;
    case 139: return 87;
    case 140: return 88;
    case 142: return 89;
    case 144: return 90;
    case 145: return 91;
    case 146: return 92;
    case 148: return 93;
    case 150: return 94;
    case 152: return 95;
    case 154: return 96;
    case 155: return 97;
    case 156: return 98;
    case 158: return 99;
    case 160: return 100;
    case 161: return 101;
    case 162: return 102;
    case 164: return 103;
    case 166: return 104;
    case 168: return 105;
    case 170: return 106;
    case 171: return 107;
    case 172: return 108;
    case 174: return 109;
    case 176: return 110;
    case 177: return 111;
    case 178: return 112;
    case 180: return 113;
    case 182: return 114;
    case 184: return 115;
    case 186: return 116;
    case 187: return 117;
    case 188: return 118;
    case 190: return 119;
    case 192: return 120;
    case 193: return 121;
    case 194: return 122;
    case 195: return 123;
    case 196: return 124;
    case 198: return 125;
    case 206: return 126;
    case 207: return 127;
    case 215: return 128;
    case 216: return 129;
    case 224: return 130;
    case 225: return 131;
    case 233: return 132;
    case 234: return 133;
    case 242: return 134;
    case 243: return 135;
    case 251: return 136;
    case 252: return 137;
    case 260: return 138;
    case 261: return 139;
    case 269: return 140;
    case 270: return 141;
    case 278: return 142;
    case 279: return 143;
    case 287: return 144;
    case 288: return 145;
    case 296: return 146;
    case 297: return 147;
    case 305: return 148;
    case 306: return 149;
    case 314: return 150;
    case 315: return 151;
    case 323: return 152;
    case 324: return 153;
    case 332: return 154;
    case 333: return 155;
    case 341: return 156;
    case 342: return 157;
    case 491: return 158;
    case 500: return 159;
    case 501: return 160;
    case 502: return 161;
    case 503: return 162;
    case 504: return 163;
    case 505: return 164;
    case 506: return 165;
    case 507: return 166;
    case 508: return 167;
    case 509: return 168;
    case 510: return 169;
    default: return -1;
  }
}
static size_t arg_bytes(const merlin_arg_t *arg) {
  size_t n = (size_t)arg->elem_size;
  for (int i = 0; i < arg->rank; i++) n *= (size_t)arg->dims[i];
  return n;
}
void merlin_stage_0_reset(void) { merlin_reset_session(); }
int merlin_stage_0_run(const void *weights, long step, int validate) {
  merlin_prepare_step(step);
  merlin_run_multi_with(MERLIN_ARGS, MERLIN_N_ARGS, weights, MERLIN_INPUT_PTR,
                        MERLIN_OUTPUT_PTR, DESCS, merlin_invoke);
#if MERLIN_N_STATE_PAIRS > 0
  if (merlin_commit_state(MERLIN_ARGS, MERLIN_N_ARGS, MERLIN_INPUT_PTR, MERLIN_OUTPUT_PTR,
                          MERLIN_N_STATE_PAIRS, MERLIN_STATE_INPUT_ARGS,
                          MERLIN_STATE_OUTPUT_INDICES) != 0) return -1;
#endif
  if (validate) merlin_validate_step(step);
  return 0;
}
void *merlin_stage_0_input(int arg) {
  arg = original_input_arg(arg);
  return arg >= 0 && arg < MERLIN_N_ARGS && MERLIN_ARGS[arg].kind == MERLIN_INPUT
      ? MERLIN_INPUT_PTR[arg] : 0;
}
size_t merlin_stage_0_input_bytes(int arg) {
  arg = original_input_arg(arg);
  return arg >= 0 && arg < MERLIN_N_ARGS && MERLIN_ARGS[arg].kind == MERLIN_INPUT
      ? arg_bytes(&MERLIN_ARGS[arg]) : 0;
}
static int output_arg(int wanted) {
  int seen = 0;
  for (int arg = 0; arg < MERLIN_N_ARGS; arg++)
    if (MERLIN_ARGS[arg].kind == MERLIN_OUTPUT && seen++ == wanted) return arg;
  return -1;
}
void *merlin_stage_0_output(int output) {
  return output >= 0 && output < MERLIN_N_OUTPUTS ? MERLIN_OUTPUT_PTR[output] : 0;
}
size_t merlin_stage_0_output_bytes(int output) {
  int arg = output_arg(output); return arg >= 0 ? arg_bytes(&MERLIN_ARGS[arg]) : 0;
}
long merlin_stage_0_quality_steps(void) { return merlin_quality_steps(); }
long merlin_stage_0_quality_min_cos_ppm(void) { return merlin_quality_min_cos_ppm(); }
long merlin_stage_0_quality_max_rel_ppm(void) { return merlin_quality_max_rel_ppm(); }
long merlin_stage_0_quality_top1(void) { return merlin_quality_top1(); }
long merlin_stage_0_correctness_steps(void) { return merlin_correctness_steps(); }
long merlin_stage_0_correctness_min_cos_ppm(void) { return merlin_correctness_min_cos_ppm(); }
long merlin_stage_0_correctness_max_rel_ppm(void) { return merlin_correctness_max_rel_ppm(); }
long merlin_stage_0_correctness_top1(void) { return merlin_correctness_top1(); }
size_t merlin_stage_0_output_elems(int output) {
  int arg = output_arg(output); if (arg < 0) return 0;
  size_t n = 1; for (int i = 0; i < MERLIN_ARGS[arg].rank; i++) n *= MERLIN_ARGS[arg].dims[i];
  return n;
}
long merlin_stage_0_output_lastdim(int output) {
  int arg = output_arg(output); return arg >= 0 && MERLIN_ARGS[arg].rank > 0
      ? MERLIN_ARGS[arg].dims[MERLIN_ARGS[arg].rank - 1] : 1;
}
