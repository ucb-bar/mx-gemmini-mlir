/* Generated multi-program session scheduler. */
#include <stddef.h>
#include <string.h>
#include "merlin_session.h"
void merlin_stage_0_reset(void);
int merlin_stage_0_run(const void *, long, int);
void *merlin_stage_0_input(int);
size_t merlin_stage_0_input_bytes(int);
void *merlin_stage_0_output(int);
size_t merlin_stage_0_output_bytes(int);
long merlin_stage_0_quality_steps(void);
long merlin_stage_0_quality_min_cos_ppm(void);
long merlin_stage_0_quality_max_rel_ppm(void);
long merlin_stage_0_quality_top1(void);
long merlin_stage_0_correctness_steps(void);
long merlin_stage_0_correctness_min_cos_ppm(void);
long merlin_stage_0_correctness_max_rel_ppm(void);
long merlin_stage_0_correctness_top1(void);
size_t merlin_stage_0_output_elems(int);
long merlin_stage_0_output_lastdim(int);
void merlin_stage_1_reset(void);
int merlin_stage_1_run(const void *, long, int);
void *merlin_stage_1_input(int);
size_t merlin_stage_1_input_bytes(int);
void *merlin_stage_1_output(int);
size_t merlin_stage_1_output_bytes(int);
long merlin_stage_1_quality_steps(void);
long merlin_stage_1_quality_min_cos_ppm(void);
long merlin_stage_1_quality_max_rel_ppm(void);
long merlin_stage_1_quality_top1(void);
long merlin_stage_1_correctness_steps(void);
long merlin_stage_1_correctness_min_cos_ppm(void);
long merlin_stage_1_correctness_max_rel_ppm(void);
long merlin_stage_1_correctness_top1(void);
size_t merlin_stage_1_output_elems(int);
long merlin_stage_1_output_lastdim(int);
void merlin_stage_2_reset(void);
int merlin_stage_2_run(const void *, long, int);
void *merlin_stage_2_input(int);
size_t merlin_stage_2_input_bytes(int);
void *merlin_stage_2_output(int);
size_t merlin_stage_2_output_bytes(int);
long merlin_stage_2_quality_steps(void);
long merlin_stage_2_quality_min_cos_ppm(void);
long merlin_stage_2_quality_max_rel_ppm(void);
long merlin_stage_2_quality_top1(void);
long merlin_stage_2_correctness_steps(void);
long merlin_stage_2_correctness_min_cos_ppm(void);
long merlin_stage_2_correctness_max_rel_ppm(void);
long merlin_stage_2_correctness_top1(void);
size_t merlin_stage_2_output_elems(int);
long merlin_stage_2_output_lastdim(int);
static const char *NAMES[MERLIN_SESSION_N_PROGRAMS] = {"prefix_encode","flow_denoise","action_decode"};
static const long STEPS[MERLIN_SESSION_N_PROGRAMS] = {1,10,1};
const char *merlin_session_program_name(int program) {
  return program >= 0 && program < MERLIN_SESSION_N_PROGRAMS ? NAMES[program] : 0;
}
long merlin_session_program_steps(int program) {
  return program >= 0 && program < MERLIN_SESSION_N_PROGRAMS ? STEPS[program] : 0;
}
void merlin_session_reset(void) {
  merlin_stage_0_reset();
  merlin_stage_1_reset();
  merlin_stage_2_reset();
}
int merlin_session_prepare_program(int program) {
  switch (program) {
    case 0: {
      (void)0;
      return 0;
    }
    case 1: {
      size_t source_bytes_0 = merlin_stage_0_output_bytes(0);
      size_t target_bytes_0 = merlin_stage_1_input_bytes(505);
      if (!source_bytes_0 || source_bytes_0 != target_bytes_0) return -1;
      memcpy(merlin_stage_1_input(505), merlin_stage_0_output(0), source_bytes_0);
      size_t source_bytes_1 = merlin_stage_0_output_bytes(1);
      size_t target_bytes_1 = merlin_stage_1_input_bytes(506);
      if (!source_bytes_1 || source_bytes_1 != target_bytes_1) return -1;
      memcpy(merlin_stage_1_input(506), merlin_stage_0_output(1), source_bytes_1);
      return 0;
    }
    case 2: {
      size_t source_bytes_2 = merlin_stage_1_output_bytes(0);
      size_t target_bytes_2 = merlin_stage_2_input_bytes(0);
      if (!source_bytes_2 || source_bytes_2 != target_bytes_2) return -1;
      memcpy(merlin_stage_2_input(0), merlin_stage_1_output(0), source_bytes_2);
      return 0;
    }
    default: return -1;
  }
}
int merlin_session_run_step(int program, const void *weights, long step, int validate) {
  switch (program) {
    case 0: return merlin_stage_0_run((const unsigned char *)weights + 0ULL, step, validate);
    case 1: return merlin_stage_1_run((const unsigned char *)weights + 97679616ULL, step, validate);
    case 2: return merlin_stage_2_run((const unsigned char *)weights + 0ULL, step, validate);
    default: return -1;
  }
}
long merlin_session_quality_steps(void) { return merlin_stage_1_quality_steps(); }
long merlin_session_quality_min_cos_ppm(void) {
  return merlin_stage_1_quality_min_cos_ppm();
}
long merlin_session_quality_max_rel_ppm(void) {
  return merlin_stage_1_quality_max_rel_ppm();
}
long merlin_session_quality_top1(void) { return merlin_stage_1_quality_top1(); }
long merlin_session_correctness_steps(void) {
  return merlin_stage_1_correctness_steps();
}
long merlin_session_correctness_min_cos_ppm(void) {
  return merlin_stage_1_correctness_min_cos_ppm();
}
long merlin_session_correctness_max_rel_ppm(void) {
  return merlin_stage_1_correctness_max_rel_ppm();
}
long merlin_session_correctness_top1(void) {
  return merlin_stage_1_correctness_top1();
}
void *merlin_session_quality_output(void) {
  return merlin_stage_1_output(0);
}
size_t merlin_session_quality_output_elems(void) {
  return merlin_stage_1_output_elems(0);
}
long merlin_session_quality_output_lastdim(void) {
  return merlin_stage_1_output_lastdim(0);
}
