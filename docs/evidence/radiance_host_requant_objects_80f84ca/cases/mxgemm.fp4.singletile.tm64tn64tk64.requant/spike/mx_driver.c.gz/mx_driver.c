#include <stdint.h>
#include <stdio.h>
#include "mx_issue.h"
extern const uint8_t activation[];
extern const uint8_t activation_scales[];
extern const uint8_t golden_fp8[];
extern const uint8_t golden_output_scales[];
extern const uint8_t weight[];
extern const uint8_t weight_scales[];
static uint8_t output_bf16[8192] __attribute__((aligned(64)));
static uint8_t output_quantized[4096] __attribute__((aligned(64)));
static uint8_t scratch_output_scales[128] __attribute__((aligned(64)));

int main(void) {
  mx_issue(activation, activation_scales, output_bf16, output_quantized, scratch_output_scales, weight, weight_scales);
  int code_errors = 0, scale_errors = 0;
  for (uint32_t i = 0; i < 4096; ++i)
    if (output_quantized[i] != golden_fp8[i]) ++code_errors;
  for (uint32_t i = 0; i < 128; ++i)
    if (scratch_output_scales[i] != golden_output_scales[i]) ++scale_errors;
  printf("runtime host MX: %d/4096 code mismatches, "
         "%d/128 scale mismatches\n", code_errors, scale_errors);
  return code_errors != 0 || scale_errors != 0;
}
