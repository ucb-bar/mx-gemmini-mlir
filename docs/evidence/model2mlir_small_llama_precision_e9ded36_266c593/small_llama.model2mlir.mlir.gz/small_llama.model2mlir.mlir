builtin.module attributes {prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<256x128xf32>, %1: tensor<128xf32>, %2: tensor<128x128xf32>, %3: tensor<128x128xf32>, %4: tensor<128x128xf32>, %5: tensor<128x128xf32>, %6: tensor<128xf32>, %7: tensor<344x128xf32>, %8: tensor<344x128xf32>, %9: tensor<128x344xf32>, %10: tensor<128xf32>, %11: tensor<128x128xf32>, %12: tensor<128x128xf32>, %13: tensor<128x128xf32>, %14: tensor<128x128xf32>, %15: tensor<128xf32>, %16: tensor<344x128xf32>, %17: tensor<344x128xf32>, %18: tensor<128x344xf32>, %19: tensor<128xf32>, %20: tensor<256x128xf32>, %21: tensor<1x8xi64>) -> tensor<1x8x256xf32> {
    %22 = tensor.empty() : tensor<8xi64>
    %23 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%22 : tensor<8xi64>) attrs =  {prov.region_id = "iota_0", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64"} {
    ^bb0(%24: i64):
      %25 = linalg.index 0 : index
      %26 = arith.index_cast %25 : index to i64
      %27 = arith.constant 1 : i64
      %28 = arith.muli %26, %27 : i64
      %29 = arith.constant 0 : i64
      %30 = arith.addi %29, %28 : i64
      linalg.yield %30 : i64
    } -> tensor<8xi64>
    %31 = tensor.empty() : tensor<1x8x128xf32>
    %32 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%21 : tensor<1x8xi64>) outs(%31 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "gather_0", prov.family = "gather_scatter", prov._pattern_hint = "embedding", prov.op = "embedding", prov.aten = "aten.embedding.default", prov.orig_dtype = "float32", prov.module = "emb", prov.fqn = "emb"} {
    ^bb1(%33: i64, %34: f32):
      %35 = arith.index_cast %33 : i64 to index
      %36 = linalg.index 2 : index
      %37 = tensor.extract %0[%35, %36] : tensor<256x128xf32>
      linalg.yield %37 : f32
    } -> tensor<1x8x128xf32>
    %38 = tensor.empty() : tensor<1x8x128xf32>
    %39 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%32 : tensor<1x8x128xf32>) outs(%38 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "pow_0", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} {
    ^bb2(%40: f32, %41: f32):
      %42 = arith.mulf %40, %40 : f32
      linalg.yield %42 : f32
    } -> tensor<1x8x128xf32>
    %43 = arith.constant {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} 0.000000e+00 : f32
    %44 = tensor.splat %43 {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} : tensor<1x8xf32>
    %45 = linalg.reduce ins(%39:tensor<1x8x128xf32>) outs(%44:tensor<1x8xf32>) dimensions = [2]
    (%46: f32, %47: f32) {
      %48 = arith.addf %46, %47 : f32
      linalg.yield %48 : f32
    }
    %49 = arith.constant {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} 1.280000e+02 : f32
    %50 = tensor.splat %49 {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} : tensor<1x8xf32>
    %51 = tensor.empty() : tensor<1x8xf32>
    %52 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%45, %50 : tensor<1x8xf32>, tensor<1x8xf32>) outs(%51 : tensor<1x8xf32>) attrs =  {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} {
    ^bb3(%53: f32, %54: f32, %55: f32):
      %56 = arith.divf %53, %54 : f32
      linalg.yield %56 : f32
    } -> tensor<1x8xf32>
    %57 = tensor.collapse_shape %52 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} : tensor<1x8xf32> into tensor<8xf32>
    %58 = tensor.expand_shape %57 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 1] {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} : tensor<8xf32> into tensor<1x8x1xf32>
    %59 = arith.constant {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} 1.000000e-05 : f32
    %60 = tensor.splat %59 {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} : tensor<1x8x1xf32>
    %61 = tensor.empty() : tensor<1x8x1xf32>
    %62 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%58, %60 : tensor<1x8x1xf32>, tensor<1x8x1xf32>) outs(%61 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} {
    ^bb4(%63: f32, %64: f32, %65: f32):
      %66 = arith.addf %63, %64 : f32
      linalg.yield %66 : f32
    } -> tensor<1x8x1xf32>
    %67 = tensor.empty() : tensor<1x8x1xf32>
    %68 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%62 : tensor<1x8x1xf32>) outs(%67 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "rsqrt_0", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} {
    ^bb5(%69: f32, %70: f32):
      %71 = math.rsqrt %69 : f32
      linalg.yield %71 : f32
    } -> tensor<1x8x1xf32>
    %72 = tensor.empty() : tensor<1x8x128xf32>
    %73 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%32, %68 : tensor<1x8x128xf32>, tensor<1x8x1xf32>) outs(%72 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} {
    ^bb6(%74: f32, %75: f32, %76: f32):
      %77 = arith.mulf %74, %75 : f32
      linalg.yield %77 : f32
    } -> tensor<1x8x128xf32>
    %78 = tensor.empty() : tensor<1x8x128xf32>
    %79 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%73, %1 : tensor<1x8x128xf32>, tensor<128xf32>) outs(%78 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n1"} {
    ^bb7(%80: f32, %81: f32, %82: f32):
      %83 = arith.mulf %80, %81 : f32
      linalg.yield %83 : f32
    } -> tensor<1x8x128xf32>
    %84 = tensor.empty() : tensor<128x128xf32>
    %85 = linalg.transpose ins(%2:tensor<128x128xf32>) outs(%84:tensor<128x128xf32>) permutation = [1, 0]
    %86 = tensor.collapse_shape %79 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.q"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %87 = tensor.expand_shape %86 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.q"} : tensor<1024xf32> into tensor<8x128xf32>
    %88 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.q"} 0.000000e+00 : f32
    %89 = tensor.splat %88 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.q"} : tensor<8x128xf32>
    %90 = linalg.matmul {prov.region_id = "matmul_0", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.q", prov.transposed_b = "true"} ins(%87, %85 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%89 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %91 = tensor.collapse_shape %90 [[0 : i64, 1 : i64]] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.q"} : tensor<8x128xf32> into tensor<1024xf32>
    %92 = tensor.expand_shape %91 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.q"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %93 = tensor.collapse_shape %92 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_2", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %94 = tensor.expand_shape %93 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 32] {prov.region_id = "view_2", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<1x8x4x32xf32>
    %95 = tensor.empty() : tensor<1x4x8x32xf32>
    %96 = linalg.transpose ins(%94:tensor<1x8x4x32xf32>) outs(%95:tensor<1x4x8x32xf32>) permutation = [0, 2, 1, 3]
    %97 = tensor.empty() : tensor<128x128xf32>
    %98 = linalg.transpose ins(%3:tensor<128x128xf32>) outs(%97:tensor<128x128xf32>) permutation = [1, 0]
    %99 = tensor.collapse_shape %79 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_3", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.k"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %100 = tensor.expand_shape %99 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_3", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.k"} : tensor<1024xf32> into tensor<8x128xf32>
    %101 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.k"} 0.000000e+00 : f32
    %102 = tensor.splat %101 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.k"} : tensor<8x128xf32>
    %103 = linalg.matmul {prov.region_id = "matmul_1", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.k", prov.transposed_b = "true"} ins(%100, %98 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%102 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %104 = tensor.collapse_shape %103 [[0 : i64, 1 : i64]] {prov.region_id = "view_4", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.k"} : tensor<8x128xf32> into tensor<1024xf32>
    %105 = tensor.expand_shape %104 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_4", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.k"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %106 = tensor.collapse_shape %105 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_5", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %107 = tensor.expand_shape %106 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 32] {prov.region_id = "view_5", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<1x8x4x32xf32>
    %108 = tensor.empty() : tensor<1x4x8x32xf32>
    %109 = linalg.transpose ins(%107:tensor<1x8x4x32xf32>) outs(%108:tensor<1x4x8x32xf32>) permutation = [0, 2, 1, 3]
    %110 = tensor.empty() : tensor<128x128xf32>
    %111 = linalg.transpose ins(%4:tensor<128x128xf32>) outs(%110:tensor<128x128xf32>) permutation = [1, 0]
    %112 = tensor.collapse_shape %79 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_6", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.v"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %113 = tensor.expand_shape %112 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_6", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.v"} : tensor<1024xf32> into tensor<8x128xf32>
    %114 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.v"} 0.000000e+00 : f32
    %115 = tensor.splat %114 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.v"} : tensor<8x128xf32>
    %116 = linalg.matmul {prov.region_id = "matmul_2", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.v", prov.transposed_b = "true"} ins(%113, %111 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%115 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %117 = tensor.collapse_shape %116 [[0 : i64, 1 : i64]] {prov.region_id = "view_7", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.v"} : tensor<8x128xf32> into tensor<1024xf32>
    %118 = tensor.expand_shape %117 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_7", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.v"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %119 = tensor.collapse_shape %118 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_8", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %120 = tensor.expand_shape %119 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 32] {prov.region_id = "view_8", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<1x8x4x32xf32>
    %121 = tensor.empty() : tensor<1x4x8x32xf32>
    %122 = linalg.transpose ins(%120:tensor<1x8x4x32xf32>) outs(%121:tensor<1x4x8x32xf32>) permutation = [0, 2, 1, 3]
    %123 = arith.constant {prov.family = "iota", prov.source_evaluation = "torch.arange:cpu:f32", prov.source_runtime = "2.10.0+cu128", prov.source_cpu_capability = "AVX2", prov.source_num_threads = 24 : i64, prov.source_num_interop_threads = 24 : i64, prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} dense<[0.000000e+00, 1.000000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 5.000000e+00, 6.000000e+00, 7.000000e+00, 8.000000e+00, 9.000000e+00, 1.000000e+01, 1.100000e+01, 1.200000e+01, 1.300000e+01, 1.400000e+01, 1.500000e+01]> : tensor<16xf32>
    %124 = arith.constant {prov.region_id = "div_0", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 1.600000e+01 : f32
    %125 = tensor.splat %124 {prov.region_id = "div_0", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<16xf32>
    %126 = tensor.empty() : tensor<16xf32>
    %127 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%123, %125 : tensor<16xf32>, tensor<16xf32>) outs(%126 : tensor<16xf32>) attrs =  {prov.region_id = "div_0", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb8(%128: f32, %129: f32, %130: f32):
      %131 = arith.divf %128, %129 : f32
      linalg.yield %131 : f32
    } -> tensor<16xf32>
    %132 = tensor.empty() : tensor<16xf32>
    %133 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%127 : tensor<16xf32>) outs(%132 : tensor<16xf32>) attrs =  {prov.region_id = "pow_1", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb9(%134: f32, %135: f32):
      %136 = arith.constant 1.000000e+04 : f32
      %137 = math.powf %136, %134 : f32
      linalg.yield %137 : f32
    } -> tensor<16xf32>
    %138 = tensor.empty() : tensor<16xf32>
    %139 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%133 : tensor<16xf32>) outs(%138 : tensor<16xf32>) attrs =  {prov.region_id = "elementwise_0", prov.family = "elementwise", prov._pattern_hint = "elementwise", prov.op = "elementwise", prov.aten = "aten.reciprocal.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb10(%140: f32, %141: f32):
      %142 = arith.constant 1.000000e+00 : f32
      %143 = arith.divf %142, %140 : f32
      linalg.yield %143 : f32
    } -> tensor<16xf32>
    %144 = arith.constant {prov.region_id = "mul_2", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 1.000000e+00 : f32
    %145 = tensor.splat %144 {prov.region_id = "mul_2", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<16xf32>
    %146 = tensor.empty() : tensor<16xf32>
    %147 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%139, %145 : tensor<16xf32>, tensor<16xf32>) outs(%146 : tensor<16xf32>) attrs =  {prov.region_id = "mul_2", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb11(%148: f32, %149: f32, %150: f32):
      %151 = arith.mulf %148, %149 : f32
      linalg.yield %151 : f32
    } -> tensor<16xf32>
    %152 = tensor.expand_shape %23 [[0 : i64, 1 : i64]] output_shape [8, 1] {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8xi64> into tensor<8x1xi64>
    %153 = tensor.empty() : tensor<8x1xf32>
    %154 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%152 : tensor<8x1xi64>) outs(%153 : tensor<8x1xf32>) attrs =  {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb12(%155: i64, %156: f32):
      %157 = arith.sitofp %155 : i64 to f32
      linalg.yield %157 : f32
    } -> tensor<8x1xf32>
    %158 = tensor.expand_shape %147 [[0 : i64, 1 : i64]] output_shape [1, 16] {prov.region_id = "unsqueeze_1", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<16xf32> into tensor<1x16xf32>
    %159 = tensor.empty() : tensor<8x16xf32>
    %160 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%154, %158 : tensor<8x1xf32>, tensor<1x16xf32>) outs(%159 : tensor<8x16xf32>) attrs =  {prov.region_id = "mul_3", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb13(%161: f32, %162: f32, %163: f32):
      %164 = arith.mulf %161, %162 : f32
      linalg.yield %164 : f32
    } -> tensor<8x16xf32>
    %165 = tensor.empty() : tensor<8x16xf32>
    %166 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%160 : tensor<8x16xf32>) outs(%165 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_0", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb14(%167: f32, %168: f32):
      %169 = math.cos %167 : f32
      linalg.yield %169 : f32
    } -> tensor<8x16xf32>
    %170 = tensor.empty() : tensor<8x16xf32>
    %171 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%160 : tensor<8x16xf32>) outs(%170 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_1", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb15(%172: f32, %173: f32):
      %174 = math.cos %172 : f32
      linalg.yield %174 : f32
    } -> tensor<8x16xf32>
    %175 = tensor.concat dim(1) %166, %171 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %176 = tensor.collapse_shape %175 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_2", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %177 = tensor.expand_shape %176 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_2", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %178 = tensor.collapse_shape %177 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_3", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %179 = tensor.expand_shape %178 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_3", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %180 = tensor.empty() : tensor<8x16xf32>
    %181 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%160 : tensor<8x16xf32>) outs(%180 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_0", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb16(%182: f32, %183: f32):
      %184 = math.sin %182 : f32
      linalg.yield %184 : f32
    } -> tensor<8x16xf32>
    %185 = tensor.empty() : tensor<8x16xf32>
    %186 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%160 : tensor<8x16xf32>) outs(%185 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_1", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb17(%187: f32, %188: f32):
      %189 = math.sin %187 : f32
      linalg.yield %189 : f32
    } -> tensor<8x16xf32>
    %190 = tensor.concat dim(1) %181, %186 {prov.region_id = "cat_1", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %191 = tensor.collapse_shape %190 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_4", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %192 = tensor.expand_shape %191 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_4", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %193 = tensor.collapse_shape %192 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_5", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %194 = tensor.expand_shape %193 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_5", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %195 = "tensor.extract_slice"(%96) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_0", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %196 = "tensor.extract_slice"(%96) <{static_offsets = array<i64: 0, 0, 0, 16>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_1", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %197 = tensor.empty() : tensor<1x4x8x16xf32>
    %198 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%196 : tensor<1x4x8x16xf32>) outs(%197 : tensor<1x4x8x16xf32>) attrs =  {prov.region_id = "neg_0", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb18(%199: f32, %200: f32):
      %201 = arith.negf %199 : f32
      linalg.yield %201 : f32
    } -> tensor<1x4x8x16xf32>
    %202 = tensor.concat dim(3) %198, %195 {prov.region_id = "cat_2", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<1x4x8x16xf32>, tensor<1x4x8x16xf32>) -> tensor<1x4x8x32xf32>
    %203 = tensor.empty() : tensor<1x4x8x32xf32>
    %204 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%96, %179 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%203 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_4", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb19(%205: f32, %206: f32, %207: f32):
      %208 = arith.mulf %205, %206 : f32
      linalg.yield %208 : f32
    } -> tensor<1x4x8x32xf32>
    %209 = tensor.empty() : tensor<1x4x8x32xf32>
    %210 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%202, %194 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%209 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_5", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb20(%211: f32, %212: f32, %213: f32):
      %214 = arith.mulf %211, %212 : f32
      linalg.yield %214 : f32
    } -> tensor<1x4x8x32xf32>
    %215 = tensor.empty() : tensor<1x4x8x32xf32>
    %216 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%204, %210 : tensor<1x4x8x32xf32>, tensor<1x4x8x32xf32>) outs(%215 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb21(%217: f32, %218: f32, %219: f32):
      %220 = arith.addf %217, %218 : f32
      linalg.yield %220 : f32
    } -> tensor<1x4x8x32xf32>
    %221 = arith.constant {prov.family = "iota", prov.source_evaluation = "torch.arange:cpu:f32", prov.source_runtime = "2.10.0+cu128", prov.source_cpu_capability = "AVX2", prov.source_num_threads = 24 : i64, prov.source_num_interop_threads = 24 : i64, prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} dense<[0.000000e+00, 1.000000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 5.000000e+00, 6.000000e+00, 7.000000e+00, 8.000000e+00, 9.000000e+00, 1.000000e+01, 1.100000e+01, 1.200000e+01, 1.300000e+01, 1.400000e+01, 1.500000e+01]> : tensor<16xf32>
    %222 = arith.constant {prov.region_id = "div_1", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 1.600000e+01 : f32
    %223 = tensor.splat %222 {prov.region_id = "div_1", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<16xf32>
    %224 = tensor.empty() : tensor<16xf32>
    %225 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%221, %223 : tensor<16xf32>, tensor<16xf32>) outs(%224 : tensor<16xf32>) attrs =  {prov.region_id = "div_1", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb22(%226: f32, %227: f32, %228: f32):
      %229 = arith.divf %226, %227 : f32
      linalg.yield %229 : f32
    } -> tensor<16xf32>
    %230 = tensor.empty() : tensor<16xf32>
    %231 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%225 : tensor<16xf32>) outs(%230 : tensor<16xf32>) attrs =  {prov.region_id = "pow_2", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb23(%232: f32, %233: f32):
      %234 = arith.constant 1.000000e+04 : f32
      %235 = math.powf %234, %232 : f32
      linalg.yield %235 : f32
    } -> tensor<16xf32>
    %236 = tensor.empty() : tensor<16xf32>
    %237 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%231 : tensor<16xf32>) outs(%236 : tensor<16xf32>) attrs =  {prov.region_id = "elementwise_1", prov.family = "elementwise", prov._pattern_hint = "elementwise", prov.op = "elementwise", prov.aten = "aten.reciprocal.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb24(%238: f32, %239: f32):
      %240 = arith.constant 1.000000e+00 : f32
      %241 = arith.divf %240, %238 : f32
      linalg.yield %241 : f32
    } -> tensor<16xf32>
    %242 = arith.constant {prov.region_id = "mul_6", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 1.000000e+00 : f32
    %243 = tensor.splat %242 {prov.region_id = "mul_6", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<16xf32>
    %244 = tensor.empty() : tensor<16xf32>
    %245 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%237, %243 : tensor<16xf32>, tensor<16xf32>) outs(%244 : tensor<16xf32>) attrs =  {prov.region_id = "mul_6", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb25(%246: f32, %247: f32, %248: f32):
      %249 = arith.mulf %246, %247 : f32
      linalg.yield %249 : f32
    } -> tensor<16xf32>
    %250 = tensor.expand_shape %23 [[0 : i64, 1 : i64]] output_shape [8, 1] {prov.region_id = "unsqueeze_6", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8xi64> into tensor<8x1xi64>
    %251 = tensor.empty() : tensor<8x1xf32>
    %252 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%250 : tensor<8x1xi64>) outs(%251 : tensor<8x1xf32>) attrs =  {prov.region_id = "dtype_cast_1", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb26(%253: i64, %254: f32):
      %255 = arith.sitofp %253 : i64 to f32
      linalg.yield %255 : f32
    } -> tensor<8x1xf32>
    %256 = tensor.expand_shape %245 [[0 : i64, 1 : i64]] output_shape [1, 16] {prov.region_id = "unsqueeze_7", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<16xf32> into tensor<1x16xf32>
    %257 = tensor.empty() : tensor<8x16xf32>
    %258 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%252, %256 : tensor<8x1xf32>, tensor<1x16xf32>) outs(%257 : tensor<8x16xf32>) attrs =  {prov.region_id = "mul_7", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb27(%259: f32, %260: f32, %261: f32):
      %262 = arith.mulf %259, %260 : f32
      linalg.yield %262 : f32
    } -> tensor<8x16xf32>
    %263 = tensor.empty() : tensor<8x16xf32>
    %264 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%258 : tensor<8x16xf32>) outs(%263 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_2", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb28(%265: f32, %266: f32):
      %267 = math.cos %265 : f32
      linalg.yield %267 : f32
    } -> tensor<8x16xf32>
    %268 = tensor.empty() : tensor<8x16xf32>
    %269 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%258 : tensor<8x16xf32>) outs(%268 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_3", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb29(%270: f32, %271: f32):
      %272 = math.cos %270 : f32
      linalg.yield %272 : f32
    } -> tensor<8x16xf32>
    %273 = tensor.concat dim(1) %264, %269 {prov.region_id = "cat_3", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %274 = tensor.collapse_shape %273 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_8", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %275 = tensor.expand_shape %274 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_8", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %276 = tensor.collapse_shape %275 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_9", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %277 = tensor.expand_shape %276 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_9", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %278 = tensor.empty() : tensor<8x16xf32>
    %279 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%258 : tensor<8x16xf32>) outs(%278 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_2", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb30(%280: f32, %281: f32):
      %282 = math.sin %280 : f32
      linalg.yield %282 : f32
    } -> tensor<8x16xf32>
    %283 = tensor.empty() : tensor<8x16xf32>
    %284 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%258 : tensor<8x16xf32>) outs(%283 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_3", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb31(%285: f32, %286: f32):
      %287 = math.sin %285 : f32
      linalg.yield %287 : f32
    } -> tensor<8x16xf32>
    %288 = tensor.concat dim(1) %279, %284 {prov.region_id = "cat_4", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %289 = tensor.collapse_shape %288 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_10", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %290 = tensor.expand_shape %289 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_10", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %291 = tensor.collapse_shape %290 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_11", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %292 = tensor.expand_shape %291 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_11", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %293 = "tensor.extract_slice"(%109) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_2", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %294 = "tensor.extract_slice"(%109) <{static_offsets = array<i64: 0, 0, 0, 16>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_3", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %295 = tensor.empty() : tensor<1x4x8x16xf32>
    %296 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%294 : tensor<1x4x8x16xf32>) outs(%295 : tensor<1x4x8x16xf32>) attrs =  {prov.region_id = "neg_1", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb32(%297: f32, %298: f32):
      %299 = arith.negf %297 : f32
      linalg.yield %299 : f32
    } -> tensor<1x4x8x16xf32>
    %300 = tensor.concat dim(3) %296, %293 {prov.region_id = "cat_5", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : (tensor<1x4x8x16xf32>, tensor<1x4x8x16xf32>) -> tensor<1x4x8x32xf32>
    %301 = tensor.empty() : tensor<1x4x8x32xf32>
    %302 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%109, %277 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%301 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_8", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb33(%303: f32, %304: f32, %305: f32):
      %306 = arith.mulf %303, %304 : f32
      linalg.yield %306 : f32
    } -> tensor<1x4x8x32xf32>
    %307 = tensor.empty() : tensor<1x4x8x32xf32>
    %308 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%300, %292 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%307 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_9", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb34(%309: f32, %310: f32, %311: f32):
      %312 = arith.mulf %309, %310 : f32
      linalg.yield %312 : f32
    } -> tensor<1x4x8x32xf32>
    %313 = tensor.empty() : tensor<1x4x8x32xf32>
    %314 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%302, %308 : tensor<1x4x8x32xf32>, tensor<1x4x8x32xf32>) outs(%313 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb35(%315: f32, %316: f32, %317: f32):
      %318 = arith.addf %315, %316 : f32
      linalg.yield %318 : f32
    } -> tensor<1x4x8x32xf32>
    %319 = tensor.empty() : tensor<1x4x32x8xf32>
    %320 = linalg.transpose ins(%314:tensor<1x4x8x32xf32>) outs(%319:tensor<1x4x32x8xf32>) permutation = [0, 1, 3, 2]
    %321 = tensor.empty() : tensor<1x4x8x32xf32>
    %322 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%216 : tensor<1x4x8x32xf32>) outs(%321 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "expand_0", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb36(%323: f32, %324: f32):
      linalg.yield %323 : f32
    } -> tensor<1x4x8x32xf32>
    %325 = tensor.collapse_shape %322 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_9", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8x32xf32> into tensor<1024xf32>
    %326 = tensor.expand_shape %325 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 8, 32] {prov.region_id = "view_9", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<4x8x32xf32>
    %327 = tensor.empty() : tensor<1x4x32x8xf32>
    %328 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%320 : tensor<1x4x32x8xf32>) outs(%327 : tensor<1x4x32x8xf32>) attrs =  {prov.region_id = "expand_1", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb37(%329: f32, %330: f32):
      linalg.yield %329 : f32
    } -> tensor<1x4x32x8xf32>
    %331 = tensor.collapse_shape %328 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_10", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x32x8xf32> into tensor<1024xf32>
    %332 = tensor.expand_shape %331 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 32, 8] {prov.region_id = "view_10", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<4x32x8xf32>
    %333 = arith.constant {prov.region_id = "matmul_3", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 0.000000e+00 : f32
    %334 = tensor.splat %333 {prov.region_id = "matmul_3", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<4x8x8xf32>
    %335 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%326, %332 : tensor<4x8x32xf32>, tensor<4x32x8xf32>) outs(%334 : tensor<4x8x8xf32>) attrs =  {prov.region_id = "matmul_3", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb38(%336: f32, %337: f32, %338: f32):
      %339 = arith.mulf %336, %337 : f32
      %340 = arith.addf %338, %339 : f32
      linalg.yield %340 : f32
    } -> tensor<4x8x8xf32>
    %341 = tensor.collapse_shape %335 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_11", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<4x8x8xf32> into tensor<256xf32>
    %342 = tensor.expand_shape %341 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 8] {prov.region_id = "view_11", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<1x4x8x8xf32>
    %343 = arith.constant {prov.region_id = "div_2", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 5.65685415 : f32
    %344 = tensor.splat %343 {prov.region_id = "div_2", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8x8xf32>
    %345 = tensor.empty() : tensor<1x4x8x8xf32>
    %346 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%342, %344 : tensor<1x4x8x8xf32>, tensor<1x4x8x8xf32>) outs(%345 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "div_2", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb39(%347: f32, %348: f32, %349: f32):
      %350 = arith.divf %347, %348 : f32
      linalg.yield %350 : f32
    } -> tensor<1x4x8x8xf32>
    %351 = arith.constant {prov.region_id = "fill_0", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 0xff800000 : f32
    %352 = tensor.splat %351 {prov.region_id = "fill_0", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8x8xf32>
    %353 = tensor.empty() : tensor<8xi64>
    %354 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%353 : tensor<8xi64>) attrs =  {prov.region_id = "iota_1", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb40(%355: i64):
      %356 = linalg.index 0 : index
      %357 = arith.index_cast %356 : index to i64
      %358 = arith.constant 1 : i64
      %359 = arith.muli %357, %358 : i64
      %360 = arith.constant 0 : i64
      %361 = arith.addi %360, %359 : i64
      linalg.yield %361 : i64
    } -> tensor<8xi64>
    %362 = tensor.expand_shape %354 [[0 : i64, 1 : i64]] output_shape [1, 8] {prov.region_id = "unsqueeze_12", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8xi64> into tensor<1x8xi64>
    %363 = tensor.empty() : tensor<8xi64>
    %364 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%363 : tensor<8xi64>) attrs =  {prov.region_id = "iota_2", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb41(%365: i64):
      %366 = linalg.index 0 : index
      %367 = arith.index_cast %366 : index to i64
      %368 = arith.constant 1 : i64
      %369 = arith.muli %367, %368 : i64
      %370 = arith.constant 0 : i64
      %371 = arith.addi %370, %369 : i64
      linalg.yield %371 : i64
    } -> tensor<8xi64>
    %372 = tensor.expand_shape %364 [[0 : i64, 1 : i64]] output_shape [8, 1] {prov.region_id = "unsqueeze_13", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8xi64> into tensor<8x1xi64>
    %373 = tensor.empty() : tensor<8x8xi64>
    %374 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%362, %372 : tensor<1x8xi64>, tensor<8x1xi64>) outs(%373 : tensor<8x8xi64>) attrs =  {prov.region_id = "sub_0", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb42(%375: i64, %376: i64, %377: i64):
      %378 = arith.subi %375, %376 : i64
      linalg.yield %378 : i64
    } -> tensor<8x8xi64>
    %379 = arith.constant {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ge.Scalar", prov.orig_dtype = "bool", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 1 : i64
    %380 = tensor.splat %379 {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ge.Scalar", prov.orig_dtype = "bool", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<8x8xi64>
    %381 = tensor.empty() : tensor<8x8xi1>
    %382 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%374, %380 : tensor<8x8xi64>, tensor<8x8xi64>) outs(%381 : tensor<8x8xi1>) attrs =  {prov.region_id = "compare_0", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.ge.Scalar", prov.orig_dtype = "bool", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb43(%383: i64, %384: i64, %385: i1):
      %386 = arith.cmpi sge, %383, %384 : i64
      linalg.yield %386 : i1
    } -> tensor<8x8xi1>
    %387 = arith.constant {prov.region_id = "fill_1", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 0.000000e+00 : f32
    %388 = tensor.splat %387 {prov.region_id = "fill_1", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<f32>
    %389 = tensor.empty() : tensor<8x8xf32>
    %390 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> ()>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%382, %352, %388 : tensor<8x8xi1>, tensor<8x8xf32>, tensor<f32>) outs(%389 : tensor<8x8xf32>) attrs =  {prov.region_id = "select_0", prov.family = "layout", prov._pattern_hint = "select", prov.op = "select", prov.aten = "aten.where.self", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb44(%391: i1, %392: f32, %393: f32, %394: f32):
      %395 = arith.select %391, %392, %393 : f32
      linalg.yield %395 : f32
    } -> tensor<8x8xf32>
    %396 = tensor.empty() : tensor<1x4x8x8xf32>
    %397 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%346, %390 : tensor<1x4x8x8xf32>, tensor<8x8xf32>) outs(%396 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "add_3", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb45(%398: f32, %399: f32, %400: f32):
      %401 = arith.addf %398, %399 : f32
      linalg.yield %401 : f32
    } -> tensor<1x4x8x8xf32>
    %402 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 0xff800000 : f32
    %403 = tensor.splat %402 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8xf32>
    %404 = linalg.reduce ins(%397:tensor<1x4x8x8xf32>) outs(%403:tensor<1x4x8xf32>) dimensions = [3]
    (%405: f32, %406: f32) {
      %407 = arith.maximumf %405, %406 : f32
      linalg.yield %407 : f32
    }
    %408 = tensor.collapse_shape %404 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8xf32> into tensor<32xf32>
    %409 = tensor.expand_shape %408 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<32xf32> into tensor<1x4x8x1xf32>
    %410 = tensor.empty() : tensor<1x4x8x8xf32>
    %411 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%397, %409 : tensor<1x4x8x8xf32>, tensor<1x4x8x1xf32>) outs(%410 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb46(%412: f32, %413: f32, %414: f32):
      %415 = arith.subf %412, %413 : f32
      linalg.yield %415 : f32
    } -> tensor<1x4x8x8xf32>
    %416 = tensor.empty() : tensor<1x4x8x8xf32>
    %417 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%411 : tensor<1x4x8x8xf32>) outs(%416 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb47(%418: f32, %419: f32):
      %420 = math.exp %418 : f32
      linalg.yield %420 : f32
    } -> tensor<1x4x8x8xf32>
    %421 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 0.000000e+00 : f32
    %422 = tensor.splat %421 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8xf32>
    %423 = linalg.reduce ins(%417:tensor<1x4x8x8xf32>) outs(%422:tensor<1x4x8xf32>) dimensions = [3]
    (%424: f32, %425: f32) {
      %426 = arith.addf %424, %425 : f32
      linalg.yield %426 : f32
    }
    %427 = tensor.collapse_shape %423 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8xf32> into tensor<32xf32>
    %428 = tensor.expand_shape %427 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<32xf32> into tensor<1x4x8x1xf32>
    %429 = tensor.empty() : tensor<1x4x8x8xf32>
    %430 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%417, %428 : tensor<1x4x8x8xf32>, tensor<1x4x8x1xf32>) outs(%429 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb48(%431: f32, %432: f32, %433: f32):
      %434 = arith.divf %431, %432 : f32
      linalg.yield %434 : f32
    } -> tensor<1x4x8x8xf32>
    %435 = tensor.empty() : tensor<1x4x8x8xf32>
    %436 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%430 : tensor<1x4x8x8xf32>) outs(%435 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "expand_2", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb49(%437: f32, %438: f32):
      linalg.yield %437 : f32
    } -> tensor<1x4x8x8xf32>
    %439 = tensor.collapse_shape %436 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_12", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8x8xf32> into tensor<256xf32>
    %440 = tensor.expand_shape %439 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 8, 8] {prov.region_id = "view_12", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<256xf32> into tensor<4x8x8xf32>
    %441 = tensor.empty() : tensor<1x4x8x32xf32>
    %442 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%122 : tensor<1x4x8x32xf32>) outs(%441 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "expand_3", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb50(%443: f32, %444: f32):
      linalg.yield %443 : f32
    } -> tensor<1x4x8x32xf32>
    %445 = tensor.collapse_shape %442 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_13", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x4x8x32xf32> into tensor<1024xf32>
    %446 = tensor.expand_shape %445 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 8, 32] {prov.region_id = "view_13", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<4x8x32xf32>
    %447 = arith.constant {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} 0.000000e+00 : f32
    %448 = tensor.splat %447 {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<4x8x32xf32>
    %449 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%440, %446 : tensor<4x8x8xf32>, tensor<4x8x32xf32>) outs(%448 : tensor<4x8x32xf32>) attrs =  {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} {
    ^bb51(%450: f32, %451: f32, %452: f32):
      %453 = arith.mulf %450, %451 : f32
      %454 = arith.addf %452, %453 : f32
      linalg.yield %454 : f32
    } -> tensor<4x8x32xf32>
    %455 = tensor.collapse_shape %449 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_14", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<4x8x32xf32> into tensor<1024xf32>
    %456 = tensor.expand_shape %455 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 32] {prov.region_id = "view_14", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<1x4x8x32xf32>
    %457 = tensor.empty() : tensor<1x8x4x32xf32>
    %458 = linalg.transpose ins(%456:tensor<1x4x8x32xf32>) outs(%457:tensor<1x8x4x32xf32>) permutation = [0, 2, 1, 3]
    %459 = tensor.collapse_shape %458 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_15", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1x8x4x32xf32> into tensor<1024xf32>
    %460 = tensor.expand_shape %459 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_15", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %461 = tensor.empty() : tensor<128x128xf32>
    %462 = linalg.transpose ins(%5:tensor<128x128xf32>) outs(%461:tensor<128x128xf32>) permutation = [1, 0]
    %463 = tensor.collapse_shape %460 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_16", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.o"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %464 = tensor.expand_shape %463 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_16", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.o"} : tensor<1024xf32> into tensor<8x128xf32>
    %465 = arith.constant {prov.region_id = "matmul_5", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.o"} 0.000000e+00 : f32
    %466 = tensor.splat %465 {prov.region_id = "matmul_5", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.o"} : tensor<8x128xf32>
    %467 = linalg.matmul {prov.region_id = "matmul_5", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.o", prov.transposed_b = "true"} ins(%464, %462 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%466 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %468 = tensor.collapse_shape %467 [[0 : i64, 1 : i64]] {prov.region_id = "view_17", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.o"} : tensor<8x128xf32> into tensor<1024xf32>
    %469 = tensor.expand_shape %468 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_17", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.attn.o"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %470 = tensor.empty() : tensor<1x8x128xf32>
    %471 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%32, %469 : tensor<1x8x128xf32>, tensor<1x8x128xf32>) outs(%470 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "add_4", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0"} {
    ^bb52(%472: f32, %473: f32, %474: f32):
      %475 = arith.addf %472, %473 : f32
      linalg.yield %475 : f32
    } -> tensor<1x8x128xf32>
    %476 = tensor.empty() : tensor<1x8x128xf32>
    %477 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%471 : tensor<1x8x128xf32>) outs(%476 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "pow_3", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} {
    ^bb53(%478: f32, %479: f32):
      %480 = arith.mulf %478, %478 : f32
      linalg.yield %480 : f32
    } -> tensor<1x8x128xf32>
    %481 = arith.constant {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} 0.000000e+00 : f32
    %482 = tensor.splat %481 {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} : tensor<1x8xf32>
    %483 = linalg.reduce ins(%477:tensor<1x8x128xf32>) outs(%482:tensor<1x8xf32>) dimensions = [2]
    (%484: f32, %485: f32) {
      %486 = arith.addf %484, %485 : f32
      linalg.yield %486 : f32
    }
    %487 = arith.constant {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} 1.280000e+02 : f32
    %488 = tensor.splat %487 {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} : tensor<1x8xf32>
    %489 = tensor.empty() : tensor<1x8xf32>
    %490 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%483, %488 : tensor<1x8xf32>, tensor<1x8xf32>) outs(%489 : tensor<1x8xf32>) attrs =  {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} {
    ^bb54(%491: f32, %492: f32, %493: f32):
      %494 = arith.divf %491, %492 : f32
      linalg.yield %494 : f32
    } -> tensor<1x8xf32>
    %495 = tensor.collapse_shape %490 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} : tensor<1x8xf32> into tensor<8xf32>
    %496 = tensor.expand_shape %495 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 1] {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} : tensor<8xf32> into tensor<1x8x1xf32>
    %497 = arith.constant {prov.region_id = "add_5", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} 1.000000e-05 : f32
    %498 = tensor.splat %497 {prov.region_id = "add_5", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} : tensor<1x8x1xf32>
    %499 = tensor.empty() : tensor<1x8x1xf32>
    %500 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%496, %498 : tensor<1x8x1xf32>, tensor<1x8x1xf32>) outs(%499 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "add_5", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} {
    ^bb55(%501: f32, %502: f32, %503: f32):
      %504 = arith.addf %501, %502 : f32
      linalg.yield %504 : f32
    } -> tensor<1x8x1xf32>
    %505 = tensor.empty() : tensor<1x8x1xf32>
    %506 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%500 : tensor<1x8x1xf32>) outs(%505 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "rsqrt_1", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} {
    ^bb56(%507: f32, %508: f32):
      %509 = math.rsqrt %507 : f32
      linalg.yield %509 : f32
    } -> tensor<1x8x1xf32>
    %510 = tensor.empty() : tensor<1x8x128xf32>
    %511 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%471, %506 : tensor<1x8x128xf32>, tensor<1x8x1xf32>) outs(%510 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_10", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} {
    ^bb57(%512: f32, %513: f32, %514: f32):
      %515 = arith.mulf %512, %513 : f32
      linalg.yield %515 : f32
    } -> tensor<1x8x128xf32>
    %516 = tensor.empty() : tensor<1x8x128xf32>
    %517 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%511, %6 : tensor<1x8x128xf32>, tensor<128xf32>) outs(%516 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_11", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.n2"} {
    ^bb58(%518: f32, %519: f32, %520: f32):
      %521 = arith.mulf %518, %519 : f32
      linalg.yield %521 : f32
    } -> tensor<1x8x128xf32>
    %522 = tensor.empty() : tensor<128x344xf32>
    %523 = linalg.transpose ins(%7:tensor<344x128xf32>) outs(%522:tensor<128x344xf32>) permutation = [1, 0]
    %524 = tensor.collapse_shape %517 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_18", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.g"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %525 = tensor.expand_shape %524 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_18", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.g"} : tensor<1024xf32> into tensor<8x128xf32>
    %526 = arith.constant {prov.region_id = "matmul_6", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.g"} 0.000000e+00 : f32
    %527 = tensor.splat %526 {prov.region_id = "matmul_6", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.g"} : tensor<8x344xf32>
    %528 = linalg.matmul {prov.region_id = "matmul_6", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.g", prov.transposed_b = "true"} ins(%525, %523 : tensor<8x128xf32>, tensor<128x344xf32>) outs(%527 : tensor<8x344xf32>) -> tensor<8x344xf32>
    %529 = tensor.collapse_shape %528 [[0 : i64, 1 : i64]] {prov.region_id = "view_19", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.g"} : tensor<8x344xf32> into tensor<2752xf32>
    %530 = tensor.expand_shape %529 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 344] {prov.region_id = "view_19", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.g"} : tensor<2752xf32> into tensor<1x8x344xf32>
    %531 = tensor.empty() : tensor<1x8x344xf32>
    %532 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%530 : tensor<1x8x344xf32>) outs(%531 : tensor<1x8x344xf32>) attrs =  {prov.region_id = "sigmoid_0", prov._pattern_hint = "sigmoid", prov.op = "sigmoid", prov.family = "elementwise", prov.aten = "aten.sigmoid.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp"} {
    ^bb59(%533: f32, %534: f32):
      %535 = arith.constant 1.000000e+00 : f32
      %536 = arith.negf %533 : f32
      %537 = math.exp %536 : f32
      %538 = arith.addf %535, %537 : f32
      %539 = arith.divf %535, %538 : f32
      linalg.yield %539 : f32
    } -> tensor<1x8x344xf32>
    %540 = tensor.empty() : tensor<1x8x344xf32>
    %541 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%530, %532 : tensor<1x8x344xf32>, tensor<1x8x344xf32>) outs(%540 : tensor<1x8x344xf32>) attrs =  {prov.region_id = "mul_12", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp"} {
    ^bb60(%542: f32, %543: f32, %544: f32):
      %545 = arith.mulf %542, %543 : f32
      linalg.yield %545 : f32
    } -> tensor<1x8x344xf32>
    %546 = tensor.empty() : tensor<128x344xf32>
    %547 = linalg.transpose ins(%8:tensor<344x128xf32>) outs(%546:tensor<128x344xf32>) permutation = [1, 0]
    %548 = tensor.collapse_shape %517 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_20", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.u"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %549 = tensor.expand_shape %548 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_20", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.u"} : tensor<1024xf32> into tensor<8x128xf32>
    %550 = arith.constant {prov.region_id = "matmul_7", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.u"} 0.000000e+00 : f32
    %551 = tensor.splat %550 {prov.region_id = "matmul_7", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.u"} : tensor<8x344xf32>
    %552 = linalg.matmul {prov.region_id = "matmul_7", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.u", prov.transposed_b = "true"} ins(%549, %547 : tensor<8x128xf32>, tensor<128x344xf32>) outs(%551 : tensor<8x344xf32>) -> tensor<8x344xf32>
    %553 = tensor.collapse_shape %552 [[0 : i64, 1 : i64]] {prov.region_id = "view_21", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.u"} : tensor<8x344xf32> into tensor<2752xf32>
    %554 = tensor.expand_shape %553 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 344] {prov.region_id = "view_21", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.u"} : tensor<2752xf32> into tensor<1x8x344xf32>
    %555 = tensor.empty() : tensor<1x8x344xf32>
    %556 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%541, %554 : tensor<1x8x344xf32>, tensor<1x8x344xf32>) outs(%555 : tensor<1x8x344xf32>) attrs =  {prov.region_id = "mul_13", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp"} {
    ^bb61(%557: f32, %558: f32, %559: f32):
      %560 = arith.mulf %557, %558 : f32
      linalg.yield %560 : f32
    } -> tensor<1x8x344xf32>
    %561 = tensor.empty() : tensor<344x128xf32>
    %562 = linalg.transpose ins(%9:tensor<128x344xf32>) outs(%561:tensor<344x128xf32>) permutation = [1, 0]
    %563 = tensor.collapse_shape %556 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_22", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.dn"} : tensor<1x8x344xf32> into tensor<2752xf32>
    %564 = tensor.expand_shape %563 [[0 : i64, 1 : i64]] output_shape [8, 344] {prov.region_id = "view_22", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.dn"} : tensor<2752xf32> into tensor<8x344xf32>
    %565 = arith.constant {prov.region_id = "matmul_8", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.dn"} 0.000000e+00 : f32
    %566 = tensor.splat %565 {prov.region_id = "matmul_8", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.dn"} : tensor<8x128xf32>
    %567 = linalg.matmul {prov.region_id = "matmul_8", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.dn", prov.transposed_b = "true"} ins(%564, %562 : tensor<8x344xf32>, tensor<344x128xf32>) outs(%566 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %568 = tensor.collapse_shape %567 [[0 : i64, 1 : i64]] {prov.region_id = "view_23", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.dn"} : tensor<8x128xf32> into tensor<1024xf32>
    %569 = tensor.expand_shape %568 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_23", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0.mlp.dn"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %570 = tensor.empty() : tensor<1x8x128xf32>
    %571 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%471, %569 : tensor<1x8x128xf32>, tensor<1x8x128xf32>) outs(%570 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "add_6", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.0"} {
    ^bb62(%572: f32, %573: f32, %574: f32):
      %575 = arith.addf %572, %573 : f32
      linalg.yield %575 : f32
    } -> tensor<1x8x128xf32>
    %576 = tensor.empty() : tensor<1x8x128xf32>
    %577 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%571 : tensor<1x8x128xf32>) outs(%576 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "pow_4", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} {
    ^bb63(%578: f32, %579: f32):
      %580 = arith.mulf %578, %578 : f32
      linalg.yield %580 : f32
    } -> tensor<1x8x128xf32>
    %581 = arith.constant {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} 0.000000e+00 : f32
    %582 = tensor.splat %581 {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} : tensor<1x8xf32>
    %583 = linalg.reduce ins(%577:tensor<1x8x128xf32>) outs(%582:tensor<1x8xf32>) dimensions = [2]
    (%584: f32, %585: f32) {
      %586 = arith.addf %584, %585 : f32
      linalg.yield %586 : f32
    }
    %587 = arith.constant {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} 1.280000e+02 : f32
    %588 = tensor.splat %587 {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} : tensor<1x8xf32>
    %589 = tensor.empty() : tensor<1x8xf32>
    %590 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%583, %588 : tensor<1x8xf32>, tensor<1x8xf32>) outs(%589 : tensor<1x8xf32>) attrs =  {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} {
    ^bb64(%591: f32, %592: f32, %593: f32):
      %594 = arith.divf %591, %592 : f32
      linalg.yield %594 : f32
    } -> tensor<1x8xf32>
    %595 = tensor.collapse_shape %590 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} : tensor<1x8xf32> into tensor<8xf32>
    %596 = tensor.expand_shape %595 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 1] {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} : tensor<8xf32> into tensor<1x8x1xf32>
    %597 = arith.constant {prov.region_id = "add_7", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} 1.000000e-05 : f32
    %598 = tensor.splat %597 {prov.region_id = "add_7", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} : tensor<1x8x1xf32>
    %599 = tensor.empty() : tensor<1x8x1xf32>
    %600 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%596, %598 : tensor<1x8x1xf32>, tensor<1x8x1xf32>) outs(%599 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "add_7", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} {
    ^bb65(%601: f32, %602: f32, %603: f32):
      %604 = arith.addf %601, %602 : f32
      linalg.yield %604 : f32
    } -> tensor<1x8x1xf32>
    %605 = tensor.empty() : tensor<1x8x1xf32>
    %606 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%600 : tensor<1x8x1xf32>) outs(%605 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "rsqrt_2", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} {
    ^bb66(%607: f32, %608: f32):
      %609 = math.rsqrt %607 : f32
      linalg.yield %609 : f32
    } -> tensor<1x8x1xf32>
    %610 = tensor.empty() : tensor<1x8x128xf32>
    %611 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%571, %606 : tensor<1x8x128xf32>, tensor<1x8x1xf32>) outs(%610 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_14", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} {
    ^bb67(%612: f32, %613: f32, %614: f32):
      %615 = arith.mulf %612, %613 : f32
      linalg.yield %615 : f32
    } -> tensor<1x8x128xf32>
    %616 = tensor.empty() : tensor<1x8x128xf32>
    %617 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%611, %10 : tensor<1x8x128xf32>, tensor<128xf32>) outs(%616 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_15", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n1"} {
    ^bb68(%618: f32, %619: f32, %620: f32):
      %621 = arith.mulf %618, %619 : f32
      linalg.yield %621 : f32
    } -> tensor<1x8x128xf32>
    %622 = tensor.empty() : tensor<128x128xf32>
    %623 = linalg.transpose ins(%11:tensor<128x128xf32>) outs(%622:tensor<128x128xf32>) permutation = [1, 0]
    %624 = tensor.collapse_shape %617 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_24", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.q"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %625 = tensor.expand_shape %624 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_24", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.q"} : tensor<1024xf32> into tensor<8x128xf32>
    %626 = arith.constant {prov.region_id = "matmul_9", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.q"} 0.000000e+00 : f32
    %627 = tensor.splat %626 {prov.region_id = "matmul_9", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.q"} : tensor<8x128xf32>
    %628 = linalg.matmul {prov.region_id = "matmul_9", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.q", prov.transposed_b = "true"} ins(%625, %623 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%627 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %629 = tensor.collapse_shape %628 [[0 : i64, 1 : i64]] {prov.region_id = "view_25", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.q"} : tensor<8x128xf32> into tensor<1024xf32>
    %630 = tensor.expand_shape %629 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_25", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.q"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %631 = tensor.collapse_shape %630 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_26", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %632 = tensor.expand_shape %631 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 32] {prov.region_id = "view_26", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<1x8x4x32xf32>
    %633 = tensor.empty() : tensor<1x4x8x32xf32>
    %634 = linalg.transpose ins(%632:tensor<1x8x4x32xf32>) outs(%633:tensor<1x4x8x32xf32>) permutation = [0, 2, 1, 3]
    %635 = tensor.empty() : tensor<128x128xf32>
    %636 = linalg.transpose ins(%12:tensor<128x128xf32>) outs(%635:tensor<128x128xf32>) permutation = [1, 0]
    %637 = tensor.collapse_shape %617 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_27", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.k"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %638 = tensor.expand_shape %637 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_27", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.k"} : tensor<1024xf32> into tensor<8x128xf32>
    %639 = arith.constant {prov.region_id = "matmul_10", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.k"} 0.000000e+00 : f32
    %640 = tensor.splat %639 {prov.region_id = "matmul_10", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.k"} : tensor<8x128xf32>
    %641 = linalg.matmul {prov.region_id = "matmul_10", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.k", prov.transposed_b = "true"} ins(%638, %636 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%640 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %642 = tensor.collapse_shape %641 [[0 : i64, 1 : i64]] {prov.region_id = "view_28", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.k"} : tensor<8x128xf32> into tensor<1024xf32>
    %643 = tensor.expand_shape %642 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_28", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.k"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %644 = tensor.collapse_shape %643 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_29", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %645 = tensor.expand_shape %644 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 32] {prov.region_id = "view_29", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<1x8x4x32xf32>
    %646 = tensor.empty() : tensor<1x4x8x32xf32>
    %647 = linalg.transpose ins(%645:tensor<1x8x4x32xf32>) outs(%646:tensor<1x4x8x32xf32>) permutation = [0, 2, 1, 3]
    %648 = tensor.empty() : tensor<128x128xf32>
    %649 = linalg.transpose ins(%13:tensor<128x128xf32>) outs(%648:tensor<128x128xf32>) permutation = [1, 0]
    %650 = tensor.collapse_shape %617 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_30", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.v"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %651 = tensor.expand_shape %650 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_30", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.v"} : tensor<1024xf32> into tensor<8x128xf32>
    %652 = arith.constant {prov.region_id = "matmul_11", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.v"} 0.000000e+00 : f32
    %653 = tensor.splat %652 {prov.region_id = "matmul_11", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.v"} : tensor<8x128xf32>
    %654 = linalg.matmul {prov.region_id = "matmul_11", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.v", prov.transposed_b = "true"} ins(%651, %649 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%653 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %655 = tensor.collapse_shape %654 [[0 : i64, 1 : i64]] {prov.region_id = "view_31", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.v"} : tensor<8x128xf32> into tensor<1024xf32>
    %656 = tensor.expand_shape %655 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_31", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.v"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %657 = tensor.collapse_shape %656 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_32", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %658 = tensor.expand_shape %657 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 32] {prov.region_id = "view_32", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<1x8x4x32xf32>
    %659 = tensor.empty() : tensor<1x4x8x32xf32>
    %660 = linalg.transpose ins(%658:tensor<1x8x4x32xf32>) outs(%659:tensor<1x4x8x32xf32>) permutation = [0, 2, 1, 3]
    %661 = arith.constant {prov.family = "iota", prov.source_evaluation = "torch.arange:cpu:f32", prov.source_runtime = "2.10.0+cu128", prov.source_cpu_capability = "AVX2", prov.source_num_threads = 24 : i64, prov.source_num_interop_threads = 24 : i64, prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} dense<[0.000000e+00, 1.000000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 5.000000e+00, 6.000000e+00, 7.000000e+00, 8.000000e+00, 9.000000e+00, 1.000000e+01, 1.100000e+01, 1.200000e+01, 1.300000e+01, 1.400000e+01, 1.500000e+01]> : tensor<16xf32>
    %662 = arith.constant {prov.region_id = "div_3", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 1.600000e+01 : f32
    %663 = tensor.splat %662 {prov.region_id = "div_3", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<16xf32>
    %664 = tensor.empty() : tensor<16xf32>
    %665 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%661, %663 : tensor<16xf32>, tensor<16xf32>) outs(%664 : tensor<16xf32>) attrs =  {prov.region_id = "div_3", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb69(%666: f32, %667: f32, %668: f32):
      %669 = arith.divf %666, %667 : f32
      linalg.yield %669 : f32
    } -> tensor<16xf32>
    %670 = tensor.empty() : tensor<16xf32>
    %671 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%665 : tensor<16xf32>) outs(%670 : tensor<16xf32>) attrs =  {prov.region_id = "pow_5", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb70(%672: f32, %673: f32):
      %674 = arith.constant 1.000000e+04 : f32
      %675 = math.powf %674, %672 : f32
      linalg.yield %675 : f32
    } -> tensor<16xf32>
    %676 = tensor.empty() : tensor<16xf32>
    %677 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%671 : tensor<16xf32>) outs(%676 : tensor<16xf32>) attrs =  {prov.region_id = "elementwise_2", prov.family = "elementwise", prov._pattern_hint = "elementwise", prov.op = "elementwise", prov.aten = "aten.reciprocal.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb71(%678: f32, %679: f32):
      %680 = arith.constant 1.000000e+00 : f32
      %681 = arith.divf %680, %678 : f32
      linalg.yield %681 : f32
    } -> tensor<16xf32>
    %682 = arith.constant {prov.region_id = "mul_16", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 1.000000e+00 : f32
    %683 = tensor.splat %682 {prov.region_id = "mul_16", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<16xf32>
    %684 = tensor.empty() : tensor<16xf32>
    %685 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%677, %683 : tensor<16xf32>, tensor<16xf32>) outs(%684 : tensor<16xf32>) attrs =  {prov.region_id = "mul_16", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb72(%686: f32, %687: f32, %688: f32):
      %689 = arith.mulf %686, %687 : f32
      linalg.yield %689 : f32
    } -> tensor<16xf32>
    %690 = tensor.expand_shape %23 [[0 : i64, 1 : i64]] output_shape [8, 1] {prov.region_id = "unsqueeze_14", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8xi64> into tensor<8x1xi64>
    %691 = tensor.empty() : tensor<8x1xf32>
    %692 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%690 : tensor<8x1xi64>) outs(%691 : tensor<8x1xf32>) attrs =  {prov.region_id = "dtype_cast_2", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb73(%693: i64, %694: f32):
      %695 = arith.sitofp %693 : i64 to f32
      linalg.yield %695 : f32
    } -> tensor<8x1xf32>
    %696 = tensor.expand_shape %685 [[0 : i64, 1 : i64]] output_shape [1, 16] {prov.region_id = "unsqueeze_15", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<16xf32> into tensor<1x16xf32>
    %697 = tensor.empty() : tensor<8x16xf32>
    %698 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%692, %696 : tensor<8x1xf32>, tensor<1x16xf32>) outs(%697 : tensor<8x16xf32>) attrs =  {prov.region_id = "mul_17", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb74(%699: f32, %700: f32, %701: f32):
      %702 = arith.mulf %699, %700 : f32
      linalg.yield %702 : f32
    } -> tensor<8x16xf32>
    %703 = tensor.empty() : tensor<8x16xf32>
    %704 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%698 : tensor<8x16xf32>) outs(%703 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_4", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb75(%705: f32, %706: f32):
      %707 = math.cos %705 : f32
      linalg.yield %707 : f32
    } -> tensor<8x16xf32>
    %708 = tensor.empty() : tensor<8x16xf32>
    %709 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%698 : tensor<8x16xf32>) outs(%708 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_5", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb76(%710: f32, %711: f32):
      %712 = math.cos %710 : f32
      linalg.yield %712 : f32
    } -> tensor<8x16xf32>
    %713 = tensor.concat dim(1) %704, %709 {prov.region_id = "cat_6", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %714 = tensor.collapse_shape %713 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_16", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %715 = tensor.expand_shape %714 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_16", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %716 = tensor.collapse_shape %715 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_17", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %717 = tensor.expand_shape %716 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_17", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %718 = tensor.empty() : tensor<8x16xf32>
    %719 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%698 : tensor<8x16xf32>) outs(%718 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_4", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb77(%720: f32, %721: f32):
      %722 = math.sin %720 : f32
      linalg.yield %722 : f32
    } -> tensor<8x16xf32>
    %723 = tensor.empty() : tensor<8x16xf32>
    %724 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%698 : tensor<8x16xf32>) outs(%723 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_5", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb78(%725: f32, %726: f32):
      %727 = math.sin %725 : f32
      linalg.yield %727 : f32
    } -> tensor<8x16xf32>
    %728 = tensor.concat dim(1) %719, %724 {prov.region_id = "cat_7", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %729 = tensor.collapse_shape %728 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_18", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %730 = tensor.expand_shape %729 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_18", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %731 = tensor.collapse_shape %730 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_19", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %732 = tensor.expand_shape %731 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_19", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %733 = "tensor.extract_slice"(%634) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_4", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %734 = "tensor.extract_slice"(%634) <{static_offsets = array<i64: 0, 0, 0, 16>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_5", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %735 = tensor.empty() : tensor<1x4x8x16xf32>
    %736 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%734 : tensor<1x4x8x16xf32>) outs(%735 : tensor<1x4x8x16xf32>) attrs =  {prov.region_id = "neg_2", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb79(%737: f32, %738: f32):
      %739 = arith.negf %737 : f32
      linalg.yield %739 : f32
    } -> tensor<1x4x8x16xf32>
    %740 = tensor.concat dim(3) %736, %733 {prov.region_id = "cat_8", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<1x4x8x16xf32>, tensor<1x4x8x16xf32>) -> tensor<1x4x8x32xf32>
    %741 = tensor.empty() : tensor<1x4x8x32xf32>
    %742 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%634, %717 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%741 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_18", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb80(%743: f32, %744: f32, %745: f32):
      %746 = arith.mulf %743, %744 : f32
      linalg.yield %746 : f32
    } -> tensor<1x4x8x32xf32>
    %747 = tensor.empty() : tensor<1x4x8x32xf32>
    %748 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%740, %732 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%747 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_19", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb81(%749: f32, %750: f32, %751: f32):
      %752 = arith.mulf %749, %750 : f32
      linalg.yield %752 : f32
    } -> tensor<1x4x8x32xf32>
    %753 = tensor.empty() : tensor<1x4x8x32xf32>
    %754 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%742, %748 : tensor<1x4x8x32xf32>, tensor<1x4x8x32xf32>) outs(%753 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "add_8", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb82(%755: f32, %756: f32, %757: f32):
      %758 = arith.addf %755, %756 : f32
      linalg.yield %758 : f32
    } -> tensor<1x4x8x32xf32>
    %759 = arith.constant {prov.family = "iota", prov.source_evaluation = "torch.arange:cpu:f32", prov.source_runtime = "2.10.0+cu128", prov.source_cpu_capability = "AVX2", prov.source_num_threads = 24 : i64, prov.source_num_interop_threads = 24 : i64, prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} dense<[0.000000e+00, 1.000000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 5.000000e+00, 6.000000e+00, 7.000000e+00, 8.000000e+00, 9.000000e+00, 1.000000e+01, 1.100000e+01, 1.200000e+01, 1.300000e+01, 1.400000e+01, 1.500000e+01]> : tensor<16xf32>
    %760 = arith.constant {prov.region_id = "div_4", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 1.600000e+01 : f32
    %761 = tensor.splat %760 {prov.region_id = "div_4", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<16xf32>
    %762 = tensor.empty() : tensor<16xf32>
    %763 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%759, %761 : tensor<16xf32>, tensor<16xf32>) outs(%762 : tensor<16xf32>) attrs =  {prov.region_id = "div_4", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb83(%764: f32, %765: f32, %766: f32):
      %767 = arith.divf %764, %765 : f32
      linalg.yield %767 : f32
    } -> tensor<16xf32>
    %768 = tensor.empty() : tensor<16xf32>
    %769 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%763 : tensor<16xf32>) outs(%768 : tensor<16xf32>) attrs =  {prov.region_id = "pow_6", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb84(%770: f32, %771: f32):
      %772 = arith.constant 1.000000e+04 : f32
      %773 = math.powf %772, %770 : f32
      linalg.yield %773 : f32
    } -> tensor<16xf32>
    %774 = tensor.empty() : tensor<16xf32>
    %775 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%769 : tensor<16xf32>) outs(%774 : tensor<16xf32>) attrs =  {prov.region_id = "elementwise_3", prov.family = "elementwise", prov._pattern_hint = "elementwise", prov.op = "elementwise", prov.aten = "aten.reciprocal.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb85(%776: f32, %777: f32):
      %778 = arith.constant 1.000000e+00 : f32
      %779 = arith.divf %778, %776 : f32
      linalg.yield %779 : f32
    } -> tensor<16xf32>
    %780 = arith.constant {prov.region_id = "mul_20", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 1.000000e+00 : f32
    %781 = tensor.splat %780 {prov.region_id = "mul_20", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<16xf32>
    %782 = tensor.empty() : tensor<16xf32>
    %783 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%775, %781 : tensor<16xf32>, tensor<16xf32>) outs(%782 : tensor<16xf32>) attrs =  {prov.region_id = "mul_20", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb86(%784: f32, %785: f32, %786: f32):
      %787 = arith.mulf %784, %785 : f32
      linalg.yield %787 : f32
    } -> tensor<16xf32>
    %788 = tensor.expand_shape %23 [[0 : i64, 1 : i64]] output_shape [8, 1] {prov.region_id = "unsqueeze_20", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8xi64> into tensor<8x1xi64>
    %789 = tensor.empty() : tensor<8x1xf32>
    %790 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%788 : tensor<8x1xi64>) outs(%789 : tensor<8x1xf32>) attrs =  {prov.region_id = "dtype_cast_3", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb87(%791: i64, %792: f32):
      %793 = arith.sitofp %791 : i64 to f32
      linalg.yield %793 : f32
    } -> tensor<8x1xf32>
    %794 = tensor.expand_shape %783 [[0 : i64, 1 : i64]] output_shape [1, 16] {prov.region_id = "unsqueeze_21", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<16xf32> into tensor<1x16xf32>
    %795 = tensor.empty() : tensor<8x16xf32>
    %796 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%790, %794 : tensor<8x1xf32>, tensor<1x16xf32>) outs(%795 : tensor<8x16xf32>) attrs =  {prov.region_id = "mul_21", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb88(%797: f32, %798: f32, %799: f32):
      %800 = arith.mulf %797, %798 : f32
      linalg.yield %800 : f32
    } -> tensor<8x16xf32>
    %801 = tensor.empty() : tensor<8x16xf32>
    %802 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%796 : tensor<8x16xf32>) outs(%801 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_6", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb89(%803: f32, %804: f32):
      %805 = math.cos %803 : f32
      linalg.yield %805 : f32
    } -> tensor<8x16xf32>
    %806 = tensor.empty() : tensor<8x16xf32>
    %807 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%796 : tensor<8x16xf32>) outs(%806 : tensor<8x16xf32>) attrs =  {prov.region_id = "cos_7", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb90(%808: f32, %809: f32):
      %810 = math.cos %808 : f32
      linalg.yield %810 : f32
    } -> tensor<8x16xf32>
    %811 = tensor.concat dim(1) %802, %807 {prov.region_id = "cat_9", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %812 = tensor.collapse_shape %811 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_22", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %813 = tensor.expand_shape %812 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_22", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %814 = tensor.collapse_shape %813 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_23", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %815 = tensor.expand_shape %814 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_23", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %816 = tensor.empty() : tensor<8x16xf32>
    %817 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%796 : tensor<8x16xf32>) outs(%816 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_6", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb91(%818: f32, %819: f32):
      %820 = math.sin %818 : f32
      linalg.yield %820 : f32
    } -> tensor<8x16xf32>
    %821 = tensor.empty() : tensor<8x16xf32>
    %822 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%796 : tensor<8x16xf32>) outs(%821 : tensor<8x16xf32>) attrs =  {prov.region_id = "sin_7", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb92(%823: f32, %824: f32):
      %825 = math.sin %823 : f32
      linalg.yield %825 : f32
    } -> tensor<8x16xf32>
    %826 = tensor.concat dim(1) %817, %822 {prov.region_id = "cat_10", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<8x16xf32>, tensor<8x16xf32>) -> tensor<8x32xf32>
    %827 = tensor.collapse_shape %826 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_24", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8x32xf32> into tensor<256xf32>
    %828 = tensor.expand_shape %827 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 32] {prov.region_id = "unsqueeze_24", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x8x32xf32>
    %829 = tensor.collapse_shape %828 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_25", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x32xf32> into tensor<256xf32>
    %830 = tensor.expand_shape %829 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 8, 32] {prov.region_id = "unsqueeze_25", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x1x8x32xf32>
    %831 = "tensor.extract_slice"(%647) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_6", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %832 = "tensor.extract_slice"(%647) <{static_offsets = array<i64: 0, 0, 0, 16>, static_sizes = array<i64: 1, 4, 8, 16>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_7", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<1x4x8x32xf32>) -> tensor<1x4x8x16xf32>
    %833 = tensor.empty() : tensor<1x4x8x16xf32>
    %834 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%832 : tensor<1x4x8x16xf32>) outs(%833 : tensor<1x4x8x16xf32>) attrs =  {prov.region_id = "neg_3", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb93(%835: f32, %836: f32):
      %837 = arith.negf %835 : f32
      linalg.yield %837 : f32
    } -> tensor<1x4x8x16xf32>
    %838 = tensor.concat dim(3) %834, %831 {prov.region_id = "cat_11", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : (tensor<1x4x8x16xf32>, tensor<1x4x8x16xf32>) -> tensor<1x4x8x32xf32>
    %839 = tensor.empty() : tensor<1x4x8x32xf32>
    %840 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%647, %815 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%839 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_22", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb94(%841: f32, %842: f32, %843: f32):
      %844 = arith.mulf %841, %842 : f32
      linalg.yield %844 : f32
    } -> tensor<1x4x8x32xf32>
    %845 = tensor.empty() : tensor<1x4x8x32xf32>
    %846 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%838, %830 : tensor<1x4x8x32xf32>, tensor<1x1x8x32xf32>) outs(%845 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "mul_23", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb95(%847: f32, %848: f32, %849: f32):
      %850 = arith.mulf %847, %848 : f32
      linalg.yield %850 : f32
    } -> tensor<1x4x8x32xf32>
    %851 = tensor.empty() : tensor<1x4x8x32xf32>
    %852 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%840, %846 : tensor<1x4x8x32xf32>, tensor<1x4x8x32xf32>) outs(%851 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "add_9", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb96(%853: f32, %854: f32, %855: f32):
      %856 = arith.addf %853, %854 : f32
      linalg.yield %856 : f32
    } -> tensor<1x4x8x32xf32>
    %857 = tensor.empty() : tensor<1x4x32x8xf32>
    %858 = linalg.transpose ins(%852:tensor<1x4x8x32xf32>) outs(%857:tensor<1x4x32x8xf32>) permutation = [0, 1, 3, 2]
    %859 = tensor.empty() : tensor<1x4x8x32xf32>
    %860 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%754 : tensor<1x4x8x32xf32>) outs(%859 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "expand_4", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb97(%861: f32, %862: f32):
      linalg.yield %861 : f32
    } -> tensor<1x4x8x32xf32>
    %863 = tensor.collapse_shape %860 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_33", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8x32xf32> into tensor<1024xf32>
    %864 = tensor.expand_shape %863 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 8, 32] {prov.region_id = "view_33", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<4x8x32xf32>
    %865 = tensor.empty() : tensor<1x4x32x8xf32>
    %866 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%858 : tensor<1x4x32x8xf32>) outs(%865 : tensor<1x4x32x8xf32>) attrs =  {prov.region_id = "expand_5", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb98(%867: f32, %868: f32):
      linalg.yield %867 : f32
    } -> tensor<1x4x32x8xf32>
    %869 = tensor.collapse_shape %866 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_34", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x32x8xf32> into tensor<1024xf32>
    %870 = tensor.expand_shape %869 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 32, 8] {prov.region_id = "view_34", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<4x32x8xf32>
    %871 = arith.constant {prov.region_id = "matmul_12", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 0.000000e+00 : f32
    %872 = tensor.splat %871 {prov.region_id = "matmul_12", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<4x8x8xf32>
    %873 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%864, %870 : tensor<4x8x32xf32>, tensor<4x32x8xf32>) outs(%872 : tensor<4x8x8xf32>) attrs =  {prov.region_id = "matmul_12", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb99(%874: f32, %875: f32, %876: f32):
      %877 = arith.mulf %874, %875 : f32
      %878 = arith.addf %876, %877 : f32
      linalg.yield %878 : f32
    } -> tensor<4x8x8xf32>
    %879 = tensor.collapse_shape %873 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_35", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<4x8x8xf32> into tensor<256xf32>
    %880 = tensor.expand_shape %879 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 8] {prov.region_id = "view_35", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<1x4x8x8xf32>
    %881 = arith.constant {prov.region_id = "div_5", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 5.65685415 : f32
    %882 = tensor.splat %881 {prov.region_id = "div_5", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8x8xf32>
    %883 = tensor.empty() : tensor<1x4x8x8xf32>
    %884 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%880, %882 : tensor<1x4x8x8xf32>, tensor<1x4x8x8xf32>) outs(%883 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "div_5", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb100(%885: f32, %886: f32, %887: f32):
      %888 = arith.divf %885, %886 : f32
      linalg.yield %888 : f32
    } -> tensor<1x4x8x8xf32>
    %889 = arith.constant {prov.region_id = "fill_2", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 0xff800000 : f32
    %890 = tensor.splat %889 {prov.region_id = "fill_2", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8x8xf32>
    %891 = tensor.empty() : tensor<8xi64>
    %892 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%891 : tensor<8xi64>) attrs =  {prov.region_id = "iota_3", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb101(%893: i64):
      %894 = linalg.index 0 : index
      %895 = arith.index_cast %894 : index to i64
      %896 = arith.constant 1 : i64
      %897 = arith.muli %895, %896 : i64
      %898 = arith.constant 0 : i64
      %899 = arith.addi %898, %897 : i64
      linalg.yield %899 : i64
    } -> tensor<8xi64>
    %900 = tensor.expand_shape %892 [[0 : i64, 1 : i64]] output_shape [1, 8] {prov.region_id = "unsqueeze_26", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8xi64> into tensor<1x8xi64>
    %901 = tensor.empty() : tensor<8xi64>
    %902 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%901 : tensor<8xi64>) attrs =  {prov.region_id = "iota_4", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb102(%903: i64):
      %904 = linalg.index 0 : index
      %905 = arith.index_cast %904 : index to i64
      %906 = arith.constant 1 : i64
      %907 = arith.muli %905, %906 : i64
      %908 = arith.constant 0 : i64
      %909 = arith.addi %908, %907 : i64
      linalg.yield %909 : i64
    } -> tensor<8xi64>
    %910 = tensor.expand_shape %902 [[0 : i64, 1 : i64]] output_shape [8, 1] {prov.region_id = "unsqueeze_27", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8xi64> into tensor<8x1xi64>
    %911 = tensor.empty() : tensor<8x8xi64>
    %912 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%900, %910 : tensor<1x8xi64>, tensor<8x1xi64>) outs(%911 : tensor<8x8xi64>) attrs =  {prov.region_id = "sub_1", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb103(%913: i64, %914: i64, %915: i64):
      %916 = arith.subi %913, %914 : i64
      linalg.yield %916 : i64
    } -> tensor<8x8xi64>
    %917 = arith.constant {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ge.Scalar", prov.orig_dtype = "bool", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 1 : i64
    %918 = tensor.splat %917 {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ge.Scalar", prov.orig_dtype = "bool", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<8x8xi64>
    %919 = tensor.empty() : tensor<8x8xi1>
    %920 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%912, %918 : tensor<8x8xi64>, tensor<8x8xi64>) outs(%919 : tensor<8x8xi1>) attrs =  {prov.region_id = "compare_1", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.ge.Scalar", prov.orig_dtype = "bool", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb104(%921: i64, %922: i64, %923: i1):
      %924 = arith.cmpi sge, %921, %922 : i64
      linalg.yield %924 : i1
    } -> tensor<8x8xi1>
    %925 = arith.constant {prov.region_id = "fill_3", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 0.000000e+00 : f32
    %926 = tensor.splat %925 {prov.region_id = "fill_3", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<f32>
    %927 = tensor.empty() : tensor<8x8xf32>
    %928 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> ()>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%920, %890, %926 : tensor<8x8xi1>, tensor<8x8xf32>, tensor<f32>) outs(%927 : tensor<8x8xf32>) attrs =  {prov.region_id = "select_1", prov.family = "layout", prov._pattern_hint = "select", prov.op = "select", prov.aten = "aten.where.self", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb105(%929: i1, %930: f32, %931: f32, %932: f32):
      %933 = arith.select %929, %930, %931 : f32
      linalg.yield %933 : f32
    } -> tensor<8x8xf32>
    %934 = tensor.empty() : tensor<1x4x8x8xf32>
    %935 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%884, %928 : tensor<1x4x8x8xf32>, tensor<8x8xf32>) outs(%934 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "add_10", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb106(%936: f32, %937: f32, %938: f32):
      %939 = arith.addf %936, %937 : f32
      linalg.yield %939 : f32
    } -> tensor<1x4x8x8xf32>
    %940 = arith.constant {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 0xff800000 : f32
    %941 = tensor.splat %940 {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8xf32>
    %942 = linalg.reduce ins(%935:tensor<1x4x8x8xf32>) outs(%941:tensor<1x4x8xf32>) dimensions = [3]
    (%943: f32, %944: f32) {
      %945 = arith.maximumf %943, %944 : f32
      linalg.yield %945 : f32
    }
    %946 = tensor.collapse_shape %942 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8xf32> into tensor<32xf32>
    %947 = tensor.expand_shape %946 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 1] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<32xf32> into tensor<1x4x8x1xf32>
    %948 = tensor.empty() : tensor<1x4x8x8xf32>
    %949 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%935, %947 : tensor<1x4x8x8xf32>, tensor<1x4x8x1xf32>) outs(%948 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb107(%950: f32, %951: f32, %952: f32):
      %953 = arith.subf %950, %951 : f32
      linalg.yield %953 : f32
    } -> tensor<1x4x8x8xf32>
    %954 = tensor.empty() : tensor<1x4x8x8xf32>
    %955 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%949 : tensor<1x4x8x8xf32>) outs(%954 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb108(%956: f32, %957: f32):
      %958 = math.exp %956 : f32
      linalg.yield %958 : f32
    } -> tensor<1x4x8x8xf32>
    %959 = arith.constant {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 0.000000e+00 : f32
    %960 = tensor.splat %959 {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8xf32>
    %961 = linalg.reduce ins(%955:tensor<1x4x8x8xf32>) outs(%960:tensor<1x4x8xf32>) dimensions = [3]
    (%962: f32, %963: f32) {
      %964 = arith.addf %962, %963 : f32
      linalg.yield %964 : f32
    }
    %965 = tensor.collapse_shape %961 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8xf32> into tensor<32xf32>
    %966 = tensor.expand_shape %965 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 1] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<32xf32> into tensor<1x4x8x1xf32>
    %967 = tensor.empty() : tensor<1x4x8x8xf32>
    %968 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%955, %966 : tensor<1x4x8x8xf32>, tensor<1x4x8x1xf32>) outs(%967 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb109(%969: f32, %970: f32, %971: f32):
      %972 = arith.divf %969, %970 : f32
      linalg.yield %972 : f32
    } -> tensor<1x4x8x8xf32>
    %973 = tensor.empty() : tensor<1x4x8x8xf32>
    %974 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%968 : tensor<1x4x8x8xf32>) outs(%973 : tensor<1x4x8x8xf32>) attrs =  {prov.region_id = "expand_6", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb110(%975: f32, %976: f32):
      linalg.yield %975 : f32
    } -> tensor<1x4x8x8xf32>
    %977 = tensor.collapse_shape %974 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_36", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8x8xf32> into tensor<256xf32>
    %978 = tensor.expand_shape %977 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 8, 8] {prov.region_id = "view_36", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<256xf32> into tensor<4x8x8xf32>
    %979 = tensor.empty() : tensor<1x4x8x32xf32>
    %980 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%660 : tensor<1x4x8x32xf32>) outs(%979 : tensor<1x4x8x32xf32>) attrs =  {prov.region_id = "expand_7", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb111(%981: f32, %982: f32):
      linalg.yield %981 : f32
    } -> tensor<1x4x8x32xf32>
    %983 = tensor.collapse_shape %980 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_37", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x4x8x32xf32> into tensor<1024xf32>
    %984 = tensor.expand_shape %983 [[0 : i64, 1 : i64, 2 : i64]] output_shape [4, 8, 32] {prov.region_id = "view_37", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<4x8x32xf32>
    %985 = arith.constant {prov.region_id = "matmul_13", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} 0.000000e+00 : f32
    %986 = tensor.splat %985 {prov.region_id = "matmul_13", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<4x8x32xf32>
    %987 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%978, %984 : tensor<4x8x8xf32>, tensor<4x8x32xf32>) outs(%986 : tensor<4x8x32xf32>) attrs =  {prov.region_id = "matmul_13", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} {
    ^bb112(%988: f32, %989: f32, %990: f32):
      %991 = arith.mulf %988, %989 : f32
      %992 = arith.addf %990, %991 : f32
      linalg.yield %992 : f32
    } -> tensor<4x8x32xf32>
    %993 = tensor.collapse_shape %987 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_38", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<4x8x32xf32> into tensor<1024xf32>
    %994 = tensor.expand_shape %993 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 32] {prov.region_id = "view_38", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<1x4x8x32xf32>
    %995 = tensor.empty() : tensor<1x8x4x32xf32>
    %996 = linalg.transpose ins(%994:tensor<1x4x8x32xf32>) outs(%995:tensor<1x8x4x32xf32>) permutation = [0, 2, 1, 3]
    %997 = tensor.collapse_shape %996 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_39", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1x8x4x32xf32> into tensor<1024xf32>
    %998 = tensor.expand_shape %997 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_39", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %999 = tensor.empty() : tensor<128x128xf32>
    %1000 = linalg.transpose ins(%14:tensor<128x128xf32>) outs(%999:tensor<128x128xf32>) permutation = [1, 0]
    %1001 = tensor.collapse_shape %998 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_40", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.o"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %1002 = tensor.expand_shape %1001 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_40", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.o"} : tensor<1024xf32> into tensor<8x128xf32>
    %1003 = arith.constant {prov.region_id = "matmul_14", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.o"} 0.000000e+00 : f32
    %1004 = tensor.splat %1003 {prov.region_id = "matmul_14", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.o"} : tensor<8x128xf32>
    %1005 = linalg.matmul {prov.region_id = "matmul_14", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.o", prov.transposed_b = "true"} ins(%1002, %1000 : tensor<8x128xf32>, tensor<128x128xf32>) outs(%1004 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %1006 = tensor.collapse_shape %1005 [[0 : i64, 1 : i64]] {prov.region_id = "view_41", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.o"} : tensor<8x128xf32> into tensor<1024xf32>
    %1007 = tensor.expand_shape %1006 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_41", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.attn.o"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %1008 = tensor.empty() : tensor<1x8x128xf32>
    %1009 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%571, %1007 : tensor<1x8x128xf32>, tensor<1x8x128xf32>) outs(%1008 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "add_11", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1"} {
    ^bb113(%1010: f32, %1011: f32, %1012: f32):
      %1013 = arith.addf %1010, %1011 : f32
      linalg.yield %1013 : f32
    } -> tensor<1x8x128xf32>
    %1014 = tensor.empty() : tensor<1x8x128xf32>
    %1015 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1009 : tensor<1x8x128xf32>) outs(%1014 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "pow_7", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} {
    ^bb114(%1016: f32, %1017: f32):
      %1018 = arith.mulf %1016, %1016 : f32
      linalg.yield %1018 : f32
    } -> tensor<1x8x128xf32>
    %1019 = arith.constant {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} 0.000000e+00 : f32
    %1020 = tensor.splat %1019 {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} : tensor<1x8xf32>
    %1021 = linalg.reduce ins(%1015:tensor<1x8x128xf32>) outs(%1020:tensor<1x8xf32>) dimensions = [2]
    (%1022: f32, %1023: f32) {
      %1024 = arith.addf %1022, %1023 : f32
      linalg.yield %1024 : f32
    }
    %1025 = arith.constant {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} 1.280000e+02 : f32
    %1026 = tensor.splat %1025 {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} : tensor<1x8xf32>
    %1027 = tensor.empty() : tensor<1x8xf32>
    %1028 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1021, %1026 : tensor<1x8xf32>, tensor<1x8xf32>) outs(%1027 : tensor<1x8xf32>) attrs =  {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} {
    ^bb115(%1029: f32, %1030: f32, %1031: f32):
      %1032 = arith.divf %1029, %1030 : f32
      linalg.yield %1032 : f32
    } -> tensor<1x8xf32>
    %1033 = tensor.collapse_shape %1028 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} : tensor<1x8xf32> into tensor<8xf32>
    %1034 = tensor.expand_shape %1033 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 1] {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} : tensor<8xf32> into tensor<1x8x1xf32>
    %1035 = arith.constant {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} 1.000000e-05 : f32
    %1036 = tensor.splat %1035 {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} : tensor<1x8x1xf32>
    %1037 = tensor.empty() : tensor<1x8x1xf32>
    %1038 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1034, %1036 : tensor<1x8x1xf32>, tensor<1x8x1xf32>) outs(%1037 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} {
    ^bb116(%1039: f32, %1040: f32, %1041: f32):
      %1042 = arith.addf %1039, %1040 : f32
      linalg.yield %1042 : f32
    } -> tensor<1x8x1xf32>
    %1043 = tensor.empty() : tensor<1x8x1xf32>
    %1044 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1038 : tensor<1x8x1xf32>) outs(%1043 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "rsqrt_3", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} {
    ^bb117(%1045: f32, %1046: f32):
      %1047 = math.rsqrt %1045 : f32
      linalg.yield %1047 : f32
    } -> tensor<1x8x1xf32>
    %1048 = tensor.empty() : tensor<1x8x128xf32>
    %1049 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1009, %1044 : tensor<1x8x128xf32>, tensor<1x8x1xf32>) outs(%1048 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_24", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} {
    ^bb118(%1050: f32, %1051: f32, %1052: f32):
      %1053 = arith.mulf %1050, %1051 : f32
      linalg.yield %1053 : f32
    } -> tensor<1x8x128xf32>
    %1054 = tensor.empty() : tensor<1x8x128xf32>
    %1055 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1049, %15 : tensor<1x8x128xf32>, tensor<128xf32>) outs(%1054 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_25", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.n2"} {
    ^bb119(%1056: f32, %1057: f32, %1058: f32):
      %1059 = arith.mulf %1056, %1057 : f32
      linalg.yield %1059 : f32
    } -> tensor<1x8x128xf32>
    %1060 = tensor.empty() : tensor<128x344xf32>
    %1061 = linalg.transpose ins(%16:tensor<344x128xf32>) outs(%1060:tensor<128x344xf32>) permutation = [1, 0]
    %1062 = tensor.collapse_shape %1055 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_42", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.g"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %1063 = tensor.expand_shape %1062 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_42", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.g"} : tensor<1024xf32> into tensor<8x128xf32>
    %1064 = arith.constant {prov.region_id = "matmul_15", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.g"} 0.000000e+00 : f32
    %1065 = tensor.splat %1064 {prov.region_id = "matmul_15", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.g"} : tensor<8x344xf32>
    %1066 = linalg.matmul {prov.region_id = "matmul_15", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.g", prov.transposed_b = "true"} ins(%1063, %1061 : tensor<8x128xf32>, tensor<128x344xf32>) outs(%1065 : tensor<8x344xf32>) -> tensor<8x344xf32>
    %1067 = tensor.collapse_shape %1066 [[0 : i64, 1 : i64]] {prov.region_id = "view_43", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.g"} : tensor<8x344xf32> into tensor<2752xf32>
    %1068 = tensor.expand_shape %1067 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 344] {prov.region_id = "view_43", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.g"} : tensor<2752xf32> into tensor<1x8x344xf32>
    %1069 = tensor.empty() : tensor<1x8x344xf32>
    %1070 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1068 : tensor<1x8x344xf32>) outs(%1069 : tensor<1x8x344xf32>) attrs =  {prov.region_id = "sigmoid_1", prov._pattern_hint = "sigmoid", prov.op = "sigmoid", prov.family = "elementwise", prov.aten = "aten.sigmoid.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp"} {
    ^bb120(%1071: f32, %1072: f32):
      %1073 = arith.constant 1.000000e+00 : f32
      %1074 = arith.negf %1071 : f32
      %1075 = math.exp %1074 : f32
      %1076 = arith.addf %1073, %1075 : f32
      %1077 = arith.divf %1073, %1076 : f32
      linalg.yield %1077 : f32
    } -> tensor<1x8x344xf32>
    %1078 = tensor.empty() : tensor<1x8x344xf32>
    %1079 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1068, %1070 : tensor<1x8x344xf32>, tensor<1x8x344xf32>) outs(%1078 : tensor<1x8x344xf32>) attrs =  {prov.region_id = "mul_26", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp"} {
    ^bb121(%1080: f32, %1081: f32, %1082: f32):
      %1083 = arith.mulf %1080, %1081 : f32
      linalg.yield %1083 : f32
    } -> tensor<1x8x344xf32>
    %1084 = tensor.empty() : tensor<128x344xf32>
    %1085 = linalg.transpose ins(%17:tensor<344x128xf32>) outs(%1084:tensor<128x344xf32>) permutation = [1, 0]
    %1086 = tensor.collapse_shape %1055 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_44", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.u"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %1087 = tensor.expand_shape %1086 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_44", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.u"} : tensor<1024xf32> into tensor<8x128xf32>
    %1088 = arith.constant {prov.region_id = "matmul_16", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.u"} 0.000000e+00 : f32
    %1089 = tensor.splat %1088 {prov.region_id = "matmul_16", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.u"} : tensor<8x344xf32>
    %1090 = linalg.matmul {prov.region_id = "matmul_16", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.u", prov.transposed_b = "true"} ins(%1087, %1085 : tensor<8x128xf32>, tensor<128x344xf32>) outs(%1089 : tensor<8x344xf32>) -> tensor<8x344xf32>
    %1091 = tensor.collapse_shape %1090 [[0 : i64, 1 : i64]] {prov.region_id = "view_45", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.u"} : tensor<8x344xf32> into tensor<2752xf32>
    %1092 = tensor.expand_shape %1091 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 344] {prov.region_id = "view_45", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.u"} : tensor<2752xf32> into tensor<1x8x344xf32>
    %1093 = tensor.empty() : tensor<1x8x344xf32>
    %1094 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1079, %1092 : tensor<1x8x344xf32>, tensor<1x8x344xf32>) outs(%1093 : tensor<1x8x344xf32>) attrs =  {prov.region_id = "mul_27", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp"} {
    ^bb122(%1095: f32, %1096: f32, %1097: f32):
      %1098 = arith.mulf %1095, %1096 : f32
      linalg.yield %1098 : f32
    } -> tensor<1x8x344xf32>
    %1099 = tensor.empty() : tensor<344x128xf32>
    %1100 = linalg.transpose ins(%18:tensor<128x344xf32>) outs(%1099:tensor<344x128xf32>) permutation = [1, 0]
    %1101 = tensor.collapse_shape %1094 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_46", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.dn"} : tensor<1x8x344xf32> into tensor<2752xf32>
    %1102 = tensor.expand_shape %1101 [[0 : i64, 1 : i64]] output_shape [8, 344] {prov.region_id = "view_46", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.dn"} : tensor<2752xf32> into tensor<8x344xf32>
    %1103 = arith.constant {prov.region_id = "matmul_17", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.dn"} 0.000000e+00 : f32
    %1104 = tensor.splat %1103 {prov.region_id = "matmul_17", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.dn"} : tensor<8x128xf32>
    %1105 = linalg.matmul {prov.region_id = "matmul_17", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.dn", prov.transposed_b = "true"} ins(%1102, %1100 : tensor<8x344xf32>, tensor<344x128xf32>) outs(%1104 : tensor<8x128xf32>) -> tensor<8x128xf32>
    %1106 = tensor.collapse_shape %1105 [[0 : i64, 1 : i64]] {prov.region_id = "view_47", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.dn"} : tensor<8x128xf32> into tensor<1024xf32>
    %1107 = tensor.expand_shape %1106 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 128] {prov.region_id = "view_47", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1.mlp.dn"} : tensor<1024xf32> into tensor<1x8x128xf32>
    %1108 = tensor.empty() : tensor<1x8x128xf32>
    %1109 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1009, %1107 : tensor<1x8x128xf32>, tensor<1x8x128xf32>) outs(%1108 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "add_13", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "blocks", prov.fqn = "blocks.1"} {
    ^bb123(%1110: f32, %1111: f32, %1112: f32):
      %1113 = arith.addf %1110, %1111 : f32
      linalg.yield %1113 : f32
    } -> tensor<1x8x128xf32>
    %1114 = tensor.empty() : tensor<1x8x128xf32>
    %1115 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1109 : tensor<1x8x128xf32>) outs(%1114 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "pow_8", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} {
    ^bb124(%1116: f32, %1117: f32):
      %1118 = arith.mulf %1116, %1116 : f32
      linalg.yield %1118 : f32
    } -> tensor<1x8x128xf32>
    %1119 = arith.constant {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} 0.000000e+00 : f32
    %1120 = tensor.splat %1119 {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} : tensor<1x8xf32>
    %1121 = linalg.reduce ins(%1115:tensor<1x8x128xf32>) outs(%1120:tensor<1x8xf32>) dimensions = [2]
    (%1122: f32, %1123: f32) {
      %1124 = arith.addf %1122, %1123 : f32
      linalg.yield %1124 : f32
    }
    %1125 = arith.constant {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} 1.280000e+02 : f32
    %1126 = tensor.splat %1125 {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} : tensor<1x8xf32>
    %1127 = tensor.empty() : tensor<1x8xf32>
    %1128 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1121, %1126 : tensor<1x8xf32>, tensor<1x8xf32>) outs(%1127 : tensor<1x8xf32>) attrs =  {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} {
    ^bb125(%1129: f32, %1130: f32, %1131: f32):
      %1132 = arith.divf %1129, %1130 : f32
      linalg.yield %1132 : f32
    } -> tensor<1x8xf32>
    %1133 = tensor.collapse_shape %1128 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} : tensor<1x8xf32> into tensor<8xf32>
    %1134 = tensor.expand_shape %1133 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 1] {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} : tensor<8xf32> into tensor<1x8x1xf32>
    %1135 = arith.constant {prov.region_id = "add_14", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} 1.000000e-05 : f32
    %1136 = tensor.splat %1135 {prov.region_id = "add_14", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} : tensor<1x8x1xf32>
    %1137 = tensor.empty() : tensor<1x8x1xf32>
    %1138 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1134, %1136 : tensor<1x8x1xf32>, tensor<1x8x1xf32>) outs(%1137 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "add_14", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} {
    ^bb126(%1139: f32, %1140: f32, %1141: f32):
      %1142 = arith.addf %1139, %1140 : f32
      linalg.yield %1142 : f32
    } -> tensor<1x8x1xf32>
    %1143 = tensor.empty() : tensor<1x8x1xf32>
    %1144 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1138 : tensor<1x8x1xf32>) outs(%1143 : tensor<1x8x1xf32>) attrs =  {prov.region_id = "rsqrt_4", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} {
    ^bb127(%1145: f32, %1146: f32):
      %1147 = math.rsqrt %1145 : f32
      linalg.yield %1147 : f32
    } -> tensor<1x8x1xf32>
    %1148 = tensor.empty() : tensor<1x8x128xf32>
    %1149 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1109, %1144 : tensor<1x8x128xf32>, tensor<1x8x1xf32>) outs(%1148 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_28", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} {
    ^bb128(%1150: f32, %1151: f32, %1152: f32):
      %1153 = arith.mulf %1150, %1151 : f32
      linalg.yield %1153 : f32
    } -> tensor<1x8x128xf32>
    %1154 = tensor.empty() : tensor<1x8x128xf32>
    %1155 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1149, %19 : tensor<1x8x128xf32>, tensor<128xf32>) outs(%1154 : tensor<1x8x128xf32>) attrs =  {prov.region_id = "mul_29", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "norm", prov.fqn = "norm"} {
    ^bb129(%1156: f32, %1157: f32, %1158: f32):
      %1159 = arith.mulf %1156, %1157 : f32
      linalg.yield %1159 : f32
    } -> tensor<1x8x128xf32>
    %1160 = tensor.empty() : tensor<128x256xf32>
    %1161 = linalg.transpose ins(%20:tensor<256x128xf32>) outs(%1160:tensor<128x256xf32>) permutation = [1, 0]
    %1162 = tensor.collapse_shape %1155 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_48", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} : tensor<1x8x128xf32> into tensor<1024xf32>
    %1163 = tensor.expand_shape %1162 [[0 : i64, 1 : i64]] output_shape [8, 128] {prov.region_id = "view_48", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} : tensor<1024xf32> into tensor<8x128xf32>
    %1164 = arith.constant {prov.region_id = "matmul_18", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} 0.000000e+00 : f32
    %1165 = tensor.splat %1164 {prov.region_id = "matmul_18", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} : tensor<8x256xf32>
    %1166 = linalg.matmul {prov.region_id = "matmul_18", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm", prov.transposed_b = "true"} ins(%1163, %1161 : tensor<8x128xf32>, tensor<128x256xf32>) outs(%1165 : tensor<8x256xf32>) -> tensor<8x256xf32>
    %1167 = tensor.collapse_shape %1166 [[0 : i64, 1 : i64]] {prov.region_id = "view_49", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} : tensor<8x256xf32> into tensor<2048xf32>
    %1168 = tensor.expand_shape %1167 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 8, 256] {prov.region_id = "view_49", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} : tensor<2048xf32> into tensor<1x8x256xf32>
    func.return %1168 : tensor<1x8x256xf32>
  }
}
