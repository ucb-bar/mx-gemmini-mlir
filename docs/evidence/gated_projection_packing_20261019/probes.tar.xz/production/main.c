#include <stdint.h>
#include <stdio.h>
#include "runtime_quant.h"
extern const uint8_t input[],expected[];
extern void old0(const uint8_t *,float *),old1(const uint8_t *,float *);
extern void sigmoid(const float *,float *),fused(const uint8_t *,uint8_t *);
enum{N=160*5632,B=N*33/32};
unsigned char workspace[4*1024*1024] __attribute__((aligned(64)));
static float gate[N],up[N],sig[N],product[N];
static uint8_t output[B+128] __attribute__((aligned(64)));
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){
 for(unsigned trial=0;trial<2;trial++)for(unsigned order=0;order<2;order++){
  unsigned role=trial^order;for(unsigned i=0;i<B+128;i++)output[i]=0xa5;
  uint64_t start=ticks();
  if(role)fused(input,output+64);
  else{old0(input,gate);old1(input,up);sigmoid(gate,sig);
   for(unsigned i=0;i<N;i++)product[i]=(gate[i]*sig[i])*up[i];
   if(mx_pack_activation_f32(product,160,5632,8,output+64,output+64+N))return 2;}
  uint64_t cycles=ticks()-start;unsigned bad=0;
  for(unsigned i=0;i<B;i++)bad+=output[i+64]!=expected[i];
  for(unsigned i=0;i<64;i++)bad+=output[i]!=0xa5||output[B+64+i]!=0xa5;
  printf("GATED trial=%u role=%u cycles=%lu bad=%u checked=%u\n",trial,role,(unsigned long)cycles,bad,B);
  if(bad)return 1;
  for(unsigned i=0;i<B;i+=32){printf("GATED_BYTES %u %u %u 32",trial,role,i);for(unsigned j=0;j<32;j++)printf(" %02x",output[i+64+j]);printf("\n");}
 }
 printf("GATED_DONE\n");return 0;
}
