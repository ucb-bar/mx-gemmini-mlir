#include "vpu_ref.h"
void reference(const float *g,const float *u,float *out){
 for(unsigned i=0;i<160u*5632u;i++){
  float sigmoid=1.0f/(1.0f+vpu_bf16_to_f(vpu_exp(vpu_f_to_bf16(-g[i]))));
  out[i]=(g[i]*sigmoid)*u[i];
 }
}
