/* MX dense f32 adapter: FP8, qualified 160x5632x2048 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void old_issue0(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t weight0[];
extern const uint8_t scales0[];
extern unsigned char workspace[];

void old0(const uint8_t *lhs, float *out) {
  if (!lhs || !out) __builtin_trap();
  uint16_t *output_bf16 = (uint16_t *)(workspace + 0);
  uint8_t *scratch_output_scales = (uint8_t *)(workspace + 1802240);
  const uint8_t *activation = lhs;
  const uint8_t *activation_scales = lhs + 327680u;
  old_issue0(activation, activation_scales, weight0, scales0,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 160u; ++row)
    for (uint32_t col = 0; col < 5632u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 5632u + col] << 16;
      out[(size_t)row * 5632u + col] = word.value;
    }
}
