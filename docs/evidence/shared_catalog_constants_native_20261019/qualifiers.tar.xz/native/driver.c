#include <stdint.h>
#include <stdio.h>
void operation_alpha(const float*,const float*,float*);
void operation_beta(const float*,const float*,float*);
unsigned char mx_catalog_workspace[65536] __attribute__((aligned(64)));
static float input[560] __attribute__((aligned(64)));
static struct {uint32_t pre[8];float data[85];uint32_t post[8];} a;
static struct {uint32_t pre[8];float data[272];uint32_t post[8];} b;
int main(void){unsigned errors=0;
  for(unsigned run=0;run<3;++run){
    float value=run==0?1.0f:run==1?-1.0f:0.5f;
    for(unsigned i=0;i<560;++i)input[i]=value;
    for(unsigned i=0;i<85;++i)a.data[i]=0.0f;
    for(unsigned i=0;i<272;++i)b.data[i]=0.0f;
    for(unsigned i=0;i<8;++i)a.pre[i]=a.post[i]=b.pre[i]=b.post[i]=0xa55aa55a;
    operation_alpha(input,input,a.data); operation_beta(input,input,b.data);
    for(unsigned i=0;i<85;++i)errors+=a.data[i]!=35.0f*value;
    for(unsigned i=0;i<272;++i)errors+=b.data[i]!=35.0f*value;
    for(unsigned i=0;i<8;++i)errors+=a.pre[i]!=0xa55aa55a || a.post[i]!=0xa55aa55a ||
      b.pre[i]!=0xa55aa55a || b.post[i]!=0xa55aa55a;
    printf("VALUES alpha run=%u ",run);
    for(unsigned i=0;i<85;++i){union{float f;uint32_t u;} v;v.f=a.data[i];printf("%08x",v.u);}
    printf("\nVALUES beta run=%u ",run);
    for(unsigned i=0;i<272;++i){union{float f;uint32_t u;} v;v.f=b.data[i];printf("%08x",v.u);}
    printf("\n");
    printf("POOL run=%u errors=%u\n",run,errors);
  }
  printf("DONE errors=%u\n",errors);return errors!=0;
}
