from pathlib import Path
import json,hashlib,tarfile,io
from mx_gemmini_support.runtime_group_preparation import emit_runtime_group_preparation
root=Path('../.tmp/mx_model_goal_20261018');suite=root/'quant_group_merlin_suite_20261019';out=Path('docs/evidence/group_word_packing_20261019')
cases={name:{'directory':suite/name,'phase':'merlin_preparation','invocation':row}for name,row in json.loads((suite/'suite.json').read_text()).items()}
cases['fp8_prefill']={'directory':root/'quant_groups_merlin_four_way_m160k2048_fp8','phase':'merlin_preparation'}
cases['prototype_fp8_prefill']={'directory':root/'quant_words_four_way_m160k2048_fp8','phase':'oot_prototype'}
files={}
def add(name,raw):assert name not in files;files[name]=raw
for name,case in cases.items():
 directory=case['directory'];report=json.loads((directory/'receipt.json').read_text());assert len(report['results'])==4
 for result in report['results'].values():assert result['exit_code']==0 and result['elf_admission']['status']=='accepted'
 if case['phase']=='merlin_preparation':
  assert (directory/'sources/runtime_quant.c').read_bytes()==Path('mx_gemmini_support/runtime_quant.c').read_bytes()
  assert (directory/'sources/runtime_group_prepare.h').read_text()==emit_runtime_group_preparation()
 for path in sorted(directory.rglob('*')):
  if path.is_file():add('cases/'+name+'/'+path.relative_to(directory).as_posix(),path.read_bytes())
 if 'invocation'in case:
  assert case['invocation']['exit_code']==0;add('cases/'+name+'/invocation.json',(json.dumps(case['invocation'],indent=2)+'\n').encode())
for path in sorted((root/'quant_group_merlin_resources').iterdir()):
 if path.is_file():add('resources/'+path.name,path.read_bytes())
add('profile.json',Path('profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json').read_bytes())
add('qualify_quant_group_words_spike.py',Path('tools/qualify_quant_group_words_spike.py').read_bytes())
add('word_group_preparation.py',Path('../merlin/src/merlin/llvmlower/word_group_preparation.py').read_bytes())
add('runtime_group_preparation.py',Path('mx_gemmini_support/runtime_group_preparation.py').read_bytes())
add('collection.py',Path(__file__).read_bytes())
archive=out/'executions.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=6)as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
reader=Path('docs/evidence/broadcast_multiply_20261019/verify.py')
manifest={'schema':'mx_gemmini.group_word_evidence.v1','scope':'host_packing_sections_not_whole_model_results',
 'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
 'members':{name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}for name,raw in sorted(files.items())},
 'cases':{name:{'phase':case['phase']}for name,case in cases.items()},'elf_reader_sha256':hashlib.sha256(reader.read_bytes()).hexdigest()}
(out/'artifacts.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print('retained',len(files),'members',archive.stat().st_size,'bytes',flush=True)
