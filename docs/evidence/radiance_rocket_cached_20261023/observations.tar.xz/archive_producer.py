"""Retain complete cached outputs and timing without distributing checkpoint weights."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile
import numpy as np

root=Path.cwd(); source=root.parent/'.tmp/independent_sessions_20261020'; builds=root.parent/'.tmp/mx_model_goal_20261018'
dest=root/'docs/evidence/radiance_rocket_cached_20261023'; dest.mkdir(exist_ok=True)
files={}
for label,base,names in [
 ('source',source/'cached_tinyllama1',['receipt.json','spike.log','perf.txt','observed0.bin','observed1.bin','checks.json','phases.bin','token_ids.bin','driver.c','radiance_rocket_llama.c','producer.py','cached_producer.py']),
 ('compiler',builds/'cached_session_compact_rhs_guarded_run',['mx_session_run.json','spike.log','gemmini_perf.txt']),
 ('compiler',builds/'cached_session_compact_rhs_guarded_link',['mx_session_link.json']),
 ('checks',source,['full_cached_comparison.json','full_cached_comparison_job.json','cached_prefill_independent_weights.json','cached_decode_independent_weights.json'])]:
 for name in names: files[label+'/'+name]=(base/name).read_bytes()
run=json.loads(files['compiler/mx_session_run.json'])
for row in run['output_dumps']:
 files['compiler/'+row['path']]=(builds/'cached_session_compact_rhs_guarded_run'/row['path']).read_bytes()
capture=builds/'cached_session_recapture/capture'
files['reference/prefill.npy']=(capture/'stages/prefill/golden.npy').read_bytes()
files['reference/decode.npz']=(capture/'stages/decode/session_quality_fp32.npz').read_bytes()
for prefix,path in [('prefill',capture/'stages/prefill'),('decode',capture/'stages/decode')]:
 files['reference/'+prefix+'_capture_receipt.json']=(path/'capture_receipt.json').read_bytes()
# Freeze the already-used parser and numerical rule without their compiler imports.
helpers=['import re\nimport numpy as np\n']
for path,names in [
 ('mx_gemmini_support/spike_timing.py',{'reject_deadlocked_timing'}),
 ('tools/qualify_radiance_rocket_llama.py',{'parse_console'}),
 ('tools/compare_radiance_rocket_cached.py',{'quality','gates'})]:
 text=(root/path).read_text()
 for node in ast.parse(text).body:
  if isinstance(node,ast.FunctionDef) and node.name in names: helpers.append(ast.get_source_segment(text,node)+'\n')
(dest/'support.py').write_text('\n'.join(helpers))
files['archive_producer.py']=Path(__file__).read_bytes()
archive=dest/'observations.tar.xz'
if archive.exists():raise ValueError('retain existing archive before a new attempt')
with tarfile.open(archive,'w:xz',preset=3) as output:
 for name,raw in sorted(files.items()):
  record=tarfile.TarInfo(name);record.size=len(raw);record.mode=0o644;record.mtime=0
  output.addfile(record,io.BytesIO(raw))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest={'schema':'mx_gemmini.cached_observations_archive.v1','archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'members':{name:{'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(files.items())},'support_sha256':sha((dest/'support.py').read_bytes()),'scope':'complete_recorded_outputs_and_inclusive_timing;_large_ELFs_and_checkpoint_data_external'}
(dest/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(archive.stat().st_size,len(files))
