module attributes {mx.profile_sha256 = "8674d57c7a133eae83baa14385d912a2c1c623fe02d2ea7f98826a09ed783487",
  mx.contract_sha256 = "4d0ca9e6b3c48d50f0892e79d7632c044a0c4d6001dada899252f1c9e2fecdbd",
  mx.policy_sha256 = "04dc8f73257310f916ed8d6b0d48e49d57d32c928a561a08d42da1594317b186",
  prov.quantization_manifest_sha256 = "8425226b26ee6c6153de9e0f6969575399ed7216efd72a1f7c441444c43fc351",
  mx.frontend_mlir_sha256 = "9e6be88fe88c703bce77ae73b0b051d46daa54715b3c862409d1e30b5b56909f",
  mx.runtime_resources_sha256 = "9b48a842e60806e24cb04533eb24ed47e018bbaa92e9d04045d4ee4120eb728a"} {
  func.func @nicolas_connected_vpu_pair(
      %a1: tensor<64x64xi8>, %a1s: tensor<2x64xi8>,
      %b1: tensor<64x64xi8>, %b1s: tensor<2x64xi8>,
      %b2: tensor<64x128xi8>, %b2s: tensor<2x128xi8>)
      -> (tensor<64x128xi8>, tensor<64x4xi8>) {
    %acc = "mx_gemmini.contract"(%a1, %a1s, %b1, %b1s) {
      site_id = "functional:matmul", activation_format = "fp8_e4m3",
      weight_format = "fp8_e4m3", activation_projection = "direct",
      weight_projection = "direct", pe_mode = 8 : i32, contract_sha256 = "4d0ca9e6b3c48d50f0892e79d7632c044a0c4d6001dada899252f1c9e2fecdbd", policy_sha256 = "04dc8f73257310f916ed8d6b0d48e49d57d32c928a561a08d42da1594317b186", manifest_sha256 = "8425226b26ee6c6153de9e0f6969575399ed7216efd72a1f7c441444c43fc351", profile_sha256 = "8674d57c7a133eae83baa14385d912a2c1c623fe02d2ea7f98826a09ed783487"}
      : (tensor<64x64xi8>, tensor<2x64xi8>, tensor<64x64xi8>, tensor<2x64xi8>)
      -> tensor<64x64xbf16>
    %bf16 = "mx_gemmini.readout_bf16"(%acc) {
      site_id = "functional:matmul", contract_sha256 = "4d0ca9e6b3c48d50f0892e79d7632c044a0c4d6001dada899252f1c9e2fecdbd", policy_sha256 = "04dc8f73257310f916ed8d6b0d48e49d57d32c928a561a08d42da1594317b186", manifest_sha256 = "8425226b26ee6c6153de9e0f6969575399ed7216efd72a1f7c441444c43fc351", profile_sha256 = "8674d57c7a133eae83baa14385d912a2c1c623fe02d2ea7f98826a09ed783487"}
      : (tensor<64x64xbf16>) -> tensor<64x64xbf16>
    %vpu = "mx_gemmini.vpu_execute"(%bf16) {
      site_id = "functional:matmul", kind = "muls",
      src1_row = 4096 : i32, src2_row = 0 : i32,
      dst_row = 4096 : i32, rows = 512 : i32,
      reduction_length = 1 : i32, broadcast = false,
      immediate_bf16 = 16384 : i32, contract_sha256 = "4d0ca9e6b3c48d50f0892e79d7632c044a0c4d6001dada899252f1c9e2fecdbd", policy_sha256 = "04dc8f73257310f916ed8d6b0d48e49d57d32c928a561a08d42da1594317b186", manifest_sha256 = "8425226b26ee6c6153de9e0f6969575399ed7216efd72a1f7c441444c43fc351", profile_sha256 = "8674d57c7a133eae83baa14385d912a2c1c623fe02d2ea7f98826a09ed783487"}
      : (tensor<64x64xbf16>) -> tensor<64x64xbf16>
    %c1, %c1s = "mx_gemmini.spad_requant"(%vpu) {
      site_id = "functional:matmul", source_row = 4096 : i32,
      destination_row = 128 : i32, m = 64 : i32, n = 64 : i32,
      output_format = "fp8_e4m3", tiled = true, resident = true,
      scale_dram_address = 0 : i64, scale_buffer = "c1_scales", contract_sha256 = "4d0ca9e6b3c48d50f0892e79d7632c044a0c4d6001dada899252f1c9e2fecdbd", policy_sha256 = "04dc8f73257310f916ed8d6b0d48e49d57d32c928a561a08d42da1594317b186", manifest_sha256 = "8425226b26ee6c6153de9e0f6969575399ed7216efd72a1f7c441444c43fc351", profile_sha256 = "8674d57c7a133eae83baa14385d912a2c1c623fe02d2ea7f98826a09ed783487"}
      : (tensor<64x64xbf16>) -> (tensor<64x64xi8>, tensor<64x2xi8>)
    %c2, %c2s = "mx_gemmini.resident_contract"(%c1, %c1s, %b2, %b2s) {
      site_id = "functional:matmul_1", activation_row = 128 : i32,
      weight_row = 15872 : i32, output_row = 512 : i32,
      m = 64 : i32, n = 128 : i32, k = 64 : i32,
      activation_format = "fp8_e4m3", weight_format = "fp8_e4m3",
      output_format = "fp8_e4m3", weight_buffer = "b2_weight",
      weight_scales_buffer = "b2_scales", output_scales_buffer = "c2_scales",
      contract_sha256 = "4d0ca9e6b3c48d50f0892e79d7632c044a0c4d6001dada899252f1c9e2fecdbd", policy_sha256 = "04dc8f73257310f916ed8d6b0d48e49d57d32c928a561a08d42da1594317b186", manifest_sha256 = "8425226b26ee6c6153de9e0f6969575399ed7216efd72a1f7c441444c43fc351", profile_sha256 = "8674d57c7a133eae83baa14385d912a2c1c623fe02d2ea7f98826a09ed783487"}
      : (tensor<64x64xi8>, tensor<64x2xi8>, tensor<64x128xi8>, tensor<2x128xi8>)
      -> (tensor<64x128xi8>, tensor<64x4xi8>)
    func.return %c2, %c2s : tensor<64x128xi8>, tensor<64x4xi8>
  }
}
