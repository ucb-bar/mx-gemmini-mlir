builtin.module attributes {prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<256000x2304xf32>, %1: tensor<2048x2304xf32>, %2: tensor<1024x2304xf32>, %3: tensor<1024x2304xf32>, %4: tensor<2304x2048xf32>, %5: tensor<9216x2304xf32>, %6: tensor<9216x2304xf32>, %7: tensor<2304x9216xf32>, %8: tensor<2304xf32>, %9: tensor<2304xf32>, %10: tensor<2304xf32>, %11: tensor<2304xf32>, %12: tensor<2048x2304xf32>, %13: tensor<1024x2304xf32>, %14: tensor<1024x2304xf32>, %15: tensor<2304x2048xf32>, %16: tensor<9216x2304xf32>, %17: tensor<9216x2304xf32>, %18: tensor<2304x9216xf32>, %19: tensor<2304xf32>, %20: tensor<2304xf32>, %21: tensor<2304xf32>, %22: tensor<2304xf32>, %23: tensor<2304xf32>, %24: tensor<256000x2304xf32>, %25: tensor<f32>, %26: tensor<128xf32>, %27: tensor<128xf32>, %28: tensor<1x4xi64>) -> tensor<1x4x256000xf32> {
    %29 = tensor.empty() : tensor<1x4x2304xf32>
    %30 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%28 : tensor<1x4xi64>) outs(%29 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "gather_0", prov.family = "gather_scatter", prov._pattern_hint = "embedding", prov.op = "embedding", prov.aten = "aten.embedding.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.embed_tokens"} {
    ^bb0(%31: i64, %32: f32):
      %33 = arith.index_cast %31 : i64 to index
      %34 = linalg.index 2 : index
      %35 = tensor.extract %0[%33, %34] : tensor<256000x2304xf32>
      linalg.yield %35 : f32
    } -> tensor<1x4x2304xf32>
    %36 = tensor.empty() : tensor<1x4x2304xf32>
    %37 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> ()>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%30, %25 : tensor<1x4x2304xf32>, tensor<f32>) outs(%36 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.embed_tokens"} {
    ^bb1(%38: f32, %39: f32, %40: f32):
      %41 = arith.mulf %38, %39 : f32
      linalg.yield %41 : f32
    } -> tensor<1x4x2304xf32>
    %42 = tensor.empty() : tensor<4xi64>
    %43 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%42 : tensor<4xi64>) attrs =  {prov.region_id = "iota_0", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb2(%44: i64):
      %45 = linalg.index 0 : index
      %46 = arith.index_cast %45 : index to i64
      %47 = arith.constant 1 : i64
      %48 = arith.muli %46, %47 : i64
      %49 = arith.constant 0 : i64
      %50 = arith.addi %49, %48 : i64
      linalg.yield %50 : i64
    } -> tensor<4xi64>
    %51 = arith.constant {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %52 = tensor.splat %51 {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %53 = tensor.empty() : tensor<4xi64>
    %54 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%43, %52 : tensor<4xi64>, tensor<4xi64>) outs(%53 : tensor<4xi64>) attrs =  {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb3(%55: i64, %56: i64, %57: i64):
      %58 = arith.addi %55, %56 : i64
      linalg.yield %58 : i64
    } -> tensor<4xi64>
    %59 = tensor.expand_shape %54 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %60 = "tensor.extract_slice"(%59) <{static_offsets = array<i64: 0, 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_0", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x4xi64>) -> tensor<1x1xi64>
    %61 = arith.constant {prov.region_id = "sub_0", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 1 : i64
    %62 = tensor.splat %61 {prov.region_id = "sub_0", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1xi64>
    %63 = tensor.empty() : tensor<1x1xi64>
    %64 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%60, %62 : tensor<1x1xi64>, tensor<1x1xi64>) outs(%63 : tensor<1x1xi64>) attrs =  {prov.region_id = "sub_0", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb4(%65: i64, %66: i64, %67: i64):
      %68 = arith.subi %65, %66 : i64
      linalg.yield %68 : i64
    } -> tensor<1x1xi64>
    %69 = tensor.concat dim(1) %64, %59 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x1xi64>, tensor<1x4xi64>) -> tensor<1x5xi64>
    %70 = "tensor.extract_slice"(%69) <{static_offsets = array<i64: 0, 0>, static_sizes = array<i64: 1, 4>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_1", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x5xi64>) -> tensor<1x4xi64>
    %71 = "tensor.extract_slice"(%69) <{static_offsets = array<i64: 0, 1>, static_sizes = array<i64: 1, 4>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_2", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x5xi64>) -> tensor<1x4xi64>
    %72 = tensor.empty() : tensor<1x4xi64>
    %73 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%71, %70 : tensor<1x4xi64>, tensor<1x4xi64>) outs(%72 : tensor<1x4xi64>) attrs =  {prov.region_id = "sub_1", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb5(%74: i64, %75: i64, %76: i64):
      %77 = arith.subi %74, %75 : i64
      linalg.yield %77 : i64
    } -> tensor<1x4xi64>
    %78 = arith.constant {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} 1 : i64
    %79 = tensor.splat %78 {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64>
    %80 = tensor.empty() : tensor<1x4xi1>
    %81 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%73, %79 : tensor<1x4xi64>, tensor<1x4xi64>) outs(%80 : tensor<1x4xi1>) attrs =  {prov.region_id = "compare_0", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb6(%82: i64, %83: i64, %84: i1):
      %85 = arith.cmpi ne, %82, %83 : i64
      linalg.yield %85 : i1
    } -> tensor<1x4xi1>
    %86 = arith.constant {prov.region_id = "scan_0", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %87 = tensor.splat %86 {prov.region_id = "scan_0", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64>
    %88 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iterator_types = ["parallel", "parallel", "reduction"]} ins(%81 : tensor<1x4xi1>) outs(%87 : tensor<1x4xi64>) attrs =  {prov.region_id = "scan_0", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb7(%89: i1, %90: i64):
      %91 = linalg.index 1 : index
      %92 = linalg.index 2 : index
      %93 = arith.cmpi ule, %92, %91 : index
      %94 = arith.extui %89 : i1 to i64
      %95 = arith.select %93, %94, %86 : i64
      %96 = arith.addi %90, %95 : i64
      linalg.yield %96 : i64
    } -> tensor<1x4xi64>
    %97 = tensor.empty() : tensor<1xi64>
    %98 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%97 : tensor<1xi64>) attrs =  {prov.region_id = "iota_1", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb8(%99: i64):
      %100 = linalg.index 0 : index
      %101 = arith.index_cast %100 : index to i64
      %102 = arith.constant 1 : i64
      %103 = arith.muli %101, %102 : i64
      %104 = arith.constant 0 : i64
      %105 = arith.addi %104, %103 : i64
      linalg.yield %105 : i64
    } -> tensor<1xi64>
    %106 = tensor.empty() : tensor<4xi64>
    %107 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%106 : tensor<4xi64>) attrs =  {prov.region_id = "iota_2", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb9(%108: i64):
      %109 = linalg.index 0 : index
      %110 = arith.index_cast %109 : index to i64
      %111 = arith.constant 1 : i64
      %112 = arith.muli %110, %111 : i64
      %113 = arith.constant 0 : i64
      %114 = arith.addi %113, %112 : i64
      linalg.yield %114 : i64
    } -> tensor<4xi64>
    %115 = arith.constant {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %116 = tensor.splat %115 {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %117 = tensor.empty() : tensor<4xi64>
    %118 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%107, %116 : tensor<4xi64>, tensor<4xi64>) outs(%117 : tensor<4xi64>) attrs =  {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb10(%119: i64, %120: i64, %121: i64):
      %122 = arith.addi %119, %120 : i64
      linalg.yield %122 : i64
    } -> tensor<4xi64>
    %123 = tensor.empty() : tensor<4xi64>
    %124 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%123 : tensor<4xi64>) attrs =  {prov.region_id = "iota_3", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb11(%125: i64):
      %126 = linalg.index 0 : index
      %127 = arith.index_cast %126 : index to i64
      %128 = arith.constant 1 : i64
      %129 = arith.muli %127, %128 : i64
      %130 = arith.constant 0 : i64
      %131 = arith.addi %130, %129 : i64
      linalg.yield %131 : i64
    } -> tensor<4xi64>
    %132 = arith.constant {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %133 = tensor.splat %132 {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %134 = tensor.empty() : tensor<4xi64>
    %135 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%124, %133 : tensor<4xi64>, tensor<4xi64>) outs(%134 : tensor<4xi64>) attrs =  {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb12(%136: i64, %137: i64, %138: i64):
      %139 = arith.addi %136, %137 : i64
      linalg.yield %139 : i64
    } -> tensor<4xi64>
    %140 = tensor.expand_shape %98 [[0 : i64, 1 : i64]] output_shape [1, 1] {prov.region_id = "unsqueeze_1", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1xi64>
    %141 = tensor.collapse_shape %140 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_2", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1xi64> into tensor<1xi64>
    %142 = tensor.expand_shape %141 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 1] {prov.region_id = "unsqueeze_2", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1x1xi64>
    %143 = tensor.collapse_shape %142 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_3", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x1xi64> into tensor<1xi64>
    %144 = tensor.expand_shape %143 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 1, 1] {prov.region_id = "unsqueeze_3", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1x1x1xi64>
    %145 = tensor.expand_shape %118 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_4", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %146 = tensor.collapse_shape %145 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_5", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64> into tensor<4xi64>
    %147 = tensor.expand_shape %146 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_5", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4xi64>
    %148 = tensor.collapse_shape %147 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_6", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x4xi64> into tensor<4xi64>
    %149 = tensor.expand_shape %148 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 1] {prov.region_id = "unsqueeze_6", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4x1xi64>
    %150 = tensor.expand_shape %135 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_7", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %151 = tensor.collapse_shape %150 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_8", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64> into tensor<4xi64>
    %152 = tensor.expand_shape %151 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_8", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4xi64>
    %153 = tensor.collapse_shape %152 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_9", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x4xi64> into tensor<4xi64>
    %154 = tensor.expand_shape %153 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 1, 4] {prov.region_id = "unsqueeze_9", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x1x4xi64>
    %155 = arith.constant {prov.region_id = "fill_0", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} true
    %156 = tensor.splat %155 {prov.region_id = "fill_0", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} : tensor<i1>
    %157 = tensor.empty() : tensor<1x1x4x4xi1>
    %158 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%154, %149 : tensor<1x1x1x4xi64>, tensor<1x1x4x1xi64>) outs(%157 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "compare_1", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.le.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb13(%159: i64, %160: i64, %161: i1):
      %162 = arith.cmpi sle, %159, %160 : i64
      linalg.yield %162 : i1
    } -> tensor<1x1x4x4xi1>
    %163 = tensor.empty() : tensor<1x1x4x4xi1>
    %164 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> ()>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%156, %158 : tensor<i1>, tensor<1x1x4x4xi1>) outs(%163 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_0", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb14(%165: i1, %166: i1, %167: i1):
      %168 = arith.andi %165, %166 : i1
      linalg.yield %168 : i1
    } -> tensor<1x1x4x4xi1>
    %169 = tensor.empty() : tensor<1x1x4x1xi64>
    %170 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%144, %149 : tensor<1x1x1x1xi64>, tensor<1x1x4x1xi64>) outs(%169 : tensor<1x1x4x1xi64>) attrs =  {prov.region_id = "gather_1", prov.family = "gather_scatter", prov._pattern_hint = "index_gather", prov.op = "index_gather", prov.aten = "aten.index.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb15(%171: i64, %172: i64, %173: i64):
      %174 = arith.index_cast %171 : i64 to index
      %175 = arith.index_cast %172 : i64 to index
      %176 = tensor.extract %88[%174, %175] : tensor<1x4xi64>
      linalg.yield %176 : i64
    } -> tensor<1x1x4x1xi64>
    %177 = tensor.empty() : tensor<1x1x1x4xi64>
    %178 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%144, %154 : tensor<1x1x1x1xi64>, tensor<1x1x1x4xi64>) outs(%177 : tensor<1x1x1x4xi64>) attrs =  {prov.region_id = "gather_2", prov.family = "gather_scatter", prov._pattern_hint = "index_gather", prov.op = "index_gather", prov.aten = "aten.index.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb16(%179: i64, %180: i64, %181: i64):
      %182 = arith.index_cast %179 : i64 to index
      %183 = arith.index_cast %180 : i64 to index
      %184 = tensor.extract %88[%182, %183] : tensor<1x4xi64>
      linalg.yield %184 : i64
    } -> tensor<1x1x1x4xi64>
    %185 = tensor.empty() : tensor<1x1x4x4xi1>
    %186 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%170, %178 : tensor<1x1x4x1xi64>, tensor<1x1x1x4xi64>) outs(%185 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "compare_2", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.eq.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb17(%187: i64, %188: i64, %189: i1):
      %190 = arith.cmpi eq, %187, %188 : i64
      linalg.yield %190 : i1
    } -> tensor<1x1x4x4xi1>
    %191 = tensor.empty() : tensor<1x1x4x4xi1>
    %192 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%164, %186 : tensor<1x1x4x4xi1>, tensor<1x1x4x4xi1>) outs(%191 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_1", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb18(%193: i1, %194: i1, %195: i1):
      %196 = arith.andi %193, %194 : i1
      linalg.yield %196 : i1
    } -> tensor<1x1x4x4xi1>
    %197 = tensor.empty() : tensor<1x1x4x4xi1>
    %198 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%192 : tensor<1x1x4x4xi1>) outs(%197 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "expand_0", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb19(%199: i1, %200: i1):
      linalg.yield %199 : i1
    } -> tensor<1x1x4x4xi1>
    %201 = "tensor.extract_slice"(%59) <{static_offsets = array<i64: 0, 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_3", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x4xi64>) -> tensor<1x1xi64>
    %202 = arith.constant {prov.region_id = "sub_2", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 1 : i64
    %203 = tensor.splat %202 {prov.region_id = "sub_2", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1xi64>
    %204 = tensor.empty() : tensor<1x1xi64>
    %205 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%201, %203 : tensor<1x1xi64>, tensor<1x1xi64>) outs(%204 : tensor<1x1xi64>) attrs =  {prov.region_id = "sub_2", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb20(%206: i64, %207: i64, %208: i64):
      %209 = arith.subi %206, %207 : i64
      linalg.yield %209 : i64
    } -> tensor<1x1xi64>
    %210 = tensor.concat dim(1) %205, %59 {prov.region_id = "cat_1", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x1xi64>, tensor<1x4xi64>) -> tensor<1x5xi64>
    %211 = "tensor.extract_slice"(%210) <{static_offsets = array<i64: 0, 0>, static_sizes = array<i64: 1, 4>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_4", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x5xi64>) -> tensor<1x4xi64>
    %212 = "tensor.extract_slice"(%210) <{static_offsets = array<i64: 0, 1>, static_sizes = array<i64: 1, 4>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_5", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x5xi64>) -> tensor<1x4xi64>
    %213 = tensor.empty() : tensor<1x4xi64>
    %214 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%212, %211 : tensor<1x4xi64>, tensor<1x4xi64>) outs(%213 : tensor<1x4xi64>) attrs =  {prov.region_id = "sub_3", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb21(%215: i64, %216: i64, %217: i64):
      %218 = arith.subi %215, %216 : i64
      linalg.yield %218 : i64
    } -> tensor<1x4xi64>
    %219 = arith.constant {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} 1 : i64
    %220 = tensor.splat %219 {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64>
    %221 = tensor.empty() : tensor<1x4xi1>
    %222 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%214, %220 : tensor<1x4xi64>, tensor<1x4xi64>) outs(%221 : tensor<1x4xi1>) attrs =  {prov.region_id = "compare_3", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb22(%223: i64, %224: i64, %225: i1):
      %226 = arith.cmpi ne, %223, %224 : i64
      linalg.yield %226 : i1
    } -> tensor<1x4xi1>
    %227 = arith.constant {prov.region_id = "scan_1", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %228 = tensor.splat %227 {prov.region_id = "scan_1", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64>
    %229 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iterator_types = ["parallel", "parallel", "reduction"]} ins(%222 : tensor<1x4xi1>) outs(%228 : tensor<1x4xi64>) attrs =  {prov.region_id = "scan_1", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb23(%230: i1, %231: i64):
      %232 = linalg.index 1 : index
      %233 = linalg.index 2 : index
      %234 = arith.cmpi ule, %233, %232 : index
      %235 = arith.extui %230 : i1 to i64
      %236 = arith.select %234, %235, %227 : i64
      %237 = arith.addi %231, %236 : i64
      linalg.yield %237 : i64
    } -> tensor<1x4xi64>
    %238 = tensor.empty() : tensor<1xi64>
    %239 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%238 : tensor<1xi64>) attrs =  {prov.region_id = "iota_4", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb24(%240: i64):
      %241 = linalg.index 0 : index
      %242 = arith.index_cast %241 : index to i64
      %243 = arith.constant 1 : i64
      %244 = arith.muli %242, %243 : i64
      %245 = arith.constant 0 : i64
      %246 = arith.addi %245, %244 : i64
      linalg.yield %246 : i64
    } -> tensor<1xi64>
    %247 = tensor.empty() : tensor<4xi64>
    %248 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%247 : tensor<4xi64>) attrs =  {prov.region_id = "iota_5", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb25(%249: i64):
      %250 = linalg.index 0 : index
      %251 = arith.index_cast %250 : index to i64
      %252 = arith.constant 1 : i64
      %253 = arith.muli %251, %252 : i64
      %254 = arith.constant 0 : i64
      %255 = arith.addi %254, %253 : i64
      linalg.yield %255 : i64
    } -> tensor<4xi64>
    %256 = arith.constant {prov.region_id = "add_3", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %257 = tensor.splat %256 {prov.region_id = "add_3", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %258 = tensor.empty() : tensor<4xi64>
    %259 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%248, %257 : tensor<4xi64>, tensor<4xi64>) outs(%258 : tensor<4xi64>) attrs =  {prov.region_id = "add_3", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb26(%260: i64, %261: i64, %262: i64):
      %263 = arith.addi %260, %261 : i64
      linalg.yield %263 : i64
    } -> tensor<4xi64>
    %264 = tensor.empty() : tensor<4xi64>
    %265 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%264 : tensor<4xi64>) attrs =  {prov.region_id = "iota_6", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb27(%266: i64):
      %267 = linalg.index 0 : index
      %268 = arith.index_cast %267 : index to i64
      %269 = arith.constant 1 : i64
      %270 = arith.muli %268, %269 : i64
      %271 = arith.constant 0 : i64
      %272 = arith.addi %271, %270 : i64
      linalg.yield %272 : i64
    } -> tensor<4xi64>
    %273 = arith.constant {prov.region_id = "add_4", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %274 = tensor.splat %273 {prov.region_id = "add_4", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %275 = tensor.empty() : tensor<4xi64>
    %276 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%265, %274 : tensor<4xi64>, tensor<4xi64>) outs(%275 : tensor<4xi64>) attrs =  {prov.region_id = "add_4", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb28(%277: i64, %278: i64, %279: i64):
      %280 = arith.addi %277, %278 : i64
      linalg.yield %280 : i64
    } -> tensor<4xi64>
    %281 = tensor.expand_shape %239 [[0 : i64, 1 : i64]] output_shape [1, 1] {prov.region_id = "unsqueeze_10", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1xi64>
    %282 = tensor.collapse_shape %281 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_11", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1xi64> into tensor<1xi64>
    %283 = tensor.expand_shape %282 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 1] {prov.region_id = "unsqueeze_11", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1x1xi64>
    %284 = tensor.collapse_shape %283 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_12", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x1xi64> into tensor<1xi64>
    %285 = tensor.expand_shape %284 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 1, 1] {prov.region_id = "unsqueeze_12", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1x1x1xi64>
    %286 = tensor.expand_shape %259 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_13", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %287 = tensor.collapse_shape %286 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_14", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64> into tensor<4xi64>
    %288 = tensor.expand_shape %287 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_14", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4xi64>
    %289 = tensor.collapse_shape %288 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_15", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x4xi64> into tensor<4xi64>
    %290 = tensor.expand_shape %289 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 1] {prov.region_id = "unsqueeze_15", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4x1xi64>
    %291 = tensor.expand_shape %276 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_16", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %292 = tensor.collapse_shape %291 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_17", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64> into tensor<4xi64>
    %293 = tensor.expand_shape %292 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_17", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4xi64>
    %294 = tensor.collapse_shape %293 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_18", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x4xi64> into tensor<4xi64>
    %295 = tensor.expand_shape %294 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 1, 4] {prov.region_id = "unsqueeze_18", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x1x4xi64>
    %296 = arith.constant {prov.region_id = "fill_1", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} true
    %297 = tensor.splat %296 {prov.region_id = "fill_1", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} : tensor<i1>
    %298 = arith.constant {prov.region_id = "fill_2", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} true
    %299 = tensor.splat %298 {prov.region_id = "fill_2", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} : tensor<i1>
    %300 = arith.constant {prov.region_id = "sub_4", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 4096 : i64
    %301 = tensor.splat %300 {prov.region_id = "sub_4", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x4x1xi64>
    %302 = tensor.empty() : tensor<1x1x4x1xi64>
    %303 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%290, %301 : tensor<1x1x4x1xi64>, tensor<1x1x4x1xi64>) outs(%302 : tensor<1x1x4x1xi64>) attrs =  {prov.region_id = "sub_4", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb29(%304: i64, %305: i64, %306: i64):
      %307 = arith.subi %304, %305 : i64
      linalg.yield %307 : i64
    } -> tensor<1x1x4x1xi64>
    %308 = tensor.empty() : tensor<1x1x4x4xi1>
    %309 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%295, %303 : tensor<1x1x1x4xi64>, tensor<1x1x4x1xi64>) outs(%308 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "compare_4", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.gt.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb30(%310: i64, %311: i64, %312: i1):
      %313 = arith.cmpi sgt, %310, %311 : i64
      linalg.yield %313 : i1
    } -> tensor<1x1x4x4xi1>
    %314 = tensor.empty() : tensor<1x1x4x4xi1>
    %315 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> ()>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%299, %309 : tensor<i1>, tensor<1x1x4x4xi1>) outs(%314 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_2", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb31(%316: i1, %317: i1, %318: i1):
      %319 = arith.andi %316, %317 : i1
      linalg.yield %319 : i1
    } -> tensor<1x1x4x4xi1>
    %320 = tensor.empty() : tensor<1x1x4x4xi1>
    %321 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%295, %290 : tensor<1x1x1x4xi64>, tensor<1x1x4x1xi64>) outs(%320 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "compare_5", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.le.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb32(%322: i64, %323: i64, %324: i1):
      %325 = arith.cmpi sle, %322, %323 : i64
      linalg.yield %325 : i1
    } -> tensor<1x1x4x4xi1>
    %326 = tensor.empty() : tensor<1x1x4x4xi1>
    %327 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%315, %321 : tensor<1x1x4x4xi1>, tensor<1x1x4x4xi1>) outs(%326 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_3", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb33(%328: i1, %329: i1, %330: i1):
      %331 = arith.andi %328, %329 : i1
      linalg.yield %331 : i1
    } -> tensor<1x1x4x4xi1>
    %332 = tensor.empty() : tensor<1x1x4x4xi1>
    %333 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> ()>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%297, %327 : tensor<i1>, tensor<1x1x4x4xi1>) outs(%332 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_4", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb34(%334: i1, %335: i1, %336: i1):
      %337 = arith.andi %334, %335 : i1
      linalg.yield %337 : i1
    } -> tensor<1x1x4x4xi1>
    %338 = tensor.empty() : tensor<1x1x4x1xi64>
    %339 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%285, %290 : tensor<1x1x1x1xi64>, tensor<1x1x4x1xi64>) outs(%338 : tensor<1x1x4x1xi64>) attrs =  {prov.region_id = "gather_3", prov.family = "gather_scatter", prov._pattern_hint = "index_gather", prov.op = "index_gather", prov.aten = "aten.index.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb35(%340: i64, %341: i64, %342: i64):
      %343 = arith.index_cast %340 : i64 to index
      %344 = arith.index_cast %341 : i64 to index
      %345 = tensor.extract %229[%343, %344] : tensor<1x4xi64>
      linalg.yield %345 : i64
    } -> tensor<1x1x4x1xi64>
    %346 = tensor.empty() : tensor<1x1x1x4xi64>
    %347 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%285, %295 : tensor<1x1x1x1xi64>, tensor<1x1x1x4xi64>) outs(%346 : tensor<1x1x1x4xi64>) attrs =  {prov.region_id = "gather_4", prov.family = "gather_scatter", prov._pattern_hint = "index_gather", prov.op = "index_gather", prov.aten = "aten.index.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb36(%348: i64, %349: i64, %350: i64):
      %351 = arith.index_cast %348 : i64 to index
      %352 = arith.index_cast %349 : i64 to index
      %353 = tensor.extract %229[%351, %352] : tensor<1x4xi64>
      linalg.yield %353 : i64
    } -> tensor<1x1x1x4xi64>
    %354 = tensor.empty() : tensor<1x1x4x4xi1>
    %355 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%339, %347 : tensor<1x1x4x1xi64>, tensor<1x1x1x4xi64>) outs(%354 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "compare_6", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.eq.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb37(%356: i64, %357: i64, %358: i1):
      %359 = arith.cmpi eq, %356, %357 : i64
      linalg.yield %359 : i1
    } -> tensor<1x1x4x4xi1>
    %360 = tensor.empty() : tensor<1x1x4x4xi1>
    %361 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%333, %355 : tensor<1x1x4x4xi1>, tensor<1x1x4x4xi1>) outs(%360 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_5", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb38(%362: i1, %363: i1, %364: i1):
      %365 = arith.andi %362, %363 : i1
      linalg.yield %365 : i1
    } -> tensor<1x1x4x4xi1>
    %366 = tensor.empty() : tensor<1x1x4x4xi1>
    %367 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%361 : tensor<1x1x4x4xi1>) outs(%366 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "expand_1", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb39(%368: i1, %369: i1):
      linalg.yield %368 : i1
    } -> tensor<1x1x4x4xi1>
    %370 = tensor.expand_shape %26 [[0 : i64, 1 : i64]] output_shape [1, 128] {prov.region_id = "unsqueeze_19", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<128xf32> into tensor<1x128xf32>
    %371 = tensor.collapse_shape %370 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_20", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x128xf32> into tensor<128xf32>
    %372 = tensor.expand_shape %371 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 128, 1] {prov.region_id = "unsqueeze_20", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<128xf32> into tensor<1x128x1xf32>
    %373 = tensor.empty() : tensor<1x128x1xf32>
    %374 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%372 : tensor<1x128x1xf32>) outs(%373 : tensor<1x128x1xf32>) attrs =  {prov.region_id = "expand_2", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb40(%375: f32, %376: f32):
      linalg.yield %375 : f32
    } -> tensor<1x128x1xf32>
    %377 = tensor.collapse_shape %59 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_21", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x4xi64> into tensor<4xi64>
    %378 = tensor.expand_shape %377 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_21", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<4xi64> into tensor<1x1x4xi64>
    %379 = tensor.empty() : tensor<1x1x4xf32>
    %380 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%378 : tensor<1x1x4xi64>) outs(%379 : tensor<1x1x4xf32>) attrs =  {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb41(%381: i64, %382: f32):
      %383 = arith.sitofp %381 : i64 to f32
      linalg.yield %383 : f32
    } -> tensor<1x1x4xf32>
    %384 = tensor.empty() : tensor<1x128x1xf32>
    %385 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%374 : tensor<1x128x1xf32>) outs(%384 : tensor<1x128x1xf32>) attrs =  {prov.region_id = "expand_3", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb42(%386: f32, %387: f32):
      linalg.yield %386 : f32
    } -> tensor<1x128x1xf32>
    %388 = tensor.empty() : tensor<1x1x4xf32>
    %389 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%380 : tensor<1x1x4xf32>) outs(%388 : tensor<1x1x4xf32>) attrs =  {prov.region_id = "expand_4", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb43(%390: f32, %391: f32):
      linalg.yield %390 : f32
    } -> tensor<1x1x4xf32>
    %392 = arith.constant {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} 0.000000e+00 : f32
    %393 = tensor.splat %392 {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x128x4xf32>
    %394 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%385, %389 : tensor<1x128x1xf32>, tensor<1x1x4xf32>) outs(%393 : tensor<1x128x4xf32>) attrs =  {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb44(%395: f32, %396: f32, %397: f32):
      %398 = arith.mulf %395, %396 : f32
      %399 = arith.addf %397, %398 : f32
      linalg.yield %399 : f32
    } -> tensor<1x128x4xf32>
    %400 = tensor.empty() : tensor<1x4x128xf32>
    %401 = linalg.transpose ins(%394:tensor<1x128x4xf32>) outs(%400:tensor<1x4x128xf32>) permutation = [0, 2, 1]
    %402 = tensor.concat dim(2) %401, %401 {prov.region_id = "cat_2", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : (tensor<1x4x128xf32>, tensor<1x4x128xf32>) -> tensor<1x4x256xf32>
    %403 = tensor.empty() : tensor<1x4x256xf32>
    %404 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%402 : tensor<1x4x256xf32>) outs(%403 : tensor<1x4x256xf32>) attrs =  {prov.region_id = "cos_0", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb45(%405: f32, %406: f32):
      %407 = math.cos %405 : f32
      linalg.yield %407 : f32
    } -> tensor<1x4x256xf32>
    %408 = arith.constant {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} 1.000000e+00 : f32
    %409 = tensor.splat %408 {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x4x256xf32>
    %410 = tensor.empty() : tensor<1x4x256xf32>
    %411 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%404, %409 : tensor<1x4x256xf32>, tensor<1x4x256xf32>) outs(%410 : tensor<1x4x256xf32>) attrs =  {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb46(%412: f32, %413: f32, %414: f32):
      %415 = arith.mulf %412, %413 : f32
      linalg.yield %415 : f32
    } -> tensor<1x4x256xf32>
    %416 = tensor.empty() : tensor<1x4x256xf32>
    %417 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%402 : tensor<1x4x256xf32>) outs(%416 : tensor<1x4x256xf32>) attrs =  {prov.region_id = "sin_0", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb47(%418: f32, %419: f32):
      %420 = math.sin %418 : f32
      linalg.yield %420 : f32
    } -> tensor<1x4x256xf32>
    %421 = arith.constant {prov.region_id = "mul_2", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} 1.000000e+00 : f32
    %422 = tensor.splat %421 {prov.region_id = "mul_2", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x4x256xf32>
    %423 = tensor.empty() : tensor<1x4x256xf32>
    %424 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%417, %422 : tensor<1x4x256xf32>, tensor<1x4x256xf32>) outs(%423 : tensor<1x4x256xf32>) attrs =  {prov.region_id = "mul_2", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb48(%425: f32, %426: f32, %427: f32):
      %428 = arith.mulf %425, %426 : f32
      linalg.yield %428 : f32
    } -> tensor<1x4x256xf32>
    %429 = tensor.empty() : tensor<1x4x2304xf32>
    %430 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%37 : tensor<1x4x2304xf32>) outs(%429 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_0", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb49(%431: f32, %432: f32):
      %433 = arith.constant 2.000000e+00 : f32
      %434 = math.powf %431, %433 : f32
      linalg.yield %434 : f32
    } -> tensor<1x4x2304xf32>
    %435 = arith.constant {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} 0.000000e+00 : f32
    %436 = tensor.splat %435 {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4xf32>
    %437 = linalg.reduce ins(%430:tensor<1x4x2304xf32>) outs(%436:tensor<1x4xf32>) dimensions = [2]
    (%438: f32, %439: f32) {
      %440 = arith.addf %438, %439 : f32
      linalg.yield %440 : f32
    }
    %441 = arith.constant {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} 2.304000e+03 : f32
    %442 = tensor.splat %441 {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4xf32>
    %443 = tensor.empty() : tensor<1x4xf32>
    %444 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%437, %442 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%443 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb50(%445: f32, %446: f32, %447: f32):
      %448 = arith.divf %445, %446 : f32
      linalg.yield %448 : f32
    } -> tensor<1x4xf32>
    %449 = tensor.collapse_shape %444 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %450 = tensor.expand_shape %449 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %451 = arith.constant {prov.region_id = "add_5", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} 1.000000e-06 : f32
    %452 = tensor.splat %451 {prov.region_id = "add_5", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4x1xf32>
    %453 = tensor.empty() : tensor<1x4x1xf32>
    %454 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%450, %452 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%453 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_5", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb51(%455: f32, %456: f32, %457: f32):
      %458 = arith.addf %455, %456 : f32
      linalg.yield %458 : f32
    } -> tensor<1x4x1xf32>
    %459 = tensor.empty() : tensor<1x4x1xf32>
    %460 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%454 : tensor<1x4x1xf32>) outs(%459 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_0", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb52(%461: f32, %462: f32):
      %463 = math.rsqrt %461 : f32
      linalg.yield %463 : f32
    } -> tensor<1x4x1xf32>
    %464 = tensor.empty() : tensor<1x4x2304xf32>
    %465 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%37, %460 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%464 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_3", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb53(%466: f32, %467: f32, %468: f32):
      %469 = arith.mulf %466, %467 : f32
      linalg.yield %469 : f32
    } -> tensor<1x4x2304xf32>
    %470 = arith.constant {prov.region_id = "add_6", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} 1.000000e+00 : f32
    %471 = tensor.splat %470 {prov.region_id = "add_6", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<2304xf32>
    %472 = tensor.empty() : tensor<2304xf32>
    %473 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%8, %471 : tensor<2304xf32>, tensor<2304xf32>) outs(%472 : tensor<2304xf32>) attrs =  {prov.region_id = "add_6", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb54(%474: f32, %475: f32, %476: f32):
      %477 = arith.addf %474, %475 : f32
      linalg.yield %477 : f32
    } -> tensor<2304xf32>
    %478 = tensor.empty() : tensor<1x4x2304xf32>
    %479 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%465, %473 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%478 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_4", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb55(%480: f32, %481: f32, %482: f32):
      %483 = arith.mulf %480, %481 : f32
      linalg.yield %483 : f32
    } -> tensor<1x4x2304xf32>
    %484 = tensor.empty() : tensor<2304x2048xf32>
    %485 = linalg.transpose ins(%1:tensor<2048x2304xf32>) outs(%484:tensor<2304x2048xf32>) permutation = [1, 0]
    %486 = tensor.collapse_shape %479 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_3", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %487 = tensor.expand_shape %486 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_3", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %488 = tensor.empty() : tensor<4x2048xf32>
    %489 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %490 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%489 : f32) outs(%488 : tensor<4x2048xf32>) -> tensor<4x2048xf32>
    %491 = linalg.matmul {prov.region_id = "matmul_1", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj", prov.transposed_b = "true"} ins(%487, %485 : tensor<4x2304xf32>, tensor<2304x2048xf32>) outs(%490 : tensor<4x2048xf32>) -> tensor<4x2048xf32>
    %492 = tensor.collapse_shape %491 [[0 : i64, 1 : i64]] {prov.region_id = "view_4", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<4x2048xf32> into tensor<8192xf32>
    %493 = tensor.expand_shape %492 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2048] {prov.region_id = "view_4", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<8192xf32> into tensor<1x4x2048xf32>
    %494 = tensor.collapse_shape %493 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_5", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x2048xf32> into tensor<8192xf32>
    %495 = tensor.expand_shape %494 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 256] {prov.region_id = "view_5", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<1x4x8x256xf32>
    %496 = tensor.empty() : tensor<1x8x4x256xf32>
    %497 = linalg.transpose ins(%495:tensor<1x4x8x256xf32>) outs(%496:tensor<1x8x4x256xf32>) permutation = [0, 2, 1, 3]
    %498 = tensor.empty() : tensor<2304x1024xf32>
    %499 = linalg.transpose ins(%2:tensor<1024x2304xf32>) outs(%498:tensor<2304x1024xf32>) permutation = [1, 0]
    %500 = tensor.collapse_shape %479 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_6", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %501 = tensor.expand_shape %500 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_6", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %502 = tensor.empty() : tensor<4x1024xf32>
    %503 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %504 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%503 : f32) outs(%502 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %505 = linalg.matmul {prov.region_id = "matmul_2", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj", prov.transposed_b = "true"} ins(%501, %499 : tensor<4x2304xf32>, tensor<2304x1024xf32>) outs(%504 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %506 = tensor.collapse_shape %505 [[0 : i64, 1 : i64]] {prov.region_id = "view_7", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<4x1024xf32> into tensor<4096xf32>
    %507 = tensor.expand_shape %506 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1024] {prov.region_id = "view_7", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<4096xf32> into tensor<1x4x1024xf32>
    %508 = tensor.collapse_shape %507 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_8", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x1024xf32> into tensor<4096xf32>
    %509 = tensor.expand_shape %508 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 4, 256] {prov.region_id = "view_8", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<4096xf32> into tensor<1x4x4x256xf32>
    %510 = tensor.empty() : tensor<1x4x4x256xf32>
    %511 = linalg.transpose ins(%509:tensor<1x4x4x256xf32>) outs(%510:tensor<1x4x4x256xf32>) permutation = [0, 2, 1, 3]
    %512 = tensor.empty() : tensor<2304x1024xf32>
    %513 = linalg.transpose ins(%3:tensor<1024x2304xf32>) outs(%512:tensor<2304x1024xf32>) permutation = [1, 0]
    %514 = tensor.collapse_shape %479 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_9", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %515 = tensor.expand_shape %514 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_9", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %516 = tensor.empty() : tensor<4x1024xf32>
    %517 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %518 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%517 : f32) outs(%516 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %519 = linalg.matmul {prov.region_id = "matmul_3", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj", prov.transposed_b = "true"} ins(%515, %513 : tensor<4x2304xf32>, tensor<2304x1024xf32>) outs(%518 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %520 = tensor.collapse_shape %519 [[0 : i64, 1 : i64]] {prov.region_id = "view_10", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<4x1024xf32> into tensor<4096xf32>
    %521 = tensor.expand_shape %520 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1024] {prov.region_id = "view_10", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<4096xf32> into tensor<1x4x1024xf32>
    %522 = tensor.collapse_shape %521 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_11", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x1024xf32> into tensor<4096xf32>
    %523 = tensor.expand_shape %522 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 4, 256] {prov.region_id = "view_11", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<4096xf32> into tensor<1x4x4x256xf32>
    %524 = tensor.empty() : tensor<1x4x4x256xf32>
    %525 = linalg.transpose ins(%523:tensor<1x4x4x256xf32>) outs(%524:tensor<1x4x4x256xf32>) permutation = [0, 2, 1, 3]
    %526 = tensor.collapse_shape %411 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_22", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x256xf32> into tensor<1024xf32>
    %527 = tensor.expand_shape %526 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 256] {prov.region_id = "unsqueeze_22", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1024xf32> into tensor<1x1x4x256xf32>
    %528 = tensor.collapse_shape %424 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_23", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x256xf32> into tensor<1024xf32>
    %529 = tensor.expand_shape %528 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 256] {prov.region_id = "unsqueeze_23", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1024xf32> into tensor<1x1x4x256xf32>
    %530 = tensor.empty() : tensor<1x8x4x256xf32>
    %531 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%497, %527 : tensor<1x8x4x256xf32>, tensor<1x1x4x256xf32>) outs(%530 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "mul_5", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb56(%532: f32, %533: f32, %534: f32):
      %535 = arith.mulf %532, %533 : f32
      linalg.yield %535 : f32
    } -> tensor<1x8x4x256xf32>
    %536 = "tensor.extract_slice"(%497) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 8, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_6", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x8x4x256xf32>) -> tensor<1x8x4x128xf32>
    %537 = "tensor.extract_slice"(%497) <{static_offsets = array<i64: 0, 0, 0, 128>, static_sizes = array<i64: 1, 8, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_7", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x8x4x256xf32>) -> tensor<1x8x4x128xf32>
    %538 = tensor.empty() : tensor<1x8x4x128xf32>
    %539 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%537 : tensor<1x8x4x128xf32>) outs(%538 : tensor<1x8x4x128xf32>) attrs =  {prov.region_id = "neg_0", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb57(%540: f32, %541: f32):
      %542 = arith.negf %540 : f32
      linalg.yield %542 : f32
    } -> tensor<1x8x4x128xf32>
    %543 = tensor.concat dim(3) %539, %536 {prov.region_id = "cat_3", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x8x4x128xf32>, tensor<1x8x4x128xf32>) -> tensor<1x8x4x256xf32>
    %544 = tensor.empty() : tensor<1x8x4x256xf32>
    %545 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%543, %529 : tensor<1x8x4x256xf32>, tensor<1x1x4x256xf32>) outs(%544 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "mul_6", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb58(%546: f32, %547: f32, %548: f32):
      %549 = arith.mulf %546, %547 : f32
      linalg.yield %549 : f32
    } -> tensor<1x8x4x256xf32>
    %550 = tensor.empty() : tensor<1x8x4x256xf32>
    %551 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%531, %545 : tensor<1x8x4x256xf32>, tensor<1x8x4x256xf32>) outs(%550 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "add_7", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb59(%552: f32, %553: f32, %554: f32):
      %555 = arith.addf %552, %553 : f32
      linalg.yield %555 : f32
    } -> tensor<1x8x4x256xf32>
    %556 = tensor.empty() : tensor<1x4x4x256xf32>
    %557 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%511, %527 : tensor<1x4x4x256xf32>, tensor<1x1x4x256xf32>) outs(%556 : tensor<1x4x4x256xf32>) attrs =  {prov.region_id = "mul_7", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb60(%558: f32, %559: f32, %560: f32):
      %561 = arith.mulf %558, %559 : f32
      linalg.yield %561 : f32
    } -> tensor<1x4x4x256xf32>
    %562 = "tensor.extract_slice"(%511) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 4, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_8", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x4x4x256xf32>) -> tensor<1x4x4x128xf32>
    %563 = "tensor.extract_slice"(%511) <{static_offsets = array<i64: 0, 0, 0, 128>, static_sizes = array<i64: 1, 4, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_9", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x4x4x256xf32>) -> tensor<1x4x4x128xf32>
    %564 = tensor.empty() : tensor<1x4x4x128xf32>
    %565 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%563 : tensor<1x4x4x128xf32>) outs(%564 : tensor<1x4x4x128xf32>) attrs =  {prov.region_id = "neg_1", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb61(%566: f32, %567: f32):
      %568 = arith.negf %566 : f32
      linalg.yield %568 : f32
    } -> tensor<1x4x4x128xf32>
    %569 = tensor.concat dim(3) %565, %562 {prov.region_id = "cat_4", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x4x4x128xf32>, tensor<1x4x4x128xf32>) -> tensor<1x4x4x256xf32>
    %570 = tensor.empty() : tensor<1x4x4x256xf32>
    %571 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%569, %529 : tensor<1x4x4x256xf32>, tensor<1x1x4x256xf32>) outs(%570 : tensor<1x4x4x256xf32>) attrs =  {prov.region_id = "mul_8", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb62(%572: f32, %573: f32, %574: f32):
      %575 = arith.mulf %572, %573 : f32
      linalg.yield %575 : f32
    } -> tensor<1x4x4x256xf32>
    %576 = tensor.empty() : tensor<1x4x4x256xf32>
    %577 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%557, %571 : tensor<1x4x4x256xf32>, tensor<1x4x4x256xf32>) outs(%576 : tensor<1x4x4x256xf32>) attrs =  {prov.region_id = "add_8", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb63(%578: f32, %579: f32, %580: f32):
      %581 = arith.addf %578, %579 : f32
      linalg.yield %581 : f32
    } -> tensor<1x4x4x256xf32>
    %582 = tensor.collapse_shape %577 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "unsqueeze_24", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x4x256xf32> into tensor<4096xf32>
    %583 = tensor.expand_shape %582 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] output_shape [1, 4, 1, 4, 256] {prov.region_id = "unsqueeze_24", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<4096xf32> into tensor<1x4x1x4x256xf32>
    %584 = tensor.empty() : tensor<1x4x2x4x256xf32>
    %585 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, 0, d3, d4)>, affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, d2, d3, d4)>], iterator_types = ["parallel", "parallel", "parallel", "parallel", "parallel"]} ins(%583 : tensor<1x4x1x4x256xf32>) outs(%584 : tensor<1x4x2x4x256xf32>) attrs =  {prov.region_id = "expand_5", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb64(%586: f32, %587: f32):
      linalg.yield %586 : f32
    } -> tensor<1x4x2x4x256xf32>
    %588 = tensor.collapse_shape %585 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] {prov.region_id = "view_12", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x2x4x256xf32> into tensor<8192xf32>
    %589 = tensor.expand_shape %588 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 256] {prov.region_id = "view_12", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<1x8x4x256xf32>
    %590 = tensor.collapse_shape %525 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "unsqueeze_25", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x4x256xf32> into tensor<4096xf32>
    %591 = tensor.expand_shape %590 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] output_shape [1, 4, 1, 4, 256] {prov.region_id = "unsqueeze_25", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<4096xf32> into tensor<1x4x1x4x256xf32>
    %592 = tensor.empty() : tensor<1x4x2x4x256xf32>
    %593 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, 0, d3, d4)>, affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, d2, d3, d4)>], iterator_types = ["parallel", "parallel", "parallel", "parallel", "parallel"]} ins(%591 : tensor<1x4x1x4x256xf32>) outs(%592 : tensor<1x4x2x4x256xf32>) attrs =  {prov.region_id = "expand_6", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb65(%594: f32, %595: f32):
      linalg.yield %594 : f32
    } -> tensor<1x4x2x4x256xf32>
    %596 = tensor.collapse_shape %593 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] {prov.region_id = "view_13", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x2x4x256xf32> into tensor<8192xf32>
    %597 = tensor.expand_shape %596 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 256] {prov.region_id = "view_13", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<1x8x4x256xf32>
    %598 = tensor.empty() : tensor<1x8x256x4xf32>
    %599 = linalg.transpose ins(%589:tensor<1x8x4x256xf32>) outs(%598:tensor<1x8x256x4xf32>) permutation = [0, 1, 3, 2]
    %600 = tensor.empty() : tensor<1x8x4x256xf32>
    %601 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%551 : tensor<1x8x4x256xf32>) outs(%600 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "expand_7", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb66(%602: f32, %603: f32):
      linalg.yield %602 : f32
    } -> tensor<1x8x4x256xf32>
    %604 = tensor.collapse_shape %601 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_14", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4x256xf32> into tensor<8192xf32>
    %605 = tensor.expand_shape %604 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 4, 256] {prov.region_id = "view_14", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<8x4x256xf32>
    %606 = tensor.empty() : tensor<1x8x256x4xf32>
    %607 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%599 : tensor<1x8x256x4xf32>) outs(%606 : tensor<1x8x256x4xf32>) attrs =  {prov.region_id = "expand_8", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb67(%608: f32, %609: f32):
      linalg.yield %608 : f32
    } -> tensor<1x8x256x4xf32>
    %610 = tensor.collapse_shape %607 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_15", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x256x4xf32> into tensor<8192xf32>
    %611 = tensor.expand_shape %610 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 256, 4] {prov.region_id = "view_15", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<8x256x4xf32>
    %612 = arith.constant {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0.000000e+00 : f32
    %613 = tensor.splat %612 {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8x4x4xf32>
    %614 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%605, %611 : tensor<8x4x256xf32>, tensor<8x256x4xf32>) outs(%613 : tensor<8x4x4xf32>) attrs =  {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb68(%615: f32, %616: f32, %617: f32):
      %618 = arith.mulf %615, %616 : f32
      %619 = arith.addf %617, %618 : f32
      linalg.yield %619 : f32
    } -> tensor<8x4x4xf32>
    %620 = tensor.collapse_shape %614 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_16", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8x4x4xf32> into tensor<128xf32>
    %621 = tensor.expand_shape %620 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 4] {prov.region_id = "view_16", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<128xf32> into tensor<1x8x4x4xf32>
    %622 = arith.constant {prov.region_id = "mul_9", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 6.250000e-02 : f32
    %623 = tensor.splat %622 {prov.region_id = "mul_9", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4x4xf32>
    %624 = tensor.empty() : tensor<1x8x4x4xf32>
    %625 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%621, %623 : tensor<1x8x4x4xf32>, tensor<1x8x4x4xf32>) outs(%624 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "mul_9", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb69(%626: f32, %627: f32, %628: f32):
      %629 = arith.mulf %626, %627 : f32
      linalg.yield %629 : f32
    } -> tensor<1x8x4x4xf32>
    %630 = tensor.empty() : tensor<1x1x4x4xi1>
    %631 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%367 : tensor<1x1x4x4xi1>) outs(%630 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_6", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_not.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb70(%632: i1, %633: i1):
      %634 = arith.constant true
      %635 = arith.xori %632, %634 : i1
      linalg.yield %635 : i1
    } -> tensor<1x1x4x4xi1>
    %636 = arith.constant {prov.region_id = "fill_3", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0xff800000 : f32
    %637 = tensor.splat %636 {prov.region_id = "fill_3", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<f32>
    %638 = tensor.empty() : tensor<1x8x4x4xf32>
    %639 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> ()>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%631, %637, %625 : tensor<1x1x4x4xi1>, tensor<f32>, tensor<1x8x4x4xf32>) outs(%638 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "select_0", prov.family = "layout", prov._pattern_hint = "select", prov.op = "select", prov.aten = "aten.where.self", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb71(%640: i1, %641: f32, %642: f32, %643: f32):
      %644 = arith.select %640, %641, %642 : f32
      linalg.yield %644 : f32
    } -> tensor<1x8x4x4xf32>
    %645 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0xff800000 : f32
    %646 = tensor.splat %645 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4xf32>
    %647 = linalg.reduce ins(%639:tensor<1x8x4x4xf32>) outs(%646:tensor<1x8x4xf32>) dimensions = [3]
    (%648: f32, %649: f32) {
      %650 = arith.maximumf %648, %649 : f32
      linalg.yield %650 : f32
    }
    %651 = tensor.collapse_shape %647 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4xf32> into tensor<32xf32>
    %652 = tensor.expand_shape %651 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<32xf32> into tensor<1x8x4x1xf32>
    %653 = tensor.empty() : tensor<1x8x4x4xf32>
    %654 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%639, %652 : tensor<1x8x4x4xf32>, tensor<1x8x4x1xf32>) outs(%653 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb72(%655: f32, %656: f32, %657: f32):
      %658 = arith.subf %655, %656 : f32
      linalg.yield %658 : f32
    } -> tensor<1x8x4x4xf32>
    %659 = tensor.empty() : tensor<1x8x4x4xf32>
    %660 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%654 : tensor<1x8x4x4xf32>) outs(%659 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb73(%661: f32, %662: f32):
      %663 = math.exp %661 : f32
      linalg.yield %663 : f32
    } -> tensor<1x8x4x4xf32>
    %664 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0.000000e+00 : f32
    %665 = tensor.splat %664 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4xf32>
    %666 = linalg.reduce ins(%660:tensor<1x8x4x4xf32>) outs(%665:tensor<1x8x4xf32>) dimensions = [3]
    (%667: f32, %668: f32) {
      %669 = arith.addf %667, %668 : f32
      linalg.yield %669 : f32
    }
    %670 = tensor.collapse_shape %666 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4xf32> into tensor<32xf32>
    %671 = tensor.expand_shape %670 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<32xf32> into tensor<1x8x4x1xf32>
    %672 = tensor.empty() : tensor<1x8x4x4xf32>
    %673 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%660, %671 : tensor<1x8x4x4xf32>, tensor<1x8x4x1xf32>) outs(%672 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb74(%674: f32, %675: f32, %676: f32):
      %677 = arith.divf %674, %675 : f32
      linalg.yield %677 : f32
    } -> tensor<1x8x4x4xf32>
    %678 = tensor.empty() : tensor<1x8x4x4xf32>
    %679 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%673 : tensor<1x8x4x4xf32>) outs(%678 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "expand_9", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb75(%680: f32, %681: f32):
      linalg.yield %680 : f32
    } -> tensor<1x8x4x4xf32>
    %682 = tensor.collapse_shape %679 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_17", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4x4xf32> into tensor<128xf32>
    %683 = tensor.expand_shape %682 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 4, 4] {prov.region_id = "view_17", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<128xf32> into tensor<8x4x4xf32>
    %684 = tensor.empty() : tensor<1x8x4x256xf32>
    %685 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%597 : tensor<1x8x4x256xf32>) outs(%684 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "expand_10", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb76(%686: f32, %687: f32):
      linalg.yield %686 : f32
    } -> tensor<1x8x4x256xf32>
    %688 = tensor.collapse_shape %685 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_18", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x8x4x256xf32> into tensor<8192xf32>
    %689 = tensor.expand_shape %688 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 4, 256] {prov.region_id = "view_18", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<8x4x256xf32>
    %690 = arith.constant {prov.region_id = "matmul_5", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0.000000e+00 : f32
    %691 = tensor.splat %690 {prov.region_id = "matmul_5", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8x4x256xf32>
    %692 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%683, %689 : tensor<8x4x4xf32>, tensor<8x4x256xf32>) outs(%691 : tensor<8x4x256xf32>) attrs =  {prov.region_id = "matmul_5", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb77(%693: f32, %694: f32, %695: f32):
      %696 = arith.mulf %693, %694 : f32
      %697 = arith.addf %695, %696 : f32
      linalg.yield %697 : f32
    } -> tensor<8x4x256xf32>
    %698 = tensor.collapse_shape %692 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_19", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8x4x256xf32> into tensor<8192xf32>
    %699 = tensor.expand_shape %698 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 256] {prov.region_id = "view_19", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<1x8x4x256xf32>
    %700 = tensor.empty() : tensor<1x4x8x256xf32>
    %701 = linalg.transpose ins(%699:tensor<1x8x4x256xf32>) outs(%700:tensor<1x4x8x256xf32>) permutation = [0, 2, 1, 3]
    %702 = tensor.collapse_shape %701 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_20", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x8x256xf32> into tensor<8192xf32>
    %703 = tensor.expand_shape %702 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2048] {prov.region_id = "view_20", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<8192xf32> into tensor<1x4x2048xf32>
    %704 = tensor.empty() : tensor<2048x2304xf32>
    %705 = linalg.transpose ins(%4:tensor<2304x2048xf32>) outs(%704:tensor<2048x2304xf32>) permutation = [1, 0]
    %706 = tensor.collapse_shape %703 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_21", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<1x4x2048xf32> into tensor<8192xf32>
    %707 = tensor.expand_shape %706 [[0 : i64, 1 : i64]] output_shape [4, 2048] {prov.region_id = "view_21", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<8192xf32> into tensor<4x2048xf32>
    %708 = tensor.empty() : tensor<4x2304xf32>
    %709 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %710 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%709 : f32) outs(%708 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %711 = linalg.matmul {prov.region_id = "matmul_6", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj", prov.transposed_b = "true"} ins(%707, %705 : tensor<4x2048xf32>, tensor<2048x2304xf32>) outs(%710 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %712 = tensor.collapse_shape %711 [[0 : i64, 1 : i64]] {prov.region_id = "view_22", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<4x2304xf32> into tensor<9216xf32>
    %713 = tensor.expand_shape %712 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2304] {prov.region_id = "view_22", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<9216xf32> into tensor<1x4x2304xf32>
    %714 = tensor.empty() : tensor<1x4x2304xf32>
    %715 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%713 : tensor<1x4x2304xf32>) outs(%714 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_1", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb78(%716: f32, %717: f32):
      %718 = arith.constant 2.000000e+00 : f32
      %719 = math.powf %716, %718 : f32
      linalg.yield %719 : f32
    } -> tensor<1x4x2304xf32>
    %720 = arith.constant {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} 0.000000e+00 : f32
    %721 = tensor.splat %720 {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4xf32>
    %722 = linalg.reduce ins(%715:tensor<1x4x2304xf32>) outs(%721:tensor<1x4xf32>) dimensions = [2]
    (%723: f32, %724: f32) {
      %725 = arith.addf %723, %724 : f32
      linalg.yield %725 : f32
    }
    %726 = arith.constant {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} 2.304000e+03 : f32
    %727 = tensor.splat %726 {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4xf32>
    %728 = tensor.empty() : tensor<1x4xf32>
    %729 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%722, %727 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%728 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb79(%730: f32, %731: f32, %732: f32):
      %733 = arith.divf %730, %731 : f32
      linalg.yield %733 : f32
    } -> tensor<1x4xf32>
    %734 = tensor.collapse_shape %729 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %735 = tensor.expand_shape %734 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %736 = arith.constant {prov.region_id = "add_9", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} 1.000000e-06 : f32
    %737 = tensor.splat %736 {prov.region_id = "add_9", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4x1xf32>
    %738 = tensor.empty() : tensor<1x4x1xf32>
    %739 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%735, %737 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%738 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_9", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb80(%740: f32, %741: f32, %742: f32):
      %743 = arith.addf %740, %741 : f32
      linalg.yield %743 : f32
    } -> tensor<1x4x1xf32>
    %744 = tensor.empty() : tensor<1x4x1xf32>
    %745 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%739 : tensor<1x4x1xf32>) outs(%744 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_1", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb81(%746: f32, %747: f32):
      %748 = math.rsqrt %746 : f32
      linalg.yield %748 : f32
    } -> tensor<1x4x1xf32>
    %749 = tensor.empty() : tensor<1x4x2304xf32>
    %750 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%713, %745 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%749 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_10", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb82(%751: f32, %752: f32, %753: f32):
      %754 = arith.mulf %751, %752 : f32
      linalg.yield %754 : f32
    } -> tensor<1x4x2304xf32>
    %755 = arith.constant {prov.region_id = "add_10", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} 1.000000e+00 : f32
    %756 = tensor.splat %755 {prov.region_id = "add_10", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<2304xf32>
    %757 = tensor.empty() : tensor<2304xf32>
    %758 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%9, %756 : tensor<2304xf32>, tensor<2304xf32>) outs(%757 : tensor<2304xf32>) attrs =  {prov.region_id = "add_10", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb83(%759: f32, %760: f32, %761: f32):
      %762 = arith.addf %759, %760 : f32
      linalg.yield %762 : f32
    } -> tensor<2304xf32>
    %763 = tensor.empty() : tensor<1x4x2304xf32>
    %764 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%750, %758 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%763 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_11", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb84(%765: f32, %766: f32, %767: f32):
      %768 = arith.mulf %765, %766 : f32
      linalg.yield %768 : f32
    } -> tensor<1x4x2304xf32>
    %769 = tensor.empty() : tensor<1x4x2304xf32>
    %770 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%37, %764 : tensor<1x4x2304xf32>, tensor<1x4x2304xf32>) outs(%769 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "add_11", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0"} {
    ^bb85(%771: f32, %772: f32, %773: f32):
      %774 = arith.addf %771, %772 : f32
      linalg.yield %774 : f32
    } -> tensor<1x4x2304xf32>
    %775 = tensor.empty() : tensor<1x4x2304xf32>
    %776 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%770 : tensor<1x4x2304xf32>) outs(%775 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_2", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} {
    ^bb86(%777: f32, %778: f32):
      %779 = arith.constant 2.000000e+00 : f32
      %780 = math.powf %777, %779 : f32
      linalg.yield %780 : f32
    } -> tensor<1x4x2304xf32>
    %781 = arith.constant {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} 0.000000e+00 : f32
    %782 = tensor.splat %781 {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} : tensor<1x4xf32>
    %783 = linalg.reduce ins(%776:tensor<1x4x2304xf32>) outs(%782:tensor<1x4xf32>) dimensions = [2]
    (%784: f32, %785: f32) {
      %786 = arith.addf %784, %785 : f32
      linalg.yield %786 : f32
    }
    %787 = arith.constant {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} 2.304000e+03 : f32
    %788 = tensor.splat %787 {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} : tensor<1x4xf32>
    %789 = tensor.empty() : tensor<1x4xf32>
    %790 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%783, %788 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%789 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} {
    ^bb87(%791: f32, %792: f32, %793: f32):
      %794 = arith.divf %791, %792 : f32
      linalg.yield %794 : f32
    } -> tensor<1x4xf32>
    %795 = tensor.collapse_shape %790 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %796 = tensor.expand_shape %795 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %797 = arith.constant {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} 1.000000e-06 : f32
    %798 = tensor.splat %797 {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} : tensor<1x4x1xf32>
    %799 = tensor.empty() : tensor<1x4x1xf32>
    %800 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%796, %798 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%799 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} {
    ^bb88(%801: f32, %802: f32, %803: f32):
      %804 = arith.addf %801, %802 : f32
      linalg.yield %804 : f32
    } -> tensor<1x4x1xf32>
    %805 = tensor.empty() : tensor<1x4x1xf32>
    %806 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%800 : tensor<1x4x1xf32>) outs(%805 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_2", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} {
    ^bb89(%807: f32, %808: f32):
      %809 = math.rsqrt %807 : f32
      linalg.yield %809 : f32
    } -> tensor<1x4x1xf32>
    %810 = tensor.empty() : tensor<1x4x2304xf32>
    %811 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%770, %806 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%810 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_12", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} {
    ^bb90(%812: f32, %813: f32, %814: f32):
      %815 = arith.mulf %812, %813 : f32
      linalg.yield %815 : f32
    } -> tensor<1x4x2304xf32>
    %816 = arith.constant {prov.region_id = "add_13", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} 1.000000e+00 : f32
    %817 = tensor.splat %816 {prov.region_id = "add_13", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} : tensor<2304xf32>
    %818 = tensor.empty() : tensor<2304xf32>
    %819 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%10, %817 : tensor<2304xf32>, tensor<2304xf32>) outs(%818 : tensor<2304xf32>) attrs =  {prov.region_id = "add_13", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} {
    ^bb91(%820: f32, %821: f32, %822: f32):
      %823 = arith.addf %820, %821 : f32
      linalg.yield %823 : f32
    } -> tensor<2304xf32>
    %824 = tensor.empty() : tensor<1x4x2304xf32>
    %825 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%811, %819 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%824 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_13", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.pre_feedforward_layernorm"} {
    ^bb92(%826: f32, %827: f32, %828: f32):
      %829 = arith.mulf %826, %827 : f32
      linalg.yield %829 : f32
    } -> tensor<1x4x2304xf32>
    %830 = tensor.empty() : tensor<2304x9216xf32>
    %831 = linalg.transpose ins(%5:tensor<9216x2304xf32>) outs(%830:tensor<2304x9216xf32>) permutation = [1, 0]
    %832 = tensor.collapse_shape %825 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_23", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %833 = tensor.expand_shape %832 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_23", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %834 = tensor.empty() : tensor<4x9216xf32>
    %835 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %836 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%835 : f32) outs(%834 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %837 = linalg.matmul {prov.region_id = "matmul_7", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj", prov.transposed_b = "true"} ins(%833, %831 : tensor<4x2304xf32>, tensor<2304x9216xf32>) outs(%836 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %838 = tensor.collapse_shape %837 [[0 : i64, 1 : i64]] {prov.region_id = "view_24", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<4x9216xf32> into tensor<36864xf32>
    %839 = tensor.expand_shape %838 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 9216] {prov.region_id = "view_24", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<36864xf32> into tensor<1x4x9216xf32>
    %840 = tensor.empty() : tensor<1x4x9216xf32>
    %841 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%839 : tensor<1x4x9216xf32>) outs(%840 : tensor<1x4x9216xf32>) attrs =  {prov.region_id = "gelu_0", prov._pattern_hint = "gelu", prov.op = "gelu", prov.family = "elementwise", prov.aten = "aten.gelu.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.act_fn"} {
    ^bb93(%842: f32, %843: f32):
      %844 = arith.constant 5.000000e-01 : f32
      %845 = arith.constant 1.000000e+00 : f32
      %846 = arith.constant 0.707106769 : f32
      %847 = arith.mulf %842, %846 : f32
      %848 = math.erf %847 : f32
      %849 = arith.addf %845, %848 : f32
      %850 = arith.mulf %844, %842 : f32
      %851 = arith.mulf %850, %849 : f32
      linalg.yield %851 : f32
    } -> tensor<1x4x9216xf32>
    %852 = tensor.empty() : tensor<2304x9216xf32>
    %853 = linalg.transpose ins(%6:tensor<9216x2304xf32>) outs(%852:tensor<2304x9216xf32>) permutation = [1, 0]
    %854 = tensor.collapse_shape %825 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_25", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %855 = tensor.expand_shape %854 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_25", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %856 = tensor.empty() : tensor<4x9216xf32>
    %857 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %858 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%857 : f32) outs(%856 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %859 = linalg.matmul {prov.region_id = "matmul_8", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj", prov.transposed_b = "true"} ins(%855, %853 : tensor<4x2304xf32>, tensor<2304x9216xf32>) outs(%858 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %860 = tensor.collapse_shape %859 [[0 : i64, 1 : i64]] {prov.region_id = "view_26", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<4x9216xf32> into tensor<36864xf32>
    %861 = tensor.expand_shape %860 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 9216] {prov.region_id = "view_26", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<36864xf32> into tensor<1x4x9216xf32>
    %862 = tensor.empty() : tensor<1x4x9216xf32>
    %863 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%841, %861 : tensor<1x4x9216xf32>, tensor<1x4x9216xf32>) outs(%862 : tensor<1x4x9216xf32>) attrs =  {prov.region_id = "mul_14", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp"} {
    ^bb94(%864: f32, %865: f32, %866: f32):
      %867 = arith.mulf %864, %865 : f32
      linalg.yield %867 : f32
    } -> tensor<1x4x9216xf32>
    %868 = tensor.empty() : tensor<9216x2304xf32>
    %869 = linalg.transpose ins(%7:tensor<2304x9216xf32>) outs(%868:tensor<9216x2304xf32>) permutation = [1, 0]
    %870 = tensor.collapse_shape %863 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_27", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<1x4x9216xf32> into tensor<36864xf32>
    %871 = tensor.expand_shape %870 [[0 : i64, 1 : i64]] output_shape [4, 9216] {prov.region_id = "view_27", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<36864xf32> into tensor<4x9216xf32>
    %872 = tensor.empty() : tensor<4x2304xf32>
    %873 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %874 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%873 : f32) outs(%872 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %875 = linalg.matmul {prov.region_id = "matmul_9", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj", prov.transposed_b = "true"} ins(%871, %869 : tensor<4x9216xf32>, tensor<9216x2304xf32>) outs(%874 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %876 = tensor.collapse_shape %875 [[0 : i64, 1 : i64]] {prov.region_id = "view_28", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<4x2304xf32> into tensor<9216xf32>
    %877 = tensor.expand_shape %876 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2304] {prov.region_id = "view_28", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<9216xf32> into tensor<1x4x2304xf32>
    %878 = tensor.empty() : tensor<1x4x2304xf32>
    %879 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%877 : tensor<1x4x2304xf32>) outs(%878 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_3", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} {
    ^bb95(%880: f32, %881: f32):
      %882 = arith.constant 2.000000e+00 : f32
      %883 = math.powf %880, %882 : f32
      linalg.yield %883 : f32
    } -> tensor<1x4x2304xf32>
    %884 = arith.constant {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} 0.000000e+00 : f32
    %885 = tensor.splat %884 {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} : tensor<1x4xf32>
    %886 = linalg.reduce ins(%879:tensor<1x4x2304xf32>) outs(%885:tensor<1x4xf32>) dimensions = [2]
    (%887: f32, %888: f32) {
      %889 = arith.addf %887, %888 : f32
      linalg.yield %889 : f32
    }
    %890 = arith.constant {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} 2.304000e+03 : f32
    %891 = tensor.splat %890 {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} : tensor<1x4xf32>
    %892 = tensor.empty() : tensor<1x4xf32>
    %893 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%886, %891 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%892 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} {
    ^bb96(%894: f32, %895: f32, %896: f32):
      %897 = arith.divf %894, %895 : f32
      linalg.yield %897 : f32
    } -> tensor<1x4xf32>
    %898 = tensor.collapse_shape %893 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %899 = tensor.expand_shape %898 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_3", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %900 = arith.constant {prov.region_id = "add_14", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} 1.000000e-06 : f32
    %901 = tensor.splat %900 {prov.region_id = "add_14", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} : tensor<1x4x1xf32>
    %902 = tensor.empty() : tensor<1x4x1xf32>
    %903 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%899, %901 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%902 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_14", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} {
    ^bb97(%904: f32, %905: f32, %906: f32):
      %907 = arith.addf %904, %905 : f32
      linalg.yield %907 : f32
    } -> tensor<1x4x1xf32>
    %908 = tensor.empty() : tensor<1x4x1xf32>
    %909 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%903 : tensor<1x4x1xf32>) outs(%908 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_3", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} {
    ^bb98(%910: f32, %911: f32):
      %912 = math.rsqrt %910 : f32
      linalg.yield %912 : f32
    } -> tensor<1x4x1xf32>
    %913 = tensor.empty() : tensor<1x4x2304xf32>
    %914 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%877, %909 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%913 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_15", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} {
    ^bb99(%915: f32, %916: f32, %917: f32):
      %918 = arith.mulf %915, %916 : f32
      linalg.yield %918 : f32
    } -> tensor<1x4x2304xf32>
    %919 = arith.constant {prov.region_id = "add_15", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} 1.000000e+00 : f32
    %920 = tensor.splat %919 {prov.region_id = "add_15", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} : tensor<2304xf32>
    %921 = tensor.empty() : tensor<2304xf32>
    %922 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%11, %920 : tensor<2304xf32>, tensor<2304xf32>) outs(%921 : tensor<2304xf32>) attrs =  {prov.region_id = "add_15", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} {
    ^bb100(%923: f32, %924: f32, %925: f32):
      %926 = arith.addf %923, %924 : f32
      linalg.yield %926 : f32
    } -> tensor<2304xf32>
    %927 = tensor.empty() : tensor<1x4x2304xf32>
    %928 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%914, %922 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%927 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_16", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_feedforward_layernorm"} {
    ^bb101(%929: f32, %930: f32, %931: f32):
      %932 = arith.mulf %929, %930 : f32
      linalg.yield %932 : f32
    } -> tensor<1x4x2304xf32>
    %933 = tensor.empty() : tensor<1x4x2304xf32>
    %934 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%770, %928 : tensor<1x4x2304xf32>, tensor<1x4x2304xf32>) outs(%933 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "add_16", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0"} {
    ^bb102(%935: f32, %936: f32, %937: f32):
      %938 = arith.addf %935, %936 : f32
      linalg.yield %938 : f32
    } -> tensor<1x4x2304xf32>
    %939 = tensor.empty() : tensor<1x4x2304xf32>
    %940 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%934 : tensor<1x4x2304xf32>) outs(%939 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_4", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} {
    ^bb103(%941: f32, %942: f32):
      %943 = arith.constant 2.000000e+00 : f32
      %944 = math.powf %941, %943 : f32
      linalg.yield %944 : f32
    } -> tensor<1x4x2304xf32>
    %945 = arith.constant {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} 0.000000e+00 : f32
    %946 = tensor.splat %945 {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} : tensor<1x4xf32>
    %947 = linalg.reduce ins(%940:tensor<1x4x2304xf32>) outs(%946:tensor<1x4xf32>) dimensions = [2]
    (%948: f32, %949: f32) {
      %950 = arith.addf %948, %949 : f32
      linalg.yield %950 : f32
    }
    %951 = arith.constant {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} 2.304000e+03 : f32
    %952 = tensor.splat %951 {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} : tensor<1x4xf32>
    %953 = tensor.empty() : tensor<1x4xf32>
    %954 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%947, %952 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%953 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} {
    ^bb104(%955: f32, %956: f32, %957: f32):
      %958 = arith.divf %955, %956 : f32
      linalg.yield %958 : f32
    } -> tensor<1x4xf32>
    %959 = tensor.collapse_shape %954 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %960 = tensor.expand_shape %959 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_4", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %961 = arith.constant {prov.region_id = "add_17", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} 1.000000e-06 : f32
    %962 = tensor.splat %961 {prov.region_id = "add_17", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} : tensor<1x4x1xf32>
    %963 = tensor.empty() : tensor<1x4x1xf32>
    %964 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%960, %962 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%963 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_17", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} {
    ^bb105(%965: f32, %966: f32, %967: f32):
      %968 = arith.addf %965, %966 : f32
      linalg.yield %968 : f32
    } -> tensor<1x4x1xf32>
    %969 = tensor.empty() : tensor<1x4x1xf32>
    %970 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%964 : tensor<1x4x1xf32>) outs(%969 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_4", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} {
    ^bb106(%971: f32, %972: f32):
      %973 = math.rsqrt %971 : f32
      linalg.yield %973 : f32
    } -> tensor<1x4x1xf32>
    %974 = tensor.empty() : tensor<1x4x2304xf32>
    %975 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%934, %970 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%974 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_17", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} {
    ^bb107(%976: f32, %977: f32, %978: f32):
      %979 = arith.mulf %976, %977 : f32
      linalg.yield %979 : f32
    } -> tensor<1x4x2304xf32>
    %980 = arith.constant {prov.region_id = "add_18", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} 1.000000e+00 : f32
    %981 = tensor.splat %980 {prov.region_id = "add_18", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} : tensor<2304xf32>
    %982 = tensor.empty() : tensor<2304xf32>
    %983 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%19, %981 : tensor<2304xf32>, tensor<2304xf32>) outs(%982 : tensor<2304xf32>) attrs =  {prov.region_id = "add_18", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} {
    ^bb108(%984: f32, %985: f32, %986: f32):
      %987 = arith.addf %984, %985 : f32
      linalg.yield %987 : f32
    } -> tensor<2304xf32>
    %988 = tensor.empty() : tensor<1x4x2304xf32>
    %989 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%975, %983 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%988 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_18", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.input_layernorm"} {
    ^bb109(%990: f32, %991: f32, %992: f32):
      %993 = arith.mulf %990, %991 : f32
      linalg.yield %993 : f32
    } -> tensor<1x4x2304xf32>
    %994 = tensor.empty() : tensor<2304x2048xf32>
    %995 = linalg.transpose ins(%12:tensor<2048x2304xf32>) outs(%994:tensor<2304x2048xf32>) permutation = [1, 0]
    %996 = tensor.collapse_shape %989 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_29", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.q_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %997 = tensor.expand_shape %996 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_29", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.q_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %998 = tensor.empty() : tensor<4x2048xf32>
    %999 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1000 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%999 : f32) outs(%998 : tensor<4x2048xf32>) -> tensor<4x2048xf32>
    %1001 = linalg.matmul {prov.region_id = "matmul_10", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.q_proj", prov.transposed_b = "true"} ins(%997, %995 : tensor<4x2304xf32>, tensor<2304x2048xf32>) outs(%1000 : tensor<4x2048xf32>) -> tensor<4x2048xf32>
    %1002 = tensor.collapse_shape %1001 [[0 : i64, 1 : i64]] {prov.region_id = "view_30", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.q_proj"} : tensor<4x2048xf32> into tensor<8192xf32>
    %1003 = tensor.expand_shape %1002 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2048] {prov.region_id = "view_30", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.q_proj"} : tensor<8192xf32> into tensor<1x4x2048xf32>
    %1004 = tensor.collapse_shape %1003 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_31", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x2048xf32> into tensor<8192xf32>
    %1005 = tensor.expand_shape %1004 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 8, 256] {prov.region_id = "view_31", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<1x4x8x256xf32>
    %1006 = tensor.empty() : tensor<1x8x4x256xf32>
    %1007 = linalg.transpose ins(%1005:tensor<1x4x8x256xf32>) outs(%1006:tensor<1x8x4x256xf32>) permutation = [0, 2, 1, 3]
    %1008 = tensor.empty() : tensor<2304x1024xf32>
    %1009 = linalg.transpose ins(%13:tensor<1024x2304xf32>) outs(%1008:tensor<2304x1024xf32>) permutation = [1, 0]
    %1010 = tensor.collapse_shape %989 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_32", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.k_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %1011 = tensor.expand_shape %1010 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_32", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.k_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %1012 = tensor.empty() : tensor<4x1024xf32>
    %1013 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1014 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%1013 : f32) outs(%1012 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %1015 = linalg.matmul {prov.region_id = "matmul_11", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.k_proj", prov.transposed_b = "true"} ins(%1011, %1009 : tensor<4x2304xf32>, tensor<2304x1024xf32>) outs(%1014 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %1016 = tensor.collapse_shape %1015 [[0 : i64, 1 : i64]] {prov.region_id = "view_33", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.k_proj"} : tensor<4x1024xf32> into tensor<4096xf32>
    %1017 = tensor.expand_shape %1016 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1024] {prov.region_id = "view_33", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.k_proj"} : tensor<4096xf32> into tensor<1x4x1024xf32>
    %1018 = tensor.collapse_shape %1017 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_34", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x1024xf32> into tensor<4096xf32>
    %1019 = tensor.expand_shape %1018 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 4, 256] {prov.region_id = "view_34", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<4096xf32> into tensor<1x4x4x256xf32>
    %1020 = tensor.empty() : tensor<1x4x4x256xf32>
    %1021 = linalg.transpose ins(%1019:tensor<1x4x4x256xf32>) outs(%1020:tensor<1x4x4x256xf32>) permutation = [0, 2, 1, 3]
    %1022 = tensor.empty() : tensor<2304x1024xf32>
    %1023 = linalg.transpose ins(%14:tensor<1024x2304xf32>) outs(%1022:tensor<2304x1024xf32>) permutation = [1, 0]
    %1024 = tensor.collapse_shape %989 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_35", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.v_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %1025 = tensor.expand_shape %1024 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_35", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.v_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %1026 = tensor.empty() : tensor<4x1024xf32>
    %1027 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1028 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%1027 : f32) outs(%1026 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %1029 = linalg.matmul {prov.region_id = "matmul_12", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.v_proj", prov.transposed_b = "true"} ins(%1025, %1023 : tensor<4x2304xf32>, tensor<2304x1024xf32>) outs(%1028 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
    %1030 = tensor.collapse_shape %1029 [[0 : i64, 1 : i64]] {prov.region_id = "view_36", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.v_proj"} : tensor<4x1024xf32> into tensor<4096xf32>
    %1031 = tensor.expand_shape %1030 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1024] {prov.region_id = "view_36", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.v_proj"} : tensor<4096xf32> into tensor<1x4x1024xf32>
    %1032 = tensor.collapse_shape %1031 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_37", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x1024xf32> into tensor<4096xf32>
    %1033 = tensor.expand_shape %1032 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 4, 256] {prov.region_id = "view_37", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<4096xf32> into tensor<1x4x4x256xf32>
    %1034 = tensor.empty() : tensor<1x4x4x256xf32>
    %1035 = linalg.transpose ins(%1033:tensor<1x4x4x256xf32>) outs(%1034:tensor<1x4x4x256xf32>) permutation = [0, 2, 1, 3]
    %1036 = tensor.collapse_shape %411 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_26", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x256xf32> into tensor<1024xf32>
    %1037 = tensor.expand_shape %1036 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 256] {prov.region_id = "unsqueeze_26", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1024xf32> into tensor<1x1x4x256xf32>
    %1038 = tensor.collapse_shape %424 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_27", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x256xf32> into tensor<1024xf32>
    %1039 = tensor.expand_shape %1038 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 256] {prov.region_id = "unsqueeze_27", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1024xf32> into tensor<1x1x4x256xf32>
    %1040 = tensor.empty() : tensor<1x8x4x256xf32>
    %1041 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1007, %1037 : tensor<1x8x4x256xf32>, tensor<1x1x4x256xf32>) outs(%1040 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "mul_19", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb110(%1042: f32, %1043: f32, %1044: f32):
      %1045 = arith.mulf %1042, %1043 : f32
      linalg.yield %1045 : f32
    } -> tensor<1x8x4x256xf32>
    %1046 = "tensor.extract_slice"(%1007) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 8, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_10", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : (tensor<1x8x4x256xf32>) -> tensor<1x8x4x128xf32>
    %1047 = "tensor.extract_slice"(%1007) <{static_offsets = array<i64: 0, 0, 0, 128>, static_sizes = array<i64: 1, 8, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_11", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : (tensor<1x8x4x256xf32>) -> tensor<1x8x4x128xf32>
    %1048 = tensor.empty() : tensor<1x8x4x128xf32>
    %1049 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1047 : tensor<1x8x4x128xf32>) outs(%1048 : tensor<1x8x4x128xf32>) attrs =  {prov.region_id = "neg_2", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb111(%1050: f32, %1051: f32):
      %1052 = arith.negf %1050 : f32
      linalg.yield %1052 : f32
    } -> tensor<1x8x4x128xf32>
    %1053 = tensor.concat dim(3) %1049, %1046 {prov.region_id = "cat_5", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : (tensor<1x8x4x128xf32>, tensor<1x8x4x128xf32>) -> tensor<1x8x4x256xf32>
    %1054 = tensor.empty() : tensor<1x8x4x256xf32>
    %1055 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1053, %1039 : tensor<1x8x4x256xf32>, tensor<1x1x4x256xf32>) outs(%1054 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "mul_20", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb112(%1056: f32, %1057: f32, %1058: f32):
      %1059 = arith.mulf %1056, %1057 : f32
      linalg.yield %1059 : f32
    } -> tensor<1x8x4x256xf32>
    %1060 = tensor.empty() : tensor<1x8x4x256xf32>
    %1061 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1041, %1055 : tensor<1x8x4x256xf32>, tensor<1x8x4x256xf32>) outs(%1060 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "add_19", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb113(%1062: f32, %1063: f32, %1064: f32):
      %1065 = arith.addf %1062, %1063 : f32
      linalg.yield %1065 : f32
    } -> tensor<1x8x4x256xf32>
    %1066 = tensor.empty() : tensor<1x4x4x256xf32>
    %1067 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1021, %1037 : tensor<1x4x4x256xf32>, tensor<1x1x4x256xf32>) outs(%1066 : tensor<1x4x4x256xf32>) attrs =  {prov.region_id = "mul_21", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb114(%1068: f32, %1069: f32, %1070: f32):
      %1071 = arith.mulf %1068, %1069 : f32
      linalg.yield %1071 : f32
    } -> tensor<1x4x4x256xf32>
    %1072 = "tensor.extract_slice"(%1021) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 4, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_12", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : (tensor<1x4x4x256xf32>) -> tensor<1x4x4x128xf32>
    %1073 = "tensor.extract_slice"(%1021) <{static_offsets = array<i64: 0, 0, 0, 128>, static_sizes = array<i64: 1, 4, 4, 128>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_13", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : (tensor<1x4x4x256xf32>) -> tensor<1x4x4x128xf32>
    %1074 = tensor.empty() : tensor<1x4x4x128xf32>
    %1075 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1073 : tensor<1x4x4x128xf32>) outs(%1074 : tensor<1x4x4x128xf32>) attrs =  {prov.region_id = "neg_3", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb115(%1076: f32, %1077: f32):
      %1078 = arith.negf %1076 : f32
      linalg.yield %1078 : f32
    } -> tensor<1x4x4x128xf32>
    %1079 = tensor.concat dim(3) %1075, %1072 {prov.region_id = "cat_6", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : (tensor<1x4x4x128xf32>, tensor<1x4x4x128xf32>) -> tensor<1x4x4x256xf32>
    %1080 = tensor.empty() : tensor<1x4x4x256xf32>
    %1081 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1079, %1039 : tensor<1x4x4x256xf32>, tensor<1x1x4x256xf32>) outs(%1080 : tensor<1x4x4x256xf32>) attrs =  {prov.region_id = "mul_22", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb116(%1082: f32, %1083: f32, %1084: f32):
      %1085 = arith.mulf %1082, %1083 : f32
      linalg.yield %1085 : f32
    } -> tensor<1x4x4x256xf32>
    %1086 = tensor.empty() : tensor<1x4x4x256xf32>
    %1087 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1067, %1081 : tensor<1x4x4x256xf32>, tensor<1x4x4x256xf32>) outs(%1086 : tensor<1x4x4x256xf32>) attrs =  {prov.region_id = "add_20", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb117(%1088: f32, %1089: f32, %1090: f32):
      %1091 = arith.addf %1088, %1089 : f32
      linalg.yield %1091 : f32
    } -> tensor<1x4x4x256xf32>
    %1092 = tensor.collapse_shape %1087 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "unsqueeze_28", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x4x256xf32> into tensor<4096xf32>
    %1093 = tensor.expand_shape %1092 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] output_shape [1, 4, 1, 4, 256] {prov.region_id = "unsqueeze_28", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<4096xf32> into tensor<1x4x1x4x256xf32>
    %1094 = tensor.empty() : tensor<1x4x2x4x256xf32>
    %1095 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, 0, d3, d4)>, affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, d2, d3, d4)>], iterator_types = ["parallel", "parallel", "parallel", "parallel", "parallel"]} ins(%1093 : tensor<1x4x1x4x256xf32>) outs(%1094 : tensor<1x4x2x4x256xf32>) attrs =  {prov.region_id = "expand_11", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb118(%1096: f32, %1097: f32):
      linalg.yield %1096 : f32
    } -> tensor<1x4x2x4x256xf32>
    %1098 = tensor.collapse_shape %1095 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] {prov.region_id = "view_38", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x2x4x256xf32> into tensor<8192xf32>
    %1099 = tensor.expand_shape %1098 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 256] {prov.region_id = "view_38", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<1x8x4x256xf32>
    %1100 = tensor.collapse_shape %1035 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "unsqueeze_29", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x4x256xf32> into tensor<4096xf32>
    %1101 = tensor.expand_shape %1100 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] output_shape [1, 4, 1, 4, 256] {prov.region_id = "unsqueeze_29", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<4096xf32> into tensor<1x4x1x4x256xf32>
    %1102 = tensor.empty() : tensor<1x4x2x4x256xf32>
    %1103 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, 0, d3, d4)>, affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, d2, d3, d4)>], iterator_types = ["parallel", "parallel", "parallel", "parallel", "parallel"]} ins(%1101 : tensor<1x4x1x4x256xf32>) outs(%1102 : tensor<1x4x2x4x256xf32>) attrs =  {prov.region_id = "expand_12", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb119(%1104: f32, %1105: f32):
      linalg.yield %1104 : f32
    } -> tensor<1x4x2x4x256xf32>
    %1106 = tensor.collapse_shape %1103 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] {prov.region_id = "view_39", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x2x4x256xf32> into tensor<8192xf32>
    %1107 = tensor.expand_shape %1106 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 256] {prov.region_id = "view_39", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<1x8x4x256xf32>
    %1108 = tensor.empty() : tensor<1x8x256x4xf32>
    %1109 = linalg.transpose ins(%1099:tensor<1x8x4x256xf32>) outs(%1108:tensor<1x8x256x4xf32>) permutation = [0, 1, 3, 2]
    %1110 = tensor.empty() : tensor<1x8x4x256xf32>
    %1111 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1061 : tensor<1x8x4x256xf32>) outs(%1110 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "expand_13", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb120(%1112: f32, %1113: f32):
      linalg.yield %1112 : f32
    } -> tensor<1x8x4x256xf32>
    %1114 = tensor.collapse_shape %1111 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_40", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4x256xf32> into tensor<8192xf32>
    %1115 = tensor.expand_shape %1114 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 4, 256] {prov.region_id = "view_40", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<8x4x256xf32>
    %1116 = tensor.empty() : tensor<1x8x256x4xf32>
    %1117 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1109 : tensor<1x8x256x4xf32>) outs(%1116 : tensor<1x8x256x4xf32>) attrs =  {prov.region_id = "expand_14", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb121(%1118: f32, %1119: f32):
      linalg.yield %1118 : f32
    } -> tensor<1x8x256x4xf32>
    %1120 = tensor.collapse_shape %1117 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_41", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x256x4xf32> into tensor<8192xf32>
    %1121 = tensor.expand_shape %1120 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 256, 4] {prov.region_id = "view_41", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<8x256x4xf32>
    %1122 = arith.constant {prov.region_id = "matmul_13", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} 0.000000e+00 : f32
    %1123 = tensor.splat %1122 {prov.region_id = "matmul_13", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8x4x4xf32>
    %1124 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%1115, %1121 : tensor<8x4x256xf32>, tensor<8x256x4xf32>) outs(%1123 : tensor<8x4x4xf32>) attrs =  {prov.region_id = "matmul_13", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb122(%1125: f32, %1126: f32, %1127: f32):
      %1128 = arith.mulf %1125, %1126 : f32
      %1129 = arith.addf %1127, %1128 : f32
      linalg.yield %1129 : f32
    } -> tensor<8x4x4xf32>
    %1130 = tensor.collapse_shape %1124 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_42", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8x4x4xf32> into tensor<128xf32>
    %1131 = tensor.expand_shape %1130 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 4] {prov.region_id = "view_42", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<128xf32> into tensor<1x8x4x4xf32>
    %1132 = arith.constant {prov.region_id = "mul_23", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} 6.250000e-02 : f32
    %1133 = tensor.splat %1132 {prov.region_id = "mul_23", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4x4xf32>
    %1134 = tensor.empty() : tensor<1x8x4x4xf32>
    %1135 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1131, %1133 : tensor<1x8x4x4xf32>, tensor<1x8x4x4xf32>) outs(%1134 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "mul_23", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb123(%1136: f32, %1137: f32, %1138: f32):
      %1139 = arith.mulf %1136, %1137 : f32
      linalg.yield %1139 : f32
    } -> tensor<1x8x4x4xf32>
    %1140 = tensor.empty() : tensor<1x1x4x4xi1>
    %1141 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%198 : tensor<1x1x4x4xi1>) outs(%1140 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_7", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_not.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb124(%1142: i1, %1143: i1):
      %1144 = arith.constant true
      %1145 = arith.xori %1142, %1144 : i1
      linalg.yield %1145 : i1
    } -> tensor<1x1x4x4xi1>
    %1146 = arith.constant {prov.region_id = "fill_4", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} 0xff800000 : f32
    %1147 = tensor.splat %1146 {prov.region_id = "fill_4", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<f32>
    %1148 = tensor.empty() : tensor<1x8x4x4xf32>
    %1149 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> ()>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1141, %1147, %1135 : tensor<1x1x4x4xi1>, tensor<f32>, tensor<1x8x4x4xf32>) outs(%1148 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "select_1", prov.family = "layout", prov._pattern_hint = "select", prov.op = "select", prov.aten = "aten.where.self", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb125(%1150: i1, %1151: f32, %1152: f32, %1153: f32):
      %1154 = arith.select %1150, %1151, %1152 : f32
      linalg.yield %1154 : f32
    } -> tensor<1x8x4x4xf32>
    %1155 = arith.constant {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} 0xff800000 : f32
    %1156 = tensor.splat %1155 {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4xf32>
    %1157 = linalg.reduce ins(%1149:tensor<1x8x4x4xf32>) outs(%1156:tensor<1x8x4xf32>) dimensions = [3]
    (%1158: f32, %1159: f32) {
      %1160 = arith.maximumf %1158, %1159 : f32
      linalg.yield %1160 : f32
    }
    %1161 = tensor.collapse_shape %1157 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4xf32> into tensor<32xf32>
    %1162 = tensor.expand_shape %1161 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 1] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<32xf32> into tensor<1x8x4x1xf32>
    %1163 = tensor.empty() : tensor<1x8x4x4xf32>
    %1164 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1149, %1162 : tensor<1x8x4x4xf32>, tensor<1x8x4x1xf32>) outs(%1163 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb126(%1165: f32, %1166: f32, %1167: f32):
      %1168 = arith.subf %1165, %1166 : f32
      linalg.yield %1168 : f32
    } -> tensor<1x8x4x4xf32>
    %1169 = tensor.empty() : tensor<1x8x4x4xf32>
    %1170 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1164 : tensor<1x8x4x4xf32>) outs(%1169 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb127(%1171: f32, %1172: f32):
      %1173 = math.exp %1171 : f32
      linalg.yield %1173 : f32
    } -> tensor<1x8x4x4xf32>
    %1174 = arith.constant {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} 0.000000e+00 : f32
    %1175 = tensor.splat %1174 {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4xf32>
    %1176 = linalg.reduce ins(%1170:tensor<1x8x4x4xf32>) outs(%1175:tensor<1x8x4xf32>) dimensions = [3]
    (%1177: f32, %1178: f32) {
      %1179 = arith.addf %1177, %1178 : f32
      linalg.yield %1179 : f32
    }
    %1180 = tensor.collapse_shape %1176 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4xf32> into tensor<32xf32>
    %1181 = tensor.expand_shape %1180 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 1] {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<32xf32> into tensor<1x8x4x1xf32>
    %1182 = tensor.empty() : tensor<1x8x4x4xf32>
    %1183 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1170, %1181 : tensor<1x8x4x4xf32>, tensor<1x8x4x1xf32>) outs(%1182 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "softmax_1", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb128(%1184: f32, %1185: f32, %1186: f32):
      %1187 = arith.divf %1184, %1185 : f32
      linalg.yield %1187 : f32
    } -> tensor<1x8x4x4xf32>
    %1188 = tensor.empty() : tensor<1x8x4x4xf32>
    %1189 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1183 : tensor<1x8x4x4xf32>) outs(%1188 : tensor<1x8x4x4xf32>) attrs =  {prov.region_id = "expand_15", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb129(%1190: f32, %1191: f32):
      linalg.yield %1190 : f32
    } -> tensor<1x8x4x4xf32>
    %1192 = tensor.collapse_shape %1189 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_43", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4x4xf32> into tensor<128xf32>
    %1193 = tensor.expand_shape %1192 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 4, 4] {prov.region_id = "view_43", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<128xf32> into tensor<8x4x4xf32>
    %1194 = tensor.empty() : tensor<1x8x4x256xf32>
    %1195 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%1107 : tensor<1x8x4x256xf32>) outs(%1194 : tensor<1x8x4x256xf32>) attrs =  {prov.region_id = "expand_16", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb130(%1196: f32, %1197: f32):
      linalg.yield %1196 : f32
    } -> tensor<1x8x4x256xf32>
    %1198 = tensor.collapse_shape %1195 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_44", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x8x4x256xf32> into tensor<8192xf32>
    %1199 = tensor.expand_shape %1198 [[0 : i64, 1 : i64, 2 : i64]] output_shape [8, 4, 256] {prov.region_id = "view_44", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<8x4x256xf32>
    %1200 = arith.constant {prov.region_id = "matmul_14", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} 0.000000e+00 : f32
    %1201 = tensor.splat %1200 {prov.region_id = "matmul_14", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8x4x256xf32>
    %1202 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%1193, %1199 : tensor<8x4x4xf32>, tensor<8x4x256xf32>) outs(%1201 : tensor<8x4x256xf32>) attrs =  {prov.region_id = "matmul_14", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} {
    ^bb131(%1203: f32, %1204: f32, %1205: f32):
      %1206 = arith.mulf %1203, %1204 : f32
      %1207 = arith.addf %1205, %1206 : f32
      linalg.yield %1207 : f32
    } -> tensor<8x4x256xf32>
    %1208 = tensor.collapse_shape %1202 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_45", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8x4x256xf32> into tensor<8192xf32>
    %1209 = tensor.expand_shape %1208 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 8, 4, 256] {prov.region_id = "view_45", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<1x8x4x256xf32>
    %1210 = tensor.empty() : tensor<1x4x8x256xf32>
    %1211 = linalg.transpose ins(%1209:tensor<1x8x4x256xf32>) outs(%1210:tensor<1x4x8x256xf32>) permutation = [0, 2, 1, 3]
    %1212 = tensor.collapse_shape %1211 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_46", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<1x4x8x256xf32> into tensor<8192xf32>
    %1213 = tensor.expand_shape %1212 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2048] {prov.region_id = "view_46", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn"} : tensor<8192xf32> into tensor<1x4x2048xf32>
    %1214 = tensor.empty() : tensor<2048x2304xf32>
    %1215 = linalg.transpose ins(%15:tensor<2304x2048xf32>) outs(%1214:tensor<2048x2304xf32>) permutation = [1, 0]
    %1216 = tensor.collapse_shape %1213 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_47", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.o_proj"} : tensor<1x4x2048xf32> into tensor<8192xf32>
    %1217 = tensor.expand_shape %1216 [[0 : i64, 1 : i64]] output_shape [4, 2048] {prov.region_id = "view_47", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.o_proj"} : tensor<8192xf32> into tensor<4x2048xf32>
    %1218 = tensor.empty() : tensor<4x2304xf32>
    %1219 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1220 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%1219 : f32) outs(%1218 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %1221 = linalg.matmul {prov.region_id = "matmul_15", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.o_proj", prov.transposed_b = "true"} ins(%1217, %1215 : tensor<4x2048xf32>, tensor<2048x2304xf32>) outs(%1220 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %1222 = tensor.collapse_shape %1221 [[0 : i64, 1 : i64]] {prov.region_id = "view_48", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.o_proj"} : tensor<4x2304xf32> into tensor<9216xf32>
    %1223 = tensor.expand_shape %1222 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2304] {prov.region_id = "view_48", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.self_attn.o_proj"} : tensor<9216xf32> into tensor<1x4x2304xf32>
    %1224 = tensor.empty() : tensor<1x4x2304xf32>
    %1225 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1223 : tensor<1x4x2304xf32>) outs(%1224 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_5", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} {
    ^bb132(%1226: f32, %1227: f32):
      %1228 = arith.constant 2.000000e+00 : f32
      %1229 = math.powf %1226, %1228 : f32
      linalg.yield %1229 : f32
    } -> tensor<1x4x2304xf32>
    %1230 = arith.constant {prov.region_id = "reduce_5", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} 0.000000e+00 : f32
    %1231 = tensor.splat %1230 {prov.region_id = "reduce_5", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} : tensor<1x4xf32>
    %1232 = linalg.reduce ins(%1225:tensor<1x4x2304xf32>) outs(%1231:tensor<1x4xf32>) dimensions = [2]
    (%1233: f32, %1234: f32) {
      %1235 = arith.addf %1233, %1234 : f32
      linalg.yield %1235 : f32
    }
    %1236 = arith.constant {prov.region_id = "reduce_5", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} 2.304000e+03 : f32
    %1237 = tensor.splat %1236 {prov.region_id = "reduce_5", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} : tensor<1x4xf32>
    %1238 = tensor.empty() : tensor<1x4xf32>
    %1239 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1232, %1237 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%1238 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_5", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} {
    ^bb133(%1240: f32, %1241: f32, %1242: f32):
      %1243 = arith.divf %1240, %1241 : f32
      linalg.yield %1243 : f32
    } -> tensor<1x4xf32>
    %1244 = tensor.collapse_shape %1239 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_5", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %1245 = tensor.expand_shape %1244 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_5", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %1246 = arith.constant {prov.region_id = "add_21", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} 1.000000e-06 : f32
    %1247 = tensor.splat %1246 {prov.region_id = "add_21", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} : tensor<1x4x1xf32>
    %1248 = tensor.empty() : tensor<1x4x1xf32>
    %1249 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1245, %1247 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%1248 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_21", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} {
    ^bb134(%1250: f32, %1251: f32, %1252: f32):
      %1253 = arith.addf %1250, %1251 : f32
      linalg.yield %1253 : f32
    } -> tensor<1x4x1xf32>
    %1254 = tensor.empty() : tensor<1x4x1xf32>
    %1255 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1249 : tensor<1x4x1xf32>) outs(%1254 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_5", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} {
    ^bb135(%1256: f32, %1257: f32):
      %1258 = math.rsqrt %1256 : f32
      linalg.yield %1258 : f32
    } -> tensor<1x4x1xf32>
    %1259 = tensor.empty() : tensor<1x4x2304xf32>
    %1260 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1223, %1255 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%1259 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_24", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} {
    ^bb136(%1261: f32, %1262: f32, %1263: f32):
      %1264 = arith.mulf %1261, %1262 : f32
      linalg.yield %1264 : f32
    } -> tensor<1x4x2304xf32>
    %1265 = arith.constant {prov.region_id = "add_22", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} 1.000000e+00 : f32
    %1266 = tensor.splat %1265 {prov.region_id = "add_22", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} : tensor<2304xf32>
    %1267 = tensor.empty() : tensor<2304xf32>
    %1268 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%20, %1266 : tensor<2304xf32>, tensor<2304xf32>) outs(%1267 : tensor<2304xf32>) attrs =  {prov.region_id = "add_22", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} {
    ^bb137(%1269: f32, %1270: f32, %1271: f32):
      %1272 = arith.addf %1269, %1270 : f32
      linalg.yield %1272 : f32
    } -> tensor<2304xf32>
    %1273 = tensor.empty() : tensor<1x4x2304xf32>
    %1274 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1260, %1268 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%1273 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_25", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_attention_layernorm"} {
    ^bb138(%1275: f32, %1276: f32, %1277: f32):
      %1278 = arith.mulf %1275, %1276 : f32
      linalg.yield %1278 : f32
    } -> tensor<1x4x2304xf32>
    %1279 = tensor.empty() : tensor<1x4x2304xf32>
    %1280 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%934, %1274 : tensor<1x4x2304xf32>, tensor<1x4x2304xf32>) outs(%1279 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "add_23", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1"} {
    ^bb139(%1281: f32, %1282: f32, %1283: f32):
      %1284 = arith.addf %1281, %1282 : f32
      linalg.yield %1284 : f32
    } -> tensor<1x4x2304xf32>
    %1285 = tensor.empty() : tensor<1x4x2304xf32>
    %1286 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1280 : tensor<1x4x2304xf32>) outs(%1285 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_6", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} {
    ^bb140(%1287: f32, %1288: f32):
      %1289 = arith.constant 2.000000e+00 : f32
      %1290 = math.powf %1287, %1289 : f32
      linalg.yield %1290 : f32
    } -> tensor<1x4x2304xf32>
    %1291 = arith.constant {prov.region_id = "reduce_6", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} 0.000000e+00 : f32
    %1292 = tensor.splat %1291 {prov.region_id = "reduce_6", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} : tensor<1x4xf32>
    %1293 = linalg.reduce ins(%1286:tensor<1x4x2304xf32>) outs(%1292:tensor<1x4xf32>) dimensions = [2]
    (%1294: f32, %1295: f32) {
      %1296 = arith.addf %1294, %1295 : f32
      linalg.yield %1296 : f32
    }
    %1297 = arith.constant {prov.region_id = "reduce_6", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} 2.304000e+03 : f32
    %1298 = tensor.splat %1297 {prov.region_id = "reduce_6", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} : tensor<1x4xf32>
    %1299 = tensor.empty() : tensor<1x4xf32>
    %1300 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1293, %1298 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%1299 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_6", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} {
    ^bb141(%1301: f32, %1302: f32, %1303: f32):
      %1304 = arith.divf %1301, %1302 : f32
      linalg.yield %1304 : f32
    } -> tensor<1x4xf32>
    %1305 = tensor.collapse_shape %1300 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_6", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %1306 = tensor.expand_shape %1305 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_6", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %1307 = arith.constant {prov.region_id = "add_24", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} 1.000000e-06 : f32
    %1308 = tensor.splat %1307 {prov.region_id = "add_24", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} : tensor<1x4x1xf32>
    %1309 = tensor.empty() : tensor<1x4x1xf32>
    %1310 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1306, %1308 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%1309 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_24", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} {
    ^bb142(%1311: f32, %1312: f32, %1313: f32):
      %1314 = arith.addf %1311, %1312 : f32
      linalg.yield %1314 : f32
    } -> tensor<1x4x1xf32>
    %1315 = tensor.empty() : tensor<1x4x1xf32>
    %1316 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1310 : tensor<1x4x1xf32>) outs(%1315 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_6", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} {
    ^bb143(%1317: f32, %1318: f32):
      %1319 = math.rsqrt %1317 : f32
      linalg.yield %1319 : f32
    } -> tensor<1x4x1xf32>
    %1320 = tensor.empty() : tensor<1x4x2304xf32>
    %1321 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1280, %1316 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%1320 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_26", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} {
    ^bb144(%1322: f32, %1323: f32, %1324: f32):
      %1325 = arith.mulf %1322, %1323 : f32
      linalg.yield %1325 : f32
    } -> tensor<1x4x2304xf32>
    %1326 = arith.constant {prov.region_id = "add_25", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} 1.000000e+00 : f32
    %1327 = tensor.splat %1326 {prov.region_id = "add_25", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} : tensor<2304xf32>
    %1328 = tensor.empty() : tensor<2304xf32>
    %1329 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%21, %1327 : tensor<2304xf32>, tensor<2304xf32>) outs(%1328 : tensor<2304xf32>) attrs =  {prov.region_id = "add_25", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} {
    ^bb145(%1330: f32, %1331: f32, %1332: f32):
      %1333 = arith.addf %1330, %1331 : f32
      linalg.yield %1333 : f32
    } -> tensor<2304xf32>
    %1334 = tensor.empty() : tensor<1x4x2304xf32>
    %1335 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1321, %1329 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%1334 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_27", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.pre_feedforward_layernorm"} {
    ^bb146(%1336: f32, %1337: f32, %1338: f32):
      %1339 = arith.mulf %1336, %1337 : f32
      linalg.yield %1339 : f32
    } -> tensor<1x4x2304xf32>
    %1340 = tensor.empty() : tensor<2304x9216xf32>
    %1341 = linalg.transpose ins(%16:tensor<9216x2304xf32>) outs(%1340:tensor<2304x9216xf32>) permutation = [1, 0]
    %1342 = tensor.collapse_shape %1335 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_49", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.gate_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %1343 = tensor.expand_shape %1342 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_49", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.gate_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %1344 = tensor.empty() : tensor<4x9216xf32>
    %1345 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1346 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%1345 : f32) outs(%1344 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %1347 = linalg.matmul {prov.region_id = "matmul_16", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.gate_proj", prov.transposed_b = "true"} ins(%1343, %1341 : tensor<4x2304xf32>, tensor<2304x9216xf32>) outs(%1346 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %1348 = tensor.collapse_shape %1347 [[0 : i64, 1 : i64]] {prov.region_id = "view_50", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.gate_proj"} : tensor<4x9216xf32> into tensor<36864xf32>
    %1349 = tensor.expand_shape %1348 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 9216] {prov.region_id = "view_50", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.gate_proj"} : tensor<36864xf32> into tensor<1x4x9216xf32>
    %1350 = tensor.empty() : tensor<1x4x9216xf32>
    %1351 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1349 : tensor<1x4x9216xf32>) outs(%1350 : tensor<1x4x9216xf32>) attrs =  {prov.region_id = "gelu_1", prov._pattern_hint = "gelu", prov.op = "gelu", prov.family = "elementwise", prov.aten = "aten.gelu.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.act_fn"} {
    ^bb147(%1352: f32, %1353: f32):
      %1354 = arith.constant 5.000000e-01 : f32
      %1355 = arith.constant 1.000000e+00 : f32
      %1356 = arith.constant 0.707106769 : f32
      %1357 = arith.mulf %1352, %1356 : f32
      %1358 = math.erf %1357 : f32
      %1359 = arith.addf %1355, %1358 : f32
      %1360 = arith.mulf %1354, %1352 : f32
      %1361 = arith.mulf %1360, %1359 : f32
      linalg.yield %1361 : f32
    } -> tensor<1x4x9216xf32>
    %1362 = tensor.empty() : tensor<2304x9216xf32>
    %1363 = linalg.transpose ins(%17:tensor<9216x2304xf32>) outs(%1362:tensor<2304x9216xf32>) permutation = [1, 0]
    %1364 = tensor.collapse_shape %1335 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_51", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.up_proj"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %1365 = tensor.expand_shape %1364 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_51", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.up_proj"} : tensor<9216xf32> into tensor<4x2304xf32>
    %1366 = tensor.empty() : tensor<4x9216xf32>
    %1367 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1368 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%1367 : f32) outs(%1366 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %1369 = linalg.matmul {prov.region_id = "matmul_17", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.up_proj", prov.transposed_b = "true"} ins(%1365, %1363 : tensor<4x2304xf32>, tensor<2304x9216xf32>) outs(%1368 : tensor<4x9216xf32>) -> tensor<4x9216xf32>
    %1370 = tensor.collapse_shape %1369 [[0 : i64, 1 : i64]] {prov.region_id = "view_52", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.up_proj"} : tensor<4x9216xf32> into tensor<36864xf32>
    %1371 = tensor.expand_shape %1370 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 9216] {prov.region_id = "view_52", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.up_proj"} : tensor<36864xf32> into tensor<1x4x9216xf32>
    %1372 = tensor.empty() : tensor<1x4x9216xf32>
    %1373 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1351, %1371 : tensor<1x4x9216xf32>, tensor<1x4x9216xf32>) outs(%1372 : tensor<1x4x9216xf32>) attrs =  {prov.region_id = "mul_28", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp"} {
    ^bb148(%1374: f32, %1375: f32, %1376: f32):
      %1377 = arith.mulf %1374, %1375 : f32
      linalg.yield %1377 : f32
    } -> tensor<1x4x9216xf32>
    %1378 = tensor.empty() : tensor<9216x2304xf32>
    %1379 = linalg.transpose ins(%18:tensor<2304x9216xf32>) outs(%1378:tensor<9216x2304xf32>) permutation = [1, 0]
    %1380 = tensor.collapse_shape %1373 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_53", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.down_proj"} : tensor<1x4x9216xf32> into tensor<36864xf32>
    %1381 = tensor.expand_shape %1380 [[0 : i64, 1 : i64]] output_shape [4, 9216] {prov.region_id = "view_53", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.down_proj"} : tensor<36864xf32> into tensor<4x9216xf32>
    %1382 = tensor.empty() : tensor<4x2304xf32>
    %1383 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1384 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%1383 : f32) outs(%1382 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %1385 = linalg.matmul {prov.region_id = "matmul_18", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.down_proj", prov.transposed_b = "true"} ins(%1381, %1379 : tensor<4x9216xf32>, tensor<9216x2304xf32>) outs(%1384 : tensor<4x2304xf32>) -> tensor<4x2304xf32>
    %1386 = tensor.collapse_shape %1385 [[0 : i64, 1 : i64]] {prov.region_id = "view_54", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.down_proj"} : tensor<4x2304xf32> into tensor<9216xf32>
    %1387 = tensor.expand_shape %1386 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 2304] {prov.region_id = "view_54", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.mlp.down_proj"} : tensor<9216xf32> into tensor<1x4x2304xf32>
    %1388 = tensor.empty() : tensor<1x4x2304xf32>
    %1389 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1387 : tensor<1x4x2304xf32>) outs(%1388 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_7", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} {
    ^bb149(%1390: f32, %1391: f32):
      %1392 = arith.constant 2.000000e+00 : f32
      %1393 = math.powf %1390, %1392 : f32
      linalg.yield %1393 : f32
    } -> tensor<1x4x2304xf32>
    %1394 = arith.constant {prov.region_id = "reduce_7", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} 0.000000e+00 : f32
    %1395 = tensor.splat %1394 {prov.region_id = "reduce_7", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} : tensor<1x4xf32>
    %1396 = linalg.reduce ins(%1389:tensor<1x4x2304xf32>) outs(%1395:tensor<1x4xf32>) dimensions = [2]
    (%1397: f32, %1398: f32) {
      %1399 = arith.addf %1397, %1398 : f32
      linalg.yield %1399 : f32
    }
    %1400 = arith.constant {prov.region_id = "reduce_7", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} 2.304000e+03 : f32
    %1401 = tensor.splat %1400 {prov.region_id = "reduce_7", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} : tensor<1x4xf32>
    %1402 = tensor.empty() : tensor<1x4xf32>
    %1403 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1396, %1401 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%1402 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_7", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} {
    ^bb150(%1404: f32, %1405: f32, %1406: f32):
      %1407 = arith.divf %1404, %1405 : f32
      linalg.yield %1407 : f32
    } -> tensor<1x4xf32>
    %1408 = tensor.collapse_shape %1403 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_7", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %1409 = tensor.expand_shape %1408 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_7", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %1410 = arith.constant {prov.region_id = "add_26", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} 1.000000e-06 : f32
    %1411 = tensor.splat %1410 {prov.region_id = "add_26", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} : tensor<1x4x1xf32>
    %1412 = tensor.empty() : tensor<1x4x1xf32>
    %1413 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1409, %1411 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%1412 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_26", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} {
    ^bb151(%1414: f32, %1415: f32, %1416: f32):
      %1417 = arith.addf %1414, %1415 : f32
      linalg.yield %1417 : f32
    } -> tensor<1x4x1xf32>
    %1418 = tensor.empty() : tensor<1x4x1xf32>
    %1419 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1413 : tensor<1x4x1xf32>) outs(%1418 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_7", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} {
    ^bb152(%1420: f32, %1421: f32):
      %1422 = math.rsqrt %1420 : f32
      linalg.yield %1422 : f32
    } -> tensor<1x4x1xf32>
    %1423 = tensor.empty() : tensor<1x4x2304xf32>
    %1424 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1387, %1419 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%1423 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_29", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} {
    ^bb153(%1425: f32, %1426: f32, %1427: f32):
      %1428 = arith.mulf %1425, %1426 : f32
      linalg.yield %1428 : f32
    } -> tensor<1x4x2304xf32>
    %1429 = arith.constant {prov.region_id = "add_27", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} 1.000000e+00 : f32
    %1430 = tensor.splat %1429 {prov.region_id = "add_27", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} : tensor<2304xf32>
    %1431 = tensor.empty() : tensor<2304xf32>
    %1432 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%22, %1430 : tensor<2304xf32>, tensor<2304xf32>) outs(%1431 : tensor<2304xf32>) attrs =  {prov.region_id = "add_27", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} {
    ^bb154(%1433: f32, %1434: f32, %1435: f32):
      %1436 = arith.addf %1433, %1434 : f32
      linalg.yield %1436 : f32
    } -> tensor<2304xf32>
    %1437 = tensor.empty() : tensor<1x4x2304xf32>
    %1438 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1424, %1432 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%1437 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_30", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1.post_feedforward_layernorm"} {
    ^bb155(%1439: f32, %1440: f32, %1441: f32):
      %1442 = arith.mulf %1439, %1440 : f32
      linalg.yield %1442 : f32
    } -> tensor<1x4x2304xf32>
    %1443 = tensor.empty() : tensor<1x4x2304xf32>
    %1444 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1280, %1438 : tensor<1x4x2304xf32>, tensor<1x4x2304xf32>) outs(%1443 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "add_28", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.1"} {
    ^bb156(%1445: f32, %1446: f32, %1447: f32):
      %1448 = arith.addf %1445, %1446 : f32
      linalg.yield %1448 : f32
    } -> tensor<1x4x2304xf32>
    %1449 = tensor.empty() : tensor<1x4x2304xf32>
    %1450 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1444 : tensor<1x4x2304xf32>) outs(%1449 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "pow_8", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb157(%1451: f32, %1452: f32):
      %1453 = arith.constant 2.000000e+00 : f32
      %1454 = math.powf %1451, %1453 : f32
      linalg.yield %1454 : f32
    } -> tensor<1x4x2304xf32>
    %1455 = arith.constant {prov.region_id = "reduce_8", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} 0.000000e+00 : f32
    %1456 = tensor.splat %1455 {prov.region_id = "reduce_8", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4xf32>
    %1457 = linalg.reduce ins(%1450:tensor<1x4x2304xf32>) outs(%1456:tensor<1x4xf32>) dimensions = [2]
    (%1458: f32, %1459: f32) {
      %1460 = arith.addf %1458, %1459 : f32
      linalg.yield %1460 : f32
    }
    %1461 = arith.constant {prov.region_id = "reduce_8", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} 2.304000e+03 : f32
    %1462 = tensor.splat %1461 {prov.region_id = "reduce_8", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4xf32>
    %1463 = tensor.empty() : tensor<1x4xf32>
    %1464 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1457, %1462 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%1463 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_8", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb158(%1465: f32, %1466: f32, %1467: f32):
      %1468 = arith.divf %1465, %1466 : f32
      linalg.yield %1468 : f32
    } -> tensor<1x4xf32>
    %1469 = tensor.collapse_shape %1464 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_8", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4xf32> into tensor<4xf32>
    %1470 = tensor.expand_shape %1469 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_8", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %1471 = arith.constant {prov.region_id = "add_29", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} 1.000000e-06 : f32
    %1472 = tensor.splat %1471 {prov.region_id = "add_29", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4x1xf32>
    %1473 = tensor.empty() : tensor<1x4x1xf32>
    %1474 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1470, %1472 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%1473 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_29", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb159(%1475: f32, %1476: f32, %1477: f32):
      %1478 = arith.addf %1475, %1476 : f32
      linalg.yield %1478 : f32
    } -> tensor<1x4x1xf32>
    %1479 = tensor.empty() : tensor<1x4x1xf32>
    %1480 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1474 : tensor<1x4x1xf32>) outs(%1479 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_8", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb160(%1481: f32, %1482: f32):
      %1483 = math.rsqrt %1481 : f32
      linalg.yield %1483 : f32
    } -> tensor<1x4x1xf32>
    %1484 = tensor.empty() : tensor<1x4x2304xf32>
    %1485 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1444, %1480 : tensor<1x4x2304xf32>, tensor<1x4x1xf32>) outs(%1484 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_31", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb161(%1486: f32, %1487: f32, %1488: f32):
      %1489 = arith.mulf %1486, %1487 : f32
      linalg.yield %1489 : f32
    } -> tensor<1x4x2304xf32>
    %1490 = arith.constant {prov.region_id = "add_30", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} 1.000000e+00 : f32
    %1491 = tensor.splat %1490 {prov.region_id = "add_30", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<2304xf32>
    %1492 = tensor.empty() : tensor<2304xf32>
    %1493 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%23, %1491 : tensor<2304xf32>, tensor<2304xf32>) outs(%1492 : tensor<2304xf32>) attrs =  {prov.region_id = "add_30", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb162(%1494: f32, %1495: f32, %1496: f32):
      %1497 = arith.addf %1494, %1495 : f32
      linalg.yield %1497 : f32
    } -> tensor<2304xf32>
    %1498 = tensor.empty() : tensor<1x4x2304xf32>
    %1499 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1485, %1493 : tensor<1x4x2304xf32>, tensor<2304xf32>) outs(%1498 : tensor<1x4x2304xf32>) attrs =  {prov.region_id = "mul_32", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb163(%1500: f32, %1501: f32, %1502: f32):
      %1503 = arith.mulf %1500, %1501 : f32
      linalg.yield %1503 : f32
    } -> tensor<1x4x2304xf32>
    %1504 = tensor.empty() : tensor<2304x256000xf32>
    %1505 = linalg.transpose ins(%24:tensor<256000x2304xf32>) outs(%1504:tensor<2304x256000xf32>) permutation = [1, 0]
    %1506 = tensor.collapse_shape %1499 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_55", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<1x4x2304xf32> into tensor<9216xf32>
    %1507 = tensor.expand_shape %1506 [[0 : i64, 1 : i64]] output_shape [4, 2304] {prov.region_id = "view_55", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<9216xf32> into tensor<4x2304xf32>
    %1508 = tensor.empty() : tensor<4x256000xf32>
    %1509 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %1510 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%1509 : f32) outs(%1508 : tensor<4x256000xf32>) -> tensor<4x256000xf32>
    %1511 = linalg.matmul {prov.region_id = "matmul_19", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head", prov.transposed_b = "true"} ins(%1507, %1505 : tensor<4x2304xf32>, tensor<2304x256000xf32>) outs(%1510 : tensor<4x256000xf32>) -> tensor<4x256000xf32>
    %1512 = tensor.collapse_shape %1511 [[0 : i64, 1 : i64]] {prov.region_id = "view_56", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<4x256000xf32> into tensor<1024000xf32>
    %1513 = tensor.expand_shape %1512 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 256000] {prov.region_id = "view_56", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<1024000xf32> into tensor<1x4x256000xf32>
    %1514 = arith.constant {prov.region_id = "div_0", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} 3.000000e+01 : f32
    %1515 = tensor.splat %1514 {prov.region_id = "div_0", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} : tensor<1x4x256000xf32>
    %1516 = tensor.empty() : tensor<1x4x256000xf32>
    %1517 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1513, %1515 : tensor<1x4x256000xf32>, tensor<1x4x256000xf32>) outs(%1516 : tensor<1x4x256000xf32>) attrs =  {prov.region_id = "div_0", prov._pattern_hint = "div", prov.op = "div", prov.family = "elementwise", prov.aten = "aten.div.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} {
    ^bb164(%1518: f32, %1519: f32, %1520: f32):
      %1521 = arith.divf %1518, %1519 : f32
      linalg.yield %1521 : f32
    } -> tensor<1x4x256000xf32>
    %1522 = tensor.empty() : tensor<1x4x256000xf32>
    %1523 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1517 : tensor<1x4x256000xf32>) outs(%1522 : tensor<1x4x256000xf32>) attrs =  {prov.region_id = "tanh_0", prov._pattern_hint = "tanh", prov.op = "tanh", prov.family = "elementwise", prov.aten = "aten.tanh.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} {
    ^bb165(%1524: f32, %1525: f32):
      %1526 = math.tanh %1524 : f32
      linalg.yield %1526 : f32
    } -> tensor<1x4x256000xf32>
    %1527 = arith.constant {prov.region_id = "mul_33", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} 3.000000e+01 : f32
    %1528 = tensor.splat %1527 {prov.region_id = "mul_33", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} : tensor<1x4x256000xf32>
    %1529 = tensor.empty() : tensor<1x4x256000xf32>
    %1530 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%1523, %1528 : tensor<1x4x256000xf32>, tensor<1x4x256000xf32>) outs(%1529 : tensor<1x4x256000xf32>) attrs =  {prov.region_id = "mul_33", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm"} {
    ^bb166(%1531: f32, %1532: f32, %1533: f32):
      %1534 = arith.mulf %1531, %1532 : f32
      linalg.yield %1534 : f32
    } -> tensor<1x4x256000xf32>
    func.return %1530 : tensor<1x4x256000xf32>
  }
}
