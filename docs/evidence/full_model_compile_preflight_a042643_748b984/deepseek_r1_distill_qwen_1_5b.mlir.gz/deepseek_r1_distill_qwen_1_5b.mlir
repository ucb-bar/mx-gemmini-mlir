builtin.module attributes {prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<151936x1536xf32>, %1: tensor<1536x1536xf32>, %2: tensor<1536xf32>, %3: tensor<256x1536xf32>, %4: tensor<256xf32>, %5: tensor<256x1536xf32>, %6: tensor<256xf32>, %7: tensor<1536x1536xf32>, %8: tensor<8960x1536xf32>, %9: tensor<8960x1536xf32>, %10: tensor<1536x8960xf32>, %11: tensor<1536xf32>, %12: tensor<1536xf32>, %13: tensor<1536xf32>, %14: tensor<151936x1536xf32>, %15: tensor<64xf32>, %16: tensor<64xf32>, %17: tensor<1x4xi64>) -> tensor<1x4x151936xf32> {
    %18 = tensor.empty() : tensor<1x4x1536xf32>
    %19 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%17 : tensor<1x4xi64>) outs(%18 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "gather_0", prov.family = "gather_scatter", prov._pattern_hint = "embedding", prov.op = "embedding", prov.aten = "aten.embedding.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.embed_tokens"} {
    ^bb0(%20: i64, %21: f32):
      %22 = arith.index_cast %20 : i64 to index
      %23 = linalg.index 2 : index
      %24 = tensor.extract %0[%22, %23] : tensor<151936x1536xf32>
      linalg.yield %24 : f32
    } -> tensor<1x4x1536xf32>
    %25 = tensor.empty() : tensor<4xi64>
    %26 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%25 : tensor<4xi64>) attrs =  {prov.region_id = "iota_0", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb1(%27: i64):
      %28 = linalg.index 0 : index
      %29 = arith.index_cast %28 : index to i64
      %30 = arith.constant 1 : i64
      %31 = arith.muli %29, %30 : i64
      %32 = arith.constant 0 : i64
      %33 = arith.addi %32, %31 : i64
      linalg.yield %33 : i64
    } -> tensor<4xi64>
    %34 = arith.constant {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %35 = tensor.splat %34 {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %36 = tensor.empty() : tensor<4xi64>
    %37 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%26, %35 : tensor<4xi64>, tensor<4xi64>) outs(%36 : tensor<4xi64>) attrs =  {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb2(%38: i64, %39: i64, %40: i64):
      %41 = arith.addi %38, %39 : i64
      linalg.yield %41 : i64
    } -> tensor<4xi64>
    %42 = tensor.expand_shape %37 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %43 = "tensor.extract_slice"(%42) <{static_offsets = array<i64: 0, 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_0", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x4xi64>) -> tensor<1x1xi64>
    %44 = arith.constant {prov.region_id = "sub_0", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 1 : i64
    %45 = tensor.splat %44 {prov.region_id = "sub_0", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1xi64>
    %46 = tensor.empty() : tensor<1x1xi64>
    %47 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%43, %45 : tensor<1x1xi64>, tensor<1x1xi64>) outs(%46 : tensor<1x1xi64>) attrs =  {prov.region_id = "sub_0", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb3(%48: i64, %49: i64, %50: i64):
      %51 = arith.subi %48, %49 : i64
      linalg.yield %51 : i64
    } -> tensor<1x1xi64>
    %52 = tensor.concat dim(1) %47, %42 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x1xi64>, tensor<1x4xi64>) -> tensor<1x5xi64>
    %53 = "tensor.extract_slice"(%52) <{static_offsets = array<i64: 0, 0>, static_sizes = array<i64: 1, 4>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_1", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x5xi64>) -> tensor<1x4xi64>
    %54 = "tensor.extract_slice"(%52) <{static_offsets = array<i64: 0, 1>, static_sizes = array<i64: 1, 4>, static_strides = array<i64: 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_2", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : (tensor<1x5xi64>) -> tensor<1x4xi64>
    %55 = tensor.empty() : tensor<1x4xi64>
    %56 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%54, %53 : tensor<1x4xi64>, tensor<1x4xi64>) outs(%55 : tensor<1x4xi64>) attrs =  {prov.region_id = "sub_1", prov._pattern_hint = "sub", prov.op = "sub", prov.family = "elementwise", prov.aten = "aten.sub.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb4(%57: i64, %58: i64, %59: i64):
      %60 = arith.subi %57, %58 : i64
      linalg.yield %60 : i64
    } -> tensor<1x4xi64>
    %61 = arith.constant {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} 1 : i64
    %62 = tensor.splat %61 {prov._pattern_hint = "compare", prov.op = "compare", prov.family = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64>
    %63 = tensor.empty() : tensor<1x4xi1>
    %64 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%56, %62 : tensor<1x4xi64>, tensor<1x4xi64>) outs(%63 : tensor<1x4xi1>) attrs =  {prov.region_id = "compare_0", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.ne.Scalar", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb5(%65: i64, %66: i64, %67: i1):
      %68 = arith.cmpi ne, %65, %66 : i64
      linalg.yield %68 : i1
    } -> tensor<1x4xi1>
    %69 = arith.constant {prov.region_id = "scan_0", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %70 = tensor.splat %69 {prov.region_id = "scan_0", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64>
    %71 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iterator_types = ["parallel", "parallel", "reduction"]} ins(%64 : tensor<1x4xi1>) outs(%70 : tensor<1x4xi64>) attrs =  {prov.region_id = "scan_0", prov.family = "scan", prov._pattern_hint = "cumsum", prov.op = "cumsum", prov.aten = "aten.cumsum.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb6(%72: i1, %73: i64):
      %74 = linalg.index 1 : index
      %75 = linalg.index 2 : index
      %76 = arith.cmpi ule, %75, %74 : index
      %77 = arith.extui %72 : i1 to i64
      %78 = arith.select %76, %77, %69 : i64
      %79 = arith.addi %73, %78 : i64
      linalg.yield %79 : i64
    } -> tensor<1x4xi64>
    %80 = tensor.empty() : tensor<1xi64>
    %81 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%80 : tensor<1xi64>) attrs =  {prov.region_id = "iota_1", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb7(%82: i64):
      %83 = linalg.index 0 : index
      %84 = arith.index_cast %83 : index to i64
      %85 = arith.constant 1 : i64
      %86 = arith.muli %84, %85 : i64
      %87 = arith.constant 0 : i64
      %88 = arith.addi %87, %86 : i64
      linalg.yield %88 : i64
    } -> tensor<1xi64>
    %89 = tensor.empty() : tensor<4xi64>
    %90 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%89 : tensor<4xi64>) attrs =  {prov.region_id = "iota_2", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb8(%91: i64):
      %92 = linalg.index 0 : index
      %93 = arith.index_cast %92 : index to i64
      %94 = arith.constant 1 : i64
      %95 = arith.muli %93, %94 : i64
      %96 = arith.constant 0 : i64
      %97 = arith.addi %96, %95 : i64
      linalg.yield %97 : i64
    } -> tensor<4xi64>
    %98 = arith.constant {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %99 = tensor.splat %98 {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %100 = tensor.empty() : tensor<4xi64>
    %101 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%90, %99 : tensor<4xi64>, tensor<4xi64>) outs(%100 : tensor<4xi64>) attrs =  {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb9(%102: i64, %103: i64, %104: i64):
      %105 = arith.addi %102, %103 : i64
      linalg.yield %105 : i64
    } -> tensor<4xi64>
    %106 = tensor.empty() : tensor<4xi64>
    %107 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%106 : tensor<4xi64>) attrs =  {prov.region_id = "iota_3", prov.family = "iota", prov._pattern_hint = "arange", prov.op = "arange", prov.aten = "aten.arange.start_step", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb10(%108: i64):
      %109 = linalg.index 0 : index
      %110 = arith.index_cast %109 : index to i64
      %111 = arith.constant 1 : i64
      %112 = arith.muli %110, %111 : i64
      %113 = arith.constant 0 : i64
      %114 = arith.addi %113, %112 : i64
      linalg.yield %114 : i64
    } -> tensor<4xi64>
    %115 = arith.constant {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} 0 : i64
    %116 = tensor.splat %115 {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64>
    %117 = tensor.empty() : tensor<4xi64>
    %118 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%107, %116 : tensor<4xi64>, tensor<4xi64>) outs(%117 : tensor<4xi64>) attrs =  {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb11(%119: i64, %120: i64, %121: i64):
      %122 = arith.addi %119, %120 : i64
      linalg.yield %122 : i64
    } -> tensor<4xi64>
    %123 = tensor.expand_shape %81 [[0 : i64, 1 : i64]] output_shape [1, 1] {prov.region_id = "unsqueeze_1", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1xi64>
    %124 = tensor.collapse_shape %123 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_2", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1xi64> into tensor<1xi64>
    %125 = tensor.expand_shape %124 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 1] {prov.region_id = "unsqueeze_2", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1x1xi64>
    %126 = tensor.collapse_shape %125 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_3", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x1xi64> into tensor<1xi64>
    %127 = tensor.expand_shape %126 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 1, 1] {prov.region_id = "unsqueeze_3", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1xi64> into tensor<1x1x1x1xi64>
    %128 = tensor.expand_shape %101 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_4", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %129 = tensor.collapse_shape %128 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_5", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64> into tensor<4xi64>
    %130 = tensor.expand_shape %129 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_5", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4xi64>
    %131 = tensor.collapse_shape %130 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_6", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x4xi64> into tensor<4xi64>
    %132 = tensor.expand_shape %131 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 1] {prov.region_id = "unsqueeze_6", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4x1xi64>
    %133 = tensor.expand_shape %118 [[0 : i64, 1 : i64]] output_shape [1, 4] {prov.region_id = "unsqueeze_7", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x4xi64>
    %134 = tensor.collapse_shape %133 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_8", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x4xi64> into tensor<4xi64>
    %135 = tensor.expand_shape %134 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_8", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x4xi64>
    %136 = tensor.collapse_shape %135 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_9", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<1x1x4xi64> into tensor<4xi64>
    %137 = tensor.expand_shape %136 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 1, 4] {prov.region_id = "unsqueeze_9", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} : tensor<4xi64> into tensor<1x1x1x4xi64>
    %138 = arith.constant {prov.region_id = "fill_0", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} true
    %139 = tensor.splat %138 {prov.region_id = "fill_0", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.full.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} : tensor<i1>
    %140 = tensor.empty() : tensor<1x1x4x4xi1>
    %141 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%137, %132 : tensor<1x1x1x4xi64>, tensor<1x1x4x1xi64>) outs(%140 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "compare_1", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.le.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb12(%142: i64, %143: i64, %144: i1):
      %145 = arith.cmpi sle, %142, %143 : i64
      linalg.yield %145 : i1
    } -> tensor<1x1x4x4xi1>
    %146 = tensor.empty() : tensor<1x1x4x4xi1>
    %147 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> ()>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%139, %141 : tensor<i1>, tensor<1x1x4x4xi1>) outs(%146 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_0", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb13(%148: i1, %149: i1, %150: i1):
      %151 = arith.andi %148, %149 : i1
      linalg.yield %151 : i1
    } -> tensor<1x1x4x4xi1>
    %152 = tensor.empty() : tensor<1x1x4x1xi64>
    %153 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%127, %132 : tensor<1x1x1x1xi64>, tensor<1x1x4x1xi64>) outs(%152 : tensor<1x1x4x1xi64>) attrs =  {prov.region_id = "gather_1", prov.family = "gather_scatter", prov._pattern_hint = "index_gather", prov.op = "index_gather", prov.aten = "aten.index.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb14(%154: i64, %155: i64, %156: i64):
      %157 = arith.index_cast %154 : i64 to index
      %158 = arith.index_cast %155 : i64 to index
      %159 = tensor.extract %71[%157, %158] : tensor<1x4xi64>
      linalg.yield %159 : i64
    } -> tensor<1x1x4x1xi64>
    %160 = tensor.empty() : tensor<1x1x1x4xi64>
    %161 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%127, %137 : tensor<1x1x1x1xi64>, tensor<1x1x1x4xi64>) outs(%160 : tensor<1x1x1x4xi64>) attrs =  {prov.region_id = "gather_2", prov.family = "gather_scatter", prov._pattern_hint = "index_gather", prov.op = "index_gather", prov.aten = "aten.index.Tensor", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb15(%162: i64, %163: i64, %164: i64):
      %165 = arith.index_cast %162 : i64 to index
      %166 = arith.index_cast %163 : i64 to index
      %167 = tensor.extract %71[%165, %166] : tensor<1x4xi64>
      linalg.yield %167 : i64
    } -> tensor<1x1x1x4xi64>
    %168 = tensor.empty() : tensor<1x1x4x4xi1>
    %169 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, 0, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%153, %161 : tensor<1x1x4x1xi64>, tensor<1x1x1x4xi64>) outs(%168 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "compare_2", prov.family = "compare", prov._pattern_hint = "compare", prov.op = "compare", prov.aten = "aten.eq.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb16(%170: i64, %171: i64, %172: i1):
      %173 = arith.cmpi eq, %170, %171 : i64
      linalg.yield %173 : i1
    } -> tensor<1x1x4x4xi1>
    %174 = tensor.empty() : tensor<1x1x4x4xi1>
    %175 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%147, %169 : tensor<1x1x4x4xi1>, tensor<1x1x4x4xi1>) outs(%174 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_1", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_and.Tensor", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb17(%176: i1, %177: i1, %178: i1):
      %179 = arith.andi %176, %177 : i1
      linalg.yield %179 : i1
    } -> tensor<1x1x4x4xi1>
    %180 = tensor.empty() : tensor<1x1x4x4xi1>
    %181 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%175 : tensor<1x1x4x4xi1>) outs(%180 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "expand_0", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model"} {
    ^bb18(%182: i1, %183: i1):
      linalg.yield %182 : i1
    } -> tensor<1x1x4x4xi1>
    %184 = tensor.expand_shape %15 [[0 : i64, 1 : i64]] output_shape [1, 64] {prov.region_id = "unsqueeze_10", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<64xf32> into tensor<1x64xf32>
    %185 = tensor.collapse_shape %184 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_11", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x64xf32> into tensor<64xf32>
    %186 = tensor.expand_shape %185 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 64, 1] {prov.region_id = "unsqueeze_11", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<64xf32> into tensor<1x64x1xf32>
    %187 = tensor.empty() : tensor<1x64x1xf32>
    %188 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%186 : tensor<1x64x1xf32>) outs(%187 : tensor<1x64x1xf32>) attrs =  {prov.region_id = "expand_1", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb19(%189: f32, %190: f32):
      linalg.yield %189 : f32
    } -> tensor<1x64x1xf32>
    %191 = tensor.collapse_shape %42 [[0 : i64, 1 : i64]] {prov.region_id = "unsqueeze_12", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x4xi64> into tensor<4xi64>
    %192 = tensor.expand_shape %191 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 4] {prov.region_id = "unsqueeze_12", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "int64", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<4xi64> into tensor<1x1x4xi64>
    %193 = tensor.empty() : tensor<1x1x4xf32>
    %194 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%192 : tensor<1x1x4xi64>) outs(%193 : tensor<1x1x4xf32>) attrs =  {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb20(%195: i64, %196: f32):
      %197 = arith.sitofp %195 : i64 to f32
      linalg.yield %197 : f32
    } -> tensor<1x1x4xf32>
    %198 = tensor.empty() : tensor<1x64x1xf32>
    %199 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%188 : tensor<1x64x1xf32>) outs(%198 : tensor<1x64x1xf32>) attrs =  {prov.region_id = "expand_2", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb21(%200: f32, %201: f32):
      linalg.yield %200 : f32
    } -> tensor<1x64x1xf32>
    %202 = tensor.empty() : tensor<1x1x4xf32>
    %203 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%194 : tensor<1x1x4xf32>) outs(%202 : tensor<1x1x4xf32>) attrs =  {prov.region_id = "expand_3", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb22(%204: f32, %205: f32):
      linalg.yield %204 : f32
    } -> tensor<1x1x4xf32>
    %206 = arith.constant {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} 0.000000e+00 : f32
    %207 = tensor.splat %206 {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x64x4xf32>
    %208 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%199, %203 : tensor<1x64x1xf32>, tensor<1x1x4xf32>) outs(%207 : tensor<1x64x4xf32>) attrs =  {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb23(%209: f32, %210: f32, %211: f32):
      %212 = arith.mulf %209, %210 : f32
      %213 = arith.addf %211, %212 : f32
      linalg.yield %213 : f32
    } -> tensor<1x64x4xf32>
    %214 = tensor.empty() : tensor<1x4x64xf32>
    %215 = linalg.transpose ins(%208:tensor<1x64x4xf32>) outs(%214:tensor<1x4x64xf32>) permutation = [0, 2, 1]
    %216 = tensor.concat dim(2) %215, %215 {prov.region_id = "cat_1", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : (tensor<1x4x64xf32>, tensor<1x4x64xf32>) -> tensor<1x4x128xf32>
    %217 = tensor.empty() : tensor<1x4x128xf32>
    %218 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%216 : tensor<1x4x128xf32>) outs(%217 : tensor<1x4x128xf32>) attrs =  {prov.region_id = "cos_0", prov._pattern_hint = "cos", prov.op = "cos", prov.family = "elementwise", prov.aten = "aten.cos.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb24(%219: f32, %220: f32):
      %221 = math.cos %219 : f32
      linalg.yield %221 : f32
    } -> tensor<1x4x128xf32>
    %222 = arith.constant {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} 1.000000e+00 : f32
    %223 = tensor.splat %222 {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x4x128xf32>
    %224 = tensor.empty() : tensor<1x4x128xf32>
    %225 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%218, %223 : tensor<1x4x128xf32>, tensor<1x4x128xf32>) outs(%224 : tensor<1x4x128xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb25(%226: f32, %227: f32, %228: f32):
      %229 = arith.mulf %226, %227 : f32
      linalg.yield %229 : f32
    } -> tensor<1x4x128xf32>
    %230 = tensor.empty() : tensor<1x4x128xf32>
    %231 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%216 : tensor<1x4x128xf32>) outs(%230 : tensor<1x4x128xf32>) attrs =  {prov.region_id = "sin_0", prov._pattern_hint = "sin", prov.op = "sin", prov.family = "elementwise", prov.aten = "aten.sin.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb26(%232: f32, %233: f32):
      %234 = math.sin %232 : f32
      linalg.yield %234 : f32
    } -> tensor<1x4x128xf32>
    %235 = arith.constant {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} 1.000000e+00 : f32
    %236 = tensor.splat %235 {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} : tensor<1x4x128xf32>
    %237 = tensor.empty() : tensor<1x4x128xf32>
    %238 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%231, %236 : tensor<1x4x128xf32>, tensor<1x4x128xf32>) outs(%237 : tensor<1x4x128xf32>) attrs =  {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.rotary_emb"} {
    ^bb27(%239: f32, %240: f32, %241: f32):
      %242 = arith.mulf %239, %240 : f32
      linalg.yield %242 : f32
    } -> tensor<1x4x128xf32>
    %243 = tensor.empty() : tensor<1x4x1536xf32>
    %244 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%19 : tensor<1x4x1536xf32>) outs(%243 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "pow_0", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb28(%245: f32, %246: f32):
      %247 = arith.constant 2.000000e+00 : f32
      %248 = math.powf %245, %247 : f32
      linalg.yield %248 : f32
    } -> tensor<1x4x1536xf32>
    %249 = arith.constant {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} 0.000000e+00 : f32
    %250 = tensor.splat %249 {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4xf32>
    %251 = linalg.reduce ins(%244:tensor<1x4x1536xf32>) outs(%250:tensor<1x4xf32>) dimensions = [2]
    (%252: f32, %253: f32) {
      %254 = arith.addf %252, %253 : f32
      linalg.yield %254 : f32
    }
    %255 = arith.constant {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} 1.536000e+03 : f32
    %256 = tensor.splat %255 {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4xf32>
    %257 = tensor.empty() : tensor<1x4xf32>
    %258 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%251, %256 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%257 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb29(%259: f32, %260: f32, %261: f32):
      %262 = arith.divf %259, %260 : f32
      linalg.yield %262 : f32
    } -> tensor<1x4xf32>
    %263 = tensor.collapse_shape %258 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %264 = tensor.expand_shape %263 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_0", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %265 = arith.constant {prov.region_id = "add_3", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} 1.000000e-06 : f32
    %266 = tensor.splat %265 {prov.region_id = "add_3", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} : tensor<1x4x1xf32>
    %267 = tensor.empty() : tensor<1x4x1xf32>
    %268 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%264, %266 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%267 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_3", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb30(%269: f32, %270: f32, %271: f32):
      %272 = arith.addf %269, %270 : f32
      linalg.yield %272 : f32
    } -> tensor<1x4x1xf32>
    %273 = tensor.empty() : tensor<1x4x1xf32>
    %274 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%268 : tensor<1x4x1xf32>) outs(%273 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_0", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb31(%275: f32, %276: f32):
      %277 = math.rsqrt %275 : f32
      linalg.yield %277 : f32
    } -> tensor<1x4x1xf32>
    %278 = tensor.empty() : tensor<1x4x1536xf32>
    %279 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%19, %274 : tensor<1x4x1536xf32>, tensor<1x4x1xf32>) outs(%278 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "mul_2", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb32(%280: f32, %281: f32, %282: f32):
      %283 = arith.mulf %280, %281 : f32
      linalg.yield %283 : f32
    } -> tensor<1x4x1536xf32>
    %284 = tensor.empty() : tensor<1x4x1536xf32>
    %285 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%11, %279 : tensor<1536xf32>, tensor<1x4x1536xf32>) outs(%284 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "mul_3", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.input_layernorm"} {
    ^bb33(%286: f32, %287: f32, %288: f32):
      %289 = arith.mulf %286, %287 : f32
      linalg.yield %289 : f32
    } -> tensor<1x4x1536xf32>
    %290 = tensor.collapse_shape %285 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_3", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %291 = tensor.expand_shape %290 [[0 : i64, 1 : i64]] output_shape [4, 1536] {prov.region_id = "view_3", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<6144xf32> into tensor<4x1536xf32>
    %292 = tensor.empty() : tensor<1536x1536xf32>
    %293 = linalg.transpose ins(%1:tensor<1536x1536xf32>) outs(%292:tensor<1536x1536xf32>) permutation = [1, 0]
    %294 = tensor.empty() : tensor<4x1536xf32>
    %295 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %296 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%295 : f32) outs(%294 : tensor<4x1536xf32>) -> tensor<4x1536xf32>
    %297 = linalg.matmul {prov.region_id = "matmul_1", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj", prov.transposed_b = "true"} ins(%291, %293 : tensor<4x1536xf32>, tensor<1536x1536xf32>) outs(%296 : tensor<4x1536xf32>) -> tensor<4x1536xf32>
    %298 = tensor.empty() : tensor<4x1536xf32>
    %299 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%297, %2 : tensor<4x1536xf32>, tensor<1536xf32>) outs(%298 : tensor<4x1536xf32>) attrs =  {prov.region_id = "add_4", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} {
    ^bb34(%300: f32, %301: f32, %302: f32):
      %303 = arith.addf %300, %301 : f32
      linalg.yield %303 : f32
    } -> tensor<4x1536xf32>
    %304 = tensor.collapse_shape %299 [[0 : i64, 1 : i64]] {prov.region_id = "view_4", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<4x1536xf32> into tensor<6144xf32>
    %305 = tensor.expand_shape %304 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1536] {prov.region_id = "view_4", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.q_proj"} : tensor<6144xf32> into tensor<1x4x1536xf32>
    %306 = tensor.collapse_shape %305 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_5", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %307 = tensor.expand_shape %306 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 12, 128] {prov.region_id = "view_5", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<1x4x12x128xf32>
    %308 = tensor.empty() : tensor<1x12x4x128xf32>
    %309 = linalg.transpose ins(%307:tensor<1x4x12x128xf32>) outs(%308:tensor<1x12x4x128xf32>) permutation = [0, 2, 1, 3]
    %310 = tensor.collapse_shape %285 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_6", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %311 = tensor.expand_shape %310 [[0 : i64, 1 : i64]] output_shape [4, 1536] {prov.region_id = "view_6", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<6144xf32> into tensor<4x1536xf32>
    %312 = tensor.empty() : tensor<1536x256xf32>
    %313 = linalg.transpose ins(%3:tensor<256x1536xf32>) outs(%312:tensor<1536x256xf32>) permutation = [1, 0]
    %314 = tensor.empty() : tensor<4x256xf32>
    %315 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %316 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%315 : f32) outs(%314 : tensor<4x256xf32>) -> tensor<4x256xf32>
    %317 = linalg.matmul {prov.region_id = "matmul_2", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj", prov.transposed_b = "true"} ins(%311, %313 : tensor<4x1536xf32>, tensor<1536x256xf32>) outs(%316 : tensor<4x256xf32>) -> tensor<4x256xf32>
    %318 = tensor.empty() : tensor<4x256xf32>
    %319 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%317, %4 : tensor<4x256xf32>, tensor<256xf32>) outs(%318 : tensor<4x256xf32>) attrs =  {prov.region_id = "add_5", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} {
    ^bb35(%320: f32, %321: f32, %322: f32):
      %323 = arith.addf %320, %321 : f32
      linalg.yield %323 : f32
    } -> tensor<4x256xf32>
    %324 = tensor.collapse_shape %319 [[0 : i64, 1 : i64]] {prov.region_id = "view_7", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<4x256xf32> into tensor<1024xf32>
    %325 = tensor.expand_shape %324 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 256] {prov.region_id = "view_7", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.k_proj"} : tensor<1024xf32> into tensor<1x4x256xf32>
    %326 = tensor.collapse_shape %325 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_8", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x256xf32> into tensor<1024xf32>
    %327 = tensor.expand_shape %326 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 2, 128] {prov.region_id = "view_8", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1024xf32> into tensor<1x4x2x128xf32>
    %328 = tensor.empty() : tensor<1x2x4x128xf32>
    %329 = linalg.transpose ins(%327:tensor<1x4x2x128xf32>) outs(%328:tensor<1x2x4x128xf32>) permutation = [0, 2, 1, 3]
    %330 = tensor.collapse_shape %285 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_9", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %331 = tensor.expand_shape %330 [[0 : i64, 1 : i64]] output_shape [4, 1536] {prov.region_id = "view_9", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<6144xf32> into tensor<4x1536xf32>
    %332 = tensor.empty() : tensor<1536x256xf32>
    %333 = linalg.transpose ins(%5:tensor<256x1536xf32>) outs(%332:tensor<1536x256xf32>) permutation = [1, 0]
    %334 = tensor.empty() : tensor<4x256xf32>
    %335 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %336 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%335 : f32) outs(%334 : tensor<4x256xf32>) -> tensor<4x256xf32>
    %337 = linalg.matmul {prov.region_id = "matmul_3", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj", prov.transposed_b = "true"} ins(%331, %333 : tensor<4x1536xf32>, tensor<1536x256xf32>) outs(%336 : tensor<4x256xf32>) -> tensor<4x256xf32>
    %338 = tensor.empty() : tensor<4x256xf32>
    %339 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%337, %6 : tensor<4x256xf32>, tensor<256xf32>) outs(%338 : tensor<4x256xf32>) attrs =  {prov.region_id = "add_6", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} {
    ^bb36(%340: f32, %341: f32, %342: f32):
      %343 = arith.addf %340, %341 : f32
      linalg.yield %343 : f32
    } -> tensor<4x256xf32>
    %344 = tensor.collapse_shape %339 [[0 : i64, 1 : i64]] {prov.region_id = "view_10", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<4x256xf32> into tensor<1024xf32>
    %345 = tensor.expand_shape %344 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 256] {prov.region_id = "view_10", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.v_proj"} : tensor<1024xf32> into tensor<1x4x256xf32>
    %346 = tensor.collapse_shape %345 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_11", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x256xf32> into tensor<1024xf32>
    %347 = tensor.expand_shape %346 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 4, 2, 128] {prov.region_id = "view_11", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1024xf32> into tensor<1x4x2x128xf32>
    %348 = tensor.empty() : tensor<1x2x4x128xf32>
    %349 = linalg.transpose ins(%347:tensor<1x4x2x128xf32>) outs(%348:tensor<1x2x4x128xf32>) permutation = [0, 2, 1, 3]
    %350 = tensor.collapse_shape %225 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_13", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x128xf32> into tensor<512xf32>
    %351 = tensor.expand_shape %350 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 128] {prov.region_id = "unsqueeze_13", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<512xf32> into tensor<1x1x4x128xf32>
    %352 = tensor.collapse_shape %238 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_14", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x128xf32> into tensor<512xf32>
    %353 = tensor.expand_shape %352 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 1, 4, 128] {prov.region_id = "unsqueeze_14", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<512xf32> into tensor<1x1x4x128xf32>
    %354 = tensor.empty() : tensor<1x12x4x128xf32>
    %355 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%309, %351 : tensor<1x12x4x128xf32>, tensor<1x1x4x128xf32>) outs(%354 : tensor<1x12x4x128xf32>) attrs =  {prov.region_id = "mul_4", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb37(%356: f32, %357: f32, %358: f32):
      %359 = arith.mulf %356, %357 : f32
      linalg.yield %359 : f32
    } -> tensor<1x12x4x128xf32>
    %360 = "tensor.extract_slice"(%309) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 12, 4, 64>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_3", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x12x4x128xf32>) -> tensor<1x12x4x64xf32>
    %361 = "tensor.extract_slice"(%309) <{static_offsets = array<i64: 0, 0, 0, 64>, static_sizes = array<i64: 1, 12, 4, 64>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_4", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x12x4x128xf32>) -> tensor<1x12x4x64xf32>
    %362 = tensor.empty() : tensor<1x12x4x64xf32>
    %363 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%361 : tensor<1x12x4x64xf32>) outs(%362 : tensor<1x12x4x64xf32>) attrs =  {prov.region_id = "neg_0", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb38(%364: f32, %365: f32):
      %366 = arith.negf %364 : f32
      linalg.yield %366 : f32
    } -> tensor<1x12x4x64xf32>
    %367 = tensor.concat dim(3) %363, %360 {prov.region_id = "cat_2", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x12x4x64xf32>, tensor<1x12x4x64xf32>) -> tensor<1x12x4x128xf32>
    %368 = tensor.empty() : tensor<1x12x4x128xf32>
    %369 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%367, %353 : tensor<1x12x4x128xf32>, tensor<1x1x4x128xf32>) outs(%368 : tensor<1x12x4x128xf32>) attrs =  {prov.region_id = "mul_5", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb39(%370: f32, %371: f32, %372: f32):
      %373 = arith.mulf %370, %371 : f32
      linalg.yield %373 : f32
    } -> tensor<1x12x4x128xf32>
    %374 = tensor.empty() : tensor<1x12x4x128xf32>
    %375 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%355, %369 : tensor<1x12x4x128xf32>, tensor<1x12x4x128xf32>) outs(%374 : tensor<1x12x4x128xf32>) attrs =  {prov.region_id = "add_7", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb40(%376: f32, %377: f32, %378: f32):
      %379 = arith.addf %376, %377 : f32
      linalg.yield %379 : f32
    } -> tensor<1x12x4x128xf32>
    %380 = tensor.empty() : tensor<1x2x4x128xf32>
    %381 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%329, %351 : tensor<1x2x4x128xf32>, tensor<1x1x4x128xf32>) outs(%380 : tensor<1x2x4x128xf32>) attrs =  {prov.region_id = "mul_6", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb41(%382: f32, %383: f32, %384: f32):
      %385 = arith.mulf %382, %383 : f32
      linalg.yield %385 : f32
    } -> tensor<1x2x4x128xf32>
    %386 = "tensor.extract_slice"(%329) <{static_offsets = array<i64: 0, 0, 0, 0>, static_sizes = array<i64: 1, 2, 4, 64>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_5", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x2x4x128xf32>) -> tensor<1x2x4x64xf32>
    %387 = "tensor.extract_slice"(%329) <{static_offsets = array<i64: 0, 0, 0, 64>, static_sizes = array<i64: 1, 2, 4, 64>, static_strides = array<i64: 1, 1, 1, 1>, operandSegmentSizes = array<i32: 1, 0, 0, 0>}> {prov.region_id = "slice_6", prov.family = "layout", prov._pattern_hint = "slice", prov.op = "slice", prov.aten = "aten.slice.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x2x4x128xf32>) -> tensor<1x2x4x64xf32>
    %388 = tensor.empty() : tensor<1x2x4x64xf32>
    %389 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%387 : tensor<1x2x4x64xf32>) outs(%388 : tensor<1x2x4x64xf32>) attrs =  {prov.region_id = "neg_1", prov._pattern_hint = "neg", prov.op = "neg", prov.family = "elementwise", prov.aten = "aten.neg.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb42(%390: f32, %391: f32):
      %392 = arith.negf %390 : f32
      linalg.yield %392 : f32
    } -> tensor<1x2x4x64xf32>
    %393 = tensor.concat dim(3) %389, %386 {prov.region_id = "cat_3", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : (tensor<1x2x4x64xf32>, tensor<1x2x4x64xf32>) -> tensor<1x2x4x128xf32>
    %394 = tensor.empty() : tensor<1x2x4x128xf32>
    %395 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%393, %353 : tensor<1x2x4x128xf32>, tensor<1x1x4x128xf32>) outs(%394 : tensor<1x2x4x128xf32>) attrs =  {prov.region_id = "mul_7", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb43(%396: f32, %397: f32, %398: f32):
      %399 = arith.mulf %396, %397 : f32
      linalg.yield %399 : f32
    } -> tensor<1x2x4x128xf32>
    %400 = tensor.empty() : tensor<1x2x4x128xf32>
    %401 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%381, %395 : tensor<1x2x4x128xf32>, tensor<1x2x4x128xf32>) outs(%400 : tensor<1x2x4x128xf32>) attrs =  {prov.region_id = "add_8", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb44(%402: f32, %403: f32, %404: f32):
      %405 = arith.addf %402, %403 : f32
      linalg.yield %405 : f32
    } -> tensor<1x2x4x128xf32>
    %406 = tensor.collapse_shape %401 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "unsqueeze_15", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x2x4x128xf32> into tensor<1024xf32>
    %407 = tensor.expand_shape %406 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] output_shape [1, 2, 1, 4, 128] {prov.region_id = "unsqueeze_15", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1024xf32> into tensor<1x2x1x4x128xf32>
    %408 = tensor.empty() : tensor<1x2x6x4x128xf32>
    %409 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, 0, d3, d4)>, affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, d2, d3, d4)>], iterator_types = ["parallel", "parallel", "parallel", "parallel", "parallel"]} ins(%407 : tensor<1x2x1x4x128xf32>) outs(%408 : tensor<1x2x6x4x128xf32>) attrs =  {prov.region_id = "expand_4", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb45(%410: f32, %411: f32):
      linalg.yield %410 : f32
    } -> tensor<1x2x6x4x128xf32>
    %412 = tensor.collapse_shape %409 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] {prov.region_id = "view_12", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x2x6x4x128xf32> into tensor<6144xf32>
    %413 = tensor.expand_shape %412 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 12, 4, 128] {prov.region_id = "view_12", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<1x12x4x128xf32>
    %414 = tensor.collapse_shape %349 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "unsqueeze_16", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x2x4x128xf32> into tensor<1024xf32>
    %415 = tensor.expand_shape %414 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] output_shape [1, 2, 1, 4, 128] {prov.region_id = "unsqueeze_16", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1024xf32> into tensor<1x2x1x4x128xf32>
    %416 = tensor.empty() : tensor<1x2x6x4x128xf32>
    %417 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, 0, d3, d4)>, affine_map<(d0, d1, d2, d3, d4) -> (d0, d1, d2, d3, d4)>], iterator_types = ["parallel", "parallel", "parallel", "parallel", "parallel"]} ins(%415 : tensor<1x2x1x4x128xf32>) outs(%416 : tensor<1x2x6x4x128xf32>) attrs =  {prov.region_id = "expand_5", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb46(%418: f32, %419: f32):
      linalg.yield %418 : f32
    } -> tensor<1x2x6x4x128xf32>
    %420 = tensor.collapse_shape %417 [[0 : i64, 1 : i64, 2 : i64, 3 : i64, 4 : i64]] {prov.region_id = "view_13", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x2x6x4x128xf32> into tensor<6144xf32>
    %421 = tensor.expand_shape %420 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 12, 4, 128] {prov.region_id = "view_13", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<1x12x4x128xf32>
    %422 = tensor.empty() : tensor<1x12x128x4xf32>
    %423 = linalg.transpose ins(%413:tensor<1x12x4x128xf32>) outs(%422:tensor<1x12x128x4xf32>) permutation = [0, 1, 3, 2]
    %424 = tensor.empty() : tensor<1x12x4x128xf32>
    %425 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%375 : tensor<1x12x4x128xf32>) outs(%424 : tensor<1x12x4x128xf32>) attrs =  {prov.region_id = "expand_6", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb47(%426: f32, %427: f32):
      linalg.yield %426 : f32
    } -> tensor<1x12x4x128xf32>
    %428 = tensor.collapse_shape %425 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_14", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4x128xf32> into tensor<6144xf32>
    %429 = tensor.expand_shape %428 [[0 : i64, 1 : i64, 2 : i64]] output_shape [12, 4, 128] {prov.region_id = "view_14", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<12x4x128xf32>
    %430 = tensor.empty() : tensor<1x12x128x4xf32>
    %431 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%423 : tensor<1x12x128x4xf32>) outs(%430 : tensor<1x12x128x4xf32>) attrs =  {prov.region_id = "expand_7", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb48(%432: f32, %433: f32):
      linalg.yield %432 : f32
    } -> tensor<1x12x128x4xf32>
    %434 = tensor.collapse_shape %431 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_15", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x128x4xf32> into tensor<6144xf32>
    %435 = tensor.expand_shape %434 [[0 : i64, 1 : i64, 2 : i64]] output_shape [12, 128, 4] {prov.region_id = "view_15", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<12x128x4xf32>
    %436 = arith.constant {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0.000000e+00 : f32
    %437 = tensor.splat %436 {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<12x4x4xf32>
    %438 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%429, %435 : tensor<12x4x128xf32>, tensor<12x128x4xf32>) outs(%437 : tensor<12x4x4xf32>) attrs =  {prov.region_id = "matmul_4", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb49(%439: f32, %440: f32, %441: f32):
      %442 = arith.mulf %439, %440 : f32
      %443 = arith.addf %441, %442 : f32
      linalg.yield %443 : f32
    } -> tensor<12x4x4xf32>
    %444 = tensor.collapse_shape %438 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_16", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<12x4x4xf32> into tensor<192xf32>
    %445 = tensor.expand_shape %444 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 12, 4, 4] {prov.region_id = "view_16", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<192xf32> into tensor<1x12x4x4xf32>
    %446 = arith.constant {prov.region_id = "mul_8", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0.0883883461 : f32
    %447 = tensor.splat %446 {prov.region_id = "mul_8", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4x4xf32>
    %448 = tensor.empty() : tensor<1x12x4x4xf32>
    %449 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%445, %447 : tensor<1x12x4x4xf32>, tensor<1x12x4x4xf32>) outs(%448 : tensor<1x12x4x4xf32>) attrs =  {prov.region_id = "mul_8", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb50(%450: f32, %451: f32, %452: f32):
      %453 = arith.mulf %450, %451 : f32
      linalg.yield %453 : f32
    } -> tensor<1x12x4x4xf32>
    %454 = tensor.empty() : tensor<1x1x4x4xi1>
    %455 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%181 : tensor<1x1x4x4xi1>) outs(%454 : tensor<1x1x4x4xi1>) attrs =  {prov.region_id = "bitwise_2", prov.family = "bitwise", prov._pattern_hint = "bitwise", prov.op = "bitwise", prov.aten = "aten.bitwise_not.default", prov.orig_dtype = "bool", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb51(%456: i1, %457: i1):
      %458 = arith.constant true
      %459 = arith.xori %456, %458 : i1
      linalg.yield %459 : i1
    } -> tensor<1x1x4x4xi1>
    %460 = arith.constant {prov.region_id = "fill_1", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0xff800000 : f32
    %461 = tensor.splat %460 {prov.region_id = "fill_1", prov.family = "fill", prov._pattern_hint = "fill", prov.op = "fill", prov.aten = "aten.scalar_tensor.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<f32>
    %462 = tensor.empty() : tensor<1x12x4x4xf32>
    %463 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> ()>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%455, %461, %449 : tensor<1x1x4x4xi1>, tensor<f32>, tensor<1x12x4x4xf32>) outs(%462 : tensor<1x12x4x4xf32>) attrs =  {prov.region_id = "select_0", prov.family = "layout", prov._pattern_hint = "select", prov.op = "select", prov.aten = "aten.where.self", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb52(%464: i1, %465: f32, %466: f32, %467: f32):
      %468 = arith.select %464, %465, %466 : f32
      linalg.yield %468 : f32
    } -> tensor<1x12x4x4xf32>
    %469 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0xff800000 : f32
    %470 = tensor.splat %469 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4xf32>
    %471 = linalg.reduce ins(%463:tensor<1x12x4x4xf32>) outs(%470:tensor<1x12x4xf32>) dimensions = [3]
    (%472: f32, %473: f32) {
      %474 = arith.maximumf %472, %473 : f32
      linalg.yield %474 : f32
    }
    %475 = tensor.collapse_shape %471 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4xf32> into tensor<48xf32>
    %476 = tensor.expand_shape %475 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 12, 4, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<48xf32> into tensor<1x12x4x1xf32>
    %477 = tensor.empty() : tensor<1x12x4x4xf32>
    %478 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%463, %476 : tensor<1x12x4x4xf32>, tensor<1x12x4x1xf32>) outs(%477 : tensor<1x12x4x4xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb53(%479: f32, %480: f32, %481: f32):
      %482 = arith.subf %479, %480 : f32
      linalg.yield %482 : f32
    } -> tensor<1x12x4x4xf32>
    %483 = tensor.empty() : tensor<1x12x4x4xf32>
    %484 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%478 : tensor<1x12x4x4xf32>) outs(%483 : tensor<1x12x4x4xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb54(%485: f32, %486: f32):
      %487 = math.exp %485 : f32
      linalg.yield %487 : f32
    } -> tensor<1x12x4x4xf32>
    %488 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0.000000e+00 : f32
    %489 = tensor.splat %488 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4xf32>
    %490 = linalg.reduce ins(%484:tensor<1x12x4x4xf32>) outs(%489:tensor<1x12x4xf32>) dimensions = [3]
    (%491: f32, %492: f32) {
      %493 = arith.addf %491, %492 : f32
      linalg.yield %493 : f32
    }
    %494 = tensor.collapse_shape %490 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4xf32> into tensor<48xf32>
    %495 = tensor.expand_shape %494 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 12, 4, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<48xf32> into tensor<1x12x4x1xf32>
    %496 = tensor.empty() : tensor<1x12x4x4xf32>
    %497 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, 0)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%484, %495 : tensor<1x12x4x4xf32>, tensor<1x12x4x1xf32>) outs(%496 : tensor<1x12x4x4xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb55(%498: f32, %499: f32, %500: f32):
      %501 = arith.divf %498, %499 : f32
      linalg.yield %501 : f32
    } -> tensor<1x12x4x4xf32>
    %502 = tensor.empty() : tensor<1x12x4x4xf32>
    %503 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%497 : tensor<1x12x4x4xf32>) outs(%502 : tensor<1x12x4x4xf32>) attrs =  {prov.region_id = "expand_8", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb56(%504: f32, %505: f32):
      linalg.yield %504 : f32
    } -> tensor<1x12x4x4xf32>
    %506 = tensor.collapse_shape %503 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_17", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4x4xf32> into tensor<192xf32>
    %507 = tensor.expand_shape %506 [[0 : i64, 1 : i64, 2 : i64]] output_shape [12, 4, 4] {prov.region_id = "view_17", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<192xf32> into tensor<12x4x4xf32>
    %508 = tensor.empty() : tensor<1x12x4x128xf32>
    %509 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%421 : tensor<1x12x4x128xf32>) outs(%508 : tensor<1x12x4x128xf32>) attrs =  {prov.region_id = "expand_9", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb57(%510: f32, %511: f32):
      linalg.yield %510 : f32
    } -> tensor<1x12x4x128xf32>
    %512 = tensor.collapse_shape %509 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_18", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x12x4x128xf32> into tensor<6144xf32>
    %513 = tensor.expand_shape %512 [[0 : i64, 1 : i64, 2 : i64]] output_shape [12, 4, 128] {prov.region_id = "view_18", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<12x4x128xf32>
    %514 = arith.constant {prov.region_id = "matmul_5", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} 0.000000e+00 : f32
    %515 = tensor.splat %514 {prov.region_id = "matmul_5", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<12x4x128xf32>
    %516 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%507, %513 : tensor<12x4x4xf32>, tensor<12x4x128xf32>) outs(%515 : tensor<12x4x128xf32>) attrs =  {prov.region_id = "matmul_5", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} {
    ^bb58(%517: f32, %518: f32, %519: f32):
      %520 = arith.mulf %517, %518 : f32
      %521 = arith.addf %519, %520 : f32
      linalg.yield %521 : f32
    } -> tensor<12x4x128xf32>
    %522 = tensor.collapse_shape %516 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_19", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<12x4x128xf32> into tensor<6144xf32>
    %523 = tensor.expand_shape %522 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [1, 12, 4, 128] {prov.region_id = "view_19", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<1x12x4x128xf32>
    %524 = tensor.empty() : tensor<1x4x12x128xf32>
    %525 = linalg.transpose ins(%523:tensor<1x12x4x128xf32>) outs(%524:tensor<1x4x12x128xf32>) permutation = [0, 2, 1, 3]
    %526 = tensor.collapse_shape %525 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_20", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<1x4x12x128xf32> into tensor<6144xf32>
    %527 = tensor.expand_shape %526 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1536] {prov.region_id = "view_20", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn"} : tensor<6144xf32> into tensor<1x4x1536xf32>
    %528 = tensor.empty() : tensor<1536x1536xf32>
    %529 = linalg.transpose ins(%7:tensor<1536x1536xf32>) outs(%528:tensor<1536x1536xf32>) permutation = [1, 0]
    %530 = tensor.collapse_shape %527 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_21", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %531 = tensor.expand_shape %530 [[0 : i64, 1 : i64]] output_shape [4, 1536] {prov.region_id = "view_21", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<6144xf32> into tensor<4x1536xf32>
    %532 = tensor.empty() : tensor<4x1536xf32>
    %533 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %534 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%533 : f32) outs(%532 : tensor<4x1536xf32>) -> tensor<4x1536xf32>
    %535 = linalg.matmul {prov.region_id = "matmul_6", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj", prov.transposed_b = "true"} ins(%531, %529 : tensor<4x1536xf32>, tensor<1536x1536xf32>) outs(%534 : tensor<4x1536xf32>) -> tensor<4x1536xf32>
    %536 = tensor.collapse_shape %535 [[0 : i64, 1 : i64]] {prov.region_id = "view_22", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<4x1536xf32> into tensor<6144xf32>
    %537 = tensor.expand_shape %536 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1536] {prov.region_id = "view_22", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.self_attn.o_proj"} : tensor<6144xf32> into tensor<1x4x1536xf32>
    %538 = tensor.empty() : tensor<1x4x1536xf32>
    %539 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%19, %537 : tensor<1x4x1536xf32>, tensor<1x4x1536xf32>) outs(%538 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "add_9", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0"} {
    ^bb59(%540: f32, %541: f32, %542: f32):
      %543 = arith.addf %540, %541 : f32
      linalg.yield %543 : f32
    } -> tensor<1x4x1536xf32>
    %544 = tensor.empty() : tensor<1x4x1536xf32>
    %545 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%539 : tensor<1x4x1536xf32>) outs(%544 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "pow_1", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb60(%546: f32, %547: f32):
      %548 = arith.constant 2.000000e+00 : f32
      %549 = math.powf %546, %548 : f32
      linalg.yield %549 : f32
    } -> tensor<1x4x1536xf32>
    %550 = arith.constant {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} 0.000000e+00 : f32
    %551 = tensor.splat %550 {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4xf32>
    %552 = linalg.reduce ins(%545:tensor<1x4x1536xf32>) outs(%551:tensor<1x4xf32>) dimensions = [2]
    (%553: f32, %554: f32) {
      %555 = arith.addf %553, %554 : f32
      linalg.yield %555 : f32
    }
    %556 = arith.constant {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} 1.536000e+03 : f32
    %557 = tensor.splat %556 {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4xf32>
    %558 = tensor.empty() : tensor<1x4xf32>
    %559 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%552, %557 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%558 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb61(%560: f32, %561: f32, %562: f32):
      %563 = arith.divf %560, %561 : f32
      linalg.yield %563 : f32
    } -> tensor<1x4xf32>
    %564 = tensor.collapse_shape %559 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4xf32> into tensor<4xf32>
    %565 = tensor.expand_shape %564 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_1", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %566 = arith.constant {prov.region_id = "add_10", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} 1.000000e-06 : f32
    %567 = tensor.splat %566 {prov.region_id = "add_10", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} : tensor<1x4x1xf32>
    %568 = tensor.empty() : tensor<1x4x1xf32>
    %569 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%565, %567 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%568 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_10", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb62(%570: f32, %571: f32, %572: f32):
      %573 = arith.addf %570, %571 : f32
      linalg.yield %573 : f32
    } -> tensor<1x4x1xf32>
    %574 = tensor.empty() : tensor<1x4x1xf32>
    %575 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%569 : tensor<1x4x1xf32>) outs(%574 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_1", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb63(%576: f32, %577: f32):
      %578 = math.rsqrt %576 : f32
      linalg.yield %578 : f32
    } -> tensor<1x4x1xf32>
    %579 = tensor.empty() : tensor<1x4x1536xf32>
    %580 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%539, %575 : tensor<1x4x1536xf32>, tensor<1x4x1xf32>) outs(%579 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "mul_9", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb64(%581: f32, %582: f32, %583: f32):
      %584 = arith.mulf %581, %582 : f32
      linalg.yield %584 : f32
    } -> tensor<1x4x1536xf32>
    %585 = tensor.empty() : tensor<1x4x1536xf32>
    %586 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%12, %580 : tensor<1536xf32>, tensor<1x4x1536xf32>) outs(%585 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "mul_10", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.post_attention_layernorm"} {
    ^bb65(%587: f32, %588: f32, %589: f32):
      %590 = arith.mulf %587, %588 : f32
      linalg.yield %590 : f32
    } -> tensor<1x4x1536xf32>
    %591 = tensor.empty() : tensor<1536x8960xf32>
    %592 = linalg.transpose ins(%8:tensor<8960x1536xf32>) outs(%591:tensor<1536x8960xf32>) permutation = [1, 0]
    %593 = tensor.collapse_shape %586 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_23", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %594 = tensor.expand_shape %593 [[0 : i64, 1 : i64]] output_shape [4, 1536] {prov.region_id = "view_23", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<6144xf32> into tensor<4x1536xf32>
    %595 = tensor.empty() : tensor<4x8960xf32>
    %596 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %597 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%596 : f32) outs(%595 : tensor<4x8960xf32>) -> tensor<4x8960xf32>
    %598 = linalg.matmul {prov.region_id = "matmul_7", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj", prov.transposed_b = "true"} ins(%594, %592 : tensor<4x1536xf32>, tensor<1536x8960xf32>) outs(%597 : tensor<4x8960xf32>) -> tensor<4x8960xf32>
    %599 = tensor.collapse_shape %598 [[0 : i64, 1 : i64]] {prov.region_id = "view_24", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<4x8960xf32> into tensor<35840xf32>
    %600 = tensor.expand_shape %599 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 8960] {prov.region_id = "view_24", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.gate_proj"} : tensor<35840xf32> into tensor<1x4x8960xf32>
    %601 = tensor.empty() : tensor<1x4x8960xf32>
    %602 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%600 : tensor<1x4x8960xf32>) outs(%601 : tensor<1x4x8960xf32>) attrs =  {prov.region_id = "sigmoid_0", prov._pattern_hint = "sigmoid", prov.op = "sigmoid", prov.family = "elementwise", prov.aten = "aten.sigmoid.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.act_fn"} {
    ^bb66(%603: f32, %604: f32):
      %605 = arith.constant 1.000000e+00 : f32
      %606 = arith.negf %603 : f32
      %607 = math.exp %606 : f32
      %608 = arith.addf %605, %607 : f32
      %609 = arith.divf %605, %608 : f32
      linalg.yield %609 : f32
    } -> tensor<1x4x8960xf32>
    %610 = tensor.empty() : tensor<1x4x8960xf32>
    %611 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%600, %602 : tensor<1x4x8960xf32>, tensor<1x4x8960xf32>) outs(%610 : tensor<1x4x8960xf32>) attrs =  {prov.region_id = "mul_11", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.act_fn"} {
    ^bb67(%612: f32, %613: f32, %614: f32):
      %615 = arith.mulf %612, %613 : f32
      linalg.yield %615 : f32
    } -> tensor<1x4x8960xf32>
    %616 = tensor.empty() : tensor<1536x8960xf32>
    %617 = linalg.transpose ins(%9:tensor<8960x1536xf32>) outs(%616:tensor<1536x8960xf32>) permutation = [1, 0]
    %618 = tensor.collapse_shape %586 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_25", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %619 = tensor.expand_shape %618 [[0 : i64, 1 : i64]] output_shape [4, 1536] {prov.region_id = "view_25", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<6144xf32> into tensor<4x1536xf32>
    %620 = tensor.empty() : tensor<4x8960xf32>
    %621 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %622 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%621 : f32) outs(%620 : tensor<4x8960xf32>) -> tensor<4x8960xf32>
    %623 = linalg.matmul {prov.region_id = "matmul_8", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj", prov.transposed_b = "true"} ins(%619, %617 : tensor<4x1536xf32>, tensor<1536x8960xf32>) outs(%622 : tensor<4x8960xf32>) -> tensor<4x8960xf32>
    %624 = tensor.collapse_shape %623 [[0 : i64, 1 : i64]] {prov.region_id = "view_26", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<4x8960xf32> into tensor<35840xf32>
    %625 = tensor.expand_shape %624 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 8960] {prov.region_id = "view_26", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.up_proj"} : tensor<35840xf32> into tensor<1x4x8960xf32>
    %626 = tensor.empty() : tensor<1x4x8960xf32>
    %627 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%611, %625 : tensor<1x4x8960xf32>, tensor<1x4x8960xf32>) outs(%626 : tensor<1x4x8960xf32>) attrs =  {prov.region_id = "mul_12", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp"} {
    ^bb68(%628: f32, %629: f32, %630: f32):
      %631 = arith.mulf %628, %629 : f32
      linalg.yield %631 : f32
    } -> tensor<1x4x8960xf32>
    %632 = tensor.empty() : tensor<8960x1536xf32>
    %633 = linalg.transpose ins(%10:tensor<1536x8960xf32>) outs(%632:tensor<8960x1536xf32>) permutation = [1, 0]
    %634 = tensor.collapse_shape %627 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_27", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<1x4x8960xf32> into tensor<35840xf32>
    %635 = tensor.expand_shape %634 [[0 : i64, 1 : i64]] output_shape [4, 8960] {prov.region_id = "view_27", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<35840xf32> into tensor<4x8960xf32>
    %636 = tensor.empty() : tensor<4x1536xf32>
    %637 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %638 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%637 : f32) outs(%636 : tensor<4x1536xf32>) -> tensor<4x1536xf32>
    %639 = linalg.matmul {prov.region_id = "matmul_9", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj", prov.transposed_b = "true"} ins(%635, %633 : tensor<4x8960xf32>, tensor<8960x1536xf32>) outs(%638 : tensor<4x1536xf32>) -> tensor<4x1536xf32>
    %640 = tensor.collapse_shape %639 [[0 : i64, 1 : i64]] {prov.region_id = "view_28", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<4x1536xf32> into tensor<6144xf32>
    %641 = tensor.expand_shape %640 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1536] {prov.region_id = "view_28", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0.mlp.down_proj"} : tensor<6144xf32> into tensor<1x4x1536xf32>
    %642 = tensor.empty() : tensor<1x4x1536xf32>
    %643 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%539, %641 : tensor<1x4x1536xf32>, tensor<1x4x1536xf32>) outs(%642 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "add_11", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.layers.0"} {
    ^bb69(%644: f32, %645: f32, %646: f32):
      %647 = arith.addf %644, %645 : f32
      linalg.yield %647 : f32
    } -> tensor<1x4x1536xf32>
    %648 = tensor.empty() : tensor<1x4x1536xf32>
    %649 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%643 : tensor<1x4x1536xf32>) outs(%648 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "pow_2", prov.family = "elementwise", prov._pattern_hint = "pow", prov.op = "pow", prov.aten = "aten.pow.Tensor_Scalar", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb70(%650: f32, %651: f32):
      %652 = arith.constant 2.000000e+00 : f32
      %653 = math.powf %650, %652 : f32
      linalg.yield %653 : f32
    } -> tensor<1x4x1536xf32>
    %654 = arith.constant {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} 0.000000e+00 : f32
    %655 = tensor.splat %654 {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4xf32>
    %656 = linalg.reduce ins(%649:tensor<1x4x1536xf32>) outs(%655:tensor<1x4xf32>) dimensions = [2]
    (%657: f32, %658: f32) {
      %659 = arith.addf %657, %658 : f32
      linalg.yield %659 : f32
    }
    %660 = arith.constant {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} 1.536000e+03 : f32
    %661 = tensor.splat %660 {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4xf32>
    %662 = tensor.empty() : tensor<1x4xf32>
    %663 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%656, %661 : tensor<1x4xf32>, tensor<1x4xf32>) outs(%662 : tensor<1x4xf32>) attrs =  {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb71(%664: f32, %665: f32, %666: f32):
      %667 = arith.divf %664, %665 : f32
      linalg.yield %667 : f32
    } -> tensor<1x4xf32>
    %668 = tensor.collapse_shape %663 [[0 : i64, 1 : i64]] {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4xf32> into tensor<4xf32>
    %669 = tensor.expand_shape %668 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 1] {prov.region_id = "reduce_2", prov.family = "reduce", prov._pattern_hint = "reduce_mean", prov.op = "reduce_mean", prov.aten = "aten.mean.dim", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<4xf32> into tensor<1x4x1xf32>
    %670 = arith.constant {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} 1.000000e-06 : f32
    %671 = tensor.splat %670 {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} : tensor<1x4x1xf32>
    %672 = tensor.empty() : tensor<1x4x1xf32>
    %673 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%669, %671 : tensor<1x4x1xf32>, tensor<1x4x1xf32>) outs(%672 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "add_12", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb72(%674: f32, %675: f32, %676: f32):
      %677 = arith.addf %674, %675 : f32
      linalg.yield %677 : f32
    } -> tensor<1x4x1xf32>
    %678 = tensor.empty() : tensor<1x4x1xf32>
    %679 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%673 : tensor<1x4x1xf32>) outs(%678 : tensor<1x4x1xf32>) attrs =  {prov.region_id = "rsqrt_2", prov._pattern_hint = "rsqrt", prov.op = "rsqrt", prov.family = "elementwise", prov.aten = "aten.rsqrt.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb73(%680: f32, %681: f32):
      %682 = math.rsqrt %680 : f32
      linalg.yield %682 : f32
    } -> tensor<1x4x1xf32>
    %683 = tensor.empty() : tensor<1x4x1536xf32>
    %684 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%643, %679 : tensor<1x4x1536xf32>, tensor<1x4x1xf32>) outs(%683 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "mul_13", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb74(%685: f32, %686: f32, %687: f32):
      %688 = arith.mulf %685, %686 : f32
      linalg.yield %688 : f32
    } -> tensor<1x4x1536xf32>
    %689 = tensor.empty() : tensor<1x4x1536xf32>
    %690 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%13, %684 : tensor<1536xf32>, tensor<1x4x1536xf32>) outs(%689 : tensor<1x4x1536xf32>) attrs =  {prov.region_id = "mul_14", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.model.norm"} {
    ^bb75(%691: f32, %692: f32, %693: f32):
      %694 = arith.mulf %691, %692 : f32
      linalg.yield %694 : f32
    } -> tensor<1x4x1536xf32>
    %695 = tensor.empty() : tensor<1536x151936xf32>
    %696 = linalg.transpose ins(%14:tensor<151936x1536xf32>) outs(%695:tensor<1536x151936xf32>) permutation = [1, 0]
    %697 = tensor.collapse_shape %690 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_29", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<1x4x1536xf32> into tensor<6144xf32>
    %698 = tensor.expand_shape %697 [[0 : i64, 1 : i64]] output_shape [4, 1536] {prov.region_id = "view_29", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<6144xf32> into tensor<4x1536xf32>
    %699 = tensor.empty() : tensor<4x151936xf32>
    %700 = arith.constant {prov.module = "lm"} 0.000000e+00 : f32
    %701 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "lm"} ins(%700 : f32) outs(%699 : tensor<4x151936xf32>) -> tensor<4x151936xf32>
    %702 = linalg.matmul {prov.region_id = "matmul_10", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head", prov.transposed_b = "true"} ins(%698, %696 : tensor<4x1536xf32>, tensor<1536x151936xf32>) outs(%701 : tensor<4x151936xf32>) -> tensor<4x151936xf32>
    %703 = tensor.collapse_shape %702 [[0 : i64, 1 : i64]] {prov.region_id = "view_30", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<4x151936xf32> into tensor<607744xf32>
    %704 = tensor.expand_shape %703 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 4, 151936] {prov.region_id = "view_30", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "lm", prov.fqn = "lm.lm_head"} : tensor<607744xf32> into tensor<1x4x151936xf32>
    func.return %704 : tensor<1x4x151936xf32>
  }
}
