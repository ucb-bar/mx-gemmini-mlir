kernel mx_issue_2_schedule(activation: i8[32768] read, activation_scales: i8[1024] read, weight: i8[65536] read, weight_scales: i8[2048] read, output_bf16: i16[512] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=16, nc=32, kt=512}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..4:
        native_loop(a=&activation[((row * 32768) + (wave * 512))], b=&weight[((wave * 16384) + (chunk * 32))], c=&output_bf16[((row * 1024) + (chunk * 64))], asc=&activation_scales[((wave * 256) + (row * 16))], bsc=&weight_scales[((wave * 512) + (chunk * 32))], write=select(wave == 3, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 4) + (chunk * 4) + wave), 2) + 1))
