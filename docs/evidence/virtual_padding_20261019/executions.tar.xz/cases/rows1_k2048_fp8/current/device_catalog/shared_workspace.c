unsigned char mx_catalog_workspace[168448] __attribute__((aligned(64)));
