#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"
static float padded[32768] __attribute__((aligned(64)));

void mx_prepare_a_fp8_m1_k2048_pm16_pk2048_kernel(const float *lhs, uint8_t *out) {
  if (!lhs || !out) __builtin_trap();
  for (size_t i = 0; i < 32768u; ++i) padded[i] = 0;
  for (size_t row = 0; row < 1u; ++row)
    for (size_t col = 0; col < 2048u; ++col)
      padded[row * 2048u + col] = lhs[row * 2048u + col];
  if (mx_pack_activation_f32(padded, 16u, 2048u,
      MX_RUNTIME_FP8, out, out+32768u)) __builtin_trap();
}
