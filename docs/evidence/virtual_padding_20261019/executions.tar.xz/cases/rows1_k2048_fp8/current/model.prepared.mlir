builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/virtual_padding_projection1_k2048/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x2048xbf16>, %1: tensor<41x2048xbf16>, %2: tensor<17x2048xbf16>, %3: tensor<1x2048xf32>) -> tensor<1x81xf32> {
    %4 = tensor.empty() : tensor<1x2048xbf16>
    %5 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%3 : tensor<1x2048xf32>) outs(%4 : tensor<1x2048xbf16>) attrs =  {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "bfloat16"} {
    ^bb0(%6: f32, %7: bf16):
      %8 = arith.truncf %6 : f32 to bf16
      linalg.yield %8 : bf16
    } -> tensor<1x2048xbf16>
    %9 = tensor.empty() : tensor<2048x23xbf16>
    %10 = linalg.transpose ins(%0:tensor<23x2048xbf16>) outs(%9:tensor<2048x23xbf16>) permutation = [1, 0]
    %11 = tensor.empty() : tensor<1x2048xf32>
    %12 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<1x2048xbf16>) outs(%11 : tensor<1x2048xf32>) attrs =  {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} {
    ^bb1(%13: bf16, %14: f32):
      %15 = arith.extf %13 : bf16 to f32
      linalg.yield %15 : f32
    } -> tensor<1x2048xf32>
    %16 = tensor.empty() : tensor<2048x23xf32>
    %17 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%10 : tensor<2048x23xbf16>) outs(%16 : tensor<2048x23xf32>) attrs =  {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} {
    ^bb2(%18: bf16, %19: f32):
      %20 = arith.extf %18 : bf16 to f32
      linalg.yield %20 : f32
    } -> tensor<2048x23xf32>
    %21 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %22 = tensor.splat %21 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : tensor<1x23xf32>
    %23 = func.call @merlin_dev_mx_gemmini_0(%12, %17, %22) : (tensor<1x2048xf32>, tensor<2048x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>
    %24 = tensor.empty() : tensor<1x23xbf16>
    %25 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%23 : tensor<1x23xf32>) outs(%24 : tensor<1x23xbf16>) attrs =  {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} {
    ^bb3(%26: f32, %27: bf16):
      %28 = arith.truncf %26 : f32 to bf16
      linalg.yield %28 : bf16
    } -> tensor<1x23xbf16>
    %29 = tensor.empty() : tensor<2048x41xbf16>
    %30 = linalg.transpose ins(%1:tensor<41x2048xbf16>) outs(%29:tensor<2048x41xbf16>) permutation = [1, 0]
    %31 = tensor.empty() : tensor<1x2048xf32>
    %32 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<1x2048xbf16>) outs(%31 : tensor<1x2048xf32>) attrs =  {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} {
    ^bb4(%33: bf16, %34: f32):
      %35 = arith.extf %33 : bf16 to f32
      linalg.yield %35 : f32
    } -> tensor<1x2048xf32>
    %36 = tensor.empty() : tensor<2048x41xf32>
    %37 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%30 : tensor<2048x41xbf16>) outs(%36 : tensor<2048x41xf32>) attrs =  {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} {
    ^bb5(%38: bf16, %39: f32):
      %40 = arith.extf %38 : bf16 to f32
      linalg.yield %40 : f32
    } -> tensor<2048x41xf32>
    %41 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %42 = tensor.splat %41 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : tensor<1x41xf32>
    %43 = func.call @merlin_dev_mx_gemmini_1(%32, %37, %42) : (tensor<1x2048xf32>, tensor<2048x41xf32>, tensor<1x41xf32>) -> tensor<1x41xf32>
    %44 = tensor.empty() : tensor<1x41xbf16>
    %45 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%43 : tensor<1x41xf32>) outs(%44 : tensor<1x41xbf16>) attrs =  {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} {
    ^bb6(%46: f32, %47: bf16):
      %48 = arith.truncf %46 : f32 to bf16
      linalg.yield %48 : bf16
    } -> tensor<1x41xbf16>
    %49 = tensor.empty() : tensor<2048x17xbf16>
    %50 = linalg.transpose ins(%2:tensor<17x2048xbf16>) outs(%49:tensor<2048x17xbf16>) permutation = [1, 0]
    %51 = tensor.empty() : tensor<1x2048xf32>
    %52 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<1x2048xbf16>) outs(%51 : tensor<1x2048xf32>) attrs =  {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} {
    ^bb7(%53: bf16, %54: f32):
      %55 = arith.extf %53 : bf16 to f32
      linalg.yield %55 : f32
    } -> tensor<1x2048xf32>
    %56 = tensor.empty() : tensor<2048x17xf32>
    %57 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%50 : tensor<2048x17xbf16>) outs(%56 : tensor<2048x17xf32>) attrs =  {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} {
    ^bb8(%58: bf16, %59: f32):
      %60 = arith.extf %58 : bf16 to f32
      linalg.yield %60 : f32
    } -> tensor<2048x17xf32>
    %61 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %62 = tensor.splat %61 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : tensor<1x17xf32>
    %63 = func.call @merlin_dev_mx_gemmini_2(%52, %57, %62) : (tensor<1x2048xf32>, tensor<2048x17xf32>, tensor<1x17xf32>) -> tensor<1x17xf32>
    %64 = tensor.empty() : tensor<1x17xbf16>
    %65 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%63 : tensor<1x17xf32>) outs(%64 : tensor<1x17xbf16>) attrs =  {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} {
    ^bb9(%66: f32, %67: bf16):
      %68 = arith.truncf %66 : f32 to bf16
      linalg.yield %68 : bf16
    } -> tensor<1x17xbf16>
    %69 = tensor.concat dim(1) %25, %45, %65 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "bfloat16"} : (tensor<1x23xbf16>, tensor<1x41xbf16>, tensor<1x17xbf16>) -> tensor<1x81xbf16>
    %70 = tensor.empty() : tensor<1x81xf32>
    %71 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%69 : tensor<1x81xbf16>) outs(%70 : tensor<1x81xf32>) attrs =  {prov.region_id = "dtype_cast_1", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32"} {
    ^bb10(%72: bf16, %73: f32):
      %74 = arith.extf %72 : bf16 to f32
      linalg.yield %74 : f32
    } -> tensor<1x81xf32>
    func.return %71 : tensor<1x81xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x2048xf32>, tensor<2048x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<1x2048xf32>, tensor<2048x41xf32>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<1x2048xf32>, tensor<2048x17xf32>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}