unsigned char mx_catalog_workspace[37376] __attribute__((aligned(64)));
