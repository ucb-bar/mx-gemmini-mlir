#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_prepare_a_fp8_m1_k2048_pm16_pk2048_kernel(const float *lhs, uint8_t *out) {
  if (!lhs || !out) __builtin_trap();
  if (mx_pack_activation_zero_rows_f32(lhs, 1u, 16u, 2048u,
      MX_RUNTIME_FP8, out, out+32768u)) __builtin_trap();
}
