builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/virtual_padding_projection160/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xbf16>, %1: tensor<41x37xbf16>, %2: tensor<17x37xbf16>, %3: tensor<160x37xf32>) -> tensor<160x81xf32> {
    %4 = tensor.empty() : tensor<160x37xbf16>
    %5 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%3 : tensor<160x37xf32>) outs(%4 : tensor<160x37xbf16>) attrs =  {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "bfloat16"} {
    ^bb0(%6: f32, %7: bf16):
      %8 = arith.truncf %6 : f32 to bf16
      linalg.yield %8 : bf16
    } -> tensor<160x37xbf16>
    %9 = tensor.empty() : tensor<160x37xf32>
    %10 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<160x37xbf16>) outs(%9 : tensor<160x37xf32>) attrs =  {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} {
    ^bb1(%11: bf16, %12: f32):
      %13 = arith.extf %11 : bf16 to f32
      linalg.yield %13 : f32
    } -> tensor<160x37xf32>
    %14 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %15 = tensor.splat %14 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : tensor<160x23xf32>
    %16 = tensor.empty() : tensor<37x23xf32>
    %17 = func.call @merlin_dev_mx_gemmini_0(%10, %16, %15) : (tensor<160x37xf32>, tensor<37x23xf32>, tensor<160x23xf32>) -> tensor<160x23xf32>
    %18 = tensor.empty() : tensor<160x23xbf16>
    %19 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%17 : tensor<160x23xf32>) outs(%18 : tensor<160x23xbf16>) attrs =  {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} {
    ^bb2(%20: f32, %21: bf16):
      %22 = arith.truncf %20 : f32 to bf16
      linalg.yield %22 : bf16
    } -> tensor<160x23xbf16>
    %23 = tensor.empty() : tensor<160x37xf32>
    %24 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<160x37xbf16>) outs(%23 : tensor<160x37xf32>) attrs =  {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} {
    ^bb3(%25: bf16, %26: f32):
      %27 = arith.extf %25 : bf16 to f32
      linalg.yield %27 : f32
    } -> tensor<160x37xf32>
    %28 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %29 = tensor.splat %28 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : tensor<160x41xf32>
    %30 = tensor.empty() : tensor<37x41xf32>
    %31 = func.call @merlin_dev_mx_gemmini_1(%24, %30, %29) : (tensor<160x37xf32>, tensor<37x41xf32>, tensor<160x41xf32>) -> tensor<160x41xf32>
    %32 = tensor.empty() : tensor<160x41xbf16>
    %33 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%31 : tensor<160x41xf32>) outs(%32 : tensor<160x41xbf16>) attrs =  {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} {
    ^bb4(%34: f32, %35: bf16):
      %36 = arith.truncf %34 : f32 to bf16
      linalg.yield %36 : bf16
    } -> tensor<160x41xbf16>
    %37 = tensor.empty() : tensor<160x37xf32>
    %38 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<160x37xbf16>) outs(%37 : tensor<160x37xf32>) attrs =  {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} {
    ^bb5(%39: bf16, %40: f32):
      %41 = arith.extf %39 : bf16 to f32
      linalg.yield %41 : f32
    } -> tensor<160x37xf32>
    %42 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %43 = tensor.splat %42 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : tensor<160x17xf32>
    %44 = tensor.empty() : tensor<37x17xf32>
    %45 = func.call @merlin_dev_mx_gemmini_2(%38, %44, %43) : (tensor<160x37xf32>, tensor<37x17xf32>, tensor<160x17xf32>) -> tensor<160x17xf32>
    %46 = tensor.empty() : tensor<160x17xbf16>
    %47 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%45 : tensor<160x17xf32>) outs(%46 : tensor<160x17xbf16>) attrs =  {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} {
    ^bb6(%48: f32, %49: bf16):
      %50 = arith.truncf %48 : f32 to bf16
      linalg.yield %50 : bf16
    } -> tensor<160x17xbf16>
    %51 = tensor.concat dim(1) %19, %33, %47 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "bfloat16"} : (tensor<160x23xbf16>, tensor<160x41xbf16>, tensor<160x17xbf16>) -> tensor<160x81xbf16>
    %52 = tensor.empty() : tensor<160x81xf32>
    %53 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%51 : tensor<160x81xbf16>) outs(%52 : tensor<160x81xf32>) attrs =  {prov.region_id = "dtype_cast_1", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32"} {
    ^bb7(%54: bf16, %55: f32):
      %56 = arith.extf %54 : bf16 to f32
      linalg.yield %56 : f32
    } -> tensor<160x81xf32>
    func.return %53 : tensor<160x81xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<160x37xf32>, tensor<37x23xf32>, tensor<160x23xf32>) -> tensor<160x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<160x37xf32>, tensor<37x41xf32>, tensor<160x41xf32>) -> tensor<160x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<160x37xf32>, tensor<37x17xf32>, tensor<160x17xf32>) -> tensor<160x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}