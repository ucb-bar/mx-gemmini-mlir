unsigned char mx_catalog_workspace[68928] __attribute__((aligned(64)));
