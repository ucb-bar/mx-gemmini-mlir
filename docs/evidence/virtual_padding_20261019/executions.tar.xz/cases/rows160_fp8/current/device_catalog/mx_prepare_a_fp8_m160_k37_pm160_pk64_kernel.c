#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"
static float padded[10240] __attribute__((aligned(64)));

void mx_prepare_a_fp8_m160_k37_pm160_pk64_kernel(const float *lhs, uint8_t *out) {
  if (!lhs || !out) __builtin_trap();
  for (size_t i = 0; i < 10240u; ++i) padded[i] = 0;
  for (size_t row = 0; row < 160u; ++row)
    for (size_t col = 0; col < 37u; ++col)
      padded[row * 64u + col] = lhs[row * 37u + col];
  if (mx_pack_activation_f32(padded, 160u, 64u,
      MX_RUNTIME_FP8, out, out+10240u)) __builtin_trap();
}
