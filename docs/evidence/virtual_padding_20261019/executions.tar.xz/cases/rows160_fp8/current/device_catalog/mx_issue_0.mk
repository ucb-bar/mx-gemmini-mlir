kernel mx_issue_0_schedule(activation: i8[10240] read, activation_scales: i8[320] read, weight: i8[2048] read, weight_scales: i8[64] read, output_bf16: i16[5120] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=160, nc=32, kt=64}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..1:
        native_loop(a=&activation[((row * 10240) + (wave * 64))], b=&weight[((wave * 2048) + (chunk * 32))], c=&output_bf16[((row * 10240) + (chunk * 64))], asc=&activation_scales[((wave * 320) + (row * 160))], bsc=&weight_scales[((wave * 64) + (chunk * 32))], write=select(wave == 0, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod((row + chunk + wave), 2) + 1))
