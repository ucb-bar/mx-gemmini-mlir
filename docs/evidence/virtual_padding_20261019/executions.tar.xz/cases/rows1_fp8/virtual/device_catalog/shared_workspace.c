unsigned char mx_catalog_workspace[4928] __attribute__((aligned(64)));
