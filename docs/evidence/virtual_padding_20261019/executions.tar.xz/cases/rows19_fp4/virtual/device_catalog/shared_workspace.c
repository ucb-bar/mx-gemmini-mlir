unsigned char mx_catalog_workspace[12096] __attribute__((aligned(64)));
