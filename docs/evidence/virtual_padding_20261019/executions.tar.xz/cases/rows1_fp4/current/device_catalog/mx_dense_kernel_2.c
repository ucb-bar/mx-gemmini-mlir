/* MX dense f32 adapter: FP4, qualified 32x32x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_2(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_2_fixed_codes[];
extern const uint8_t mx_dense_kernel_2_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_2(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 8192);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 9216);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 9280);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 11328);
  for (size_t i = 0; i < 2048u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 1u; ++row)
    for (size_t col = 0; col < 37u; ++col)
      padded_a[row * 64u + col] = lhs[row * 37u + col];
  if (mx_pack_activation_f32(padded_a, 32u, 64u, MX_RUNTIME_FP4,
                             activation, activation_scales)) __builtin_trap();
  mx_issue_2(activation, activation_scales, mx_dense_kernel_2_fixed_codes, mx_dense_kernel_2_fixed_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 1u; ++row)
    for (uint32_t col = 0; col < 17u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 32u + col] << 16;
      out[(size_t)row * 17u + col] = word.value;
    }
}
