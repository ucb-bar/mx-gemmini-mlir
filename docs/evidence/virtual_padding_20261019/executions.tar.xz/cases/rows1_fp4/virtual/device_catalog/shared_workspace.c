unsigned char mx_catalog_workspace[7488] __attribute__((aligned(64)));
