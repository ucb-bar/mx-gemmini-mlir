#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"
static float padded[64] __attribute__((aligned(64)));

void mx_prepare_a_fp4_m1_k37_pm32_pk64_kernel(const float *lhs, uint8_t *out) {
  if (!lhs || !out) __builtin_trap();
  for (size_t i = 0; i < 64u; ++i) padded[i] = 0;
  for (size_t row = 0; row < 1u; ++row)
    for (size_t col = 0; col < 37u; ++col)
      padded[row * 64u + col] = lhs[row * 37u + col];
  if (mx_pack_activation_zero_rows_f32(padded, 1u, 32u, 64u,
      MX_RUNTIME_FP4, out, out+1024u)) __builtin_trap();
}
