/* Generated multi-program stage adapter. */
#include <stddef.h>
#include "merlin_model.h"
#include "model_gen.h"
#include "model_io.h"
extern void merlin_invoke(void **);
static merlin_descriptor_t DESCS[MERLIN_N_ARGS];
static int original_input_arg(int arg) {
  switch (arg) {
    case 0: return 0;
    case 8: return 1;
    case 9: return 2;
    case 17: return 3;
    case 18: return 4;
    case 26: return 5;
    case 27: return 6;
    case 35: return 7;
    case 36: return 8;
    case 44: return 9;
    case 45: return 10;
    case 53: return 11;
    case 54: return 12;
    case 62: return 13;
    case 63: return 14;
    case 71: return 15;
    case 72: return 16;
    case 80: return 17;
    case 81: return 18;
    case 89: return 19;
    case 90: return 20;
    case 98: return 21;
    case 99: return 22;
    case 107: return 23;
    case 108: return 24;
    case 116: return 25;
    case 117: return 26;
    case 125: return 27;
    case 126: return 28;
    case 134: return 29;
    case 135: return 30;
    case 143: return 31;
    case 144: return 32;
    case 152: return 33;
    case 153: return 34;
    case 161: return 35;
    case 162: return 36;
    case 170: return 37;
    case 171: return 38;
    case 179: return 39;
    case 180: return 40;
    case 188: return 41;
    case 189: return 42;
    case 197: return 43;
    case 198: return 44;
    case 199: return 45;
    case 201: return 46;
    case 202: return 47;
    case 203: return 48;
    default: return -1;
  }
}
static size_t arg_bytes(const merlin_arg_t *arg) {
  size_t n = (size_t)arg->elem_size;
  for (int i = 0; i < arg->rank; i++) n *= (size_t)arg->dims[i];
  return n;
}
void merlin_stage_0_reset(void) { merlin_reset_session(); }
int merlin_stage_0_run(const void *weights, long step, int validate) {
  merlin_prepare_step(step);
  merlin_run_multi_with(MERLIN_ARGS, MERLIN_N_ARGS, weights, MERLIN_INPUT_PTR,
                        MERLIN_OUTPUT_PTR, DESCS, merlin_invoke);
#if MERLIN_N_STATE_PAIRS > 0
  if (merlin_commit_state(MERLIN_ARGS, MERLIN_N_ARGS, MERLIN_INPUT_PTR, MERLIN_OUTPUT_PTR,
                          MERLIN_N_STATE_PAIRS, MERLIN_STATE_INPUT_ARGS,
                          MERLIN_STATE_OUTPUT_INDICES) != 0) return -1;
#endif
  if (validate) merlin_validate_step(step);
  return 0;
}
void *merlin_stage_0_input(int arg) {
  arg = original_input_arg(arg);
  return arg >= 0 && arg < MERLIN_N_ARGS && MERLIN_ARGS[arg].kind == MERLIN_INPUT
      ? MERLIN_INPUT_PTR[arg] : 0;
}
size_t merlin_stage_0_input_bytes(int arg) {
  arg = original_input_arg(arg);
  return arg >= 0 && arg < MERLIN_N_ARGS && MERLIN_ARGS[arg].kind == MERLIN_INPUT
      ? arg_bytes(&MERLIN_ARGS[arg]) : 0;
}
static int output_arg(int wanted) {
  int seen = 0;
  for (int arg = 0; arg < MERLIN_N_ARGS; arg++)
    if (MERLIN_ARGS[arg].kind == MERLIN_OUTPUT && seen++ == wanted) return arg;
  return -1;
}
void *merlin_stage_0_output(int output) {
  return output >= 0 && output < MERLIN_N_OUTPUTS ? MERLIN_OUTPUT_PTR[output] : 0;
}
size_t merlin_stage_0_output_bytes(int output) {
  int arg = output_arg(output); return arg >= 0 ? arg_bytes(&MERLIN_ARGS[arg]) : 0;
}
long merlin_stage_0_quality_steps(void) { return merlin_quality_steps(); }
long merlin_stage_0_quality_min_cos_ppm(void) { return merlin_quality_min_cos_ppm(); }
long merlin_stage_0_quality_max_rel_ppm(void) { return merlin_quality_max_rel_ppm(); }
long merlin_stage_0_quality_top1(void) { return merlin_quality_top1(); }
long merlin_stage_0_correctness_steps(void) { return merlin_correctness_steps(); }
long merlin_stage_0_correctness_min_cos_ppm(void) { return merlin_correctness_min_cos_ppm(); }
long merlin_stage_0_correctness_max_rel_ppm(void) { return merlin_correctness_max_rel_ppm(); }
long merlin_stage_0_correctness_top1(void) { return merlin_correctness_top1(); }
size_t merlin_stage_0_output_elems(int output) {
  int arg = output_arg(output); if (arg < 0) return 0;
  size_t n = 1; for (int i = 0; i < MERLIN_ARGS[arg].rank; i++) n *= MERLIN_ARGS[arg].dims[i];
  return n;
}
long merlin_stage_0_output_lastdim(int output) {
  int arg = output_arg(output); return arg >= 0 && MERLIN_ARGS[arg].rank > 0
      ? MERLIN_ARGS[arg].dims[MERLIN_ARGS[arg].rank - 1] : 1;
}
