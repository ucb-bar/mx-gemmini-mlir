/* Generated. Embedded runtime inputs. */
#ifndef MERLIN_MODEL_IO_H
#define MERLIN_MODEL_IO_H
#include <math.h>
#include <string.h>
static float merlin_in_201[] = {1.0,0.7498942017555237,0.5623413324356079,0.4216965138912201,0.3162277638912201,0.23713736236095428,0.17782793939113617,0.1333521455526352,0.10000000149011612,0.07498941570520401,0.05623412877321243,0.04216964915394783,0.03162277862429619,0.0237137358635664,0.017782794311642647,0.01333521492779255,0.009999999776482582,0.007498942315578461,0.005623413249850273,0.0042169648222625256,0.003162277862429619,0.0023713738191872835,0.0017782794311642647,0.0013335214462131262,0.0010000000474974513,0.0007498941849917173,0.000562341301701963,0.00042169648804701865,0.0003162277862429619,0.0002371373848291114,0.00017782794020604342,0.0001333521504420787};
static float merlin_in_202[] = {1.0,0.7498942017555237,0.5623413324356079,0.4216965138912201,0.3162277638912201,0.23713736236095428,0.17782793939113617,0.1333521455526352,0.10000000149011612,0.07498941570520401,0.05623412877321243,0.04216964915394783,0.03162277862429619,0.0237137358635664,0.017782794311642647,0.01333521492779255,0.009999999776482582,0.007498942315578461,0.005623413249850273,0.0042169648222625256,0.003162277862429619,0.0023713738191872835,0.0017782794311642647,0.0013335214462131262,0.0010000000474974513,0.0007498941849917173,0.000562341301701963,0.00042169648804701865,0.0003162277862429619,0.0002371373848291114,0.00017782794020604342,0.0001333521504420787};
static long merlin_in_203[] = {16044,8239,2933,13760,16963,16379,31427,6503,31497,9683,14101,26866,30756,13399,23878,28376,20056,9868,20794,4033,17126,14119,2391,14254,20824,21841,15269,18969,9549,17480,9481,5012,21363,17360,10995,6085,13822,17999,1711,4288,29778,19043,7896,13489,22771,9757,27283,21395,16782,21671,23840,11969,17673,441,10111,21280,9503,21706,31476,18327,1699,3326,28363,15474,14775,28700,29218,21632,29568,15012,20277,645,3110,15080,15348,21521,23119,22916,11881,8490,10682,31519,13944,5633,15169,5863,10409,18233,29219,31078,15735,3083,2222,11858,6235,12416,2446,20835,13877,3212,16505,11946,3156,26315,9284,31750,7108,1071,30847,5108,19075,27084,22884,20148,7144,19534,5519,26260,7907,3514,17175,19663,9613,23157,2133,3120,19249,24389};
static _Alignas(64) unsigned char merlin_out_0[128000];
static _Alignas(64) unsigned char merlin_out_1[7208960];
static _Alignas(64) unsigned char merlin_out_2[176];
static void *MERLIN_INPUT_PTR[MERLIN_N_ARGS] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,(void*)merlin_in_201,(void*)merlin_in_202,(void*)merlin_in_203,0,0,0};
static void *MERLIN_OUTPUT_PTR[MERLIN_N_OUTPUTS] = {(void*)merlin_out_0,(void*)merlin_out_1,(void*)merlin_out_2};
static const int MERLIN_STATE_INPUT_ARGS[1] = {0};
static const int MERLIN_STATE_OUTPUT_INDICES[1] = {0};
static void merlin_reset_session(void) {
}
static void merlin_prepare_step(long step) {
  long s = step % MERLIN_SESSION_STEPS;
  (void)s;
}
typedef struct {
  long steps; double min_cos; double max_rel; long top1;
} merlin_trajectory_metrics_t;
static merlin_trajectory_metrics_t merlin_correctness_metrics = {0, 1.0, 0.0, 0};
static merlin_trajectory_metrics_t merlin_quality_metrics = {0, 1.0, 0.0, 0};
static void merlin_compare_trajectory(const float *got, const float *ref, long n,
                                      merlin_trajectory_metrics_t *metrics) {
  double dot = 0.0, gn = 0.0, rn = 0.0, rmax = 0.0, errmax = 0.0;
  long gi = 0, ri = 0;
  for (long i = 0; i < n; i++) {
    double g = got[i], r = ref[i], e = fabs(g - r);
    dot += g * r; gn += g * g; rn += r * r;
    if (fabs(r) > rmax) rmax = fabs(r); if (e > errmax) errmax = e;
    if (got[i] > got[gi]) gi = i; if (ref[i] > ref[ri]) ri = i;
  }
  double denom = sqrt(gn) * sqrt(rn);
  double cos = denom > 0.0 ? dot / denom : (gn == rn ? 1.0 : 0.0);
  double rel = rmax > 0.0 ? errmax / rmax : errmax;
  if (cos < metrics->min_cos) metrics->min_cos = cos;
  if (rel > metrics->max_rel) metrics->max_rel = rel;
  if (gi == ri) metrics->top1++; metrics->steps++;
}
static void merlin_validate_step(long step) {
  (void)step;
}
static long merlin_correctness_steps(void) { return merlin_correctness_metrics.steps; }
static long merlin_correctness_min_cos_ppm(void) {
  return (long)(merlin_correctness_metrics.min_cos * 1000000.0);
}
static long merlin_correctness_max_rel_ppm(void) {
  return (long)(merlin_correctness_metrics.max_rel * 1000000.0);
}
static long merlin_correctness_top1(void) { return merlin_correctness_metrics.top1; }
static long merlin_quality_steps(void) { return merlin_quality_metrics.steps; }
static long merlin_quality_min_cos_ppm(void) {
  return (long)(merlin_quality_metrics.min_cos * 1000000.0);
}
static long merlin_quality_max_rel_ppm(void) {
  return (long)(merlin_quality_metrics.max_rel * 1000000.0);
}
static long merlin_quality_top1(void) { return merlin_quality_metrics.top1; }
#endif
