builtin.module {
  func.func @forward(%0: tensor<1x8311xf32>, %1: tensor<1x8311xf32>) -> tensor<1x8311xf32> {
    %2 = tensor.empty() : tensor<1x8311xf32>
    %3 = func.call @forward$kernel_0__rsigmoid_0(%0) : (tensor<1x8311xf32>) -> tensor<1x8311xf32>
    %4 = tensor.empty() : tensor<1x8311xf32>
    %5 = func.call @forward$kernel_1__rmul_0(%0, %3) : (tensor<1x8311xf32>, tensor<1x8311xf32>) -> tensor<1x8311xf32>
    %6 = tensor.empty() : tensor<1x8311xf32>
    %7 = func.call @forward$kernel_2__rmul_1(%5, %1) : (tensor<1x8311xf32>, tensor<1x8311xf32>) -> tensor<1x8311xf32>
    func.return %7 : tensor<1x8311xf32>
  }
  func.func private @forward$kernel_0__rsigmoid_0(%0: tensor<1x8311xf32>) -> tensor<1x8311xf32> {
    %1 = tensor.empty() : tensor<1x8311xf32>
    %2 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%0 : tensor<1x8311xf32>) outs(%1 : tensor<1x8311xf32>) attrs =  {prov.region_id = "sigmoid_0", prov._pattern_hint = "sigmoid", prov.op = "sigmoid", prov.family = "elementwise", prov.aten = "aten.sigmoid.default", prov.orig_dtype = "float32"} {
    ^bb0(%3: f32, %4: f32):
      %5 = arith.constant 1.000000e+00 : f32
      %6 = arith.negf %3 : f32
      %7 = math.exp %6 : f32
      %8 = arith.addf %5, %7 : f32
      %9 = arith.divf %5, %8 : f32
      linalg.yield %9 : f32
    } -> tensor<1x8311xf32>
    func.return %2 : tensor<1x8311xf32>
  }
  func.func private @forward$kernel_1__rmul_0(%0: tensor<1x8311xf32>, %1: tensor<1x8311xf32>) -> tensor<1x8311xf32> {
    %2 = tensor.empty() : tensor<1x8311xf32>
    %3 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%0, %1 : tensor<1x8311xf32>, tensor<1x8311xf32>) outs(%2 : tensor<1x8311xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb0(%4: f32, %5: f32, %6: f32):
      %7 = arith.mulf %4, %5 : f32
      linalg.yield %7 : f32
    } -> tensor<1x8311xf32>
    func.return %3 : tensor<1x8311xf32>
  }
  func.func private @forward$kernel_2__rmul_1(%0: tensor<1x8311xf32>, %1: tensor<1x8311xf32>) -> tensor<1x8311xf32> {
    %2 = tensor.empty() : tensor<1x8311xf32>
    %3 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%0, %1 : tensor<1x8311xf32>, tensor<1x8311xf32>) outs(%2 : tensor<1x8311xf32>) attrs =  {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb0(%4: f32, %5: f32, %6: f32):
      %7 = arith.mulf %4, %5 : f32
      linalg.yield %7 : f32
    } -> tensor<1x8311xf32>
    func.return %3 : tensor<1x8311xf32>
  }
}