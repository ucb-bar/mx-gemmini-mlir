builtin.module attributes {prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<1x137xf32>, %1: tensor<1x137xf32>) -> tensor<1x137xf32> {
    %2 = tensor.empty() : tensor<1x137xf32>
    %3 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%0 : tensor<1x137xf32>) outs(%2 : tensor<1x137xf32>) attrs =  {prov.region_id = "sigmoid_0", prov._pattern_hint = "sigmoid", prov.op = "sigmoid", prov.family = "elementwise", prov.aten = "aten.sigmoid.default", prov.orig_dtype = "float32"} {
    ^bb0(%4: f32, %5: f32):
      %6 = arith.constant 1.000000e+00 : f32
      %7 = arith.negf %4 : f32
      %8 = math.exp %7 : f32
      %9 = arith.addf %6, %8 : f32
      %10 = arith.divf %6, %9 : f32
      linalg.yield %10 : f32
    } -> tensor<1x137xf32>
    %11 = tensor.empty() : tensor<1x137xf32>
    %12 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%0, %3 : tensor<1x137xf32>, tensor<1x137xf32>) outs(%11 : tensor<1x137xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb1(%13: f32, %14: f32, %15: f32):
      %16 = arith.mulf %13, %14 : f32
      linalg.yield %16 : f32
    } -> tensor<1x137xf32>
    %17 = tensor.empty() : tensor<1x137xf32>
    %18 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%12, %1 : tensor<1x137xf32>, tensor<1x137xf32>) outs(%17 : tensor<1x137xf32>) attrs =  {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb2(%19: f32, %20: f32, %21: f32):
      %22 = arith.mulf %19, %20 : f32
      linalg.yield %22 : f32
    } -> tensor<1x137xf32>
    func.return %18 : tensor<1x137xf32>
  }
}