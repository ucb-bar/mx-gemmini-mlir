#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void chain(const float *,const float *,float *);
static float output[360448] __attribute__((aligned(64)));
static uint64_t cycle(void) {uint64_t n; asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
static uint32_t bits(float x) {union{float f;uint32_t u;} w;w.f=x;return w.u;}
static uint32_t input_hash(const float *x) {uint32_t h=2166136261u;
  for(unsigned i=0;i<720896u;++i)h=(h^bits(x[i]))*16777619u;return h;}
int main(void) {
  const float *x=(const float *)payload,*u=x+360448;
  const uint32_t *reference=(const uint32_t *)(u+360448);
  uint32_t original=input_hash(x);
  for(unsigned run=0;run<3;++run) {
    uint64_t begin=cycle();chain(x,u,output);uint64_t elapsed=cycle()-begin;
    unsigned mismatches=0;uint32_t h=2166136261u;
    for(unsigned i=0;i<360448u;++i) {
      uint32_t word=bits(output[i]);h=(h^word)*16777619u;
      if(0)mismatches+=word!=reference[i];
    }
    if(input_hash(x)!=original)return 4;
    printf("SECTION %u %lu %u %u\n",run,elapsed,mismatches,h);
    if(mismatches)return 3;
    if(!run)for(unsigned base=0;base<360448u;base+=128u) {
      unsigned count=360448u-base;if(count>128u)count=128u;
      printf("WORDS %u %u",base,count);
      for(unsigned i=0;i<count;++i)printf(" %08x",bits(output[base+i]));
      printf("\n");
    }
  }
  printf("DONE\n");return 0;
}
