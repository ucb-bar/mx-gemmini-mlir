#include <stdint.h>
#include <math.h>
#include "runtime_quant.h"
static float mx_softmax_packed_0_kernel_probability[8160] __attribute__((aligned(64)));
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_softmax_packed_0_kernel_exp_51(const void *score, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(256))), "r"(UINT64_C(0x0010001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(512))), "r"(UINT64_C(0x0010001000000020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(768))), "r"(UINT64_C(0x0010001000000030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1024))), "r"(UINT64_C(0x0010001000000040)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1280))), "r"(UINT64_C(0x0010001000000050)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1536))), "r"(UINT64_C(0x0010001000000060)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1792))), "r"(UINT64_C(0x0010001000000070)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2048))), "r"(UINT64_C(0x0010001000000080)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2304))), "r"(UINT64_C(0x0010001000000090)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2560))), "r"(UINT64_C(0x00100010000000a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2816))), "r"(UINT64_C(0x00100010000000b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3072))), "r"(UINT64_C(0x00100010000000c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3328))), "r"(UINT64_C(0x00100010000000d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3584))), "r"(UINT64_C(0x00100010000000e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3840))), "r"(UINT64_C(0x00100010000000f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4096))), "r"(UINT64_C(0x0010001000000100)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4352))), "r"(UINT64_C(0x0010001000000110)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4608))), "r"(UINT64_C(0x0010001000000120)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4864))), "r"(UINT64_C(0x0010001000000130)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5120))), "r"(UINT64_C(0x0010001000000140)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5376))), "r"(UINT64_C(0x0010001000000150)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5632))), "r"(UINT64_C(0x0010001000000160)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5888))), "r"(UINT64_C(0x0010001000000170)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(6144))), "r"(UINT64_C(0x0010001000000180)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(6400))), "r"(UINT64_C(0x0010001000000190)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(6656))), "r"(UINT64_C(0x00100010000001a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(6912))), "r"(UINT64_C(0x00100010000001b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(7168))), "r"(UINT64_C(0x00100010000001c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(7424))), "r"(UINT64_C(0x00100010000001d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(7680))), "r"(UINT64_C(0x00100010000001e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(7936))), "r"(UINT64_C(0x00100010000001f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(8192))), "r"(UINT64_C(0x0010001000000200)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(8448))), "r"(UINT64_C(0x0010001000000210)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(8704))), "r"(UINT64_C(0x0010001000000220)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(8960))), "r"(UINT64_C(0x0010001000000230)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(9216))), "r"(UINT64_C(0x0010001000000240)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(9472))), "r"(UINT64_C(0x0010001000000250)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(9728))), "r"(UINT64_C(0x0010001000000260)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(9984))), "r"(UINT64_C(0x0010001000000270)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(10240))), "r"(UINT64_C(0x0010001000000280)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(10496))), "r"(UINT64_C(0x0010001000000290)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(10752))), "r"(UINT64_C(0x00100010000002a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(11008))), "r"(UINT64_C(0x00100010000002b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(11264))), "r"(UINT64_C(0x00100010000002c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(11520))), "r"(UINT64_C(0x00100010000002d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(11776))), "r"(UINT64_C(0x00100010000002e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(12032))), "r"(UINT64_C(0x00100010000002f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(12288))), "r"(UINT64_C(0x0010001000000300)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(12544))), "r"(UINT64_C(0x0010001000000310)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(12800))), "r"(UINT64_C(0x0010001000000320)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(13056))), "r"(UINT64_C(0x0010001000000330)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(13312))), "r"(UINT64_C(0x0010001000000340)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(13568))), "r"(UINT64_C(0x0010001000000350)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(13824))), "r"(UINT64_C(0x0010001000000360)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(14080))), "r"(UINT64_C(0x0010001000000370)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(14336))), "r"(UINT64_C(0x0010001000000380)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(14592))), "r"(UINT64_C(0x0010001000000390)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(14848))), "r"(UINT64_C(0x00100010000003a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(15104))), "r"(UINT64_C(0x00100010000003b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(15360))), "r"(UINT64_C(0x00100010000003c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(15616))), "r"(UINT64_C(0x00100010000003d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(15872))), "r"(UINT64_C(0x00100010000003e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(16128))), "r"(UINT64_C(0x000c0010000003f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x000ff20000000000)), "r"(UINT64_C(0x0000000000000025)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0010001000002010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(512))), "r"(UINT64_C(0x0010001000002020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(768))), "r"(UINT64_C(0x0010001000002030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1024))), "r"(UINT64_C(0x0010001000002040)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1280))), "r"(UINT64_C(0x0010001000002050)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1536))), "r"(UINT64_C(0x0010001000002060)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1792))), "r"(UINT64_C(0x0010001000002070)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2048))), "r"(UINT64_C(0x0010001000002080)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2304))), "r"(UINT64_C(0x0010001000002090)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2560))), "r"(UINT64_C(0x00100010000020a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2816))), "r"(UINT64_C(0x00100010000020b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3072))), "r"(UINT64_C(0x00100010000020c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3328))), "r"(UINT64_C(0x00100010000020d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3584))), "r"(UINT64_C(0x00100010000020e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3840))), "r"(UINT64_C(0x00100010000020f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4096))), "r"(UINT64_C(0x0010001000002100)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4352))), "r"(UINT64_C(0x0010001000002110)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4608))), "r"(UINT64_C(0x0010001000002120)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4864))), "r"(UINT64_C(0x0010001000002130)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5120))), "r"(UINT64_C(0x0010001000002140)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5376))), "r"(UINT64_C(0x0010001000002150)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5632))), "r"(UINT64_C(0x0010001000002160)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5888))), "r"(UINT64_C(0x0010001000002170)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(6144))), "r"(UINT64_C(0x0010001000002180)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(6400))), "r"(UINT64_C(0x0010001000002190)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(6656))), "r"(UINT64_C(0x00100010000021a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(6912))), "r"(UINT64_C(0x00100010000021b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(7168))), "r"(UINT64_C(0x00100010000021c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(7424))), "r"(UINT64_C(0x00100010000021d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(7680))), "r"(UINT64_C(0x00100010000021e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(7936))), "r"(UINT64_C(0x00100010000021f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(8192))), "r"(UINT64_C(0x0010001000002200)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(8448))), "r"(UINT64_C(0x0010001000002210)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(8704))), "r"(UINT64_C(0x0010001000002220)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(8960))), "r"(UINT64_C(0x0010001000002230)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(9216))), "r"(UINT64_C(0x0010001000002240)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(9472))), "r"(UINT64_C(0x0010001000002250)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(9728))), "r"(UINT64_C(0x0010001000002260)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(9984))), "r"(UINT64_C(0x0010001000002270)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(10240))), "r"(UINT64_C(0x0010001000002280)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(10496))), "r"(UINT64_C(0x0010001000002290)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(10752))), "r"(UINT64_C(0x00100010000022a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(11008))), "r"(UINT64_C(0x00100010000022b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(11264))), "r"(UINT64_C(0x00100010000022c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(11520))), "r"(UINT64_C(0x00100010000022d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(11776))), "r"(UINT64_C(0x00100010000022e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(12032))), "r"(UINT64_C(0x00100010000022f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(12288))), "r"(UINT64_C(0x0010001000002300)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(12544))), "r"(UINT64_C(0x0010001000002310)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(12800))), "r"(UINT64_C(0x0010001000002320)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(13056))), "r"(UINT64_C(0x0010001000002330)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(13312))), "r"(UINT64_C(0x0010001000002340)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(13568))), "r"(UINT64_C(0x0010001000002350)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(13824))), "r"(UINT64_C(0x0010001000002360)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(14080))), "r"(UINT64_C(0x0010001000002370)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(14336))), "r"(UINT64_C(0x0010001000002380)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(14592))), "r"(UINT64_C(0x0010001000002390)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(14848))), "r"(UINT64_C(0x00100010000023a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(15104))), "r"(UINT64_C(0x00100010000023b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(15360))), "r"(UINT64_C(0x00100010000023c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(15616))), "r"(UINT64_C(0x00100010000023d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(15872))), "r"(UINT64_C(0x00100010000023e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(16128))), "r"(UINT64_C(0x000c0010000023f0)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_softmax_packed_0_kernel_exp_20(const void *score, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(256))), "r"(UINT64_C(0x0010001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(512))), "r"(UINT64_C(0x0010001000000020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(768))), "r"(UINT64_C(0x0010001000000030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1024))), "r"(UINT64_C(0x0010001000000040)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1280))), "r"(UINT64_C(0x0010001000000050)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1536))), "r"(UINT64_C(0x0010001000000060)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(1792))), "r"(UINT64_C(0x0010001000000070)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2048))), "r"(UINT64_C(0x0010001000000080)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2304))), "r"(UINT64_C(0x0010001000000090)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2560))), "r"(UINT64_C(0x00100010000000a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(2816))), "r"(UINT64_C(0x00100010000000b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3072))), "r"(UINT64_C(0x00100010000000c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3328))), "r"(UINT64_C(0x00100010000000d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3584))), "r"(UINT64_C(0x00100010000000e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(3840))), "r"(UINT64_C(0x00100010000000f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4096))), "r"(UINT64_C(0x0010001000000100)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4352))), "r"(UINT64_C(0x0010001000000110)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4608))), "r"(UINT64_C(0x0010001000000120)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(4864))), "r"(UINT64_C(0x0010001000000130)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5120))), "r"(UINT64_C(0x0010001000000140)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5376))), "r"(UINT64_C(0x0010001000000150)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5632))), "r"(UINT64_C(0x0010001000000160)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(5888))), "r"(UINT64_C(0x0010001000000170)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)score + UINT64_C(6144))), "r"(UINT64_C(0x0010001000000180)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0006420000000000)), "r"(UINT64_C(0x0000000000000025)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0010001000002010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(512))), "r"(UINT64_C(0x0010001000002020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(768))), "r"(UINT64_C(0x0010001000002030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1024))), "r"(UINT64_C(0x0010001000002040)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1280))), "r"(UINT64_C(0x0010001000002050)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1536))), "r"(UINT64_C(0x0010001000002060)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1792))), "r"(UINT64_C(0x0010001000002070)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2048))), "r"(UINT64_C(0x0010001000002080)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2304))), "r"(UINT64_C(0x0010001000002090)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2560))), "r"(UINT64_C(0x00100010000020a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2816))), "r"(UINT64_C(0x00100010000020b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3072))), "r"(UINT64_C(0x00100010000020c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3328))), "r"(UINT64_C(0x00100010000020d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3584))), "r"(UINT64_C(0x00100010000020e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3840))), "r"(UINT64_C(0x00100010000020f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4096))), "r"(UINT64_C(0x0010001000002100)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4352))), "r"(UINT64_C(0x0010001000002110)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4608))), "r"(UINT64_C(0x0010001000002120)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(4864))), "r"(UINT64_C(0x0010001000002130)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5120))), "r"(UINT64_C(0x0010001000002140)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5376))), "r"(UINT64_C(0x0010001000002150)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5632))), "r"(UINT64_C(0x0010001000002160)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(5888))), "r"(UINT64_C(0x0010001000002170)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(6144))), "r"(UINT64_C(0x0010001000002180)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_softmax_packed_0_kernel_score[8160] __attribute__((aligned(64)));
static uint16_t mx_softmax_packed_0_kernel_result[8160] __attribute__((aligned(64)));
void mx_softmax_packed_0_kernel(const float *input, uint8_t *output) {
  if (!input || !output) __builtin_trap();
  uintptr_t a = (uintptr_t)input, b = (uintptr_t)output;
  uintptr_t bytes = (uintptr_t)5120 * 160 * sizeof(float);
  uintptr_t output_bytes=(uintptr_t)5120*160*33u/32u;
  if (a > UINTPTR_MAX - bytes || b > UINTPTR_MAX - output_bytes ||
      !(a + bytes <= b || b + output_bytes <= a)) __builtin_trap();
  for (uint32_t base = 0; base < 5120; base += 51) {
    uint32_t count = 5120 - base;
    if (count > 51) count = 51;
    for (uint32_t row = 0; row < count; ++row) {
      const float *in = input + (base + row) * 160;
      float maximum = -INFINITY;
      for (uint32_t col = 0; col < 160; ++col) {
        union { float f; uint32_t u; } x = { .f = in[col] };
        if ((x.u & 0x7f800000u) == 0x7f800000u && x.u != 0xff800000u) __builtin_trap();
        if (x.f > maximum) maximum = x.f;
      }
      if (maximum == -INFINITY) __builtin_trap();
      for (uint32_t col = 0; col < 160; ++col) {
        union { float f; uint32_t u; } x;
        x.f = col < 160 ? in[col] - maximum : -INFINITY;
        x.u += 0x7fffu + ((x.u >> 16) & 1u);
        mx_softmax_packed_0_kernel_score[row * 160 + col] = (uint16_t)(x.u >> 16);
      }
    }
    const void *score = mx_softmax_packed_0_kernel_score, *result = mx_softmax_packed_0_kernel_result;
    switch (count) {
      case 51: mx_softmax_packed_0_kernel_exp_51(score, result); break;
      case 20: mx_softmax_packed_0_kernel_exp_20(score, result); break;
      default: __builtin_trap();
    }
    for (uint32_t row = 0; row < count; ++row) {
      float sum = 0.0f;
      for (uint32_t col = 0; col < 160; ++col) {
        union { float f; uint32_t u; } x;
        x.u = (uint32_t)mx_softmax_packed_0_kernel_result[row * 160 + col] << 16;
        sum += x.f;
      }
      for (uint32_t col = 0; col < 160; ++col) {
        union { float f; uint32_t u; } x;
        x.u = (uint32_t)mx_softmax_packed_0_kernel_result[row * 160 + col] << 16;
        mx_softmax_packed_0_kernel_probability[row * 160 + col] = x.f / sum;
      }
    }

    for (uint32_t first=0; first<count;) {
      uint32_t global=base+first, matrix=global/160u;
      uint32_t local=global%160u, length=160u-local;
      if (length>count-first) length=count-first;
      uint8_t *codes=output+matrix*26400u;
      if (mx_pack_activation_f32_rows(mx_softmax_packed_0_kernel_probability+first*160u,
              160u,160u,local,length,codes,
              codes+25600u)) __builtin_trap();
      first+=length;
    }
  }
}
