#include <stdint.h>
#include <stdio.h>
extern const float input[];
extern const uint32_t old_expected[],hybrid_expected[];
extern void old(const float *,float *);
extern void hybrid(const float *,float *);
enum{N=160*5632};
static uint32_t output[N+32] __attribute__((aligned(64)));
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){
 for(unsigned trial=0;trial<2;trial++)for(unsigned order=0;order<2;order++){
  unsigned role=trial^order;for(unsigned i=0;i<N+32;i++)output[i]=0xa5a5a5a5;
  uint64_t start=ticks();if(role)hybrid(input,(float *)(output+16));else old(input,(float *)(output+16));
  uint64_t cycles=ticks()-start;unsigned bad=0;const uint32_t *expected=role?hybrid_expected:old_expected;
  for(unsigned i=0;i<N;i++)bad+=output[i+16]!=expected[i];
  for(unsigned i=0;i<16;i++)bad+=output[i]!=0xa5a5a5a5||output[N+16+i]!=0xa5a5a5a5;
  printf("SIGMOID trial=%u role=%u cycles=%lu bad=%u checked=%u\n",trial,role,(unsigned long)cycles,bad,N);
  if(bad)return 1;
  for(unsigned i=0;i<N;i+=32){printf("SIGMOID_WORDS %u %u %u 32",trial,role,i);for(unsigned j=0;j<32;j++)printf(" %08x",output[i+16+j]);printf("\n");}
 }
 printf("SIGMOID_DONE\n");return 0;
}
