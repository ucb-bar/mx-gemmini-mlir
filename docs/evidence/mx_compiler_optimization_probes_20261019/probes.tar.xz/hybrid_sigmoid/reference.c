#include "vpu_ref.h"
void reference(const float *x,float *old,float *hybrid){
 for(unsigned i=0;i<160u*5632u;i++){
  uint16_t a=vpu_f_to_bf16(x[i]);
  old[i]=vpu_bf16_to_f(vpu_rcp(vpu_add(vpu_exp(vpu_mul(a,0xbf80)),0x3f80)));
  hybrid[i]=1.0f/(1.0f+vpu_bf16_to_f(vpu_exp(vpu_f_to_bf16(-x[i]))));
 }
}
