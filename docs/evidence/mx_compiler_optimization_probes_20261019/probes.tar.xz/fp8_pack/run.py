import pathlib,subprocess,os,json,hashlib
p=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path.cwd();riscv=pathlib.Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools');startup=pathlib.Path('/scratch/agustin/projects/chipyard-mx/generators/gemmini/software/gemmini-rocc-tests/riscv-tests/benchmarks/common')
cc=riscv/'bin/riscv64-unknown-elf-gcc'; flags=['-march=rv64gc','-mabi=lp64d','-mcmodel=medany','-O2','-fno-fast-math','-ffp-contract=off','-ffreestanding','-fno-common','-fno-builtin','-DPREALLOCATE=1','-DMULTITHREAD=1','-DBAREMETAL=1','-DSPIKE_SIM','-I',str(repo/'mx_gemmini_support'),'-I',str(p),'-I',str(startup),'-I',str(startup.parent.parent),'-I',str(startup.parent.parent/'env')]
cmds=[]
def run(cmd):
 cmds.append(list(map(str,cmd)));subprocess.run(cmd,cwd=p,check=True)
objs=[]
names=['mx_pack_activation_f32','mx_pack_activation_zero_rows_f32','mx_pack_weight_f32','mx_widen_bf16_f32','mx_pack_activation_bf16']
for role in ['old','new']:
 obj=p/(role+'.o');run([cc,*flags,'-DMX_QUANT_GROUP_WORDS','-DMX_QUANT_INLINE_GROUP','-DMX_QUANT_BF16_INPUT',*[f'-D{n}={role}_{n}' for n in names],'-c',p/(role+'_quant.c'),'-o',obj]);objs.append(obj)
for i,src in enumerate([p/'main.c',p/'data.S',*sorted(startup.glob('*.c')),*sorted(startup.glob('*.S'))]):
 obj=p/f'part{i}.o';run([cc,*flags,'-c',src,'-o',obj]);objs.append(obj)
run([cc,'-nostdlib','-nostartfiles','-static','-T',startup/'test.ld',*objs,'-lm','-lgcc','-o',p/'pair.elf'])
ext=repo/'docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so'
env=os.environ|{'GEMMINI_MODE':'both','GEMMINI_PERF_CONFIG':'e4m3_vpu','GEMMINI_PERF_SET':'mem.host_tracking=0','GEMMINI_PERF_OUT':str(p/'perf.txt')}
cmd=[str(riscv/'bin/spike'),'--isa=rv64gc_zicntr','--extlib='+str(ext),'--extension=gemmini','-m0x80000000:0x1c0000000',str(p/'pair.elf')];cmds.append(cmd)
(p/'commands.json').write_text(json.dumps(cmds,indent=2)+'\n')
with (p/'spike.log').open('wb') as f:r=subprocess.run(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
(p/'status.json').write_text(json.dumps({'exit_code':r.returncode,'elf_sha256':hashlib.sha256((p/'pair.elf').read_bytes()).hexdigest()})+'\n')
print((p/'spike.log').read_text());r.check_returncode()
