#include <stdint.h>
#include <stdio.h>
extern const float input[];
extern const uint8_t expected_codes[], expected_scales[];
extern int old_mx_pack_activation_f32(const float *,uint32_t,uint32_t,uint32_t,uint8_t*,uint8_t*);
extern int new_mx_pack_activation_f32(const float *,uint32_t,uint32_t,uint32_t,uint8_t*,uint8_t*);
enum {N=160*5632, S=N/32};
static uint8_t codes[N+128] __attribute__((aligned(64)));
static uint8_t scales[S+128] __attribute__((aligned(64)));
static uint64_t ticks(void) {uint64_t x;asm volatile("rdcycle %0":"=r"(x)::"memory");return x;}
int main(void) {
 for(int trial=0;trial<4;trial++)for(int order=0;order<2;order++){
  int role=order^(trial&1);for(int i=0;i<N+128;i++)codes[i]=0xa5;for(int i=0;i<S+128;i++)scales[i]=0xa5;
  uint64_t begin=ticks();
  int rc=(role?new_mx_pack_activation_f32:old_mx_pack_activation_f32)(input,160,5632,8,codes+64,scales+64);
  uint64_t cycles=ticks()-begin;int bad=rc!=0;
  for(int i=0;i<N;i++)bad+=codes[i+64]!=expected_codes[i];
  for(int i=0;i<S;i++)bad+=scales[i+64]!=expected_scales[i];
  for(int i=0;i<64;i++)bad+=codes[i]!=0xa5||codes[i+N+64]!=0xa5||scales[i]!=0xa5||scales[i+S+64]!=0xa5;
  printf("QUANT trial=%d role=%d cycles=%lu bad=%d checked=%d\n",trial,role,(unsigned long)cycles,bad,N+S);
  if(bad)return 1;
 }
 printf("QUANT_DONE\n");return 0;
}
