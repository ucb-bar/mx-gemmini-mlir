#include <stdio.h>
#include <stdint.h>
extern const float input[];
extern const uint32_t expected[];
extern void hybrid(const float *,float *);
enum{N=5120*160};
static uint32_t output[N+32] __attribute__((aligned(64)));
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){
 for(unsigned i=0;i<N+32;i++)output[i]=0xa5a5a5a5;
 uint64_t begin=ticks();hybrid(input,(float *)(output+16));uint64_t cycles=ticks()-begin;
 unsigned bad=0;for(unsigned i=0;i<N;i++)bad+=output[i+16]!=expected[i];
 for(unsigned i=0;i<16;i++)bad+=output[i]!=0xa5a5a5a5||output[N+16+i]!=0xa5a5a5a5;
 printf("HYBRID cycles=%lu bad=%u checked=%u\n",(unsigned long)cycles,bad,N);
 for(unsigned i=0;i<N;i+=32){printf("SOFTMAX_WORDS %u 32",i);for(unsigned j=0;j<32;j++)printf(" %08x",output[i+16+j]);printf("\n");}
 printf("HYBRID_DONE\n");return bad?1:0;
}
