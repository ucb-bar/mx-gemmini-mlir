#include <stdint.h>
#include <stdio.h>
#include "runtime_quant.h"
extern const float scores[],rhs[];
extern const uint8_t expected[];
extern void mx_vpu_softmax_1_32_160_160_kernel(const float *,float *);
extern void mx_dense_kernel_156_repeated_rhs_8_compact_kernel(const float *,const float *,float *);
extern void mx_softmax_packed_0_kernel(const float *,const float *,float *);
extern void mx_softmax_packed_0_softmax(const float *,uint8_t *);

enum{N=32*160*64,P=32*160*160,B=P*33/32,S=160*160*33/32};
unsigned char mx_catalog_workspace[131072] __attribute__((aligned(64)));
static float probability[P];
static uint8_t packed[B+128] __attribute__((aligned(64)));
static uint32_t output[N+32] __attribute__((aligned(64))),reference[N];
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){
 for(unsigned trial=0;trial<2;trial++)for(unsigned order=0;order<2;order++){
  unsigned role=trial^order;
  for(unsigned i=0;i<B+128;i++)packed[i]=0xa5;
  for(unsigned i=0;i<N+32;i++)output[i]=0xa5a5a5a5;
  uint64_t start=ticks();
  if(role){mx_softmax_packed_0_kernel(scores,rhs,(float *)(output+16));}
  else{mx_vpu_softmax_1_32_160_160_kernel(scores,probability);
    mx_dense_kernel_156_repeated_rhs_8_compact_kernel(probability,rhs,(float *)(output+16));}
  uint64_t cycles=ticks()-start;unsigned bad=0;
  if(role)for(unsigned b=0;b<32;b++)mx_softmax_packed_0_softmax(scores+b*160*160,packed+64+b*S);
  if(!role)for(unsigned b=0;b<32;b++)if(mx_pack_activation_f32(probability+b*160*160,160,160,8,packed+64+b*S,packed+64+b*S+160*160))return 2;
  for(unsigned i=0;i<B;i++)bad+=packed[i+64]!=expected[i];
  for(unsigned i=0;i<64;i++)bad+=packed[i]!=0xa5||packed[i+B+64]!=0xa5;
  for(unsigned i=0;i<16;i++)bad+=output[i]!=0xa5a5a5a5||output[N+16+i]!=0xa5a5a5a5;
  if(!trial&&!order)for(unsigned i=0;i<N;i++)reference[i]=output[i+16];
  else for(unsigned i=0;i<N;i++)bad+=reference[i]!=output[i+16];
  printf("SOFTMAX_PACK trial=%u role=%u cycles=%lu bad=%u packed=%u matrix_words=%u\n",trial,role,(unsigned long)cycles,bad,B,N);
  if(bad)return 1;
  for(unsigned i=0;i<N;i+=32){printf("MATRIX_WORDS %u %u %u 32",trial,role,i);for(unsigned j=0;j<32;j++)printf(" %08x",output[i+16+j]);printf("\n");}
  for(unsigned i=0;i<B;i+=32){printf("PACKED_BYTES %u %u %u 32",trial,role,i);for(unsigned j=0;j<32;j++)printf(" %02x",packed[i+64+j]);printf("\n");}
 }
 printf("SOFTMAX_PACK_DONE\n");return 0;
}
