/* MX dense f32 adapter: FP8, qualified 160x256x2048 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void old_issue1(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t weight1[];
extern const uint8_t scales1[];
extern unsigned char workspace[];

void old1(const uint8_t *lhs, float *out) {
  if (!lhs || !out) __builtin_trap();
  uint16_t *output_bf16 = (uint16_t *)(workspace + 0);
  uint8_t *scratch_output_scales = (uint8_t *)(workspace + 81920);
  const uint8_t *activation = lhs;
  const uint8_t *activation_scales = lhs + 327680u;
  old_issue1(activation, activation_scales, weight1, scales1,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 160u; ++row)
    for (uint32_t col = 0; col < 256u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 256u + col] << 16;
      out[(size_t)row * 256u + col] = word.value;
    }
}
