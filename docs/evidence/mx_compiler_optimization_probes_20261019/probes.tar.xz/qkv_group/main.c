#include <stdint.h>
#include <stdio.h>
extern const uint8_t input[];
extern const uint32_t expected0[],expected1[],expected2[];
extern void old0(const void*,void*),old1(const void*,void*),old2(const void*,void*);
extern void grouped(const void*,void*,void*,void*);
unsigned char workspace[1048576] __attribute__((aligned(64)));
enum{N=160*2048};
static uint32_t output[3][N+32] __attribute__((aligned(64)));
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){
 const uint32_t *expected[]={expected0,expected1,expected2}; const unsigned sizes[]={160*2048,160*256,160*256};
 for(unsigned trial=0;trial<2;trial++)for(unsigned order=0;order<2;order++){
  unsigned role=trial^order;
  for(unsigned p=0;p<3;p++)for(unsigned i=0;i<N+32;i++)output[p][i]=0xa5a5a5a5;
  uint64_t start=ticks();
  if(role)grouped(input,output[0]+16,output[1]+16,output[2]+16);
  else{old0(input,output[0]+16);old1(input,output[1]+16);old2(input,output[2]+16);}
  uint64_t cycles=ticks()-start;unsigned bad=0;
  for(unsigned p=0;p<3;p++){
   for(unsigned i=0;i<sizes[p];i++)bad+=output[p][i+16]!=expected[p][i];
   for(unsigned i=0;i<16;i++)bad+=output[p][i]!=0xa5a5a5a5||output[p][sizes[p]+16+i]!=0xa5a5a5a5;
  }
  printf("PROJECTION trial=%u role=%u cycles=%lu bad=%u checked=%u\n",trial,role,(unsigned long)cycles,bad,160*(2048+256+256));
  if(bad)return 1;
  for(unsigned p=0;p<3;p++)for(unsigned i=0;i<sizes[p];i+=32){
   printf("PROJECTION_WORDS %u %u %u %u 32",trial,role,p,i);
   for(unsigned j=0;j<32;j++)printf(" %08x",output[p][16+i+j]);printf("\n");
  }
 }
 printf("PROJECTION_DONE\n");return 0;
}
