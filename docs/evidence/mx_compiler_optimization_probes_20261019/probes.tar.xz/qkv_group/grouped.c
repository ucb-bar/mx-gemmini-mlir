#include <stdint.h>
#include <stddef.h>
_Static_assert(sizeof(uintptr_t) == 8, "MX native commands require RV64");
#ifdef MX_TRACE_COMMANDS
extern void mx_trace_command(uint32_t funct, uint64_t rs1, uint64_t rs2);
extern void mx_trace_fence(void);
#define MX_CMD(F, A, B) mx_trace_command((F), (uint64_t)(A), (uint64_t)(B))
#define MX_FENCE() mx_trace_fence()
#else
#define MX_CMD(F, A, B) __asm__ volatile (".insn r 0x7b, 3, " #F ", x0, %0, %1" \
    : : "r"((uint64_t)(A)), "r"((uint64_t)(B)) : "memory")
#define MX_FENCE() __asm__ volatile ("fence" ::: "memory")
#endif
static void grouped_issue_0_scheduled(uint8_t *activation, uint8_t *activation_scales, uint8_t *weight, uint8_t *weight_scales, uint16_t *output_bf16, uint8_t *scratch_output_scales) {
    MX_CMD(7, 0, 0);
    MX_CMD(0, UINT64_C(114692), UINT64_C(1) << 48);
    MX_CMD(0, UINT64_C(1048833), UINT64_C(2048));
    MX_CMD(0, UINT64_C(1048841), UINT64_C(2048));
    MX_CMD(0, 2, UINT64_C(4096));
    for (int row = 0; row < 2; row++) {
        for (int chunk = 0; chunk < 16; chunk++) {
            for (int wave = 0; wave < 4; wave++) {
                do {
      MX_CMD(31, (uint64_t)(uintptr_t)((uint8_t *)activation_scales + ((wave * 2560) + (row * 80))), (uint64_t)(uintptr_t)((uint8_t *)weight_scales + ((wave * 32768) + (chunk * 128))));
      MX_CMD(32, UINT64_C(160), UINT64_C(2048));
      MX_CMD(9, 0, UINT64_C(137439477765));
      MX_CMD(10, (uint64_t)(uintptr_t)((uint8_t *)activation + ((row * 163840) + (wave * 512))), (uint64_t)(uintptr_t)((uint8_t *)weight + ((wave * 1048576) + (chunk * 128))));
      MX_CMD(11, 0, (((wave == 3) ? 1 : 0)) ? (uint64_t)(uintptr_t)((uint8_t *)output_bf16 + ((row * 327680) + (chunk * 256))) : 0);
      MX_CMD(12, UINT64_C(2048), UINT64_C(2048));
      MX_CMD(13, 0, UINT64_C(2048));
      MX_CMD(8, (UINT64_C(1) << 18) | ((uint64_t)(((((((row * 64) + (chunk * 4) + wave) % 2) + 2) % 2) + 1)) << 16) | (uint64_t)(((wave == 0) ? 0 : 1)), 0);
    } while (0);
            }
        }
    }
    
}

void grouped_issue_0(const void *activation, const void *activation_scales,
              const void *weight, const void *weight_scales,
              const void *output_bf16, const void *scratch_output_scales) {
  if (!activation || !activation_scales || !weight || !weight_scales ||
      !output_bf16 || !scratch_output_scales ||
      (((uintptr_t)activation_scales | (uintptr_t)weight_scales) & 7)) __builtin_trap();
  grouped_issue_0_scheduled((uint8_t *)activation, (uint8_t *)activation_scales,
                     (uint8_t *)weight, (uint8_t *)weight_scales,
                     (uint16_t *)output_bf16, (uint8_t *)scratch_output_scales);
}

#include <stdint.h>
#include <stddef.h>
_Static_assert(sizeof(uintptr_t) == 8, "MX native commands require RV64");
#ifdef MX_TRACE_COMMANDS
extern void mx_trace_command(uint32_t funct, uint64_t rs1, uint64_t rs2);
extern void mx_trace_fence(void);
#define MX_CMD(F, A, B) mx_trace_command((F), (uint64_t)(A), (uint64_t)(B))
#define MX_FENCE() mx_trace_fence()
#else
#define MX_CMD(F, A, B) __asm__ volatile (".insn r 0x7b, 3, " #F ", x0, %0, %1" \
    : : "r"((uint64_t)(A)), "r"((uint64_t)(B)) : "memory")
#define MX_FENCE() __asm__ volatile ("fence" ::: "memory")
#endif
static void grouped_issue_1_scheduled(uint8_t *activation, uint8_t *activation_scales, uint8_t *weight, uint8_t *weight_scales, uint16_t *output_bf16, uint8_t *scratch_output_scales) {
    MX_CMD(7, 0, 0);
    MX_CMD(0, UINT64_C(114692), UINT64_C(1) << 48);
    MX_CMD(0, UINT64_C(1048833), UINT64_C(2048));
    MX_CMD(0, UINT64_C(1048841), UINT64_C(256));
    MX_CMD(0, 2, UINT64_C(512));
    for (int row = 0; row < 2; row++) {
        for (int chunk = 0; chunk < 2; chunk++) {
            for (int wave = 0; wave < 4; wave++) {
                do {
      MX_CMD(31, (uint64_t)(uintptr_t)((uint8_t *)activation_scales + ((wave * 2560) + (row * 80))), (uint64_t)(uintptr_t)((uint8_t *)weight_scales + ((wave * 4096) + (chunk * 128))));
      MX_CMD(32, UINT64_C(160), UINT64_C(256));
      MX_CMD(9, 0, UINT64_C(137439477765));
      MX_CMD(10, (uint64_t)(uintptr_t)((uint8_t *)activation + ((row * 163840) + (wave * 512))), (uint64_t)(uintptr_t)((uint8_t *)weight + ((wave * 131072) + (chunk * 128))));
      MX_CMD(11, 0, (((wave == 3) ? 1 : 0)) ? (uint64_t)(uintptr_t)((uint8_t *)output_bf16 + ((row * 40960) + (chunk * 256))) : 0);
      MX_CMD(12, UINT64_C(2048), UINT64_C(256));
      MX_CMD(13, 0, UINT64_C(256));
      MX_CMD(8, (UINT64_C(1) << 18) | ((uint64_t)(((((((row * 8) + (chunk * 4) + wave) % 2) + 2) % 2) + 1)) << 16) | (uint64_t)(((wave == 0) ? 0 : 1)), 0);
    } while (0);
            }
        }
    }
    
}

void grouped_issue_1(const void *activation, const void *activation_scales,
              const void *weight, const void *weight_scales,
              const void *output_bf16, const void *scratch_output_scales) {
  if (!activation || !activation_scales || !weight || !weight_scales ||
      !output_bf16 || !scratch_output_scales ||
      (((uintptr_t)activation_scales | (uintptr_t)weight_scales) & 7)) __builtin_trap();
  grouped_issue_1_scheduled((uint8_t *)activation, (uint8_t *)activation_scales,
                     (uint8_t *)weight, (uint8_t *)weight_scales,
                     (uint16_t *)output_bf16, (uint8_t *)scratch_output_scales);
}

#include <stdint.h>
#include <stddef.h>
_Static_assert(sizeof(uintptr_t) == 8, "MX native commands require RV64");
#ifdef MX_TRACE_COMMANDS
extern void mx_trace_command(uint32_t funct, uint64_t rs1, uint64_t rs2);
extern void mx_trace_fence(void);
#define MX_CMD(F, A, B) mx_trace_command((F), (uint64_t)(A), (uint64_t)(B))
#define MX_FENCE() mx_trace_fence()
#else
#define MX_CMD(F, A, B) __asm__ volatile (".insn r 0x7b, 3, " #F ", x0, %0, %1" \
    : : "r"((uint64_t)(A)), "r"((uint64_t)(B)) : "memory")
#define MX_FENCE() __asm__ volatile ("fence" ::: "memory")
#endif
static void grouped_issue_2_scheduled(uint8_t *activation, uint8_t *activation_scales, uint8_t *weight, uint8_t *weight_scales, uint16_t *output_bf16, uint8_t *scratch_output_scales) {
    MX_CMD(7, 0, 0);
    MX_CMD(0, UINT64_C(114692), UINT64_C(1) << 48);
    MX_CMD(0, UINT64_C(1048833), UINT64_C(2048));
    MX_CMD(0, UINT64_C(1048841), UINT64_C(256));
    MX_CMD(0, 2, UINT64_C(512));
    for (int row = 0; row < 2; row++) {
        for (int chunk = 0; chunk < 2; chunk++) {
            for (int wave = 0; wave < 4; wave++) {
                do {
      MX_CMD(31, (uint64_t)(uintptr_t)((uint8_t *)activation_scales + ((wave * 2560) + (row * 80))), (uint64_t)(uintptr_t)((uint8_t *)weight_scales + ((wave * 4096) + (chunk * 128))));
      MX_CMD(32, UINT64_C(160), UINT64_C(256));
      MX_CMD(9, 0, UINT64_C(137439477765));
      MX_CMD(10, (uint64_t)(uintptr_t)((uint8_t *)activation + ((row * 163840) + (wave * 512))), (uint64_t)(uintptr_t)((uint8_t *)weight + ((wave * 131072) + (chunk * 128))));
      MX_CMD(11, 0, (((wave == 3) ? 1 : 0)) ? (uint64_t)(uintptr_t)((uint8_t *)output_bf16 + ((row * 40960) + (chunk * 256))) : 0);
      MX_CMD(12, UINT64_C(2048), UINT64_C(256));
      MX_CMD(13, 0, UINT64_C(256));
      MX_CMD(8, (UINT64_C(1) << 18) | ((uint64_t)(((((((row * 8) + (chunk * 4) + wave) % 2) + 2) % 2) + 1)) << 16) | (uint64_t)(((wave == 0) ? 0 : 1)), 0);
    } while (0);
            }
        }
    }
    
}

void grouped_issue_2(const void *activation, const void *activation_scales,
              const void *weight, const void *weight_scales,
              const void *output_bf16, const void *scratch_output_scales) {
  if (!activation || !activation_scales || !weight || !weight_scales ||
      !output_bf16 || !scratch_output_scales ||
      (((uintptr_t)activation_scales | (uintptr_t)weight_scales) & 7)) __builtin_trap();
  grouped_issue_2_scheduled((uint8_t *)activation, (uint8_t *)activation_scales,
                     (uint8_t *)weight, (uint8_t *)weight_scales,
                     (uint16_t *)output_bf16, (uint8_t *)scratch_output_scales);
}

extern const uint8_t weight0[];
extern const uint8_t scales0[];
extern const uint8_t weight1[];
extern const uint8_t scales1[];
extern const uint8_t weight2[];
extern const uint8_t scales2[];
extern unsigned char workspace[];
#define SCRATCH_OFFSET 819200u
void grouped(const uint8_t *packed, float *out0, float *out1, float *out2) {
  if (!packed || !out0 || !out1 || !out2) __builtin_trap();
  grouped_issue_0(packed,packed+327680u,weight0,scales0,workspace+0u,workspace+SCRATCH_OFFSET);
  grouped_issue_1(packed,packed+327680u,weight1,scales1,workspace+655360u,workspace+SCRATCH_OFFSET);
  grouped_issue_2(packed,packed+327680u,weight2,scales2,workspace+737280u,workspace+SCRATCH_OFFSET);
  MX_FENCE();
  for (uint32_t i=0; i<327680u; ++i) {
    union { uint32_t u; float f; } word;
    word.u=(uint32_t)((const uint16_t *)(workspace+0u))[i]<<16;
    out0[i]=word.f;
  }
  for (uint32_t i=0; i<40960u; ++i) {
    union { uint32_t u; float f; } word;
    word.u=(uint32_t)((const uint16_t *)(workspace+655360u))[i]<<16;
    out1[i]=word.f;
  }
  for (uint32_t i=0; i<40960u; ++i) {
    union { uint32_t u; float f; } word;
    word.u=(uint32_t)((const uint16_t *)(workspace+737280u))[i]<<16;
    out2[i]=word.f;
  }
}
