#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_rsqrt_f32_1_160_1_kernel_issue_160(const void *input, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)input + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)input + UINT64_C(256))), "r"(UINT64_C(0x0004001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000520000000000)), "r"(UINT64_C(0x0000000000000027)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0004001000002010)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_rsqrt_f32_1_160_1_kernel_a[160] __attribute__((aligned(64)));
static uint16_t mx_vpu_rsqrt_f32_1_160_1_kernel_c[160] __attribute__((aligned(64)));
static uint16_t mx_vpu_rsqrt_f32_1_160_1_kernel_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_rsqrt_f32_1_160_1_kernel_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_rsqrt_f32_1_160_1_kernel(const float *input, float *output) {
  if (!input || !output) __builtin_trap();
  for (uint32_t base = 0; base < 160; base += 160) {
    uint32_t count = 160 - base;
    if (count > 160) count = 160;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index)
      mx_vpu_rsqrt_f32_1_160_1_kernel_a[index] = index < count ? mx_vpu_rsqrt_f32_1_160_1_kernel_narrow(input[base + index]) : 1;
    const void *a = mx_vpu_rsqrt_f32_1_160_1_kernel_a, *c = mx_vpu_rsqrt_f32_1_160_1_kernel_c;
    switch (count) {
    case 160: mx_vpu_rsqrt_f32_1_160_1_kernel_issue_160(a, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      output[base + index] = mx_vpu_rsqrt_f32_1_160_1_kernel_widen(mx_vpu_rsqrt_f32_1_160_1_kernel_c[index]);
  }
}
