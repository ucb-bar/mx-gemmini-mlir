#include "vpu_ref.h"
void reference_norm(const float *x,const float *g,uint16_t *out) {
 for(unsigned row=0;row<160;row++) {
  uint16_t square[256][8],sum[1][8];
  for(unsigned j=0;j<2048;j++){uint16_t a=vpu_f_to_bf16(x[row*2048+j]);square[j/8][j%8]=vpu_mul(a,a);}
  vpu_ref_exec(VPU_RSUM,sum,square,0,256,256,0,0);
  uint16_t mean=vpu_mul(sum[0][0],vpu_rcp(vpu_f_to_bf16(2048.0f)));
  uint16_t inv=vpu_rsqrt(vpu_add(mean,vpu_f_to_bf16(1e-5f)));
  for(unsigned j=0;j<2048;j++)out[row*2048+j]=vpu_mul(vpu_mul(vpu_f_to_bf16(x[row*2048+j]),inv),vpu_f_to_bf16(g[j]));
 }
}
