#include <stdint.h>
#include <stdio.h>
#include "runtime_quant.h"
extern const float input[],gamma[];
extern const uint8_t expected[];
extern void mx_vpu_square_f32_1_160_2048_kernel(const void *,const void *);
extern void mx_vpu_rsum_1_160_2048_kernel(const void *,const void *);
extern void mx_vpu_div_f32_lf32_rf32_1_160_lhs_1_160_laxes_0_1_rhs_scalar_axes__kernel(const void *,const void *,const void *);
extern void mx_vpu_add_f32_lf32_rf32_1_160_1_lhs_1_160_1_laxes_0_1_2_rhs_scalar_axes__kernel(const void *,const void *,const void *);
extern void mx_vpu_rsqrt_f32_1_160_1_kernel(const void *,const void *);
extern void mx_vpu_mul_chain_f32_1_160_2048_inputs_1_160_2048_axes_0_1_2__1_160_1_axes_0_1_2__2048_axes_2_middle1_bf16_output_kernel(const float *,const float *,const float *,uint16_t *);
extern void fused(const float *,const float *,const float *,const float *,uint8_t *);
enum{N=160*2048,B=N*33/32};
static float square[N],sum[160],mean[160],added[160],inv[160];
static uint16_t norm[N];
static uint8_t output[B+128] __attribute__((aligned(64)));
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){float divisor=2048,epsilon=1e-5f;
 for(unsigned trial=0;trial<2;trial++)for(unsigned order=0;order<2;order++){
  unsigned role=trial^order;for(unsigned i=0;i<B+128;i++)output[i]=0xa5;
  uint64_t start=ticks();
  if(role)fused(input,gamma,&divisor,&epsilon,output+64);
  else{mx_vpu_square_f32_1_160_2048_kernel(input,square);
mx_vpu_rsum_1_160_2048_kernel(square,sum);
mx_vpu_div_f32_lf32_rf32_1_160_lhs_1_160_laxes_0_1_rhs_scalar_axes__kernel(sum,&divisor,mean);
mx_vpu_add_f32_lf32_rf32_1_160_1_lhs_1_160_1_laxes_0_1_2_rhs_scalar_axes__kernel(mean,&epsilon,added);
mx_vpu_rsqrt_f32_1_160_1_kernel(added,inv);
mx_vpu_mul_chain_f32_1_160_2048_inputs_1_160_2048_axes_0_1_2__1_160_1_axes_0_1_2__2048_axes_2_middle1_bf16_output_kernel(input,inv,gamma,norm);
   if(mx_pack_activation_bf16(norm,160,2048,8,output+64,output+64+N))return 2;}
  uint64_t cycles=ticks()-start;unsigned bad=0;
  for(unsigned i=0;i<B;i++)bad+=output[i+64]!=expected[i];
  for(unsigned i=0;i<64;i++)bad+=output[i]!=0xa5||output[i+B+64]!=0xa5;
  printf("RMS trial=%u role=%u cycles=%lu bad=%u checked=%u\n",trial,role,(unsigned long)cycles,bad,B);
  if(bad)return 1;
 }
 printf("RMS_DONE\n");return 0;}
