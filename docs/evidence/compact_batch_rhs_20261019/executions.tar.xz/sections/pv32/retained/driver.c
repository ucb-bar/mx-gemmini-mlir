#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void produce(const float *,const float *,float *);
void __attribute__((noreturn)) tohost_exit(uintptr_t);
static float a[5152],b[40992],out[2080] __attribute__((aligned(64)));
static unsigned run;
static float value(uint32_t u){union{float f;uint32_t u;}w;w.u=u;return w.f;}
static uint32_t bits(float f){union{float f;uint32_t u;}w;w.f=f;return w.u;}
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
static void dump(void){
 unsigned guard=0;
 for(unsigned i=0;i<16;++i)guard+=bits(a[i])!=0xa5a50000u||bits(a[5120+16+i])!=0xa5a50000u||bits(b[i])!=0xa5a50000u||bits(b[40960+16+i])!=0xa5a50000u||bits(out[i])!=0xa5a50000u||bits(out[2048+16+i])!=0xa5a50000u;
 for(unsigned i=0;i<2048;++i){if(i%16==0)printf("WORDS %u %u ",run,i);printf("%08x ",bits(out[16+i]));if(i%16==15||i==2047)printf("\n");}
 printf("STATUS run=%u guard=%u\n",run,guard);
}
uintptr_t handle_trap(uintptr_t cause,uintptr_t pc,uintptr_t regs[32]){
 (void)regs;dump();printf("TRAP cause=%lu pc=%lu\n",(unsigned long)cause,(unsigned long)pc);tohost_exit(77);
}
int main(void){
 for(run=0;run<3;++run){
  for(unsigned i=0;i<5152;++i)a[i]=value(0xa5a50000u);
  for(unsigned i=0;i<40992;++i)b[i]=value(0xa5a50000u);
  for(unsigned i=0;i<2080;++i)out[i]=value(0xa5a50000u);
  for(unsigned i=0;i<5120;++i)a[i+16]=((const float*)payload)[i];
  for(unsigned i=0;i<40960;++i)b[i+16]=((const float*)payload)[5120+(i/10240u)*81920u+i%10240u];
  if(!0)for(unsigned group=0;group<4;++group)if((run==1&&group==0)||(run==2&&group==1))for(unsigned r=0;r<1;++r)b[16+(group*1+r)*10240]=-b[16+(group*1+r)*10240];
  uint64_t t=cycle();produce(a+16,b+16,out+16);t=cycle()-t;
  printf("PERF run=%u cycles=%lu\n",run,(unsigned long)t);dump();
 }
 printf("DONE\n");return 0;
}
