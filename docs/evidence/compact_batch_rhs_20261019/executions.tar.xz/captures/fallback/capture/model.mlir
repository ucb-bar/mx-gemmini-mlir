builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/repeated_batch_materialized_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<6x19x37xf32>, %1: tensor<6x23x37xf32>) -> tensor<6x19x23xf32> {
    %2 = tensor.empty() : tensor<6x37x23xf32>
    %3 = linalg.transpose ins(%1:tensor<6x23x37xf32>) outs(%2:tensor<6x37x23xf32>) permutation = [0, 2, 1]
    %4 = arith.constant {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} 0.000000e+00 : f32
    %5 = tensor.splat %4 {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : tensor<6x19x23xf32>
    %6 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d3, d2)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%0, %3 : tensor<6x19x37xf32>, tensor<6x37x23xf32>) outs(%5 : tensor<6x19x23xf32>) attrs =  {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} {
    ^bb0(%7: f32, %8: f32, %9: f32):
      %10 = arith.mulf %7, %8 : f32
      %11 = arith.addf %9, %10 : f32
      linalg.yield %11 : f32
    } -> tensor<6x19x23xf32>
    func.return %6 : tensor<6x19x23xf32>
  }
}