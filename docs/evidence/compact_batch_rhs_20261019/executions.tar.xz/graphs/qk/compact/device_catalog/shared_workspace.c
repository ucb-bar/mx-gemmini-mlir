unsigned char mx_catalog_workspace[18816] __attribute__((aligned(64)));
