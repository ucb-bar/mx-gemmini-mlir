/* MX dense f32 adapter: FP8, qualified 16x160x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_0(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern unsigned char mx_catalog_workspace[];

static void mx_dense_kernel_0_repeated_rhs_8_compact_kernel_slice(const float *lhs, const float *rhs, float *out, unsigned prepare_weight) {
  if (!lhs || !rhs || !out) __builtin_trap();
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 0);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 1024);
  uint8_t *weight = (uint8_t *)(mx_catalog_workspace + 1088);
  uint8_t *weight_scales = (uint8_t *)(mx_catalog_workspace + 11328);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 11648);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 16768);
  if (mx_pack_activation_zero_rows_f32(lhs, 1u, 16u, 64u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      (prepare_weight && mx_pack_weight_f32(rhs, 64u, 160u, MX_RUNTIME_FP8,
                         weight, weight_scales))) __builtin_trap();
  mx_issue_0(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 1u; ++row)
    for (uint32_t col = 0; col < 160u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 160u + col] << 16;
      out[(size_t)row * 160u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void mx_dense_kernel_0_repeated_rhs_8_compact_kernel(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 32u; ++batch)
    mx_dense_kernel_0_repeated_rhs_8_compact_kernel_slice(lhs + batch * 1u * 64u,
                   rhs + (batch / 8u) * 64u * 160u,
                   out + batch * 1u * 160u, batch % 8u == 0u);
}
