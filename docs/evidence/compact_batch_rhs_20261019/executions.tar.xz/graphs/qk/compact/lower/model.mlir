"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<32x1x64xf32>, tensor<4x160x64xf32>) -> tensor<32x1x160xf32>}> ({
  ^bb0(%0: tensor<32x1x64xf32>, %1: tensor<4x160x64xf32>):
    %2 = "tensor.collapse_shape"(%1) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]]}> {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : (tensor<4x160x64xf32>) -> tensor<40960xf32>
    %3 = "tensor.expand_shape"(%2) <{reassociation = [[0 : i64, 1 : i64, 2 : i64, 3 : i64]], static_output_shape = array<i64: 4, 1, 160, 64>}> {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : (tensor<40960xf32>) -> tensor<4x1x160x64xf32>
    %4 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : () -> f32
    %5 = "tensor.splat"(%4) {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : (f32) -> tensor<32x1x160xf32>
    %6 = "tensor.collapse_shape"(%3) <{reassociation = [[0 : i64, 1 : i64, 2 : i64, 3 : i64]]}> : (tensor<4x1x160x64xf32>) -> tensor<40960xf32>
    %7 = "tensor.expand_shape"(%6) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 4, 160, 64>}> : (tensor<40960xf32>) -> tensor<4x160x64xf32>
    %8 = "tensor.empty"() : () -> tensor<4x64x160xf32>
    %9 = "linalg.transpose"(%7, %8) <{permutation = array<i64: 0, 2, 1>}> ({
    ^bb1(%10: f32, %11: f32):
      "linalg.yield"(%10) : (f32) -> ()
    }) : (tensor<4x160x64xf32>, tensor<4x64x160xf32>) -> tensor<4x64x160xf32>
    %12 = "func.call"(%0, %9, %5) <{callee = @mx_compact_repeated_rhs_0}> : (tensor<32x1x64xf32>, tensor<4x64x160xf32>, tensor<32x1x160xf32>) -> tensor<32x1x160xf32>
    "func.return"(%12) : (tensor<32x1x160xf32>) -> ()
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "mx_compact_repeated_rhs_0", function_type = (tensor<32x1x64xf32>, tensor<4x64x160xf32>, tensor<32x1x160xf32>) -> tensor<32x1x160xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {merlin.repeated_batch_input = "{\22argument\22: 1, \22compact_input\22: true, \22provider_obligation\22: \22original_results_rounding_effects_refusal_and_synchronous_private_preparation\22, \22repeat\22: 8}", llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<32x1x64xf32>, tensor<32x64x160xf32>, tensor<32x1x160xf32>) -> tensor<32x1x160xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/compact_batch_qk_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()