"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<6x19x37xf32>, tensor<6x23x37xf32>) -> tensor<6x19x23xf32>}> ({
  ^bb0(%0: tensor<6x19x37xf32>, %1: tensor<6x23x37xf32>):
    %2 = "tensor.empty"() : () -> tensor<6x37x23xf32>
    %3 = "linalg.transpose"(%1, %2) <{permutation = array<i64: 0, 2, 1>}> ({
    ^bb1(%4: f32, %5: f32):
      "linalg.yield"(%4) : (f32) -> ()
    }) : (tensor<6x23x37xf32>, tensor<6x37x23xf32>) -> tensor<6x37x23xf32>
    %6 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : () -> f32
    %7 = "tensor.splat"(%6) {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : (f32) -> tensor<6x19x23xf32>
    %8 = "func.call"(%0, %3, %7) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>
    "func.return"(%8) : (tensor<6x19x23xf32>) -> ()
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/repeated_batch_materialized_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()