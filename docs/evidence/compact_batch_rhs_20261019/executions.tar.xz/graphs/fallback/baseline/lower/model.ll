; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_6x19x23xf32 = private constant [6 x [19 x [23 x float]]] zeroinitializer, align 64

declare void @free(ptr)

declare ptr @malloc(i64)

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7, i64 %8, ptr %9, ptr %10, i64 %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, i64 %17, ptr %18, ptr %19, i64 %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26) {
  %28 = call ptr @malloc(i64 20488)
  %29 = ptrtoint ptr %28 to i64
  %30 = add i64 %29, 63
  %31 = urem i64 %30, 64
  %32 = sub i64 %30, %31
  %33 = inttoptr i64 %32 to ptr
  br label %34

34:                                               ; preds = %59, %27
  %35 = phi i64 [ %60, %59 ], [ 0, %27 ]
  %36 = icmp slt i64 %35, 6
  br i1 %36, label %37, label %61

37:                                               ; preds = %34
  br label %38

38:                                               ; preds = %57, %37
  %39 = phi i64 [ %58, %57 ], [ 0, %37 ]
  %40 = icmp slt i64 %39, 37
  br i1 %40, label %41, label %59

41:                                               ; preds = %38
  br label %42

42:                                               ; preds = %45, %41
  %43 = phi i64 [ %56, %45 ], [ 0, %41 ]
  %44 = icmp slt i64 %43, 23
  br i1 %44, label %45, label %57

45:                                               ; preds = %42
  %46 = mul nuw nsw i64 %35, 851
  %47 = mul nuw nsw i64 %43, 37
  %48 = add nuw nsw i64 %46, %47
  %49 = add nuw nsw i64 %48, %39
  %50 = getelementptr inbounds nuw float, ptr %10, i64 %49
  %51 = load float, ptr %50, align 4
  %52 = mul nuw nsw i64 %39, 23
  %53 = add nuw nsw i64 %46, %52
  %54 = add nuw nsw i64 %53, %43
  %55 = getelementptr inbounds nuw float, ptr %33, i64 %54
  store float %51, ptr %55, align 4
  %56 = add i64 %43, 1
  br label %42

57:                                               ; preds = %42
  %58 = add i64 %39, 1
  br label %38

59:                                               ; preds = %38
  %60 = add i64 %35, 1
  br label %34

61:                                               ; preds = %34
  %62 = call ptr @malloc(i64 10552)
  %63 = ptrtoint ptr %62 to i64
  %64 = add i64 %63, 63
  %65 = urem i64 %64, 64
  %66 = sub i64 %64, %65
  %67 = inttoptr i64 %66 to ptr
  %68 = call { ptr, ptr, i64, [3 x i64], [3 x i64] } @merlin_dev_mx_gemmini_0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7, i64 %8, ptr %28, ptr %33, i64 0, i64 6, i64 37, i64 23, i64 851, i64 23, i64 1, ptr %62, ptr %67, i64 0, i64 6, i64 19, i64 23, i64 437, i64 23, i64 1)
  %69 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %68, 3, 0
  %70 = mul i64 %69, 1
  %71 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %68, 3, 1
  %72 = mul i64 %70, %71
  %73 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %68, 3, 2
  %74 = mul i64 %72, %73
  %75 = mul i64 %74, 4
  %76 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %68, 1
  %77 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %68, 2
  %78 = getelementptr float, ptr %76, i64 %77
  %79 = getelementptr float, ptr %19, i64 %20
  call void @llvm.memcpy.p0.p0.i64(ptr %79, ptr %78, i64 %75, i1 false)
  call void @free(ptr %62)
  call void @free(ptr %28)
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1, ptr %2) {
  %4 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %0, align 8
  %5 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 0
  %6 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 1
  %7 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 2
  %8 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 3, 0
  %9 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 3, 1
  %10 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 3, 2
  %11 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 4, 0
  %12 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 4, 1
  %13 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 4, 2
  %14 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %1, align 8
  %15 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 0
  %16 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 1
  %17 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 2
  %18 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 3, 0
  %19 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 3, 1
  %20 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 3, 2
  %21 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 4, 0
  %22 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 4, 1
  %23 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 4, 2
  %24 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %2, align 8
  %25 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 0
  %26 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 1
  %27 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 2
  %28 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 3, 0
  %29 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 3, 1
  %30 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 3, 2
  %31 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 4, 0
  %32 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 4, 1
  %33 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 4, 2
  call void @forward(ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, i64 %20, i64 %21, i64 %22, i64 %23, ptr %25, ptr %26, i64 %27, i64 %28, i64 %29, i64 %30, i64 %31, i64 %32, i64 %33)
  ret void
}

define private { ptr, ptr, i64, [3 x i64], [3 x i64] } @merlin_dev_mx_gemmini_0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7, i64 %8, ptr %9, ptr %10, i64 %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, i64 %17, ptr %18, ptr %19, i64 %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26) {
  %28 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  %29 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } poison, ptr %0, 0
  %30 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %29, ptr %1, 1
  %31 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %30, i64 %2, 2
  %32 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %31, i64 %3, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %32, i64 %6, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %33, i64 %4, 3, 1
  %35 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %34, i64 %7, 4, 1
  %36 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %35, i64 %5, 3, 2
  %37 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %36, i64 %8, 4, 2
  %38 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [3 x i64], [3 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } poison, ptr %9, 0
  %40 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %39, ptr %10, 1
  %41 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %40, i64 %11, 2
  %42 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %41, i64 %12, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %42, i64 %15, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %43, i64 %13, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %44, i64 %16, 4, 1
  %46 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %45, i64 %14, 3, 2
  %47 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %46, i64 %17, 4, 2
  %48 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [3 x i64], [3 x i64] } %47, ptr %48, align 8
  %49 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } poison, ptr %18, 0
  %50 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %49, ptr %19, 1
  %51 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %50, i64 %20, 2
  %52 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %51, i64 %21, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %52, i64 %24, 4, 0
  %54 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %53, i64 %22, 3, 1
  %55 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %54, i64 %25, 4, 1
  %56 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %55, i64 %23, 3, 2
  %57 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %56, i64 %26, 4, 2
  %58 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [3 x i64], [3 x i64] } %57, ptr %58, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr %28, ptr %38, ptr %48, ptr %58)
  %59 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %28, align 8
  ret { ptr, ptr, i64, [3 x i64], [3 x i64] } %59
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr, ptr, ptr, ptr)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
