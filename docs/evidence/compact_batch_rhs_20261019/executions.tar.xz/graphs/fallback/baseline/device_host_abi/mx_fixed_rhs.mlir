builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/repeated_batch_materialized_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<6x19x37xf32>, %1: tensor<6x23x37xf32>) -> tensor<6x19x23xf32> {
    %2 = tensor.empty() : tensor<6x37x23xf32>
    %3 = linalg.transpose ins(%1:tensor<6x23x37xf32>) outs(%2:tensor<6x37x23xf32>) permutation = [0, 2, 1]
    %4 = arith.constant {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} 0.000000e+00 : f32
    %5 = tensor.splat %4 {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : tensor<6x19x23xf32>
    %6 = func.call @merlin_dev_mx_gemmini_0(%0, %3, %5) : (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>
    func.return %6 : tensor<6x19x23xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}