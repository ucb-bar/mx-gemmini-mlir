kernel mx_issue_6_schedule(activation: i8[25600] read, activation_scales: i8[800] read, weight: i8[10240] read, weight_scales: i8[320] read, output_bf16: i16[10240] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=160, nc=64, kt=32}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..5:
        native_loop(a=&activation[((row * 25600) + (wave * 32))], b=&weight[((wave * 2048) + (chunk * 64))], c=&output_bf16[((row * 20480) + (chunk * 128))], asc=&activation_scales[((wave * 160) + (row * 160))], bsc=&weight_scales[((wave * 64) + (chunk * 64))], write=select(wave == 4, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 5) + (chunk * 5) + wave), 2) + 1))
