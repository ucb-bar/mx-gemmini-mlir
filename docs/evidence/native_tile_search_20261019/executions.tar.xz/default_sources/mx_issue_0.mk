kernel mx_issue_0_schedule(activation: i8[327680] read, activation_scales: i8[10240] read, weight: i8[4194304] read, weight_scales: i8[131072] read, output_bf16: i16[327680] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=160, nc=64, kt=512}
  configure()
  for row in 0..1:
    for chunk in 0..32:
      for wave in 0..4:
        native_loop(a=&activation[((row * 327680) + (wave * 512))], b=&weight[((wave * 1048576) + (chunk * 64))], c=&output_bf16[((row * 655360) + (chunk * 128))], asc=&activation_scales[((wave * 2560) + (row * 160))], bsc=&weight_scales[((wave * 32768) + (chunk * 64))], write=select(wave == 3, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 128) + (chunk * 4) + wave), 2) + 1))
