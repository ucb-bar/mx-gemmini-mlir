kernel candidate_issue_schedule(activation: i8[327680] read, activation_scales: i8[10240] read, weight: i8[11534336] read, weight_scales: i8[360448] read, output_bf16: i16[901120] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=80, nc=128, kt=512}
  configure()
  for row in 0..2:
    for chunk in 0..44:
      for wave in 0..4:
        native_loop(a=&activation[((row * 163840) + (wave * 512))], b=&weight[((wave * 2883584) + (chunk * 128))], c=&output_bf16[((row * 901120) + (chunk * 256))], asc=&activation_scales[((wave * 2560) + (row * 80))], bsc=&weight_scales[((wave * 90112) + (chunk * 128))], write=select(wave == 3, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 176) + (chunk * 4) + wave), 2) + 1))
