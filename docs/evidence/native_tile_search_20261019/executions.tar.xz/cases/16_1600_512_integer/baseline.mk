kernel legacy_issue_schedule(activation: i8[8192] read, activation_scales: i8[256] read, weight: i8[819200] read, weight_scales: i8[25600] read, output_bf16: i16[25600] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=16, nc=64, kt=512}
  configure()
  for row in 0..1:
    for chunk in 0..25:
      for wave in 0..1:
        native_loop(a=&activation[((row * 8192) + (wave * 512))], b=&weight[((wave * 819200) + (chunk * 64))], c=&output_bf16[((row * 51200) + (chunk * 128))], asc=&activation_scales[((wave * 256) + (row * 16))], bsc=&weight_scales[((wave * 25600) + (chunk * 64))], write=select(wave == 0, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 25) + chunk + wave), 2) + 1))
