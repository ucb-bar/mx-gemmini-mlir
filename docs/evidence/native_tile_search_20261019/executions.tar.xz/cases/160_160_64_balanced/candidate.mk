kernel candidate_issue_schedule(activation: i8[10240] read, activation_scales: i8[320] read, weight: i8[10240] read, weight_scales: i8[320] read, output_bf16: i16[25600] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=80, nc=80, kt=64}
  configure()
  for row in 0..2:
    for chunk in 0..2:
      for wave in 0..1:
        native_loop(a=&activation[((row * 5120) + (wave * 64))], b=&weight[((wave * 10240) + (chunk * 80))], c=&output_bf16[((row * 25600) + (chunk * 160))], asc=&activation_scales[((wave * 320) + (row * 80))], bsc=&weight_scales[((wave * 320) + (chunk * 80))], write=select(wave == 0, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 2) + chunk + wave), 2) + 1))
