#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void legacy_issue(const void *,const void *,const void *,const void *,const void *,const void *);
void candidate_issue(const void *,const void *,const void *,const void *,const void *,const void *);
typedef void (*issuer)(const void *,const void *,const void *,const void *,const void *,const void *);
static uint16_t before[25664] __attribute__((aligned(64)));
static uint16_t after[25664] __attribute__((aligned(64)));
static uint8_t scratch[2048] __attribute__((aligned(64)));
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
__attribute__((noinline)) static uint64_t measure(issuer fn,uint16_t *out){
  uint64_t begin=cycle();
  fn(payload+0,payload+10240,payload+10560,payload+20800,out,scratch);
  return cycle()-begin;
}
int main(void){
  const uint16_t *gold=(const uint16_t *)(payload+21120);
  for(unsigned run=0;run<3;++run){
    for(unsigned i=0;i<25664;++i)before[i]=after[i]=0xa55a;
    uint64_t old,new;
    if(run&1){new=measure(candidate_issue,after+32);old=measure(legacy_issue,before+32);}
    else{old=measure(legacy_issue,before+32);new=measure(candidate_issue,after+32);}
    unsigned mismatch=0,oracle=0,guard=0;uint32_t hash=2166136261u;
    for(unsigned i=0;i<25600;++i){
      mismatch+=before[i+32]!=after[i+32];
      if(1)oracle+=before[i+32]!=gold[i] || after[i+32]!=gold[i];
      hash=(hash^before[i+32])*16777619u;
    }
    for(unsigned i=0;i<32;++i)guard+=before[i]!=0xa55a || after[i]!=0xa55a ||
      before[25600+32+i]!=0xa55a || after[25600+32+i]!=0xa55a;
    printf("TILE run=%u baseline=%lu candidate=%lu mismatch=%u oracle=%u guard=%u hash=%u\n",run,old,new,mismatch,oracle,guard,hash);
    if(mismatch || oracle || guard)return 3;
  }
  printf("DONE\n");return 0;
}
