kernel legacy_issue_schedule(activation: i8[163840] read, activation_scales: i8[5120] read, weight: i8[262144] read, weight_scales: i8[8192] read, output_bf16: i16[40960] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=160, nc=64, kt=512}
  configure()
  for row in 0..1:
    for chunk in 0..4:
      for wave in 0..2:
        native_loop(a=&activation[((row * 163840) + (wave * 512))], b=&weight[((wave * 131072) + (chunk * 64))], c=&output_bf16[((row * 81920) + (chunk * 128))], asc=&activation_scales[((wave * 2560) + (row * 160))], bsc=&weight_scales[((wave * 4096) + (chunk * 64))], write=select(wave == 1, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 8) + (chunk * 2) + wave), 2) + 1))
