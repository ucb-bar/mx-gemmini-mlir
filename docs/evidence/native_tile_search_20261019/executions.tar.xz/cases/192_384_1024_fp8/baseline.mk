kernel legacy_issue_schedule(activation: i8[196608] read, activation_scales: i8[6144] read, weight: i8[393216] read, weight_scales: i8[12288] read, output_bf16: i16[73728] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=192, nc=64, kt=512}
  configure()
  for row in 0..1:
    for chunk in 0..6:
      for wave in 0..2:
        native_loop(a=&activation[((row * 196608) + (wave * 512))], b=&weight[((wave * 196608) + (chunk * 64))], c=&output_bf16[((row * 147456) + (chunk * 128))], asc=&activation_scales[((wave * 3072) + (row * 192))], bsc=&weight_scales[((wave * 6144) + (chunk * 64))], write=select(wave == 1, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 12) + (chunk * 2) + wave), 2) + 1))
