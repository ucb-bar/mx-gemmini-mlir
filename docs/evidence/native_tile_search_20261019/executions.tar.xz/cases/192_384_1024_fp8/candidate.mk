kernel candidate_issue_schedule(activation: i8[196608] read, activation_scales: i8[6144] read, weight: i8[393216] read, weight_scales: i8[12288] read, output_bf16: i16[73728] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=96, nc=128, kt=512}
  configure()
  for row in 0..2:
    for chunk in 0..3:
      for wave in 0..2:
        native_loop(a=&activation[((row * 98304) + (wave * 512))], b=&weight[((wave * 196608) + (chunk * 128))], c=&output_bf16[((row * 73728) + (chunk * 256))], asc=&activation_scales[((wave * 3072) + (row * 96))], bsc=&weight_scales[((wave * 6144) + (chunk * 128))], write=select(wave == 1, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 6) + (chunk * 2) + wave), 2) + 1))
