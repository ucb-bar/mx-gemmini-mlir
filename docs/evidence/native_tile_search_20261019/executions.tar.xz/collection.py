from pathlib import Path
import hashlib,json,tarfile,io
from mx_gemmini_support.scheduled_native_issuer import emit_scheduled_native_issuer
from mx_gemmini_support.target_profile import load_profile
base=Path('../.tmp/mx_model_goal_20261018');out=Path('docs/evidence/native_tile_search_20261019');out.mkdir()
labels=['160_256_1024_integer','160_2048_2048_fp8','192_384_1024_fp8','160_160_64_integer','160_160_64_integer_reverse','16_1600_512_integer','160_160_64_balanced','160_160_64_balanced_reverse','160_2048_2048_fp8_reverse','192_384_1024_fp8_reverse','gate_full_shape','down_full_shape']
profile_path=Path('profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json');profile=load_profile(profile_path);files={};cases={}
def add(name,raw):assert name not in files;files[name]=raw
for label in labels:
 directory=base/('native_tiles_'+label);r=json.loads((directory/'receipt.json').read_text());assert r['exit_code']==0 and len(r['checks'])==3
 shape=tuple(r['shape_mnk']);policy=emit_scheduled_native_issuer(profile,shape,precision='FP8',symbol='candidate_issue',tile_policy='movement')
 baseline=emit_scheduled_native_issuer(profile,shape,precision='FP8',symbol='legacy_issue');assert baseline.issuer.source==(directory/'baseline.c').read_text()
 accepted=policy.chunks==tuple(r['schedules']['candidate']['tile_mnk'])
 if accepted:assert policy.issuer.source==(directory/'candidate.c').read_text()
 cases[label]={'accepted_by_current_policy':accepted,'policy':policy.issuer.plan['tile_selection']}
 for p in sorted(directory.rglob('*')):
  if p.is_file():add('cases/'+label+'/'+p.relative_to(directory).as_posix(),p.read_bytes())
for p in sorted((base/'native_tile_identity_sources').iterdir()):
 add('default_sources/'+p.name,p.read_bytes())
add('default_source_identity.json',(base/'native_tile_default_identity.json').read_bytes())
add('profile.json',profile_path.read_bytes());add('collection.py',Path(__file__).read_bytes())
add('tile_search.py',Path('../merlin/src/merlin/sched/tile_search.py').read_bytes());add('scheduled_native_issuer.py',Path('mx_gemmini_support/scheduled_native_issuer.py').read_bytes());add('qualify_native_tile_pair_spike.py',Path('tools/qualify_native_tile_pair_spike.py').read_bytes())
for name in ['native_tile_integrated_images_fixed.log','native_tile_dialect_integration.log','dso_reuse_debug.log']:
 add('checks/'+name,(base/name).read_bytes())
archive=out/'executions.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=9)as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest={'schema':'mx_gemmini.native_tile_evidence.v1','scope':'paired_encoded_issuer_sections_not_model_results','cases':cases,'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'members':{name:{'bytes':len(raw),'sha256':sha(raw)}for name,raw in sorted(files.items())},'elf_reader_sha256':sha(Path('docs/evidence/broadcast_multiply_20261019/verify.py').read_bytes())}
(out/'artifacts.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');print(len(files),'members',archive.stat().st_size,'bytes',flush=True)
