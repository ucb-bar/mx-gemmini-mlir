#include "llama_data.h"
#define RK_ROUND_QUANT_INPUTS 1
#define RK_PROFILE_PHASES 0
#define RK_STEPS 34u
#define RK_CAPACITY 97u
#define RK_SESSION_RECORDED 0
struct RkCheck { uint32_t address,bytes; };
#define RK_NCHECKS 2
static const struct RkCheck RK_CHECKS[] = {
{0u,69632u},
{1u,198656u},
};
#define RK_REGION1_BYTES 608256u
#define RK_REGION2_BYTES 608256u
#define RK_REGION3_BYTES 1998336u
