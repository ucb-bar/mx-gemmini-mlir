#include "llama_data.h"
#define RK_ROUND_QUANT_INPUTS 1
#define RK_PROFILE_PHASES 0
#define RK_STEPS 33u
#define RK_CAPACITY 160u
#define RK_SESSION_RECORDED 1
struct RkCheck { uint32_t address,bytes; };
#define RK_NCHECKS 2
static const struct RkCheck RK_CHECKS[] = {
{0u,4224000u},
{1u,7208960u},
};
#define RK_REGION1_BYTES 499580928u
#define RK_REGION2_BYTES 499580928u
#define RK_REGION3_BYTES 223561728u
