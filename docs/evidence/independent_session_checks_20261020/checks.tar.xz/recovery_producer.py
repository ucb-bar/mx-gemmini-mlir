"""Restore missing retained artifacts only when their original hashes match."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path.cwd()
BASE = ROOT.parent / '.tmp/mx_model_goal_20261018'
OUT = ROOT.parent / '.tmp/independent_sessions_20261020'
BIN = Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools/bin')
report_path = OUT/'cached_recovery.json'
report = json.loads(report_path.read_text()) if report_path.exists() else {'scope': 'restore_missing_files_to_original_hashes_not_new_measurements', 'actions': []}

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save():
    (OUT/'cached_recovery.json').write_text(json.dumps(report, indent=2)+'\n')

def record(target, expected, method):
    actual = sha(target)
    report['actions'].append(dict(path=str(target), expected_sha256=expected, actual_sha256=actual, method=method))
    save()
    if actual != expected: raise ValueError('restored artifact differs: '+str(target))
    print('restored',target,flush=True)

def share(source,target,expected):
    if target.exists():
        if sha(target) != expected: raise ValueError('existing artifact differs: '+str(target))
        return
    if sha(source) != expected: raise ValueError('donor differs: '+str(source))
    os.link(source,target)
    record(target,expected,'verified_donor_hardlink')

spec=importlib.util.spec_from_file_location('archive_reader',ROOT/'docs/evidence/cached_compact_rhs_session_20261019/verify.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
manifest,data=reader.assembled_members(ROOT/'docs/evidence/cached_compact_rhs_session_20261019')
runtime=ROOT.parent/'merlin/merlin/runtime/c'
cc=BIN/'riscv64-unknown-elf-gcc'
ld=BIN/'riscv64-unknown-elf-ld'
objcopy=BIN/'riscv64-unknown-elf-objcopy'
for role,label,stage in [('reference','rhs_reuse_shared','cached_decode_rhs_reuse_shared'),('candidate','compact_rhs_guarded','cached_decode_compact_rhs_guarded')]:
    linkdir=BASE/f'cached_session_{label}_link'
    link=json.loads((linkdir/'mx_session_link.json').read_text())
    build=BASE/stage
    model=build/'model.o'
    modelsha=link['stage_object_sha256']['decode']['model.o']
    if not model.exists():
        raw=data[f'{role}/stages/decode/model.o']
        if hashlib.sha256(raw).hexdigest()!=modelsha:raise ValueError('archive model differs')
        model.write_bytes(raw);record(model,modelsha,'hash_checked_portable_archive')
    catdir=build/'device_catalog'
    catalog=json.loads((catdir/'mx_catalog.json').read_text())
    const=catdir/'checkpoint_weights.o'
    share(BASE/'cached_prefill_latest/device_catalog/checkpoint_weights.o',const,catalog['packed_object_storage_reuse']['sha256'])
    # Missing large data files are identical across the source-bound stage catalogs.
    for kernel in catalog['kernels']:
        if not kernel.get('prepacked_checkpoint_weight'):continue
        for suffix in ('codes','scales'):
            name=kernel['symbol']+'_'+suffix+'.bin'
            target=catdir/name
            if not target.exists():
                share(BASE/'cached_prefill_latest/device_catalog'/name,target,kernel[suffix+'_sha256'])
    cat=catdir/'mx_catalog.o'
    if cat.exists() and sha(cat) != catalog['compilation']['object_sha256']:
        quarantined=OUT/f'catalog_{role}_incomplete_order_attempt1.o'
        if quarantined.exists():raise ValueError('prior mismatched catalog already retained')
        cat.rename(quarantined)
        report.setdefault('retained_failed_attempts',[]).append(str(quarantined));save()
    if not cat.exists():
        sources=[]
        for name,digest in catalog['compilation']['source_sha256'].items():
            source=catdir/(name+'.c')
            if source.is_file():
                if sha(source)!=digest:raise ValueError('catalog source changed '+name)
                if not source.with_suffix('.o').exists():raise ValueError('missing catalog code object '+name)
                sources.append(source)
        sources.sort(key=lambda p:p.stat().st_mtime_ns)
        objects=[p.with_suffix('.o') for p in sources]+[const]
        # A large generated shim source was also pruned. Its retained object
        # belongs immediately before runtime_quant in the frozen builder.
        shim=catdir/'shared_activation_shims.o'
        if shim not in objects and shim.exists():
            raw=data[f'{role}/stages/decode/device_catalog/shared_activation_shims.c']
            if hashlib.sha256(raw).hexdigest()!=catalog['compilation']['source_sha256']['shared_activation_shims']:
                raise ValueError('archived shim source differs')
            shim.with_suffix('.c').write_bytes(raw)
            objects.insert(objects.index(catdir/'runtime_quant.o'),shim)
        recorded=report.get('catalog_object_order_'+role)
        if report.get('passed') and recorded:
            if set(recorded)!={p.name for p in objects}:raise ValueError('recorded catalog object set differs')
            objects=[catdir/name for name in recorded]
        cmd=[str(ld),'-r','-o',str(cat),*map(str,objects)]
        report['catalog_object_order_'+role]=[p.name for p in objects];save()
        subprocess.run(cmd,check=True)
        record(cat,catalog['compilation']['object_sha256'],'link_retained_objects_in_original_source_creation_order')
    for namespace in sorted(linkdir.glob('stage_*_*.namespace.json')):
        ns=json.loads(namespace.read_text()); target=Path(ns['output']);source=Path(ns['source'])
        if target.exists():continue
        if sha(source)!=ns['source_sha256']:raise ValueError('namespace source differs')
        if not ns['renames']:
            share(source,target,ns['output_sha256'])
        else:
            mapping=OUT/(target.stem+'_'+role+'.symbols')
            mapping.write_text(''.join(f'{a} {b}\n' for a,b in ns['renames'].items()))
            subprocess.run([str(objcopy),'--redefine-syms',str(mapping),str(source),str(target)],check=True)
            record(target,ns['output_sha256'],'original_recorded_symbol_rewrite')
    recipes=[]
    for path in linkdir.glob('host_math/link_attempt_*/compilation_recipe.json'):
        value=json.loads(path.read_text())
        if value.get('executable',{}).get('sha256')==link['elf_sha256']:recipes.append(value)
    if len(recipes)!=1:raise ValueError('ambiguous original linker recipe')
    command=recipes[0]['commands'][-1]
    expected_inputs={r['path']:r['sha256'] for r in command['inputs']}
    weight=linkdir/'weights_blob.o'
    if not weight.exists():
        blobdir=linkdir/'shared_weights'
        share(Path(link['shared_weight_storage_source']),blobdir/'weights.bin',link['shared_weight_sha256'])
        subprocess.run([str(ld),'-r','-b','binary','-o',str(weight),'weights.bin'],cwd=blobdir,check=True)
        record(weight,expected_inputs[str(weight)],'original_binary_weight_object_command')
    adapter=linkdir/'adapter_1.o'
    if not adapter.exists():
        gen=linkdir/'generated/stage_1_decode'
        donor=BASE/'cached_session_latest_link/generated/stage_1_decode/model_io.h'
        header=gen/'model_io.h'
        if not header.exists():
            # Final object identity below is mandatory; donor text alone is insufficient.
            os.link(donor,header)
        flags=['-O2','-ffreestanding','-fno-builtin','-march=rv64gc','-mabi=lp64d','-mcmodel=medany']
        subprocess.run([str(cc),*flags,'-I',str(runtime),'-I',str(gen),'-c',str(gen/'stage_adapter.c'),'-o',str(adapter)],check=True)
        record(adapter,expected_inputs[str(adapter)],'compile_original_adapter_and_require_exact_object_hash')
    for path,digest in expected_inputs.items():
        if sha(path)!=digest:raise ValueError('final linker input differs '+path)
    elf=linkdir/'session.elf'
    if not elf.exists():
        with (OUT/f'cached_relink_{role}.log').open('wb') as log:
            subprocess.run(command['argv'],cwd=command['cwd'],check=True,stdout=log,stderr=subprocess.STDOUT)
        record(elf,link['elf_sha256'],'original_final_link_command_all_inputs_hash_checked')
report['passed']=True;save()
