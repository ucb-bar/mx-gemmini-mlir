"""Retain recurrent smoke evidence and fresh artifact checks with content deduplication."""
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT=Path.cwd()
BASE=ROOT.parent/'.tmp/independent_sessions_20261020'
DEST=ROOT/'docs/evidence/independent_session_checks_20261020'
DEST.mkdir(exist_ok=True)
files={}
if (DEST/'artifacts.json').is_file():
    previous=json.loads((DEST/'artifacts.json').read_text())
    raw=(DEST/'checks.tar.xz').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==previous['archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as archive:
        for entry in archive:
            assert entry.isfile();files[entry.name]=archive.extractfile(entry).read()
    for alias,original in previous['aliases'].items():files[alias]=files[original]
for label,name in [('port','cached_smoke2'),('replay','cached_smoke2_replay'),
                   ('gqa8_port','cached_gqa8_smoke2'),('gqa8_replay','cached_gqa8_smoke2_replay'),
                   ('logical_graph','cached_gqa8_graph1')]:
    for path in sorted((BASE/name).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            files[label+'/'+str(path.relative_to(BASE/name))]=path.read_bytes()
receipt=json.loads(files['port/receipt.json'])
source=ROOT.parent/'.tmp/stitched_baseline_20261019/radiance-latest-5866983682'
for name,digest in receipt['source_files_sha256'].items():
    raw=(source/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==digest
    files['radiance/'+name]=raw
for path,digest in receipt['startup_sha256'].items():
    raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest
    files['startup/'+Path(path).name]=raw
for name in ['forward_recomputed.json','forward_actual_payload.json','cached_recovery.json',
             'cached_restored_state_audit.json','smol_state_audit.json','smol_control_state_audit.json',
             'cached_restored_artifact_verify2.log','smol_artifact_verify.log',
             'regression_tests.log','state_regression_tests.log','all_recurrent_regressions.log',
             'forward_independent_weights.json','cached_prefill_independent_weights.json',
             'cached_decode_independent_weights.json','link_object_storage.json']:
    files['checks/'+name]=(BASE/name).read_bytes()
files['recovery_producer.py']=(BASE/'recover_cached_artifacts.py').read_bytes()
for directory in ['failed_catalog_delta','link_object_storage']:
    for path in sorted((BASE/directory).rglob('*')):
        if path.is_file():files[directory+'/'+str(path.relative_to(BASE/directory))]=path.read_bytes()
files['preflight/cached_port_receipt.json']=(BASE/'cached_tinyllama1/receipt.json').read_bytes()
for name in ['driver.c','radiance_rocket_llama.c','rocket_data.h','llama_data.h','data.S',
             'phases.bin','session_programs.bin','token_ids.bin','cos.bin','sin.bin',
             'producer.py','cached_producer.py','part1_storage.json','part1.prefix.xz','part1.suffix.xz']:
    files['preflight/'+name]=(BASE/'cached_tinyllama1'/name).read_bytes()
for name in ['replay_radiance_rocket_llama.py','replay_radiance_rocket_cached.py']:
    files['replay_helpers/'+name]=(ROOT/'tools'/name).read_bytes()
files['archive_producer.py']=Path(__file__).read_bytes()
unique={};members={};aliases={}
archive=DEST/'checks.tar.xz'
if archive.exists() and not (BASE/'checks_previous_verified.tar.xz').exists():
    os.link(archive,BASE/'checks_previous_verified.tar.xz')
    (BASE/'artifacts_previous_verified.json').write_bytes((DEST/'artifacts.json').read_bytes())
temporary=BASE/'checks.next.tar.xz'
if temporary.exists():raise ValueError('prior temporary archive must be retained or examined first')
with tarfile.open(temporary,'w:xz',preset=3) as output:
    for name,raw in sorted(files.items()):
        digest=hashlib.sha256(raw).hexdigest()
        members[name]={'bytes':len(raw),'sha256':digest}
        if digest in unique:
            aliases[name]=unique[digest]
            continue
        unique[digest]=name
        entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;entry.mtime=0
        output.addfile(entry,io.BytesIO(raw))
manifest={'schema':'mx_gemmini.independent_session_checks_archive.v1',
          'archive_sha256':hashlib.sha256(temporary.read_bytes()).hexdigest(),
          'archive_bytes':temporary.stat().st_size,'members':members,'aliases':aliases,
          'stored_members':len(unique),'logical_members':len(members),
          'scope':'exact_recurrent_source_smoke_and_independent_checks_of_existing_full_runs_not_new_full_session_speedups'}
manifest_temp=BASE/'artifacts.next.json'
manifest_temp.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
os.replace(temporary,archive)
os.replace(manifest_temp,DEST/'artifacts.json')
print({key:manifest[key] for key in ('archive_bytes','stored_members','logical_members')})
