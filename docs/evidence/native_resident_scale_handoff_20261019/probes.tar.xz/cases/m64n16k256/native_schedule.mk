kernel native_issue_schedule(activation: i8[16384] read, activation_scales: i8[512] read, weight: i8[4096] read, weight_scales: i8[128] read, output_bf16: i16[1024] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=64, nc=16, kt=32}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..8:
        native_loop(a=&activation[((row * 16384) + (wave * 32))], b=&weight[((wave * 512) + (chunk * 16))], c=&output_bf16[((row * 2048) + (chunk * 32))], asc=&activation_scales[((wave * 64) + (row * 64))], bsc=&weight_scales[((wave * 16) + (chunk * 16))], write=select(wave == 7, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 8) + (chunk * 8) + wave), 2) + 1))
