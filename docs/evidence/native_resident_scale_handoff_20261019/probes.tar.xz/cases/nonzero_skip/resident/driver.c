#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void native_issue(const void *,const void *,const void *,const void *,const void *,const void *);
void epilogue(const void *,const void *);
static uint16_t matrix[1088] __attribute__((aligned(64)));
static uint16_t output[1088] __attribute__((aligned(64)));
static uint8_t scratch[2048] __attribute__((aligned(64)));
static uint8_t zero[64] __attribute__((aligned(64)));
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
__attribute__((noinline)) static unsigned invoke(unsigned index,const void *a,const void *asc,
    const void *b,const void *bsc,const uint16_t *golden){
  for(unsigned i=0;i<1088;++i)matrix[i]=output[i]=0xa55a;
  uint64_t begin=cycle();
  native_issue(a,asc,b,bsc,matrix+32,scratch);
  epilogue(zero,output+32);
  uint64_t elapsed=cycle()-begin;
  unsigned mismatch=0,guard=0;
  for(unsigned i=0;i<1024;++i)mismatch+=output[i+32]!=golden[i];
  for(unsigned i=0;i<32;++i)guard+=matrix[i]!=0xa55a || output[i]!=0xa55a ||
    matrix[1056+i]!=0xa55a || output[1056+i]!=0xa55a;
  printf("PROBE run=%u cycles=%lu mismatch=%u guard=%u\n",index,elapsed,mismatch,guard);
  printf("WORDS run=%u ",index);
  for(unsigned i=0;i<1024;++i)printf("%04x",output[i+32]);
  printf("\n");
  return mismatch+guard;
}
int main(void){unsigned errors=0;
  errors += invoke(0, payload+0, payload+2048,
      payload+2112, payload+4160, (const uint16_t *)(payload+4224));
  errors += invoke(1, payload+6272, payload+8320,
      payload+8384, payload+10432, (const uint16_t *)(payload+10496));
  errors += invoke(2, payload+12544, payload+14592,
      payload+14656, payload+16704, (const uint16_t *)(payload+16768));
  printf("DONE errors=%u\n",errors);return errors!=0;
}
