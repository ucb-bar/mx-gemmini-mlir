kernel native_issue_schedule(activation: i8[1024] read, activation_scales: i8[32] read, weight: i8[4096] read, weight_scales: i8[128] read, output_bf16: i16[1024] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=16, nc=64, kt=32}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..2:
        native_loop(a=&activation[((row * 1024) + (wave * 32))], b=&weight[((wave * 2048) + (chunk * 64))], c=&output_bf16[((row * 2048) + (chunk * 128))], asc=&activation_scales[((wave * 16) + (row * 16))], bsc=&weight_scales[((wave * 64) + (chunk * 64))], write=select(wave == 1, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 2) + (chunk * 2) + wave), 2) + 1))
