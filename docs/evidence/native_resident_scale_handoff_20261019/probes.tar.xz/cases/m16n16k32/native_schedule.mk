kernel native_issue_schedule(activation: i8[512] read, activation_scales: i8[16] read, weight: i8[512] read, weight_scales: i8[16] read, output_bf16: i16[256] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=16, nc=16, kt=32}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..1:
        native_loop(a=&activation[((row * 512) + (wave * 32))], b=&weight[((wave * 512) + (chunk * 16))], c=&output_bf16[((row * 512) + (chunk * 32))], asc=&activation_scales[((wave * 16) + (row * 16))], bsc=&weight_scales[((wave * 16) + (chunk * 16))], write=select(wave == 0, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod((row + chunk + wave), 2) + 1))
