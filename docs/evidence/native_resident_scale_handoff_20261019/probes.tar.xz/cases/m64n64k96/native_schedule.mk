kernel native_issue_schedule(activation: i8[6144] read, activation_scales: i8[192] read, weight: i8[6144] read, weight_scales: i8[192] read, output_bf16: i16[4096] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=64, nc=64, kt=32}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..3:
        native_loop(a=&activation[((row * 6144) + (wave * 32))], b=&weight[((wave * 2048) + (chunk * 64))], c=&output_bf16[((row * 8192) + (chunk * 128))], asc=&activation_scales[((wave * 64) + (row * 64))], bsc=&weight_scales[((wave * 64) + (chunk * 64))], write=select(wave == 2, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 3) + (chunk * 3) + wave), 2) + 1))
