#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void native_issue(const void *,const void *,const void *,const void *,const void *,const void *);
void epilogue(const void *,const void *);
static uint16_t matrix[4160] __attribute__((aligned(64)));
static uint16_t output[4160] __attribute__((aligned(64)));
static uint8_t scratch[2048] __attribute__((aligned(64)));
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
__attribute__((noinline)) static unsigned invoke(unsigned index,const void *a,const void *asc,
    const void *b,const void *bsc,const uint16_t *golden){
  for(unsigned i=0;i<4160;++i)matrix[i]=output[i]=0xa55a;
  uint64_t begin=cycle();
  native_issue(a,asc,b,bsc,matrix+32,scratch);
  epilogue(matrix+32,output+32);
  uint64_t elapsed=cycle()-begin;
  unsigned mismatch=0,guard=0;
  for(unsigned i=0;i<4096;++i)mismatch+=output[i+32]!=golden[i];
  for(unsigned i=0;i<32;++i)guard+=matrix[i]!=0xa55a || output[i]!=0xa55a ||
    matrix[4128+i]!=0xa55a || output[4128+i]!=0xa55a;
  printf("PROBE run=%u cycles=%lu mismatch=%u guard=%u\n",index,elapsed,mismatch,guard);
  printf("WORDS run=%u ",index);
  for(unsigned i=0;i<4096;++i)printf("%04x",output[i+32]);
  printf("\n");
  return mismatch+guard;
}
int main(void){unsigned errors=0;
  errors += invoke(0, payload+0, payload+6144,
      payload+6336, payload+12480, (const uint16_t *)(payload+12672));
  errors += invoke(1, payload+20864, payload+27008,
      payload+27200, payload+33344, (const uint16_t *)(payload+33536));
  errors += invoke(2, payload+41728, payload+47872,
      payload+48064, payload+54208, (const uint16_t *)(payload+54400));
  printf("DONE errors=%u\n",errors);return errors!=0;
}
