kernel native_issue_schedule(activation: i8[2048] read, activation_scales: i8[64] read, weight: i8[2048] read, weight_scales: i8[64] read, output_bf16: i16[1024] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=32, nc=32, kt=32}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..2:
        native_loop(a=&activation[((row * 2048) + (wave * 32))], b=&weight[((wave * 1024) + (chunk * 32))], c=&output_bf16[((row * 2048) + (chunk * 64))], asc=&activation_scales[((wave * 32) + (row * 32))], bsc=&weight_scales[((wave * 32) + (chunk * 32))], write=select(wave == 1, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 2) + (chunk * 2) + wave), 2) + 1))
