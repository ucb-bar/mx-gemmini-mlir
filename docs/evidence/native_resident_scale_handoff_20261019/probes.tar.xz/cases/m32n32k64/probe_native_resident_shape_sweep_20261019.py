"""Unpromoted native matrix -> scratchpad -> scalar VPU feasibility experiment.

Two independent images; finite integer inputs and an independent BF16 oracle.
This grants neither hardware qualification nor a generic compiler rewrite.
"""

import hashlib
import json
import os
import subprocess
from pathlib import Path

import numpy as np

from mx_gemmini_support.command_ir import Fence, emit_c, vpu_command
from mx_gemmini_support.physical_program import _cmd, _config_ld, _config_st, _regular_schedule_steps, _transfer_rect
from mx_gemmini_support.planned_runtime_issuer import emit_planned_runtime_issuer
from mx_gemmini_support.scheduled_native_issuer import emit_scheduled_native_issuer
from mx_gemmini_support.target_profile import load_profile, profile_sha256

ROOT = Path.cwd()
BASE = ROOT.parent / '.tmp/mx_model_goal_20261018'
M, N, K = map(int, os.environ['MX_EPILOGUE_PROBE_MNK'].split(','))
assert M % 16 == N % 16 == K % 32 == 0 and min(M, N, K) > 0
assert max(M, N) <= 64 and K <= 256
COUNT, ROWS = M * N, M * N // 8
OUT = BASE / os.environ['MX_EPILOGUE_PROBE_DIR']
OUT.mkdir(exist_ok=False)
PROFILE = ROOT / 'profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json'
RISCV = Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools')
STARTUP = Path('/scratch/agustin/projects/chipyard/generators/gemmini/software/gemmini-rocc-tests/riscv-tests/benchmarks/common')
EXTENSION = ROOT / 'docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so'
profile = load_profile(PROFILE)
scalar_bits = 0x3f8d
scalar = np.array([scalar_bits << 16], dtype='<u4').view('<f4')[0]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bf16(values):
    words = np.asarray(values, dtype='<f4').view('<u4')
    return ((words + np.uint32(0x7fff) + ((words >> 16) & 1)) >> 16).astype('<u2')


def run(command, directory, label, environment=None):
    result = subprocess.run(list(map(str, command)), cwd=directory, env=environment,
                            capture_output=True, timeout=180, check=False)
    (directory / (label + '.log')).write_bytes(result.stdout + result.stderr)
    commands.append({'argv': list(map(str, command)), 'exit_code': result.returncode, 'log': label + '.log'})
    if result.returncode:
        raise RuntimeError(f'{directory.name}/{label} failed: {result.returncode}')
    return result


rng = np.random.default_rng(351953)
payload, offsets = bytearray(), []
for index in range(3):
    a = rng.integers(0, 2, (M, K), dtype=np.int8) * 2 - 1
    b = rng.integers(0, 2, (K, N), dtype=np.int8) * 2 - 1
    a[0] = 1 if index != 1 else -1
    b[:, 0] = 1
    if index == 2:
        a[1] = 1
        b[:, 1] = -1
    raw = (a.astype(np.int32) @ b.astype(np.int32)).astype('<f4')
    matrix = bf16(raw)
    golden = bf16((matrix.astype('<u4') << 16).view('<f4') * scalar)
    row = {}
    for name, data in [('a', np.where(a > 0, 0x38, 0xb8).astype('u1')),
                       ('asc', np.full((K // 32, M), 127, 'u1')),
                       ('b', np.where(b > 0, 0x38, 0xb8).astype('u1')),
                       ('bsc', np.full((K // 32, N), 127, 'u1')), ('golden', golden)]:
        payload.extend(bytes((-len(payload)) % 64))
        row[name] = len(payload)
        payload.extend(data.tobytes())
        np.save(OUT / f'{name}_{index}.npy', data)
    offsets.append(row)
(OUT / 'payload.bin').write_bytes(payload)
schedule = emit_scheduled_native_issuer(profile, (M, N, K), precision='FP8',
                                         symbol='native_issue', tile_mnk=(M, N, 32))
(OUT / 'native_schedule.mk').write_text(schedule.text)
(OUT / 'profile.json').write_text(json.dumps(profile, indent=2, sort_keys=True) + '\n')
(OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
reports, commands = {}, []
for role in ['baseline', 'resident']:
    directory = OUT / role
    directory.mkdir()
    native = schedule.issuer.source
    if role == 'resident':
        lines = native.splitlines()
        selected = [i for i, line in enumerate(lines) if 'MX_CMD(11, 0,' in line]
        assert len(selected) == 1
        lines[selected[0]] = '      MX_CMD(11, 0, 0); /* Preserve native compute; no DRAM C store. */'
        native = '\n'.join(lines) + '\n'
    if role == 'manual_resident':
        planned = emit_planned_runtime_issuer(profile, (32,32,64), (32,32,32), precision='FP8', symbol='native_issue')
        plan = planned.plan
        vector_ops = [('vpu', dict(kind='muls', src1_row=plan['c_spad_dest'], src2_row=0,
                                  dst_row=plan['c_spad_dest'], rows=plan['c_rows'], immediate_bf16=scalar_bits))]
        steps = _regular_schedule_steps(profile, 'FP8', (32,32,64), (32,32,32), plan,
                                         planned.buffer_bytes, quant_output=False, matrix_quant_output=False,
                                         vector_requant=False, vector_ops=vector_ops, mode='spike_serial')
        native = emit_c([s.command for s in steps], transport='rocket_rocc',
                        buffers=tuple(planned.buffer_bytes), symbol='native_issue')
        commands_to_issue = []
    elif role == 'resident':
        # One output tile, K/32 waves. Accumulator 0 retained by C==0.
        # K=0 prevents the simulator's raw path from repeating the multiply.
        # RTL skips LOAD_A/B/D and EX, stores accumulator to scratchpad row0.
        commands_to_issue = [_cmd(9, 0, ((N // 16) << 16) | (M // 16)), _cmd(8, 1, 0x278), Fence()]
    else:
        commands_to_issue = [_config_ld(16)]
        commands_to_issue.extend(_transfer_rect(2, 'matrix', start * 16, start, rows=16)
                                 for start in range(0, ROWS, 16))
        commands_to_issue.append(Fence())
    if role != 'manual_resident':
        commands_to_issue.extend([
        vpu_command(profile, kind='muls', src1_row=0, src2_row=0,
                    dst_row=0, rows=ROWS, immediate_bf16=scalar_bits), Fence(),
        _config_st(16),
        ])
        commands_to_issue.extend(_transfer_rect(3, 'result', start * 16, start, rows=16)
                                 for start in range(0, ROWS, 16))
        commands_to_issue.append(Fence())
    if role == 'resident':
        # After completion/readout, unmanaged configs release both managed halves.
        # Next native loop installs its own scales and dimensions.
        commands_to_issue.extend([_cmd(26, 0, 1),
                                  _cmd(26, (1 << 60) | (1 << 61), 1), Fence()])
    (directory / 'native.c').write_text(native)
    epilogue = emit_c(commands_to_issue, transport='rocket_rocc', buffers=('matrix', 'result'), symbol='epilogue')
    (directory / 'epilogue.c').write_text(epilogue)
    calls = '\n'.join(f'''  errors += invoke({index}, payload+{row['a']}, payload+{row['asc']},
      payload+{row['b']}, payload+{row['bsc']}, (const uint16_t *)(payload+{row['golden']}));'''
                      for index, row in enumerate(offsets))
    driver = '''#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void native_issue(const void *,const void *,const void *,const void *,const void *,const void *);
void epilogue(const void *,const void *);
static uint16_t matrix[1088] __attribute__((aligned(64)));
static uint16_t output[1088] __attribute__((aligned(64)));
static uint8_t scratch[2048] __attribute__((aligned(64)));
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
__attribute__((noinline)) static unsigned invoke(unsigned index,const void *a,const void *asc,
    const void *b,const void *bsc,const uint16_t *golden){
  for(unsigned i=0;i<1088;++i)matrix[i]=output[i]=0xa55a;
  uint64_t begin=cycle();
  native_issue(a,asc,b,bsc,matrix+32,scratch);
  epilogue(matrix+32,output+32);
  uint64_t elapsed=cycle()-begin;
  unsigned mismatch=0,guard=0;
  for(unsigned i=0;i<1024;++i)mismatch+=output[i+32]!=golden[i];
  for(unsigned i=0;i<32;++i)guard+=matrix[i]!=0xa55a || output[i]!=0xa55a ||
    matrix[1056+i]!=0xa55a || output[1056+i]!=0xa55a;
  printf("PROBE run=%u cycles=%lu mismatch=%u guard=%u\\n",index,elapsed,mismatch,guard);
  printf("WORDS run=%u ",index);
  for(unsigned i=0;i<1024;++i)printf("%04x",output[i+32]);
  printf("\\n");
  return mismatch+guard;
}
int main(void){unsigned errors=0;
''' + calls + '\n  printf("DONE errors=%u\\n",errors);return errors!=0;\n}\n'
    if role == 'manual_resident':
        driver = driver.replace('native_issue(a,asc,b,bsc,matrix+32,scratch);',
                                'native_issue(a,asc,b,bsc,output+32,scratch);')
    driver = (driver.replace('1088', str(COUNT + 64)).replace('1056', str(COUNT + 32))
              .replace('1024', str(COUNT)))
    (directory / 'driver.c').write_text(driver)
    (directory / 'payload.S').write_text('.section .rodata\n.balign 64\n.global payload\npayload:\n.incbin "../payload.bin"\n')
    cc = RISCV / 'bin/riscv64-unknown-elf-gcc'
    flags = ['-DPREALLOCATE=1', '-DMULTITHREAD=1', '-DBAREMETAL=1', '-mcmodel=medany', '-O2',
             '-ffreestanding', '-fno-fast-math', '-ffp-contract=off', '-fno-common', '-fno-builtin',
             '-fno-tree-loop-distribute-patterns', '-march=rv64gc', '-mabi=lp64d',
             '-I', str(STARTUP), '-I', str(STARTUP.parent.parent), '-I', str(STARTUP.parent.parent / 'env')]
    objects = []
    for index, path in enumerate([directory / 'native.c', directory / 'epilogue.c', directory / 'driver.c',
                                  directory / 'payload.S', *sorted(STARTUP.glob('*.c')), *sorted(STARTUP.glob('*.S'))]):
        obj = directory / f'part{index}.o'
        run([cc, *flags, '-c', path, '-o', obj], directory, f'compile{index}')
        objects.append(obj)
    elf = directory / 'section.elf'
    run([cc, '-nostdlib', '-nostartfiles', '-static', '-T', STARTUP / 'test.ld', *objects,
         '-lm', '-lgcc', '-o', elf], directory, 'link')
    from merlin.llvmlower.device_build import DeviceRouting, admit_linked_device_elf, freeze_device_elf_admission
    from merlin.model_check.admission import service
    route = DeviceRouting(device='mx_gemmini', package_dir=ROOT, operand_dtype='f32',
                          accum_dtype='bf16', linked_elf_admission=service('mx_gemmini'))
    admission = admit_linked_device_elf(route, freeze_device_elf_admission(route), elf=elf,
                                       linked_sha256=sha(elf), directory=directory)
    command = [RISCV / 'bin/spike', '--isa=rv64gc_zicntr', '--extlib=' + str(EXTENSION), '--extension=gemmini', elf]
    environment = os.environ | {'GEMMINI_MODE': 'both', 'GEMMINI_PERF_CONFIG': 'e4m3_vpu',
                                'GEMMINI_PERF_SET': 'mem.host_tracking=0', 'GEMMINI_PERF_OUT': str(directory / 'perf.txt')}
    (directory / 'invocation.json').write_text(json.dumps({'command': list(map(str, command)),
        'environment': {k:v for k,v in environment.items() if k.startswith('GEMMINI_')},
        'admission': admission}, indent=2) + '\n')
    result = run(command, directory, 'spike', environment)
    lines = result.stdout.decode().splitlines()
    rows = [dict(item.split('=') for item in line.split()[1:]) for line in lines if line.startswith('PROBE ')]
    values = [bytes.fromhex(line.split()[-1]) for line in lines if line.startswith('WORDS ')]
    assert lines.count('DONE errors=0') == 1 and len(rows) == len(values) == 3
    assert all(int(row['mismatch']) == int(row['guard']) == 0 for row in rows)
    for index, raw in enumerate(values):
        expected = np.load(OUT / f'golden_{index}.npy', allow_pickle=False)
        assert raw == expected.astype('>u2').tobytes()
    perf = (directory / 'perf.txt').read_text().splitlines()
    first, mesh, traffic = [line.split() for line in perf[:3]]
    counters = {'commands': int(first[3]), 'loops': int(first[5]), 'fences': int(first[7]),
                'mesh_tiles': int(mesh[1]), 'mesh_busy': int(mesh[3]), 'vpu_commands': int(mesh[7]),
                'load_bytes': int(traffic[1]), 'scale_bytes': int(traffic[traffic.index('scales:') + 1])}
    model_deadlock = 'gemmini perf: MODEL DEADLOCK' in (directory / 'spike.log').read_text()
    work_complete = not model_deadlock and all(counters[k] == v for k,v in {
        'loops': 3 * (K // 32 + int(role == 'resident')),
        'mesh_tiles': 3 * (M // 16) * (N // 16) * (K // 16),
        'mesh_busy': 48 * (M // 16) * (N // 16) * (K // 16),
        'vpu_commands': 3, 'scale_bytes': 3 * (M + N) * (K // 32)}.items())
    reports[role] = {'rows': rows, 'full_words_sha256': [hashlib.sha256(raw).hexdigest() for raw in values],
                     'elf_sha256': sha(elf), 'elf_bytes': elf.stat().st_size, 'counters': counters,
                     'model_deadlock': model_deadlock, 'timing_work_complete': work_complete,
                     'performance_qualification': 'incomplete_work_counters_refuse_cycle_comparison' if not work_complete else 'section_counters_complete_not_full_model_qualification'}
    print(role, rows, flush=True)
assert reports['baseline']['full_words_sha256'] == reports['resident']['full_words_sha256']
assert reports['baseline']['timing_work_complete'] and reports['resident']['timing_work_complete']
report = {'schema': 'mx_gemmini.native_resident_epilogue_probe.v1',
          'scope': 'finite_integer_native_section_only; no full-model, exceptional-value or hardware qualification',
          'profile_sha256': profile_sha256(profile), 'extension_sha256': sha(EXTENSION),
          'shape_mnk': [M,N,K], 'native_tile_mnk': [M,N,32], 'scalar_bf16': scalar_bits,
          'reports': reports, 'commands': commands,
          'source_manifest_sha256': sha(BASE / 'resident_epilogue_source_study_20261019/source_manifest.json')}
(OUT / 'result.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print('PASS: two independent images, three changing inputs, all BF16 words per image match independent oracle and guards.')
print(json.dumps({role: {k:v for k,v in r.items() if k not in ['rows','full_words_sha256']} for role,r in reports.items()}, sort_keys=True))
