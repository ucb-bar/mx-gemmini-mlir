"""Freeze actual probes, timing-source study and completed-log audit."""
import datetime
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT.parent / '.tmp/mx_model_goal_20261018'
OUT = ROOT / 'docs/evidence/native_resident_scale_handoff_20261019'
OUT.mkdir(exist_ok=True)
files, origins = {}, {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def add(path, name):
    path = Path(path)
    assert path.is_file() and not path.is_symlink() and name not in files
    files[name] = path.read_bytes()
    origins[name] = str(path.resolve())


cases = {
    'nonzero_skip': 'native_resident_epilogue_probe_nonzero_skip_20261019',
    'zero_compute': 'native_resident_epilogue_probe_zero_compute_20261019',
    'release_two_fences': 'native_resident_epilogue_probe_scale_release_v2_20261019',
    'm16n16k32': 'native_resident_scale_handoff_m16n16k32_v3_20261019',
    'm16n64k64': 'native_resident_scale_handoff_m16n64k64_20261019',
    'm32n32k64': 'native_resident_scale_handoff_m32n32k64_20261019',
    'm64n16k256': 'native_resident_scale_handoff_m64n16k256_20261019',
    'm64n64k96': 'native_resident_scale_handoff_m64n64k96_20261019',
}
failures = {
    'report_key_error': ('native_resident_epilogue_probe_scale_release_20261019', 'probe_native_resident_scale_release_20261019.log'),
    'fixed_count_wrong_shape': ('native_resident_scale_handoff_m16n16k32_20261019', 'probe_native_resident_scale_handoff_m16n16k32_20261019.log'),
    'payload_offset_substitution': ('native_resident_scale_handoff_m16n16k32_v2_20261019', 'probe_native_resident_scale_handoff_m16n16k32_v2_20261019.log'),
    'payload_offset_diagnostic': ('native_resident_scale_handoff_m16_diagnostic_20261019', 'probe_native_resident_scale_handoff_m16_diagnostic_20261019.log'),
}
for label, directory in cases.items():
    for path in sorted((BASE / directory).rglob('*')):
        if path.is_file():
            assert '__pycache__' not in path.parts
            add(path, f'cases/{label}/' + str(path.relative_to(BASE / directory)))
for label, (directory, log) in failures.items():
    for path in sorted((BASE / directory).rglob('*')):
        if path.is_file():
            add(path, f'harness_failures/{label}/' + str(path.relative_to(BASE / directory)))
    add(BASE / log, f'harness_failures/{label}/runner.log')

study = BASE / 'resident_epilogue_source_study_20261019'
old = json.loads((study / 'source_manifest.json').read_text())
new = dict(schema='mx_gemmini.resident_timing_source_study.v1', observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
           libgemmini_gitlink_revision=old['libgemmini_gitlink_revision'], profile_sha256=old['profile_sha256'],
           source_to_existing_extension_binary_equivalence='not_established_by_this_retrieval',
           scope='pinned public source study; actual admitted native probes separately qualify this binary', sources={})
for name, remote, cache in [
    ('gemmini_perf.cc', 'gemmini_perf.cc', 'gemmini-perf'),
    ('perf_model.cc', 'perf/model.cc', 'perf-model-cc'),
    ('perf_model.h', 'perf/model.h', 'perf-model-h'),
    ('perf_scale_loader.cc', 'perf/lsu/scale_loader.cc', 'scale-loader'),
    ('perf_loop_matmul.cc', 'perf/control/loop_matmul.cc', 'loop-matmul'),
]:
    raw = (study / name).read_bytes()
    cached = json.loads((ROOT.parent / f'.tmp/.firecrawl/mx-266c593-{cache}.json').read_text())
    assert cached['markdown'].encode() == raw
    new['sources'][name] = dict(url=f"https://raw.githubusercontent.com/ucb-bar/libgemmini/{old['libgemmini_gitlink_revision']}/{remote}",
                               bytes=len(raw), sha256=sha(raw), firecrawl_text_byte_identical=True)
(study / 'timing_source_manifest.json').write_text(json.dumps(new, indent=2, sort_keys=True) + '\n')
for name in ['source_manifest.json', 'timing_source_manifest.json', *old['sources'], *new['sources']]:
    add(study / name, 'source_study/' + name)
for name in ['command_ir.py', 'physical_program.py', 'planned_runtime_issuer.py', 'scheduled_native_issuer.py', 'target_profile.py', 'spike_timing.py']:
    add(ROOT / 'mx_gemmini_support' / name, 'frozen_target/' + name)
for name in ['run_linked_merlin_session.py', 'build_merlin_stage.py', 'compare_linked_session_cycles.py', 'compare_matched_tinyllama_forward.py', 'qualify_native_tile_pair_spike.py']:
    add(ROOT / 'tools' / name, 'frozen_tools/' + name)
for name in ['test_run_linked_merlin_session.py', 'test_build_merlin_stage.py', 'test_compare_linked_session_cycles.py', 'test_matched_forward_boundary.py']:
    add(ROOT / 'tests' / name, 'frozen_tests/' + name)
add(BASE / 'timing_deadlock_gate_tests_committed_20261019.log', 'checks/focused_tests.log')
add(BASE / 'completed_timing_deadlock_audit_v2_20261019.json', 'audit/completed_log_audit.json')
add(BASE / 'audit_completed_spike_timing_20261019.py', 'audit/audit_completed.py')
audit = json.loads(files['audit/completed_log_audit.json'])
for row in audit['rows']:
    add(BASE / row['receipt'], 'audit/receipts/' + row['receipt'])
    assert sha(files['audit/receipts/' + row['receipt']]) == row['receipt_sha256']
startup = Path('/scratch/agustin/projects/chipyard/generators/gemmini/software/gemmini-rocc-tests/riscv-tests/benchmarks/common')
for path in sorted(startup.iterdir()):
    if path.is_file() and path.suffix in {'.c', '.h', '.S', '.ld'}:
        add(path, 'startup/' + path.name)
add(Path(__file__), 'collector.py')
metadata = dict(schema='mx_gemmini.native_resident_scale_handoff_archive.v1',
                scope='finite integer native sections and rejected timing probes; no production resident rewrite, complete-model resident gain, exceptional-value or hardware qualification',
                cases=cases, harness_failures=failures,
                target_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                extension_sha256=sha((ROOT / 'docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so').read_bytes()),
                tool_versions={}, source_revisions={})
for label, directory in [('mx', ROOT), ('merlin', ROOT.parent / 'merlin'), ('model2mlir', ROOT.parent / 'model2mlir')]:
    metadata['source_revisions'][label] = subprocess.check_output(['git', '-C', str(directory), 'rev-parse', 'HEAD'], text=True).strip()
for label, path in [('gcc', '/scratch/agustin/projects/chipyard/.conda-env/riscv-tools/bin/riscv64-unknown-elf-gcc'),
                    ('spike', '/scratch/agustin/projects/chipyard/.conda-env/riscv-tools/bin/spike'),
                    ('readelf', '/scratch/agustin/projects/oscar-merlin/third_party/llvm-install/bin/llvm-readelf')]:
    raw = Path(path).read_bytes()
    metadata['tool_versions'][label] = dict(path=path, bytes=len(raw), sha256=sha(raw))
files['metadata.json'] = (json.dumps(metadata, indent=2, sort_keys=True) + '\n').encode()
blob = io.BytesIO()
with tarfile.open(fileobj=blob, mode='w:xz', preset=6) as archive:
    for name, raw in sorted(files.items()):
        entry = tarfile.TarInfo(name)
        entry.size, entry.mtime, entry.mode = len(raw), 0, 0o644
        archive.addfile(entry, io.BytesIO(raw))
raw = blob.getvalue()
(OUT / 'probes.tar.xz').write_bytes(raw)
manifest = dict(schema='mx_gemmini.native_resident_scale_handoff_archive_manifest.v1',
                archive_bytes=len(raw), archive_sha256=sha(raw),
                members={name: dict(bytes=len(value), sha256=sha(value)) for name, value in sorted(files.items())}, origins=origins)
(OUT / 'artifacts.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print('ARCHIVED', len(files), 'files,', len(raw), 'compressed bytes')
