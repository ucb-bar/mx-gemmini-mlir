"""Scan actual retained completed receipts; absence is not work-completeness proof."""
import argparse
import hashlib
import json
from pathlib import Path

from mx_gemmini_support.spike_timing import reject_deadlocked_timing


def audit(root):
    root = root.resolve(strict=True)
    rows = []
    for pattern, kind in [('mx_stage_probe.json', 'complete_stage'),
                          ('mx_session_run.json', 'complete_session')]:
        for receipt in sorted(root.rglob(pattern)):
            raw = receipt.read_bytes()
            data = json.loads(raw)
            if kind == 'complete_stage':
                spike = data.get('spike') or {}
                selected = spike.get('done') is True and spike.get('exit_code') == 0
            else:
                selected = (data.get('complete') is True and data.get('exit_code') == 0
                            and data.get('timing_model_active') is True)
            if not selected:
                continue
            console = receipt.parent / 'spike.log'
            content = console.read_bytes()
            digest = hashlib.sha256(content).hexdigest()
            if kind == 'complete_session' and digest != data['log_sha256']:
                raise ValueError(f'changed receipt-bound log: {console}')
            reject_deadlocked_timing(content.decode())
            rows.append(dict(kind=kind, receipt=str(receipt.relative_to(root)),
                             receipt_sha256=hashlib.sha256(raw).hexdigest(),
                             console=str(console.relative_to(root)), bytes=len(content),
                             sha256=digest))
    return dict(schema='mx_gemmini.completed_timing_deadlock_audit.v2',
                scope='all task-retained completed stage and timing-session receipts with actual logs; absence of explicit diagnostic only, not a new arithmetic/cycle completeness proof',
                stage_count=sum(r['kind'] == 'complete_stage' for r in rows),
                session_count=sum(r['kind'] == 'complete_session' for r in rows), rows=rows)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('output must be fresh')
    report = audit(args.build_root)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print('PASS:', report['stage_count'], 'stage logs and', report['session_count'], 'session logs')
