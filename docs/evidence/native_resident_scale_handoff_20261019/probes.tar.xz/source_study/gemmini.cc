#include "gemmini.h"
#include "mx_fp_math.h"
#include "../gemmini-rocc-tests/include/vpu_ref.h"   // bit-exact VPU reference (shared with the tests)
#include <riscv/mmu.h>
#include <riscv/trap.h>
#include <stdexcept>
#include <iostream>
#include <assert.h>
#include <math.h>
#include <cfloat>
#include <array>
#include <vector>

using namespace std;

// DIM=16 builds register as "gemmini" (libgemmini.so); DIM=32 builds register as
// "gemmini_dim32" (libgemmini_dim32.so) so both meshes coexist as spike extensions.
#if GEMMINI_DIM == 32
REGISTER_EXTENSION(gemmini_dim32, []() { return new gemmini_t; })
#elif GEMMINI_DIM == 8
REGISTER_EXTENSION(gemmini_dim8, []() { return new gemmini_t; })
#else
REGISTER_EXTENSION(gemmini, []() { return new gemmini_t; })
#endif

#define dprintf(...) { if (p->get_log_commits_enabled()) printf(__VA_ARGS__); }

void gemmini_state_t::reset()
{
  enable = true;
  // mode = OS;
  // sys_act = NONE;
  // acc_act = NONE;
  // sys_shift = 0;
  // output_sp_addr = 0;
  // load_stride = DIM * sizeof(elem_t);
  // store_stride = DIM * sizeof(elem_t);
  // pool_stride = 0;
  // load_shrunk = false;

  spad.clear();
  spad.resize(sp_matrices*DIM, std::vector<elem_t>(DIM, 0));

  pe_state.clear();
  pe_state.resize(DIM, std::vector<acc_t>(DIM));

  accumulator.clear();
  accumulator.resize(accum_rows, std::vector<acc_t>(DIM, 0));

  // cisc reset
  a_addr = b_addr = c_addr = d_addr = 0;
  m = n = k = 0;
  repeating_bias = false;

  // Norm reset
  for (int i = 0; i < NORM_STAT_IDS; i++) norm_reset[i] = true;

  // Dummy counter reset
  snapshot_enable = false;
  op_in_progress = false;

  mx_act_fmt = 0;
  mx_wgt_fmt = 0;
  mx_out_fmt = 0;
  mx_use_lut = 0;
  mx_lut_en = 0;   // G1: runtime LUT-usage flag (set by MX_LOAD_LUT, cleared by MX_LUT_DISABLE)
  mx_lut_a_loaded = 0; mx_lut_b_loaded = 0;   // per-operand quad (deproject) flags
  mx_scale_dram = 0;
  mx_tiles_I = mx_tiles_J = mx_tiles_K = 0;
  mx_scale_act_sel = mx_scale_wgt_sel = 0;
  mx_sc_ci = mx_sc_cj = mx_sc_ck = 0;
  mx_lut_update_granularity = 0;
  mx_loop_a_spad = mx_loop_b_spad = mx_loop_c_spad = 0;
  mx_loop_skips = 0;
  mx_loop_spad_marker = false;
  mx_loop_reuse_tiled = false;
  mx_loop_scale_resident = false;
  mx_scales_used = false;
  loop_ws_A_sc = loop_ws_B_sc = loop_ws_A_sc_stride = loop_ws_B_sc_stride = 0;
  mx_loop_slot = 0;
  for (int i = 0; i < 2; i++) {
    mx_slot_a_start[i] = (uint32_t)(i * (BANK_NUM * BANK_ROWS) / 2);
    mx_slot_b_end[i] = (uint32_t)((i + 1) * (BANK_NUM * BANK_ROWS) / 2);
  }
  mx_asc_valid[0] = mx_asc_valid[1] = false;
  mx_dram_C = mx_dram_C_stride = 0;
  mx_dram_out = false;
  mx_scale_a_mem.clear(); mx_scale_a_mem.resize(8192, 0x7f);
  mx_scale_b_mem.clear(); mx_scale_b_mem.resize(8192, 0x7f);
  mx_smem.clear(); mx_smem.resize(sp_matrices * DIM * 16, 0);
  mx_lut_a.clear(); mx_lut_a.resize(2048 * 16, 0);
  mx_lut_b.clear(); mx_lut_b.resize(2048 * 16, 0);
  mx_lut_c.clear(); mx_lut_c.resize(2048 * 16, 0);

  resetted = true;

  printf("Gemmini extension configured with:\n");
  printf("    dim = %u\n", DIM);
}

void gemmini_t::reset() {
  gemmini_state.reset();
  perf.reset();
}

template <class T>
T gemmini_t::read_from_dram(reg_t addr) {
  T value = 0;
  for (size_t byte_idx = 0; byte_idx < sizeof(T); ++byte_idx) {
    value |= p->get_mmu()->load<uint8_t>(addr + byte_idx) << (byte_idx*8);
  }
  return value;
}

template <class T>
std::vector<std::vector<T>> *
matrix_zeroes(reg_t rows, reg_t cols) {
  return new std::vector<std::vector<T>>(rows, std::vector<T>(cols, 0));
}

template <class T>
std::vector<std::vector<T>> *
gemmini_t::read_matrix_from_dram(reg_t addr, reg_t rows, reg_t cols,
                                  bool zeroable, bool repeating_bias) {
  // Read and return Matrix of size `rows*cols` from address `addr` in main
  // memory

  // Initialize to all zeroes
  auto result = matrix_zeroes<T>(rows, cols);

  // if an input matrix is at addr 0, it is NULL, so don't do anything with
  // it only the D matrix is zeroable; the A, B matrices must be valid
  if(addr == 0) {
    if(zeroable) {
      return result;
    }
    printf("ERROR: non-zeroable matrix given address zero!\n");
    exit(1);
  }

  // Load from memory
  for (size_t i = 0; i < rows; i++) {
    auto ii = repeating_bias ? 0 : i;
    auto const dram_row_addr = addr + ii*sizeof(T)*cols;
    for (size_t j = 0; j < cols; j++) {
      auto const dram_byte_addr = dram_row_addr + j*sizeof(T);
#ifdef ELEM_T_IS_FLOAT
      result->at(i).at(j) = elem_t_bits_to_elem_t(gemmini_t::read_from_dram<elem_t_bits>(dram_byte_addr));
#else
      result->at(i).at(j) = gemmini_t::read_from_dram<elem_t>(dram_byte_addr);
#endif
    }
  }
  return result;
}

template <class T>
void gemmini_t::write_to_dram(reg_t addr, T data) {
  for (size_t byte_idx = 0; byte_idx < sizeof(T); ++byte_idx) {
    p->get_mmu()->store<uint8_t>(addr + byte_idx, (data >> (byte_idx*8)) & 0xFF);
  }
}

// Move a gemmini block from DRAM at dram_addr (byte addr) to
// the scratchpad/accumulator at sp_addr (gemmini-row addressed)
void gemmini_t::mvin(reg_t dram_addr, reg_t sp_addr, int state_id) {
  bool const accumulator = (sp_addr >> 31) & 0x1;
  bool const accumulate = (sp_addr >> 30) & 0x1;
  auto const base_row_addr = (sp_addr & 0x1FFFFFFF); // Strip accumulator addressing bits [31:29]
  auto const cols = (sp_addr >> addr_len) & 0xFFFF;
  auto const rows = (sp_addr >> (addr_len + 16)) & 0xFFFF;

  bool is_zeros = dram_addr == 0;

  auto const load_stride = gemmini_state.load_strides[state_id];
  auto const load_block_stride = gemmini_state.load_block_strides[state_id];
  auto const load_shrunk = gemmini_state.load_shrunks[state_id];
#if defined(HAS_MVIN_SCALE) || defined(HAS_MVIN_ACC_SCALE)
  auto const load_scale = gemmini_state.load_scales[state_id];
#endif
  auto const pixels_per_row = gemmini_state.pixels_per_rows[state_id];

  dprintf("GEMMINI: mvin - 0x%02lx cols and 0x%02lx rows from 0x%08lx to addr 0x%08lx\n", cols, rows, dram_addr, sp_addr & 0xFFFFFFFF);

  for (size_t row = 0; row < rows; ++row) {
    auto const dram_row_addr = dram_addr + row*load_stride;

    for (size_t col = 0; col < cols; ++col) {
      const size_t block = col / DIM;
      const size_t spad_col = col % DIM;
      const size_t spad_row = base_row_addr + row + block*load_block_stride;

      for (size_t pixel = 0; pixel < pixels_per_row && pixel <= spad_row; pixel++) {

        if (accumulator) {
            auto const dram_byte_addr = dram_row_addr + col *
              (load_shrunk ? sizeof(elem_t) : sizeof(acc_t));

            acc_t value;
            if (is_zeros) {
              value = 0;
            } else if (!load_shrunk) {
#ifdef ELEM_T_IS_FLOAT
              value = acc_t_bits_to_acc_t(read_from_dram<acc_t_bits>(dram_byte_addr));
#else
              value = read_from_dram<acc_t>(dram_byte_addr);
#endif

#ifdef HAS_MVIN_ACC_SCALE
              value = mvin_scale_acc(value, load_scale);
#endif
            } else {
#ifdef ELEM_T_IS_FLOAT
              value = elem_t_bits_to_elem_t(read_from_dram<elem_t_bits>(dram_byte_addr));
#else
              value = read_from_dram<elem_t>(dram_byte_addr);
#endif

#ifdef HAS_MVIN_SCALE
              value = mvin_scale(value, load_scale);
#endif
            }

            if (accumulate) {
              gemmini_state.accumulator.at(spad_row - pixel).at(spad_col + pixel*cols) += value;
            } else {
              gemmini_state.accumulator.at(spad_row - pixel).at(spad_col + pixel*cols) = value;
            }

#ifdef ELEM_T_IS_FLOAT
            dprintf("%f ", gemmini_state.accumulator.at(spad_row).at(spad_col));
#else
            dprintf("%d ", gemmini_state.accumulator.at(spad_row).at(spad_col));
#endif
        } else {
            auto const dram_byte_addr = dram_row_addr + col*sizeof(elem_t);

            elem_t value;
            if (is_zeros) {
              value = 0;
            } else {
#ifdef ELEM_T_IS_FLOAT
              value = elem_t_bits_to_elem_t(read_from_dram<elem_t_bits>(dram_byte_addr));
#else
              value = read_from_dram<elem_t>(dram_byte_addr);
#endif

#ifdef HAS_MVIN_SCALE
              value = mvin_scale(value, load_scale);
#endif
            }

            gemmini_state.spad.at(spad_row - pixel).at(spad_col + pixel * cols) = value;

#ifdef ELEM_T_IS_FLOAT
            dprintf("%f ", gemmini_state.spad.at(spad_row).at(spad_col));
#else
            dprintf("%d", gemmini_state.spad.at(spad_row).at(spad_col));
#endif
        }
      }
    }
    dprintf("\n");
  }
}

void gemmini_t::mvout(reg_t dram_addr, reg_t sp_addr) {
  bool const accumulator = (sp_addr >> 31) & 0x1;
  bool const full = (sp_addr >> 29) & 0x1;
  auto const norm_cmd = static_cast<gemmini_state_t::NormCmd>((sp_addr >> 26) & 0x7);
  auto const base_row_addr = (sp_addr & 0x3FFFFFF); // Strip accumulator addressing bits [31:26]
  auto const cols = (sp_addr >> addr_len) & 0xFFFF;
  auto const rows = (sp_addr >> (addr_len + 16)) & 0xFFFF;

  const int block_stride = DIM;

  dprintf("GEMMINI: mvout - 0x%02lx cols and 0x%02lx rows from 0x%08lx to addr 0x%08lx\n", cols, rows, sp_addr, dram_addr);

  if (gemmini_state.pool_stride == 0) {
    for (size_t i = 0; i < rows; ++i) {
      auto const dram_row_addr = dram_addr + i*gemmini_state.store_stride;

      bool should_write = true;
      for (size_t j = 0; j < cols; j += DIM) {
        const size_t block = j / DIM;
        const size_t spad_row = base_row_addr + block*block_stride + i;
        const size_t len = cols - j > DIM ? DIM : cols - j;

        const bool is_last = j + DIM >= cols;
        const auto n_cmd = is_last ? norm_cmd : non_terminating_norm_cmd(norm_cmd);

        // Norm is an accumulator-path feature; only read the accumulator for accumulator mvouts.
        // (Scratchpad mvouts of large MX outputs address rows beyond accum_rows -> avoid OOB.)
        if (accumulator) {
          should_write = apply_norm(
              &gemmini_state.accumulator.at(spad_row).at(0),
              len, n_cmd);
        }
      }

      if (!should_write)
        continue;

      for (size_t j = 0; j < cols; ++j) {
        const size_t block = j / DIM;
        const size_t spad_col = j % DIM;
        const size_t spad_row = base_row_addr + block*block_stride + i;

        if (accumulator) { // Apply shift and activation when moving out of accumulator
          acc_t acc_value = gemmini_state.accumulator.at(spad_row).at(spad_col);
          acc_value = apply_pre_activation_acc(acc_value);

          auto shifted = acc_scale(acc_value, gemmini_state.acc_shift);
          elem_t activated = apply_activation_acc(shifted); // Activation is always applied in either WS/OS mode

          auto const sizeof_output = full ? sizeof(acc_t) : sizeof(elem_t);

          auto const dram_byte_addr = dram_row_addr + j*sizeof_output;
#ifdef ELEM_T_IS_FLOAT
          if (full) {
            write_to_dram<acc_t_bits>(dram_byte_addr, acc_t_to_acc_t_bits(acc_value));
            dprintf("%f ", acc_value);
          } else {
            write_to_dram<elem_t_bits>(dram_byte_addr, elem_t_to_elem_t_bits(activated));
            dprintf("%f ", activated);
          }
#else
          if (full) {
            write_to_dram<acc_t>(dram_byte_addr, acc_value);
            dprintf("%d ", acc_value);
          } else {
            write_to_dram<elem_t>(dram_byte_addr, activated);
            dprintf("%d ", activated);
          }
#endif

        } else { // Scratchpad, write to DRAM directly
          auto const dram_byte_addr = dram_row_addr + j*sizeof(elem_t);
          elem_t value = gemmini_state.spad.at(spad_row).at(spad_col);

#ifdef ELEM_T_IS_FLOAT
          write_to_dram<elem_t_bits>(dram_byte_addr, elem_t_to_elem_t_bits(value));
          dprintf("%f ", value);
#else
          write_to_dram<elem_t>(dram_byte_addr, value);
          dprintf("%d ", value);
#endif
        }
      }
      dprintf("\n");
    }

  } else {

    // Perform pooling
    auto const pool_stride = gemmini_state.pool_stride;
    auto const pool_size = gemmini_state.pool_size;
    auto const pool_out_dim = gemmini_state.pool_out_dim;
    auto const porows = gemmini_state.pool_porows;
    auto const pocols = gemmini_state.pool_pocols;
    auto const orows = gemmini_state.pool_orows;
    auto const ocols = gemmini_state.pool_ocols;
    auto const plpad = gemmini_state.pool_lpad;
    auto const pupad = gemmini_state.pool_upad;
    auto const channels = cols;

    for (int porow = 0; porow < porows; porow++) {
      for (int pocol = 0; pocol < pocols; pocol++) {
        for (int poch = 0; poch < (int)channels; poch++) {
          elem_t value = elem_t_min;

          for (int wrow = 0; wrow < pool_size; wrow++) {
            for (int wcol = 0; wcol < pool_size; wcol++) {

              const int orow = porow * pool_stride + wrow - pupad;
              const int ocol = pocol * pool_stride + wcol - plpad;

              const int row_addr = base_row_addr + orow*ocols + ocol;

              elem_t elem;

              if (orow < 0 || ocol < 0 || orow >= orows || ocol >= ocols) {
                elem = 0;
              } else if (accumulator) {
                acc_t acc_value = gemmini_state.accumulator.at(row_addr).at(poch);
                auto shifted = acc_scale(acc_value, gemmini_state.acc_shift);
                elem = apply_activation_acc(shifted); // Activation is always applied in either WS/OS mode
              } else {
                elem = gemmini_state.spad.at(row_addr).at(poch);
              }

              if (elem > value) {
                value = elem;
              }
            }
          }

          auto const dram_byte_addr = dram_addr + (porow * pool_out_dim + pocol) * gemmini_state.store_stride + poch * sizeof(elem_t);

#ifdef ELEM_T_IS_FLOAT
          write_to_dram<elem_t_bits>(dram_byte_addr, elem_t_to_elem_t_bits(value));
#else
          write_to_dram<elem_t>(dram_byte_addr, value);
#endif
        }
      }
    }
  }
}

void gemmini_t::preload(reg_t bd_addr, reg_t c_addr) {
  // TODO: rename these state variables
  gemmini_state.preload_sp_addr = static_cast<uint32_t>(bd_addr & 0xFFFFFFFF);
  gemmini_state.output_sp_addr = static_cast<uint32_t>(c_addr & 0xFFFFFFFF);

  gemmini_state.preload_cols = (bd_addr >> addr_len) & 0xFFFF;
  gemmini_state.preload_rows = (bd_addr >> (addr_len + 16)) & 0xFFFF;
  gemmini_state.output_cols = (c_addr >> addr_len) & 0xFFFF;
  gemmini_state.output_rows = (c_addr >> (addr_len + 16)) & 0xFFFF;

  dprintf("GEMMINI: preload - scratchpad output addr = 0x%08x, scratchpad preload addr = 0x%08x\n",
            gemmini_state.output_sp_addr, gemmini_state.preload_sp_addr);
}

void gemmini_t::config(reg_t rs1, reg_t rs2) {
  if ((rs1 & 0b11) == 0) { // rs1[1:0] == 2'b00, config_ex, configure execute pipeline
    gemmini_state_t::Dataflow new_mode;
    gemmini_state_t::Activation new_act;
    reg_t new_sys_shift, new_sys_acc_shift, new_c_stride, new_a_stride, new_a_transpose, new_b_transpose;

    auto rs1_2 = (rs1 >> 2) & 0b1; // extract rs1[2], 0 = output stationary, 1 = weight stationary
    if (rs1_2 == 0) {
      new_mode = gemmini_state_t::OS;
    } else {
      new_mode = gemmini_state_t::WS;
    }

    auto rs1_4_3 = (rs1 >> 3) & 0b11; // extract rs1[4:3], 0 = no activation, 1 = ReLU, 2 = ReLU6
    if (rs1_4_3 == 0) {
      if (static_cast<int>(gemmini_state.acc_act) != 4) {
        new_act = gemmini_state_t::NONE;
      } else {
        new_act = gemmini_state_t::SOFTMAX;
      }
    } else if (rs1_4_3 == 1) {
      new_act = gemmini_state_t::RELU;
    } else if (rs1_4_3 == 2) {
      new_act = gemmini_state_t::LAYERNORM;
    } else if (rs1_4_3 == 3) {
      new_act = gemmini_state_t::IGELU;
    } else {
      assert(false);
    }

    new_sys_shift = (rs2) & 0xFFFFFFFF;
    new_sys_acc_shift = (rs1 >> 32) & 0xFFFFFFFF;
    new_c_stride = (rs2 >> 48) & 0xFFFF;
    new_a_stride = (rs1 >> 16) & 0xFFFF;
    new_a_transpose = (rs1 >> 8) & 0x1;
    new_b_transpose = (rs1 >> 9) & 0x1;

    const bool set_only_strides = (rs1 >> 7) & 0x1;

    dprintf("GEMMINI: config_ex - set dataflow mode from %d to %d\n", gemmini_state.mode, new_mode);
    dprintf("GEMMINI: config_ex - set activation function from %d to %d\n", gemmini_state.sys_act, new_act);
    dprintf("GEMMINI: config_ex - set sys_shift from %lu to %lu\n", gemmini_state.sys_shift, new_sys_shift);

    // assert(new_acc_shift >= 0 && new_acc_shift < sizeof(acc_t)*8);
    assert(new_sys_shift >= 0 && new_sys_shift < sizeof(output_t)*8);

    if (!set_only_strides) {
      gemmini_state.mode = new_mode;
      gemmini_state.sys_act = new_act;
      gemmini_state.sys_shift = new_sys_shift;
      gemmini_state.sys_acc_shift = new_sys_acc_shift;
      gemmini_state.a_transpose = new_a_transpose;
      gemmini_state.b_transpose = new_b_transpose;
    }

    gemmini_state.c_stride = new_c_stride;
    gemmini_state.a_stride = new_a_stride;

    if (!set_only_strides) {
      gemmini_state.mx_use_lut = (rs1 >> 5) & 0x1;
      gemmini_state.mx_fp8_altfmt = (rs1 >> 6) & 0x1;   // activation (and output) sub-format alt select
      // Per-operand weight altfmt: rs1 bit 31 XORs the activation altfmt (0 = same sub-format, default).
      gemmini_state.mx_wgt_altfmt = ((rs1 >> 6) & 0x1) ^ ((rs1 >> 31) & 0x1);
      gemmini_state.mx_act_fmt = (rs1 >> 10) & 0x3;
      gemmini_state.mx_wgt_fmt = (rs1 >> 12) & 0x3;
      gemmini_state.mx_out_fmt = (rs1 >> 14) & 0x3;
    }

    assert(!(new_mode == gemmini_state_t::OS && !new_a_transpose && new_b_transpose) && !(new_mode == gemmini_state_t::WS && new_a_transpose && new_b_transpose));

  } else if ((rs1 & 0b11) == 1) { // rs1[1:0] == 2'b01, config_mvin, configure load pipeline
    const int state_id = (rs1 >> 3) & 0x3;
    dprintf("GEMMINI: config_mvin - set load stride from %lu to %lu\n", gemmini_state.load_strides[state_id], rs2);
    gemmini_state.load_strides[state_id] = rs2;
    gemmini_state.load_block_strides[state_id] = (rs1 >> 16) & 0xFFFF;
#if defined(HAS_MVIN_SCALE) || defined(HAS_MVIN_ACC_SCALE)
    dprintf("GEMMINI: config_mvin - set load scale from %lu to %lu\n", gemmini_state.load_scales[state_id], scale_t_bits_to_scale_t(rs1 >> 32));
    {
      const uint32_t _sbits = (uint32_t)(rs1 >> 32);
      gemmini_state.load_scales[state_id] = (_sbits == 0) ? (scale_t)1.0f : scale_t_bits_to_scale_t(_sbits);
    }
    gemmini_state.load_shrunks[state_id] = (rs1 >> 2) & 1;
#endif
    gemmini_state.pixels_per_rows[state_id] = (rs1 >> 8) & 0xFF;

    if (gemmini_state.pixels_per_rows[state_id] == 0)
      gemmini_state.pixels_per_rows[state_id] = 1;

#ifndef HAS_FIRST_LAYER_OPTIMIZATIONS
    assert(gemmini_state.pixels_per_rows[state_id] <= 1, "If Gemmini is built without first-layer optimizations, then 'pixels_per_rows' cannot be larger than 1\n");
#endif
  } else if ((rs1 & 0b11) == 2) { // rs1[1:0] == 2'b10, config_mvout, configure store pipeline
    dprintf("GEMMINI: config_mvout - set store stride from %lu to %lu\n", gemmini_state.store_stride, rs2 & 0xFFFFFFFF);
    gemmini_state.store_stride = rs2 & 0xFFFFFFFF;

    gemmini_state_t::Activation new_act;
    auto rs1_3_2 = (rs1 >> 2) & 0b11; // extract rs1[3:2], 0 = no activation, 1 = ReLU, 2 = ReLU6
    if (rs1_3_2 == 0) {
      if (static_cast<int>(gemmini_state.acc_act) != 4) {
        new_act = gemmini_state_t::NONE;
      } else {
        new_act = gemmini_state_t::SOFTMAX;
      }
    } else if (rs1_3_2 == 1) {
      new_act = gemmini_state_t::RELU;
    } else if (rs1_3_2 == 2) {
      new_act = gemmini_state_t::LAYERNORM;
    } else if (rs1_3_2 == 3) {
      new_act = gemmini_state_t::IGELU;
    } else {
      assert(false);
    }
    gemmini_state.acc_act = new_act;

    auto new_acc_shift = (rs2 >> 32) & 0xFFFFFFFF;
    gemmini_state.acc_shift = acc_scale_t_bits_to_acc_scale_t(new_acc_shift);

    gemmini_state.pool_stride = (rs1 >> 4) & 0x3;
    gemmini_state.pool_size = (rs1 >> 6) & 0x3;
    gemmini_state.pool_upad = (rs1 >> 8) & 0x3;
    gemmini_state.pool_lpad = (rs1 >> 10) & 0x3;
    gemmini_state.pool_out_dim = (rs1 >> 24) & 0xFF;
    gemmini_state.pool_porows = (rs1 >> 32) & 0xFF;
    gemmini_state.pool_pocols = (rs1 >> 40) & 0xFF;
    gemmini_state.pool_orows = (rs1 >> 48) & 0xFF;
    gemmini_state.pool_ocols = (rs1 >> 56) & 0xFF;

    if (gemmini_state.pool_stride == 0) {
        dprintf("GEMMINI: config_mvout - no pooling\n");
    } else {
        dprintf("GEMMINI: config_mvout - set pool_stride to %u\n", gemmini_state.pool_stride);
        dprintf("GEMMINI: config_mvout - set pool_size to %u\n", gemmini_state.pool_size);
        dprintf("GEMMINI: config_mvout - set pool_upad to %u\n", gemmini_state.pool_upad);
        dprintf("GEMMINI: config_mvout - set pool_lpad to %u\n", gemmini_state.pool_lpad);
        dprintf("GEMMINI: config_mvout - set pool_out_dim to %u\n", gemmini_state.pool_out_dim);
        dprintf("GEMMINI: config_mvout - set pool_porows to %u\n", gemmini_state.pool_porows);
        dprintf("GEMMINI: config_mvout - set pool_pocols to %u\n", gemmini_state.pool_pocols);
        dprintf("GEMMINI: config_mvout - set pool_orows to %u\n", gemmini_state.pool_orows);
        dprintf("GEMMINI: config_mvout - set pool_ocols to %u\n", gemmini_state.pool_ocols);
        dprintf("GEMMINI: config_mvout - rs1 is %llx\n", rs1);
    }
  } else if ((rs1 & 0b11) == 3) { // rs1[1:0] == 2'b11, config_norm, configure norm pipeline
    gemmini_state.norm_stat_id = (rs1 >> 8) & 0xFF;
    if (!((rs1 >> 17) & 1)) { // set stat_id only
      gemmini_state.igelu_qb = rs2 & 0xFFFFFFFF;
      gemmini_state.igelu_qc = (rs2 >> 32) & 0xFFFFFFFF;

      auto act_msb = (rs1 >> 16) & 0x1;
      gemmini_state.acc_act = static_cast<gemmini_state_t::Activation>((act_msb << 2) | static_cast<int>(gemmini_state.acc_act));
      assert(static_cast<int>(gemmini_state.acc_act) <= 4);

      if ((rs1 >> 18) & 1) { // q const type = 1
        gemmini_state.qln2_inv = (rs1 >> 32) & 0xFFFFFFFF;
      } else {
        gemmini_state.qln2 = (rs1 >> 32) & 0xFFFFFFFF;
      }
    }
  }
}

void gemmini_t::compute(reg_t a_addr, reg_t bd_addr, bool preload) {
  auto a_addr_real = static_cast<uint32_t>(a_addr & 0xFFFFFFFF);
  auto bd_addr_real = static_cast<uint32_t>(bd_addr & 0xFFFFFFFF);

  const uint16_t a_cols = (a_addr >> addr_len) & 0xFFFF;
  const uint16_t a_rows = (a_addr >> (addr_len + 16)) & 0xFFFF;

  const uint16_t bd_cols = (bd_addr >> addr_len) & 0xFFFF;
  const uint16_t bd_rows = (bd_addr >> (addr_len + 16)) & 0xFFFF;

  dprintf("GEMMINI: compute - preload = %d, scratchpad A addr = 0x%08x,"
           "scratchpad B addr 0x%08x\n", preload, a_addr_real, bd_addr_real);

  // Preload
  if (preload) {
    dprintf("GEMMINI: compute - PEs after preloading:\n");
    for (size_t i = 0; i < DIM; i++) {
      for (size_t j = 0; j < DIM; j++) {
        // TODO: Handle preloads from accumulator, values are shifted and activated before preload
        if (~gemmini_state.preload_sp_addr != 0) {
          assert(((gemmini_state.preload_sp_addr >> 30) & 0b11) == 0); // Preloads from accumulator not supported
        }

        bool preload_tranpose = (gemmini_state.mode == gemmini_state_t::WS) &&
          gemmini_state.b_transpose;
        size_t r = preload_tranpose ? j : i;
        size_t c = preload_tranpose ? i : j;

        // In OS mode, pe_state stores the accumulator values
        // In WS mode, pe_state stores the persistent weight matrix
        if (i < gemmini_state.preload_rows && j < gemmini_state.preload_cols) {
          auto preload_value = (~gemmini_state.preload_sp_addr == 0) ? 0 :
                  gemmini_state.spad.at(gemmini_state.preload_sp_addr + r).at(c);
          gemmini_state.pe_state.at(i).at(j) = preload_value;
        } else {
          gemmini_state.pe_state.at(i).at(j) = 0;
        }

#ifdef ELEM_T_IS_FLOAT
        dprintf("%f ", gemmini_state.pe_state.at(i).at(j));
#else
        dprintf("%d ", gemmini_state.pe_state.at(i).at(j));
#endif
      }
      dprintf("\n");
    }
  }

  // Compute
  // For OS, accumulate the PE results internally in pe_state
  // For WS, allocate a new results array which won't affect pe_state, seed the results array with the bias (D) matrix
  auto results = std::vector<std::vector<acc_t>>(DIM, std::vector<acc_t>(DIM));
  for (size_t i = 0; i < DIM; ++i) {
    for (size_t j = 0; j < DIM; ++j) {
      if (i < bd_rows && j < bd_cols) {
        results.at(i).at(j) = (~bd_addr_real == 0) ? 0 : gemmini_state.spad.at(bd_addr_real + i).at(j);
      } else {
        results.at(i).at(j) = 0;
      }
    }
  }

  for (size_t i = 0; i < DIM; ++i) {
    for (size_t j = 0; j < DIM; ++j) {
      for (size_t k = 0; k < DIM; ++k) {
        elem_t a;
        if (~a_addr_real != 0) {
            const size_t r = gemmini_state.a_stride * (gemmini_state.a_transpose ? k : i);
            const size_t c = gemmini_state.a_transpose ? i : k;

            a = i < a_rows && k < a_cols ? gemmini_state.spad.at(a_addr_real + r).at(c) : 0;
        }

        if (gemmini_state.mode == gemmini_state_t::WS) {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
          results.at(i).at(j) += a * gemmini_state.pe_state.at(k).at(j);
#pragma GCC diagnostic pop
        } else {
          elem_t b = 0;
          if (~bd_addr_real != 0) {
            const size_t r = gemmini_state.b_transpose ? j : k;
            const size_t c = gemmini_state.b_transpose ? k : j;

            b = k < bd_rows && j < bd_cols ? gemmini_state.spad.at(bd_addr_real + r).at(c) : 0;
          }

          gemmini_state.pe_state.at(i).at(j) += a * b;
        }
      }
    }
  }

  dprintf("GEMMINI: compute - PEs after matmul:\n");
  for (size_t i = 0; i < DIM; ++i) {
    for (size_t j = 0; j < DIM; ++j) {
#ifdef ELEM_T_IS_FLOAT
      dprintf("%f ", gemmini_state.pe_state.at(i).at(j));
#else
      dprintf("%d ", gemmini_state.pe_state.at(i).at(j));
#endif
    }
    dprintf("\n");
  }

  // Write results
  if (~gemmini_state.output_sp_addr != 0) {
    bool const acc = (gemmini_state.output_sp_addr >> 31) & 0x1;
    bool const acc_accum = (gemmini_state.output_sp_addr >> 30) & 0x1;
    auto const base_sp_addr = gemmini_state.output_sp_addr & 0x1FFFFFFF;
    dprintf("GEMMINI: compute - writing results to addr 0x%08x, :\n", gemmini_state.output_sp_addr);

    for (size_t i = 0; i < gemmini_state.output_rows; ++i) {
      for (size_t j = 0; j < gemmini_state.output_cols; ++j) {
        acc_t value = gemmini_state.mode == gemmini_state_t::OS ? gemmini_state.pe_state.at(i).at(j) : results.at(i).at(j);
        if (acc) {
          output_t shifted = gemmini_state.mode == gemmini_state_t::OS ?
                  sys_shift(value, gemmini_state.sys_shift) :
                  sys_shift(value, 0);

          if (acc_accum) {
            gemmini_state.accumulator.at(base_sp_addr + gemmini_state.c_stride * i).at(j) += value;
          } else { // Overwrite
            gemmini_state.accumulator.at(base_sp_addr + gemmini_state.c_stride * i).at(j) = value;
          }

#ifdef ELEM_T_IS_FLOAT
          dprintf("%f ", gemmini_state.accumulator.at(base_sp_addr + gemmini_state.c_stride * i).at(j));
#else
          dprintf("%d ", gemmini_state.accumulator.at(base_sp_addr + gemmini_state.c_stride * i).at(j));
#endif
        } else { // Move to scratchpad, apply activation along the way
          elem_t shifted = gemmini_state.mode == gemmini_state_t::OS ?
                             sys_shift(value, gemmini_state.sys_shift) :
                             sys_shift(value, 0);
          elem_t activated = apply_activation_sys(shifted);
          gemmini_state.spad.at(base_sp_addr + gemmini_state.c_stride * i).at(j) = activated;
#ifdef ELEM_T_IS_FLOAT
          dprintf("%f ", gemmini_state.spad.at(base_sp_addr + gemmini_state.c_stride * i).at(j));
#else
          dprintf("%d ", gemmini_state.spad.at(base_sp_addr + gemmini_state.c_stride * i).at(j));
#endif
        }
      }
      dprintf("\n");
    }
  }
}

void gemmini_t::loop_ws(reg_t rs1, reg_t rs2) {
  const bool ex_accumulate = rs1 & 1;
  const bool full_C = (rs1 >> 1) & 1;
  const bool low_D = (rs1 >> 2) & 1;
  const uint8_t act = (rs1 >> 8) & 0x7;
  const bool a_transpose = rs2 & 1;
  const bool b_transpose = (rs2 >> 1) & 1;
  uint8_t a_spad_id = (rs1 >> 18) & 0b11;
  uint8_t b_spad_id = (rs1 >> 16) & 0b11;
  const bool is_resadd = (rs2 >> 2) & 1;

  const uint16_t I = gemmini_state.loop_ws_I;
  const uint16_t J = gemmini_state.loop_ws_J;
  const uint16_t K = gemmini_state.loop_ws_K;

  const uint16_t pad_I = gemmini_state.loop_ws_pad_I;
  const uint16_t pad_J = gemmini_state.loop_ws_pad_J;
  const uint16_t pad_K = gemmini_state.loop_ws_pad_K;

  const uint32_t GARBAGE_ADDR = ~0;

  const int total_spad_rows = (I * K + K * J) * DIM;
  const int total_acc_rows = (I * J) * DIM;

  if (total_spad_rows > BANK_NUM * BANK_ROWS / 2 || total_acc_rows > ACC_ROWS / 2) {
    printf("LOOP_WS bounds were too large for double-buffering\n");
    exit(1);
  }

  uint32_t A_sp_addr_start = 0;
  uint32_t B_sp_addr_start = (BANK_NUM * BANK_ROWS / 2) - K * J * DIM;
  const uint32_t D_sp_addr_start = 1 << (ADDR_LEN-1);
  const uint32_t C_sp_addr_start = (3 << (ADDR_LEN-2)) | (full_C << (ADDR_LEN-3));
  if(a_spad_id == 2) A_sp_addr_start = (BANK_NUM * BANK_ROWS) / 2;
  if(b_spad_id == 2) B_sp_addr_start = (BANK_NUM * BANK_ROWS) - K * J * DIM;
  if(is_resadd) {
    A_sp_addr_start = 1 << (ADDR_LEN - 1);
    B_sp_addr_start = 3 << (ADDR_LEN - 2);
    for(uint16_t i = 0; i < I; i++){
      for(uint16_t j = 0; j < J; j++){
        const uint32_t A_sp_addr = A_sp_addr_start + (i*J+j)*DIM;
        const uint32_t B_sp_addr = B_sp_addr_start + (i*J+j)*DIM;
        const uint32_t C_sp_addr = C_sp_addr_start + (i*J+j)*DIM;
        uint64_t dram_addr, cols, rows;
        dram_addr = gemmini_state.loop_ws_A + (i*gemmini_state.loop_ws_A_stride + j) * DIM * sizeof(elem_t);
        cols = DIM - (j == J-1 ? pad_J : 0);
        rows = DIM - (i == I-1 ? pad_I : 0);
        mvin(dram_addr, (rows << 48) | (cols << 32) | A_sp_addr, 0);

        dram_addr = gemmini_state.loop_ws_B + (i*gemmini_state.loop_ws_B_stride + j) * DIM * sizeof(elem_t);
        cols = DIM - (j == J-1 ? pad_J : 0);
        rows = DIM - (i == I-1 ? pad_I : 0);
        mvin(dram_addr, (rows << 48) | (cols << 32) | B_sp_addr, 1);
        if(gemmini_state.loop_ws_C != 0){
          const size_t sizeof_C = full_C ? sizeof(acc_t) : sizeof(elem_t);
          const uint64_t C_dram_addr = gemmini_state.loop_ws_C +
            (i*gemmini_state.loop_ws_C_stride + j) * DIM * sizeof_C;
          const uint64_t C_cols = DIM - (j == J - 1 ? pad_J : 0);
          const uint64_t C_rows = DIM - (i == I - 1 ? pad_I : 0);

          mvout(C_dram_addr, (C_rows << 48) | (C_cols << 32) | C_sp_addr);
        }
      }
    }
    return;
  }

  if (gemmini_state.loop_ws_D != 0) {
    for (uint16_t i = 0; i < I; i++) {
      for (uint16_t j = 0; j < J; j++) {
        const size_t sizeof_D = low_D ? sizeof(elem_t) : sizeof(acc_t);

        const uint64_t dram_addr = gemmini_state.loop_ws_D +
          (i * gemmini_state.loop_ws_D_stride + j) * DIM * sizeof_D;

        const uint64_t sp_addr = D_sp_addr_start + (i*J + j)*DIM;

        const uint64_t cols = DIM - (j == J-1 ? pad_J : 0);
        const uint64_t rows = DIM - (i == I-1 ? pad_I : 0);

        mvin(dram_addr, (rows << 48) | (cols << 32) | sp_addr, 2);
      }
    }
  }

  for (uint16_t k = 0; k < K; k++) {
    for (uint16_t j = 0; j < J; j++) {
      for (uint16_t i = 0; i < I; i++) {
        const uint32_t A_sp_addr = a_transpose ? (A_sp_addr_start + (k*I + i)*DIM) :
          (A_sp_addr_start + (i*K + k)*DIM);
        const uint32_t B_sp_addr = b_transpose ? (B_sp_addr_start + (j*K + k)*DIM) :
          (B_sp_addr_start + (k*J + j)*DIM);
        const uint32_t C_sp_addr = C_sp_addr_start + (i*J + j)*DIM;

        // Mvin A
        if (j == 0 && gemmini_state.loop_ws_A != 0) {
          uint64_t dram_addr, cols, rows;

          if (a_transpose) {
            dram_addr = gemmini_state.loop_ws_A +
                (k*gemmini_state.loop_ws_A_stride + i) * DIM * sizeof(elem_t);
            cols = DIM - (i == I-1 ? pad_I : 0);
            rows = DIM - (k == K-1 ? pad_K : 0);
          } else {
            dram_addr = gemmini_state.loop_ws_A +
                (i*gemmini_state.loop_ws_A_stride + k) * DIM * sizeof(elem_t);
            cols = DIM - (k == K-1 ? pad_K : 0);
            rows = DIM - (i == I-1 ? pad_I : 0);
          }

          mvin(dram_addr, (rows << 48) | (cols << 32) | A_sp_addr, 0);
        }

        // Mvin B
        if (i == 0 && gemmini_state.loop_ws_B != 0) {
          uint64_t dram_addr, cols, rows;

          if (b_transpose) {
            dram_addr = gemmini_state.loop_ws_B +
                (j*gemmini_state.loop_ws_B_stride + k) * DIM * sizeof(elem_t);
            cols = DIM - (k == K-1 ? pad_K : 0);
            rows = DIM - (j == J-1 ? pad_J : 0);
          } else {
            dram_addr = gemmini_state.loop_ws_B +
                (k*gemmini_state.loop_ws_B_stride + j) * DIM * sizeof(elem_t);
            cols = DIM - (j == J-1 ? pad_J : 0);
            rows = DIM - (k == K-1 ? pad_K : 0);
          }

          mvin(dram_addr, (rows << 48) | (cols << 32) | B_sp_addr, 1);
        }

        // Compute
        if(!is_resadd) {
          uint32_t pre_sp_addr = i == 0 ? B_sp_addr : GARBAGE_ADDR;
          uint32_t out_sp_addr = C_sp_addr;

          if (!ex_accumulate && k == 0) {
            out_sp_addr &= ~(1 << (ADDR_LEN-2));
          }

          const uint64_t A_cols = DIM - (k == K - 1 ? pad_K : 0);
          const uint64_t A_rows = DIM - (i == I - 1 ? pad_I : 0);
          const uint64_t B_cols = DIM - (j == J - 1 ? pad_J : 0);
          const uint64_t B_rows = DIM - (k == K - 1 ? pad_K : 0);
          const uint64_t C_cols = DIM - (j == J - 1 ? pad_J : 0);
          const uint64_t C_rows = DIM - (i == I - 1 ? pad_I : 0);

          preload((B_rows << 48) | (B_cols << 32) | pre_sp_addr,
              (C_rows << 48) | (C_cols << 32) | out_sp_addr);

          compute((A_rows << 48) | (A_cols << 32) | A_sp_addr,
              ((uint64_t)DIM << 48) | ((uint64_t)DIM << 32) | GARBAGE_ADDR, i == 0);
        }

        // Move-out C
        if (gemmini_state.loop_ws_C != 0 && k == K-1) {
          const size_t sizeof_C = full_C ? sizeof(acc_t) : sizeof(elem_t);

          if ((act != gemmini_state_t::LAYERNORM) && (act != gemmini_state_t::SOFTMAX)) {
            const uint64_t C_dram_addr = gemmini_state.loop_ws_C +
                (i*gemmini_state.loop_ws_C_stride + j) * DIM * sizeof_C;

            const uint64_t C_cols = DIM - (j == J - 1 ? pad_J : 0);
            const uint64_t C_rows = DIM - (i == I - 1 ? pad_I : 0);

            mvout(C_dram_addr, (C_rows << 48) | (C_cols << 32) | C_sp_addr);
          }

          else if (((act == gemmini_state_t::LAYERNORM) || (act == gemmini_state_t::SOFTMAX)) && j == J - 1){
            int norm_cmds_size;
            uint32_t (*norm_cmds)[2];
            uint32_t ln_norm_cmds[][2] = {{1,2},{3,4},{0,0}};
            uint32_t sm_norm_cmds[][2] = {{5,5},{6,7},{0,0}};

            if (act == gemmini_state_t::LAYERNORM) {
              norm_cmds = ln_norm_cmds;
              norm_cmds_size = 3;
            } else {
              norm_cmds = sm_norm_cmds;
              norm_cmds_size = 3;
            }

            const size_t rows = DIM - (i == I-1 ? pad_I : 0);

            for (size_t row = 0; row < rows; row += NORM_STAT_IDS) {
              const size_t stat_ids = rows - row > NORM_STAT_IDS ?
                NORM_STAT_IDS : rows - row;

              for (int cmd = 0; cmd < norm_cmds_size; cmd++) {
                for (size_t stat_id = 0; stat_id < stat_ids; stat_id++) {
                  config((1 << 17) | (stat_id << 8) | 3, 0);
                  const size_t r = row + stat_id;

                  for (size_t jj = 0; jj < J; jj++) {
                    uint32_t norm_C_sp_addr = C_sp_addr_start + (i*J + jj)*DIM + r;
                    if (jj + 1 == J) {
                      norm_C_sp_addr |= (norm_cmds[cmd][1] << 26); // Final mean/inv-std-dev calculation
                    } else {
                      norm_C_sp_addr |= (norm_cmds[cmd][0] << 26); // Accumulate sum/variance
                    }

                    const uint64_t C_dram_addr = gemmini_state.loop_ws_C +
                      (i*gemmini_state.loop_ws_C_stride + jj) * DIM * sizeof_C +
                      r * gemmini_state.loop_ws_C_stride * sizeof_C;

                    const size_t cols = DIM - (jj + 1 == J ? pad_J : 0);

                    // gemmini_extended_mvout(C_dram_addr, norm_C_sp_addr, cols, 1);
                    mvout(C_dram_addr, ((uint64_t)1 << 48) | (cols << 32) | norm_C_sp_addr);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

void gemmini_t::compute_cisc() {
  // `compute` performs Gemmini's core function - matrix multiply-add -
  //  without referencing any underlying hardware detail.
  //
  // * Operands A, B, and D are loaded from memory
  // * Multiply, add, activation, and any requested shifts are performed
  // * Result D is written back to memory
  //
  // These computations are made independent of systolic array sizes,
  // scratchpad-memory sizes,
  // and any other microarchitectural detail (other than datatypes).

  // Load operands from memory
  auto A = read_matrix_from_dram<elem_t>(gemmini_state.a_addr,
                                          gemmini_state.m,
                                          gemmini_state.k,
                                          false, false);
  auto B = read_matrix_from_dram<elem_t>(gemmini_state.b_addr,
                                          gemmini_state.k,
                                          gemmini_state.n,
                                          false, false);
  auto D = read_matrix_from_dram<acc_t>(gemmini_state.d_addr,
                                          gemmini_state.m,
                                          gemmini_state.n,
                                          true,
                                          gemmini_state.repeating_bias);
  // Initialize an accumulator/ result
  auto C = matrix_zeroes<elem_t>(gemmini_state.m, gemmini_state.n);

  // Multiply & apply activation
  for (size_t i=0; i<gemmini_state.m; i++) {
    for (size_t j=0; j<gemmini_state.n; j++) {
      acc_t value = D->at(i).at(j);
      for (size_t k=0; k<gemmini_state.k; k++) {
        value += ((acc_t)A->at(i).at(k)) * ((acc_t)B->at(k).at(j));
      }
      elem_t shifted = acc_scale(value,
                          gemmini_state.acc_shift);
      elem_t activated = apply_activation_acc(shifted);
      C->at(i).at(j) = activated;
    }
  }

  // Write back to memory
  for (size_t i = 0; i < gemmini_state.m; i++) {
    auto const dram_row_addr = gemmini_state.c_addr +
                               i*sizeof(elem_t)*gemmini_state.n;
    for (size_t j = 0; j < gemmini_state.n; j++) {
      auto const dram_byte_addr = dram_row_addr + j*sizeof(elem_t);
#ifdef ELEM_T_IS_FLOAT
      write_to_dram<elem_t_bits>(dram_byte_addr, C->at(i).at(j));
#else
      write_to_dram<elem_t>(dram_byte_addr, C->at(i).at(j));
#endif
    }
  }
}

// Union for counter operation argument extraction
union counter_op_param {
  reg_t arg;
  struct {
    uint64_t counter_reset:1;
    uint64_t snapshot_reset:1;
    uint64_t take_snapshot:1;
    uint64_t change_config:1;
    uint64_t counter_index:3;
    uint64_t padding2:5;
    uint64_t counter_addr:6;
    uint64_t padding1:13;
    uint64_t external_counter:1;
    uint64_t padding0:32;
  };
};

reg_t gemmini_t::counter_operation(reg_t rs1) {
  counter_op_param decoder;
  decoder.arg = rs1;

  if (decoder.counter_reset) {
    for (size_t i = 0; i < NUM_COUNTERS; i++)
      gemmini_state.counter_val[i] = 0;
    gemmini_state.op_in_progress = false;
  }
  if (decoder.snapshot_reset) gemmini_state.snapshot_enable = false;
  if (decoder.take_snapshot) {
    gemmini_state.snapshot_enable = true;
    for (size_t i = 0; i < NUM_COUNTERS; i++) {
      if (gemmini_state.counter_external_flag[i])
        gemmini_state.counter_snapshot_val[i] = gemmini_state.counter_external[gemmini_state.counter_config[i]];
      else
        gemmini_state.counter_snapshot_val[i] = gemmini_state.counter_val[i];
    }
  }
  if (decoder.change_config) {
    gemmini_state.counter_config[decoder.counter_index] = decoder.counter_addr;
    gemmini_state.counter_val[decoder.counter_index] = 0;
    gemmini_state.counter_external_flag[decoder.counter_index] = decoder.external_counter;
  }
  if (gemmini_state.snapshot_enable)
    return gemmini_state.counter_snapshot_val[decoder.counter_index];
  else if (gemmini_state.counter_external_flag[decoder.counter_index])
    return gemmini_state.counter_external[gemmini_state.counter_config[decoder.counter_index]];
  else
    return gemmini_state.counter_val[decoder.counter_index];
}

void gemmini_t::loop_ws_config_bounds(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_ws_I = rs2 & 0xFFFF;
  gemmini_state.loop_ws_J = (rs2 >> 16) & 0xFFFF;
  gemmini_state.loop_ws_K = (rs2 >> 32) & 0xFFFF;

  gemmini_state.loop_ws_pad_I = rs1 & 0xFFFF;
  gemmini_state.loop_ws_pad_J = (rs1 >> 16) & 0xFFFF;
  gemmini_state.loop_ws_pad_K = (rs1 >> 32) & 0xFFFF;
}

void gemmini_t::loop_ws_config_addrs_AB(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_ws_A = rs1;
  gemmini_state.loop_ws_B = rs2;
}

void gemmini_t::loop_ws_config_addrs_DC(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_ws_D = rs1;
  gemmini_state.loop_ws_C = rs2;
}

void gemmini_t::loop_ws_config_strides_AB(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_ws_A_stride = rs1;
  gemmini_state.loop_ws_B_stride = rs2;
}

void gemmini_t::loop_ws_config_strides_DC(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_ws_D_stride = rs1;
  gemmini_state.loop_ws_C_stride = rs2;
}

void gemmini_t::loop_ws_config_spad_AB(reg_t rs1, reg_t rs2) {
  gemmini_state.mx_loop_a_spad = (uint32_t)rs1;
  gemmini_state.mx_loop_b_spad = (uint32_t)rs2;
  gemmini_state.mx_slot_a_start[gemmini_state.mx_loop_slot] = (uint32_t)rs1;   // the slot the next LOOP_WS takes
  gemmini_state.mx_slot_b_end[gemmini_state.mx_loop_slot] = (uint32_t)rs2;
}

void gemmini_t::loop_ws_config_spad_C(reg_t rs1, reg_t rs2) {
  gemmini_state.mx_loop_c_spad = (uint32_t)rs1;
  (void)rs2;
}

void gemmini_t::mxquant_config_mvout(reg_t rs1, reg_t rs2) {
  gemmini_state.mx_scale_dram          = rs1 & 0x1FFFFFFFFULL;
  gemmini_state.mx_tiles_I             = (rs1 >> 33) & 0x1FF;
  gemmini_state.mx_tiles_J             = (rs1 >> 42) & 0x1FF;
  gemmini_state.mx_tiles_K             = (rs1 >> 51) & 0x1FF;
  gemmini_state.mx_scale_act_sel       = (rs1 >> 60) & 0x1;
  gemmini_state.mx_scale_wgt_sel       = (rs1 >> 61) & 0x1;
  // C8.3: MX_SCALE_RESIDENT sourced from rs1 bit 62 of the mxquant scale-config (a FREE bit here).
  // The requant scale post-passes read this to also write the act-scale window transposed [GN][M].
  // Sourced here (not the loop flag) so the RTL requantizer -- which reads ex io.mx set by this same
  // instruction -- sees the identical bit. gemmini_mxquant_config_mvout_resident() sets it.
  gemmini_state.mx_loop_scale_resident = ((rs1 >> 63) & 0x1) != 0;   // MX_SCALE_RESIDENT (bit63, decoupled from bit62 counter_reset)
  gemmini_state.mx_lut_update_granularity = rs2 & 0xFFFF;
}

// VPU_EXEC (MxE4M3VpuGemminiRocketConfig): rs1 = src1[13:0] | src2[27:14] | dst[41:28] | rows[57:42],
// rs2 = op[3:0] | bcast[4] | rlen[14:5] | imm[31:16]. Spad row = DIM bytes = 8 LE BF16 lanes. Inputs are read
// before any output is written (the RTL reads several rows ahead of its writes), addresses wrap at 14 bits.
void gemmini_t::vpu_exec(reg_t rs1, reg_t rs2) {
  const uint32_t src1 = rs1 & 0x3FFF, src2 = (rs1 >> 14) & 0x3FFF, dst = (rs1 >> 28) & 0x3FFF;
  const int rows = (int)((rs1 >> 42) & 0xFFFF);
  const int op = (int)(rs2 & 0xF), bcast = (int)((rs2 >> 4) & 1);
  int rlen = (int)((rs2 >> 5) & 0x3FF);
  const uint16_t imm = (uint16_t)((rs2 >> 16) & 0xFFFF);
  if (DIM != 2 * VPU_LANES) { fprintf(stderr, "VPU_EXEC: needs DIM=16 (8 BF16 per spad row)\n"); abort(); }
  if (op > VPU_EXPSUM) { fprintf(stderr, "VPU_EXEC: illegal op %d\n", op); abort(); }
  if (rows == 0) return;
  if (rlen == 0) rlen = 1024;   // RTL row-in-group counter is 10 bits
  if (gemmini_state.spad.size() < 0x4000) gemmini_state.spad.resize(0x4000, std::vector<elem_t>(DIM, 0));
  auto rd = [&](uint32_t addr, uint16_t *v) {
    const auto &r = gemmini_state.spad[addr & 0x3FFF];
    for (int l = 0; l < VPU_LANES; l++) v[l] = (uint16_t)((uint8_t)r[2 * l] | ((uint8_t)r[2 * l + 1] << 8));
  };
  const int n2 = bcast ? (rows + rlen - 1) / rlen : rows;
  std::vector<std::array<uint16_t, VPU_LANES>> a(rows), b(vpu_uses_src2(op) ? n2 : 0), o(rows);
  for (int i = 0; i < rows; i++) rd(src1 + i, a[i].data());
  for (int i = 0; i < (int)b.size(); i++) rd(src2 + i, b[i].data());
  vpu_ref_exec(op, (uint16_t (*)[VPU_LANES])o.data(), (const uint16_t (*)[VPU_LANES])a.data(),
               b.empty() ? nullptr : (const uint16_t (*)[VPU_LANES])b.data(), rows, rlen, bcast, imm);
  const int nout = vpu_is_reduction(op) ? rows / rlen : rows;
  for (int i = 0; i < nout; i++) {
    auto &r = gemmini_state.spad[(dst + i) & 0x3FFF];
    for (int l = 0; l < VPU_LANES; l++) { r[2 * l] = (elem_t)(o[i][l] & 0xFF); r[2 * l + 1] = (elem_t)(o[i][l] >> 8); }
  }
  if (op == VPU_EXPSUM) {   // row sums of the written result (as RSUM over it), one row per logical row at imm[13:0]
    std::vector<std::array<uint16_t, VPU_LANES>> s(rows / rlen);
    vpu_ref_exec(VPU_RSUM, (uint16_t (*)[VPU_LANES])s.data(), (const uint16_t (*)[VPU_LANES])o.data(), nullptr,
                 rows, rlen, 0, 0);
    for (int g = 0; g < rows / rlen; g++) {
      auto &r = gemmini_state.spad[((imm & 0x3FFF) + g) & 0x3FFF];
      for (int l = 0; l < VPU_LANES; l++) { r[2 * l] = (elem_t)(s[g][l] & 0xFF); r[2 * l + 1] = (elem_t)(s[g][l] >> 8); }
    }
  }
}

// SPAD_REQUANT: rs1 = src[13:0] | dst[27:14] | tiled[28] | resident[29] | scale DRAM[62:30], rs2 = M[15:0] | N[31:16] |
// fp4[32]. FP4: codes = the matmul FP4 requant element (bf16(v / scale) -> E2M1), byte (m/2, n) = row m even low nibble,
// flat dst + (m/2)*N/16 + n/16 or tiled as the FP4 operand A (dst + ((m/32)*N/16 + n/16)*16 + (m/2)%16).
// Row-major BF16 tile in the spad -> E4M3 codes (flat or operand-A tiled) + one E8M0 per 32 values along a row, filed
// row-major to the command's scale DRAM address and, when resident, transposed [GN][M] into the act-scale window.
// Same block scale / element encoding as the matmul requant golden.
void gemmini_t::spad_requant(reg_t rs1, reg_t rs2) {
  const uint32_t src = rs1 & 0x3FFF, dst = (rs1 >> 14) & 0x3FFF;
  const bool tiled = (rs1 >> 28) & 1;
  const bool resident = (rs1 >> 29) & 1;
  const reg_t scale_dram = (rs1 >> 30) & 0x1FFFFFFFFULL;
  const int M = (int)(rs2 & 0xFFFF), N = (int)((rs2 >> 16) & 0xFFFF);
  const bool fp4 = (rs2 >> 32) & 1;
  if (DIM != 16 || N % 32 != 0 || M % 8 != 0 || ((M * (N / 32)) % 32) != 0 || M * (N / 32) > 2048) {
    fprintf(stderr, "SPAD_REQUANT: needs DIM=16, N%%32==0, M%%8==0, M*N/32 a multiple of 32 and <= 2048\n");
    abort();
  }
  if (gemmini_state.spad.size() < 0x4000) gemmini_state.spad.resize(0x4000, std::vector<elem_t>(DIM, 0));
  const int GN = N / 32;
  for (int m = 0; m < M; m++)
    for (int b = 0; b < GN; b++) {
      const uint32_t blk = (uint32_t)(m * GN + b);
      float v[32];
      for (int k = 0; k < 32; k++) {
        const auto &row = gemmini_state.spad[(src + 4 * blk + k / 8) & 0x3FFF];
        const int l = k % 8;
        v[k] = mx::bf16_to_f32((uint16_t)((uint8_t)row[2 * l] | ((uint8_t)row[2 * l + 1] << 8)));
      }
      float max_abs = 0.0f; bool has_nan = false, has_inf = false;
      for (int k = 0; k < 32; k++) {
        if (std::isnan(v[k])) { has_nan = true; continue; }
        if (std::isinf(v[k])) { has_inf = true; continue; }
        if (fabsf(v[k]) > max_abs) max_abs = fabsf(v[k]);
      }
      uint8_t scale_code; float scale;
      if (has_nan || has_inf) { scale_code = 0xFF; scale = has_nan ? (float)NAN : (float)INFINITY; }
      else {
        const float amax = (max_abs < FLT_EPSILON) ? FLT_EPSILON : max_abs;
        int s = (int)floorf(log2f(amax)) + 127;
        scale_code = (uint8_t)(s < 0 ? 0 : s > 254 ? 254 : s);
        scale = ldexpf(1.0f, (int)scale_code - 127);
      }
      p->get_mmu()->store<uint8_t>(scale_dram + blk, scale_code);
      if (resident) {
        const size_t a_off = (size_t)b * (size_t)M + (size_t)m;
        if (a_off >= gemmini_state.mx_scale_a_mem.size()) gemmini_state.mx_scale_a_mem.resize(a_off + 1, 0x7f);
        gemmini_state.mx_scale_a_mem[a_off] = scale_code;
      }
      if (fp4) {
        for (int k = 0; k < 32; k++) {
          const int p = m / 2, n = 32 * b + k;
          const uint32_t r = tiled ? dst + ((uint32_t)((p / 16) * (N / 16) + n / 16) << 4) + (uint32_t)(p % 16)
                                   : dst + (uint32_t)(p * (N / 16) + n / 16);
          auto &row = gemmini_state.spad[r & 0x3FFF];
          const uint8_t code = mx::bf16_bits_to_fp4_e2m1_code(mx::f32_to_bf16_rne(v[k] / scale));
          uint8_t byte = (uint8_t)row[n % 16];
          byte = (m & 1) ? (uint8_t)((byte & 0x0F) | (code << 4)) : (uint8_t)((byte & 0xF0) | code);
          row[n % 16] = (elem_t)byte;
        }
        continue;
      }
      for (int h = 0; h < 2; h++) {
        const uint32_t r = tiled ? dst + ((uint32_t)((m / 16) * (N / 16) + 2 * b + h) << 4) + (uint32_t)(m % 16)
                                 : dst + 2 * blk + (uint32_t)h;
        auto &row = gemmini_state.spad[r & 0x3FFF];
        // a -0.0 element keeps its sign (0x80), as the RTL requantizer does; fp8_e4m3_to_code canonicalizes it to +0
        // for the Python matmul-requant golden
        for (int c = 0; c < 16; c++) {
          const float x = v[16 * h + c] / scale;
          row[c] = (elem_t)(x == 0.0f && std::signbit(x) ? 0x80 : mx::fp8_e4m3_to_code(x));
        }
      }
    }
}

void gemmini_t::mx_load_scales(reg_t rs1, reg_t rs2) {
  // rs1[39:0] addr, rs1[63:40] DRAM row pitch; rs2[31:0] bytes/row (1-D: total), [32] sel, [45:33] dest byte
  // offset, [53:46] rows (0 = 1). Rows land contiguously from dest, matching the RTL loader.
  const reg_t dram_addr = rs1 & 0xFFFFFFFFFFULL;
  const uint32_t pitch = (uint32_t)((rs1 >> 40) & 0xFFFFFF);
  const uint32_t len   = (uint32_t)(rs2 & 0xFFFFFFFFu);
  const uint8_t sel    = (uint8_t)((rs2 >> 32) & 0x1);
  const uint32_t dest  = (uint32_t)((rs2 >> 33) & 0x1FFF);
  uint32_t rows        = (uint32_t)((rs2 >> 46) & 0xFF);
  if (rows == 0) rows = 1;
  const uint32_t step = pitch ? pitch : len;
  gemmini_state.mx_scales_used = true;
  auto &dst = sel ? gemmini_state.mx_scale_b_mem : gemmini_state.mx_scale_a_mem;
  if (dst.size() < dest + rows * len) dst.resize(dest + rows * len, 0x7f);
  for (uint32_t r = 0; r < rows; r++)
    for (uint32_t i = 0; i < len; i++)
      dst[dest + r * len + i] = read_from_dram<uint8_t>(dram_addr + (reg_t) r * step + i);
}

void gemmini_t::mx_read_smem(reg_t rs1, reg_t rs2) {
  const reg_t dram_addr = rs1;
  const uint32_t smem_off_words = (uint32_t)(rs2 & 0xFFFFFFFFu);
  const uint32_t num_words      = (uint32_t)((rs2 >> 32) & 0xFFFFFFFFu);
  for (uint32_t i = 0; i < num_words; i++) {
    if (smem_off_words + i >= gemmini_state.mx_smem.size()) break;
    uint16_t v = gemmini_state.mx_smem[smem_off_words + i];
    p->get_mmu()->store<uint8_t>(dram_addr + i*2,     v & 0xFF);
    p->get_mmu()->store<uint8_t>(dram_addr + i*2 + 1, (v >> 8) & 0xFF);
  }
}

// Load num_luts × (16 6-bit FP6 E3M2 codes) from DRAM. Each LUT in DRAM is
// 3 little-endian uint32 words (96 bits) — same on-the-wire format the HW
// MMIO path expects (lut_mapping_demo.py::pack_lut_hw_words).
//   rs1 = dram_addr
//   rs2 = (sel << 32) | num_luts ; sel: 0=B, 1=A, 2=C
void gemmini_t::mx_load_lut(reg_t rs1, reg_t rs2) {
  gemmini_state.mx_lut_en = 1;   // G1: loading a codebook enables runtime LUT usage
  const reg_t dram_addr = rs1;
  const uint32_t num_luts = (uint32_t)(rs2 & 0xFFFFFFFFu);
  const uint8_t  sel      = (uint8_t)((rs2 >> 32) & 0x3);
  // Per-operand quad detection: an ACT LUT (sel==1) means the activation is deprojected (quad); a WEIGHT
  // LUT (sel==0) means the weight is deprojected (quad). This decouples each operand's single-vs-quad
  // throughput from the global mx_lut_en, so E4M3-single x LUT-quad (dual throughput) selects correctly.
  if (sel == 1) gemmini_state.mx_lut_a_loaded = 1;
  else if (sel == 0) gemmini_state.mx_lut_b_loaded = 1;
  auto &dst = (sel == 1) ? gemmini_state.mx_lut_a
            : (sel == 2) ? gemmini_state.mx_lut_c
                         : gemmini_state.mx_lut_b;
  if (dst.size() < (size_t)num_luts * 16) dst.resize((size_t)num_luts * 16, 0);
  // The load carries the codebook ENTRY WIDTH (datatype): FP6/E2M3=6, FP8 E5M2=8. Codebooks are stored in
  // their native packing (16 * entry_bits bits per table, LE bitstream); each code is stored as one uint8
  // (fp6 in the low 6). fp6_e3m2_decode reads only the low 6, so a 6-bit code in a uint8 decodes correctly.
  int entry_bits = (int)((rs2 >> 34) & 0x3F);
  if (entry_bits == 0) entry_bits = 6;                 // default FP6
  const int lut_bytes = (16 * entry_bits) / 8;          // 12 (fp6) or 16 (e5m2)
  for (uint32_t li = 0; li < num_luts; li++) {
    const reg_t tbase = dram_addr + (reg_t)li * lut_bytes;
    for (int e = 0; e < 16; e++) {
      int bit0 = e * entry_bits;
      uint32_t code = 0;
      for (int k = 0; k < entry_bits; k++) {
        int gbit = bit0 + k;
        uint8_t byte = read_from_dram<uint8_t>(tbase + (gbit >> 3));
        code |= ((uint32_t)((byte >> (gbit & 7)) & 1)) << k;
      }
      dst[(size_t)li * 16 + e] = (uint8_t)code;
    }
  }
}

void gemmini_t::loop_ws_config_scales(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_ws_A_sc = rs1;
  gemmini_state.loop_ws_B_sc = rs2;
}

void gemmini_t::loop_ws_config_scale_strides(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_ws_A_sc_stride = rs1;
  gemmini_state.loop_ws_B_sc_stride = rs2;
}

// Native MX DRAM loop (RTL LoopMatmul with A/B/C in DRAM), E4M3-single x E4M3-single or FP4 x FP4 (quad: 2*DIM-row A
// tiles [M/2][K] row-pair packed, 2*DIM-col B tiles [K][N/2]), BF16 out, no padding.
// K-tiling: consecutive loops with ex_accumulate (C = NULL except on the last K-tile) add into the same
// shadow-acc region, as the RTL keeps one acc half while C is NULL.
// Loop-managed scales (A_sc != 0) mirror the loop unit: 2-D scale loads into half = slot (A skipped when A is
// resident and the slot's half already holds the same slice), then CONFIG_SCALE_MEM(bounds = I/J/K, both
// halves = slot, no counter reset). Operands land where the RTL puts them; the math is mx_loop_ws_spad's.
void gemmini_t::mx_loop_ws_dram(reg_t rs1, reg_t rs2) {
  const bool ex_accumulate = rs1 & 1;
  const uint8_t a_spad_id = (rs1 >> 18) & 0b11;
  const uint8_t b_spad_id = (rs1 >> 16) & 0b11;
  const uint16_t I = gemmini_state.loop_ws_I, J = gemmini_state.loop_ws_J, K = gemmini_state.loop_ws_K;
  const uint8_t slot = gemmini_state.mx_loop_slot;
  const bool single = gemmini_state.mx_act_fmt == 0 && !gemmini_state.mx_fp8_altfmt && !gemmini_state.mx_lut_a_loaded &&
                      gemmini_state.mx_wgt_fmt == 0 && !gemmini_state.mx_wgt_altfmt && !gemmini_state.mx_lut_b_loaded;
  const bool fp4 = gemmini_state.mx_act_fmt == 2 && gemmini_state.mx_wgt_fmt == 2 && !gemmini_state.mx_fp8_altfmt &&
                   !gemmini_state.mx_wgt_altfmt && !gemmini_state.mx_lut_a_loaded && !gemmini_state.mx_lut_b_loaded;
  const reg_t TW = fp4 ? 2 * DIM : DIM;   // scale bytes per tile row / col
  if (!(single || fp4) || gemmini_state.mx_out_fmt != 3 || (rs2 & 0x7) ||
      gemmini_state.loop_ws_pad_I || gemmini_state.loop_ws_pad_J || gemmini_state.loop_ws_pad_K ||
      gemmini_state.loop_ws_D != 0) {
    printf("MX DRAM LOOP_WS: only E4M3-single x single or FP4 x FP4, BF16 out, no pad/D/transpose/resadd\n");
    exit(1);
  }
  const uint32_t half = (BANK_NUM * BANK_ROWS) / 2;
  // spad id 0: the slot's a_addr_start / b_addr_end (LOOP_WS_CONFIG_SPAD_AB, else the slot's half), as the RTL
  const uint32_t A_sp = a_spad_id ? (a_spad_id - 1) * half : gemmini_state.mx_slot_a_start[slot];
  const uint32_t B_end = b_spad_id ? b_spad_id * half : gemmini_state.mx_slot_b_end[slot];
  const uint32_t B_sp = B_end - (uint32_t)K * J * DIM;

  if (gemmini_state.loop_ws_A_sc != 0) {
    const reg_t rows = (reg_t)K * DIM / 32;
    const reg_t dest = (reg_t)slot << 12;
    const bool hit = gemmini_state.loop_ws_A == 0 && gemmini_state.mx_asc_valid[slot] &&
                     gemmini_state.mx_asc_addr[slot] == gemmini_state.loop_ws_A_sc &&
                     gemmini_state.mx_asc_stride[slot] == gemmini_state.loop_ws_A_sc_stride &&
                     gemmini_state.mx_asc_I[slot] == I && gemmini_state.mx_asc_K[slot] == K;
    if (!hit) {
      mx_load_scales((gemmini_state.loop_ws_A_sc & 0xFFFFFFFFFFULL) | (gemmini_state.loop_ws_A_sc_stride << 40),
                     (rows << 46) | (dest << 33) | ((reg_t)I * TW));
      gemmini_state.mx_asc_valid[slot] = true;
      gemmini_state.mx_asc_addr[slot] = gemmini_state.loop_ws_A_sc;
      gemmini_state.mx_asc_stride[slot] = gemmini_state.loop_ws_A_sc_stride;
      gemmini_state.mx_asc_I[slot] = I;
      gemmini_state.mx_asc_K[slot] = K;
    }
    mx_load_scales((gemmini_state.loop_ws_B_sc & 0xFFFFFFFFFFULL) | (gemmini_state.loop_ws_B_sc_stride << 40),
                   (rows << 46) | (dest << 33) | (1ULL << 32) | ((reg_t)J * TW));
    // the loop's own CONFIG_SCALE_MEM: rs1 = {0,0, slot, slot, K, J, I, 0}, rs2 = managed | granularity 1
    gemmini_state.mx_scale_dram = 0;
    gemmini_state.mx_tiles_I = I & 0x1FF;
    gemmini_state.mx_tiles_J = J & 0x1FF;
    gemmini_state.mx_tiles_K = K & 0x1FF;
    gemmini_state.mx_scale_act_sel = slot;
    gemmini_state.mx_scale_wgt_sel = slot;
    gemmini_state.mx_loop_scale_resident = false;
    gemmini_state.mx_lut_update_granularity = 1;
  }

  for (uint16_t i = 0; i < I && gemmini_state.loop_ws_A != 0; i++)
    for (uint16_t k = 0; k < K; k++)
      mvin(gemmini_state.loop_ws_A + (i * gemmini_state.loop_ws_A_stride + k) * DIM * sizeof(elem_t),
           ((uint64_t)DIM << 48) | ((uint64_t)DIM << 32) | (A_sp + (i * K + k) * DIM), 0);
  for (uint16_t k = 0; k < K && gemmini_state.loop_ws_B != 0; k++)
    for (uint16_t j = 0; j < J; j++)
      mvin(gemmini_state.loop_ws_B + (k * gemmini_state.loop_ws_B_stride + j) * DIM * sizeof(elem_t),
           ((uint64_t)DIM << 48) | ((uint64_t)DIM << 32) | (B_sp + (k * J + j) * DIM), 1);

  gemmini_state.mx_loop_a_spad = A_sp;
  gemmini_state.mx_loop_b_spad = B_end;
  gemmini_state.mx_dram_C = gemmini_state.loop_ws_C;
  gemmini_state.mx_dram_C_stride = gemmini_state.loop_ws_C_stride;
  gemmini_state.mx_dram_out = true;
  mx_loop_ws_spad(ex_accumulate, 0);   // C_spad 0 (shadow acc base), no skips
  gemmini_state.mx_dram_out = false;
  gemmini_state.mx_loop_spad_marker = false;
}

void gemmini_t::mvout_spad(reg_t rs1, reg_t rs2) {
  (void)rs1; (void)rs2;
}

void gemmini_t::mx_loop_ws_spad(reg_t rs1, reg_t rs2) {
  using namespace mx;
  gemmini_state.mx_loop_spad_marker = true;
  gemmini_state.mx_loop_skips = (uint8_t)(rs2 & 0x3F);
  gemmini_state.mx_loop_reuse_tiled = ((rs2 >> 10) & 0x1) != 0;   // LOOP_WS_REQUANT_TILED
  // C8.3: mx_loop_scale_resident is no longer sourced here (rs2 bit11). It now comes from
  // gemmini_mxquant_config_mvout rs1 bit 62 (see mxquant_config_mvout), so the RTL requantizer
  // can see the same flag on the scale-config path. rs2 bit11 is left free.
  // rs1 bit 0 is `ex_accumulate`, exactly as in the stock loop_ws (:712). Every caller already
  // passes it -- gemmini_loop_ws_spad's macro ends `| ((full_C) << 1) | (ex_accumulate)` -- but this
  // handler used to discard rs1 wholesale, so the MX path ALWAYS accumulated.
  const bool ex_accumulate = rs1 & 1;

  const uint32_t C_spad = (uint32_t)((rs2 >> 32) & 0xFFFFFFFFu);
  const uint16_t TI = gemmini_state.loop_ws_I;
  const uint16_t TJ = gemmini_state.loop_ws_J;
  const uint16_t TK = gemmini_state.loop_ws_K;
  const uint32_t A_sp = gemmini_state.mx_loop_a_spad;
  const uint8_t actf = gemmini_state.mx_act_fmt;
  const uint8_t wgtf = gemmini_state.mx_wgt_fmt;

  // Decode a B (weight) nibble by the WEIGHT format, so act and weight may differ (asymmetric).
  // wgtf==2: fp4 direct; else weight-LUT deproject (fp6 e3m2/e2m3, or fp8 e4m3/e5m2 by altfmt).
  auto decode_B_nib = [&](uint8_t nib, int bcol) -> float {
    if (wgtf == 2) return fp4_e2m1_decode(nib);
    const int Gw = gemmini_state.mx_lut_update_granularity;
    const uint8_t code = gemmini_state.mx_lut_b[((size_t)(bcol >> Gw)) * 16 + nib];
    if (wgtf == 0) return gemmini_state.mx_wgt_altfmt ? fp8_e5m2_decode(code) : fp8_e4m3_decode(code);
    return gemmini_state.mx_wgt_altfmt ? fp6_e2m3_decode(code) : fp6_e3m2_decode(code);
  };

  const int prod_e = 4, prod_m = 3;
  // Mesh acc precision ramp, matching ConfigsFP dim{16,32}MxFPConfig meshAccPrecisionList
  // (Python frac = Scala sig-1). Lanes 0-15 = the dim16 ramp; lanes 16+ = bf16 (8,7).
  int8_t acc_e[DIM], acc_m[DIM];
  for (int kk = 0; kk < DIM; kk++) {
#if GEMMINI_DIM == 8
    acc_e[kk] = 8; acc_m[kk] = 7;   // DIM=8: ALL rows bf16 (design assumption -- no reduced-precision ramp)
#else
    if      (kk < 8)  { acc_e[kk] = 4; acc_m[kk] = 4; }
    else if (kk < 10) { acc_e[kk] = 4; acc_m[kk] = 5; }
    else if (kk < 15) { acc_e[kk] = 4; acc_m[kk] = 6; }
    else              { acc_e[kk] = 8; acc_m[kk] = 7; }
#endif
  }
  const int GROUP = 32;
  const size_t smem_base = (size_t)C_spad * DIM;
  // RTL applies the store activation (config_st acc_act) on the acc READ path: ReLU affects what is
  // stored, never the accumulator itself (K-tiles keep accumulating pre-ReLU partial sums).
  const bool out_relu = gemmini_state.acc_act == gemmini_state_t::RELU;
  auto relu_bf16 = [&](uint16_t v) -> uint16_t { return (out_relu && (v & 0x8000)) ? 0 : v; };

  // Stock loop_ws drops the accumulator's accumulate bit on the first k-tile when the caller asked
  // to overwrite (`if (!ex_accumulate && k == 0)`, :848), which is what lets a C region be reused.
  // The MX path had no equivalent: it did `smem[idx] = bf16_accum_add(prev, scaled)` unconditionally,
  // so every matmul added to whatever that region already held. That forced callers to keep each C
  // region disjoint for the whole life of the program -- and silently corrupted any that reused one,
  // since mvout frees the SPAD rows but never touches this shadow accumulator. Honour the bit here.
  // Zeroing the region up front is equivalent to the per-tile guard and costs one pass.
  auto clear_smem_if_overwrite = [&](int M_out, int N_out) {
    if (ex_accumulate) return;
    const size_t n = (size_t)M_out * (size_t)N_out;
    for (size_t w = 0; w < n; w++) {
      const size_t idx = smem_base + w;
      if (idx >= gemmini_state.mx_smem.size()) break;
      gemmini_state.mx_smem[idx] = 0;
    }
  };

  // Internal-spad model (standalone MxGemminiRocket): deposit the MX output (already computed into
  // mx_smem, row-major) into the normal scratchpad at C_spad so a regular mvout drains it -- same as
  // the RTL, which routes the requant/BF16 output back into its internal scratchpad. mvout copies
  // spad bytes raw (DIM int8/row), so byte k of the packed output -> spad[C_spad + k/DIM][k%DIM].
  // Output word count W (uint16): BF16=M*N, FP8=M*N/2, FP4/FP6=M*N/4 (packing), from mx_out_fmt.
  auto deposit_to_spad = [&](int M_out, int N_out) {
    if (gemmini_state.mx_dram_out) {   // native DRAM loop: BF16 C -> DRAM, row pitch C_stride elements
      if (gemmini_state.mx_dram_C == 0) return;
      for (int m = 0; m < M_out; m++)
        for (int n = 0; n < N_out; n++)
          p->get_mmu()->store<uint16_t>(gemmini_state.mx_dram_C + ((reg_t)m * gemmini_state.mx_dram_C_stride + n) * 2,
                                        relu_bf16(gemmini_state.mx_smem[smem_base + (size_t)m * N_out + n]));
      return;
    }
    const size_t out_elems = (size_t)M_out * (size_t)N_out;
    // Symmetric output encoding: only PLAIN E4M3-single (fp8/code0, altfmt0, no LUT) is 8-bit direct.
    // Every LUT sub-format -- E4M3-quad, E5M2 (fp8/altfmt1), E3M2/E2M3 (fp6), FP4 -- writes 4-bit LUT
    // indices (0.5 byte/elem), per the "always 4-bit LUT index" requant-output convention.
    const bool out_e4m3_single = (gemmini_state.mx_out_fmt == 0) &&
                                 !gemmini_state.mx_fp8_altfmt && !gemmini_state.mx_lut_en;
    const size_t W = (gemmini_state.mx_out_fmt == 3) ? out_elems        // BF16: 1 u16/elem
                   : out_e4m3_single                 ? out_elems / 2     // E4M3-single: 1 byte/elem
                   :                                    out_elems / 4;   // 4-bit LUT / FP4: 0.5 byte/elem
    const size_t need = (size_t)C_spad + (2 * W + DIM - 1) / DIM + 1;
    if (gemmini_state.spad.size() < need)
      gemmini_state.spad.resize(need, std::vector<elem_t>(DIM, 0));
    // LOOP_WS_REQUANT_TILED (rs2 bit10): deposit the requant output in the BLOCK-TILED operand-A
    // layout instead of flat row-major, so the resident output can be re-read in place as the next
    // matmul's operand A (chained matmul, zero DRAM). Only for requant formats (FP8/FP4/FP6); BF16
    // non-requant keeps flat. Byte k (0..2W-1) of the packed output = element (hw=k/N, col=k%N)
    // [hw = m for FP8, m/2 for the nibble formats, exactly as operand A is packed]. Tiled address =
    // C_spad + (i*tiles_N + nt)*DIM + r, byte col%DIM (i=hw/DIM, r=hw%DIM, nt=col/DIM) -- identical
    // to the operand-A read A_sp + (i*tiles_K + kt)*DIM + r. Flat is byte k -> C_spad+k/DIM,k%DIM.
    const bool tiled = gemmini_state.mx_loop_reuse_tiled && (gemmini_state.mx_out_fmt != 3);
    const size_t tiles_N = (size_t)N_out / (size_t)DIM;
    for (size_t w = 0; w < W; w++) {
      const uint16_t v = gemmini_state.mx_out_fmt == 3 ? relu_bf16(gemmini_state.mx_smem[smem_base + w])
                                                       : gemmini_state.mx_smem[smem_base + w];
      for (int half = 0; half < 2; half++) {
        const size_t k = 2 * w + (size_t)half;
        const elem_t byte = (elem_t)((half == 0) ? (v & 0xFF) : ((v >> 8) & 0xFF));
        size_t row, col;
        if (tiled) {
          const size_t hw = k / (size_t)N_out, c = k % (size_t)N_out;
          row = (size_t)C_spad + ((hw / DIM) * tiles_N + c / DIM) * DIM + (hw % DIM);
          col = c % (size_t)DIM;
        } else {
          row = (size_t)C_spad + k / DIM;
          col = k % DIM;
        }
        gemmini_state.spad[row][col] = byte;
      }
    }
  };

  if (actf == 0 && !gemmini_state.mx_fp8_altfmt && !gemmini_state.mx_lut_a_loaded) {
    // E4M3-single ACTIVATION (direct 8-bit, 1 row/lane). The WEIGHT is single (E4M3 direct, 1 col/lane
    // -> 16x16 tile) OR quad (fp4/fp6/E5M2 nibble-packed, 2 col/lane -> 16x32 tile). This is the
    // single x quad "dual throughput" case (modes 6/7): TM=16 always (single act), TN=32 iff wgt quad.
    const bool wgt_quad = (wgtf != 0) || gemmini_state.mx_wgt_altfmt;
    const int TM = DIM;
    const int TN = wgt_quad ? 2*DIM : DIM;
    const uint32_t B_sp = gemmini_state.mx_loop_b_spad - (uint32_t)TK * TJ * DIM;
    const int M_DIM = TI * TM;
    const int N_DIM = TJ * TN;
    clear_smem_if_overwrite(M_DIM, N_DIM);

    // Single act x single wgt: model the RTL ScaleFactorMem read address -- tile counters (i fastest)
    // that wrap at the CONFIG_SCALE_MEM bounds and persist across loops, plus the act/wgt half select
    // (+4096B). Byte = sel*4096 + (bound*(ck >> log2(32/DIM)) + c)*DIM + lane. Equals the per-loop
    // formula below when bounds == loop dims and the counters start at 0. Quad weights keep that formula.
    const bool sc_rtl = !wgt_quad;
    int sc_kshift = 0;
    while ((DIM << sc_kshift) < GROUP) sc_kshift++;
    const size_t SC_HALF = 4096;
    const uint16_t sc_lbi = gemmini_state.mx_tiles_I ? gemmini_state.mx_tiles_I : 1;
    const uint16_t sc_lbj = gemmini_state.mx_tiles_J ? gemmini_state.mx_tiles_J : 1;
    const uint16_t sc_lbk = gemmini_state.mx_tiles_K ? gemmini_state.mx_tiles_K : 1;
    uint16_t &sc_ci = gemmini_state.mx_sc_ci, &sc_cj = gemmini_state.mx_sc_cj, &sc_ck = gemmini_state.mx_sc_ck;

    for (uint16_t k_outer = 0; k_outer < TK; k_outer++) {
      const size_t group = (size_t)(k_outer * DIM) / GROUP;
      for (uint16_t j = 0; j < TJ; j++) {
        for (uint16_t i = 0; i < TI; i++) {
          const uint32_t A_t = A_sp + (i * TK + k_outer) * DIM;
          const uint32_t B_t = B_sp + (k_outer * TJ + j) * DIM;
          const size_t sc_kb = (size_t)(sc_ck >> sc_kshift);
          const size_t sc_a = gemmini_state.mx_scale_act_sel * SC_HALF + ((size_t)sc_lbi * sc_kb + sc_ci) * DIM;
          const size_t sc_b = gemmini_state.mx_scale_wgt_sel * SC_HALF + ((size_t)sc_lbj * sc_kb + sc_cj) * DIM;
          std::vector<std::vector<float>> Ct(TM, std::vector<float>(TN, 0.0f));
          for (int kk = 0; kk < DIM; kk++) {
            float A_col[DIM], B_row[2*DIM];
            for (int r = 0; r < TM; r++)
              A_col[r] = fp8_e4m3_decode(gemmini_state.spad.at(A_t + r).at(kk));
            for (int c = 0; c < TN; c++) {
              if (wgt_quad) {
                uint8_t byte = (uint8_t)gemmini_state.spad.at(B_t + kk).at(c >> 1);
                uint8_t nib  = (c & 1) ? ((byte >> 4) & 0xF) : (byte & 0xF);
                B_row[c] = decode_B_nib(nib, j * TN + c);
              } else {
                B_row[c] = fp8_e4m3_decode(gemmini_state.spad.at(B_t + kk).at(c));
              }
            }
            const int ae = acc_e[kk], am = acc_m[kk];
            for (int r = 0; r < TM; r++)
              for (int c = 0; c < TN; c++) {
                float p  = mx_product_quantize_trunc(A_col[r] * B_row[c], prod_e, prod_m);
                float Cq = fp_quantize_rne(Ct[r][c], ae, am);
                float pq = fp_quantize_rne(p, ae, am);
                Ct[r][c] = fp_add_exact(Cq, pq, ae, am);
              }
          }
          for (int r = 0; r < TM; r++)
            for (int c = 0; c < TN; c++) {
              const size_t a_off = sc_rtl ? sc_a + r : group * (size_t)M_DIM + (size_t)(i*TM + r);
              const size_t b_off = sc_rtl ? sc_b + c : group * (size_t)N_DIM + (size_t)(j*TN + c);
              const uint8_t sa = (a_off < gemmini_state.mx_scale_a_mem.size()) ? gemmini_state.mx_scale_a_mem[a_off] : 0x7f;
              const uint8_t sb = (b_off < gemmini_state.mx_scale_b_mem.size()) ? gemmini_state.mx_scale_b_mem[b_off] : 0x7f;
              int e = (int)sa + (int)sb - 127;
              uint8_t s_code = (e < 0) ? 0 : (e > 254 ? 254 : (uint8_t)e);
              float s = fpe8m0_decode(s_code);
              float scaled = bf16_round(Ct[r][c] * s);
              const size_t idx = smem_base + (size_t)(i*TM + r) * N_DIM + (j*TN + c);
              if (idx >= gemmini_state.mx_smem.size()) continue;
              float prev = bf16_to_f32(gemmini_state.mx_smem[idx]);
              gemmini_state.mx_smem[idx] = f32_to_bf16_rne(bf16_accum_add(prev, scaled));
            }
          if (sc_rtl) {   // one counter step per tile, in the RTL's order (i, then j, then k)
            if (sc_ci + 1 < sc_lbi) sc_ci++;
            else {
              sc_ci = 0;
              if (sc_cj + 1 < sc_lbj) sc_cj++;
              else { sc_cj = 0; sc_ck = (sc_ck + 1 < sc_lbk) ? sc_ck + 1 : 0; }
            }
          }
        }
      }
    }

    // FP8 requant post-pass: when out_mx_fmt == 0 (FP8 E4M3) we replace the BF16
    // tile contents in-place with packed FP8 codes (2 per uint16_t) and emit
    // per-row per-N-group e8m0 scale codes to user DRAM at mx_scale_dram.
    if (gemmini_state.mx_out_fmt == 0) {
      const int GROUP_OUT = 32;
      const int N_blocks = N_DIM / GROUP_OUT;
      const reg_t scale_dram = gemmini_state.mx_scale_dram;
      for (int m = 0; m < M_DIM; m++) {
        for (int bi = 0; bi < N_blocks; bi++) {
          // Block max. Non-finite values are tracked SEPARATELY because NaN loses every `>`
          // comparison and would otherwise be invisible here; the reference propagates it
          // (torch's amax does), and an overflow that silently becomes a plausible block is the
          // single worst failure mode this path had.
          float max_abs = 0.0f;
          bool has_nan = false, has_inf = false;
          for (int j = bi * GROUP_OUT; j < (bi + 1) * GROUP_OUT; j++) {
            const size_t idx = smem_base + (size_t)m * N_DIM + j;
            float v = bf16_to_f32(relu_bf16(gemmini_state.mx_smem[idx]));
            if (std::isnan(v)) { has_nan = true; continue; }
            if (std::isinf(v)) { has_inf = true; continue; }
            float a = fabsf(v);
            if (a > max_abs) max_abs = a;
          }
          // MXQuant's end-to-end convention (MXQuant/end_to_end_linear/mx_block_quant.py::_po2):
          //   X = 2^floor(log2(max(amax, FLT_EPSILON)))
          // There is NO `- emax` term, so a block's max lands in [1,2) rather than [256,512).
          // See planning/chain_seam_hw_notes.md §8: this is the convention the LLM evaluations
          // use, and it also puts 16*|A|max*|B|max four times UNDER the mesh accumulator's 2^8
          // bound, which is what made chained MX matmuls overflow. Matches the RTL's
          // log2_pmax_floor = 0 (MxRequantizer.scala).
          // The eps clamp subsumes the all-zero block (amax == 0 -> code 104), so there is no
          // separate sentinel -- and with it goes the old ambiguity where code 0 meant both
          // "all-zero block" and "the accumulator overflowed".
          uint8_t scale_code;
          float scale;
          if (has_nan || has_inf) {
            scale_code = 0xFF;                    // E8M0 NaN -- the only out-of-band code E8M0 has
            // Reproduce the reference's X exactly so the element codes match byte-for-byte:
            // /inf sends finite siblings to 0 and the inf itself to NaN; /nan sends all to NaN.
            scale = has_nan ? (float)NAN : (float)INFINITY;
          } else {
            const float amax = (max_abs < FLT_EPSILON) ? FLT_EPSILON : max_abs;
            int s = (int)floorf(log2f(amax)) + 127;
            if (s < 0) s = 0;
            if (s > 254) s = 254;
            scale_code = (uint8_t)s;
            scale = ldexpf(1.0f, (int)scale_code - 127);
          }
          if (scale_dram != 0) {
            p->get_mmu()->store<uint8_t>(scale_dram + (reg_t)m * N_blocks + bi, scale_code);
          }
          // C8.1 scale residency: also write the act-scale window in TRANSPOSED [GN][M] layout
          // (a_off = block*M + row), so the next matmul reads these as its A-scales in place -- no
          // DRAM round-trip / SW reload. Runs in the STORE phase (after this matmul's compute has
          // finished reading the current A-scales), so no read/write race on Spike. Gated flag.
          if (gemmini_state.mx_loop_scale_resident) {
            const size_t a_off_out = (size_t)bi * (size_t)M_DIM + (size_t)m;
            if (a_off_out >= gemmini_state.mx_scale_a_mem.size())
              gemmini_state.mx_scale_a_mem.resize(a_off_out + 1, 0x7f);
            gemmini_state.mx_scale_a_mem[a_off_out] = scale_code;
          }
          // Snapshot BF16 values first; subsequent FP8 packing overwrites the
          // BF16 cells for the same row, so reading after writing would corrupt
          // later iterations.
          float vals[32];
          for (int j = bi * GROUP_OUT; j < (bi + 1) * GROUP_OUT; j++) {
            const size_t idx = smem_base + (size_t)m * N_DIM + j;
            vals[j - bi * GROUP_OUT] = bf16_to_f32(relu_bf16(gemmini_state.mx_smem[idx]));
          }
          for (int jj = 0; jj < GROUP_OUT; jj++) {
            const int j = bi * GROUP_OUT + jj;
            uint8_t code = mx::fp8_e4m3_to_code(vals[jj] / scale);
            const size_t byte_idx = (size_t)m * N_DIM + j;
            const size_t u16_idx  = smem_base + byte_idx / 2;
            uint16_t cur = gemmini_state.mx_smem[u16_idx];
            if (byte_idx & 1) cur = (cur & 0x00FF) | ((uint16_t)code << 8);
            else              cur = (cur & 0xFF00) |  (uint16_t)code;
            gemmini_state.mx_smem[u16_idx] = cur;
          }
        }
      }
    }
    deposit_to_spad(M_DIM, N_DIM);
    return;
  }

  if (actf == 1 || (actf == 0 && (gemmini_state.mx_lut_a_loaded || gemmini_state.mx_fp8_altfmt))) {
    // LUT path (4-wide) for the ACTIVATION (quad, 2 rows/lane). A in spad is 4-bit LUT indices. The
    // WEIGHT is quad (nibble LUT indices, TN=32) OR E4M3-single (direct 8-bit, 1 col/lane, TN=16 ->
    // 32x16 dual-throughput tile, modes 2/5). wgt_single = fp8/code0, altfmt0, no weight LUT loaded.
    const bool wgt_single = (wgtf == 0) && !gemmini_state.mx_wgt_altfmt && !gemmini_state.mx_lut_b_loaded;
    const int TM = 2*DIM;
    const int TN = wgt_single ? DIM : 2*DIM;
    const uint32_t B_sp = gemmini_state.mx_loop_b_spad - (uint32_t)TK * TJ * DIM;
    const int M_DIM = TI * TM;
    const int N_DIM = TJ * TN;
    clear_smem_if_overwrite(M_DIM, N_DIM);
    const int G = gemmini_state.mx_lut_update_granularity;
    // Decode by (code, altfmt): fp8 -> altfmt? E5M2 : E4M3 ; fp6 -> altfmt? E2M3 : E3M2.
    float (*lut_decode)(uint8_t) = (actf == 0)
      ? (gemmini_state.mx_fp8_altfmt ? fp8_e5m2_decode : fp8_e4m3_decode)
      : (gemmini_state.mx_fp8_altfmt ? fp6_e2m3_decode : fp6_e3m2_decode);

    for (uint16_t k_outer = 0; k_outer < TK; k_outer++) {
      const size_t group = (size_t)(k_outer * DIM) / GROUP;
      for (uint16_t j = 0; j < TJ; j++) {
        for (uint16_t i = 0; i < TI; i++) {
          const uint32_t A_t = A_sp + (i * TK + k_outer) * DIM;
          const uint32_t B_t = B_sp + (k_outer * TJ + j) * DIM;
          std::vector<std::vector<float>> Ct(TM, std::vector<float>(TN, 0.0f));
          for (int kk = 0; kk < DIM; kk++) {
            float A_col[2*DIM], B_row[2*DIM];
            for (int m = 0; m < TM; m++) {
              uint8_t byte = (uint8_t)gemmini_state.spad.at(A_t + (m >> 1)).at(kk);
              uint8_t nib = (m & 1) ? ((byte >> 4) & 0xF) : (byte & 0xF);
              const size_t lut_idx = (size_t)((i * TM + m) >> G);
              const uint8_t code = gemmini_state.mx_lut_a[lut_idx * 16 + nib];
              A_col[m] = lut_decode(code);
            }
            for (int n = 0; n < TN; n++) {
              if (wgt_single) {
                B_row[n] = fp8_e4m3_decode((uint8_t)gemmini_state.spad.at(B_t + kk).at(n));
              } else {
                uint8_t byte = (uint8_t)gemmini_state.spad.at(B_t + kk).at(n >> 1);
                uint8_t nib = (n & 1) ? ((byte >> 4) & 0xF) : (byte & 0xF);
                B_row[n] = decode_B_nib(nib, j * TN + n);
              }
            }
            const int ae = acc_e[kk], am = acc_m[kk];
            for (int r = 0; r < TM; r++)
              for (int c = 0; c < TN; c++) {
                float p  = mx_product_quantize_trunc(A_col[r] * B_row[c], prod_e, prod_m);
                float Cq = fp_quantize_rne(Ct[r][c], ae, am);
                float pq = fp_quantize_rne(p, ae, am);
                Ct[r][c] = fp_add_exact(Cq, pq, ae, am);
              }
          }
          for (int r = 0; r < TM; r++)
            for (int c = 0; c < TN; c++) {
              const size_t a_off = group * (size_t)M_DIM + (size_t)(i*TM + r);
              const size_t b_off = group * (size_t)N_DIM + (size_t)(j*TN + c);
              const uint8_t sa = (a_off < gemmini_state.mx_scale_a_mem.size()) ? gemmini_state.mx_scale_a_mem[a_off] : 0x7f;
              const uint8_t sb = (b_off < gemmini_state.mx_scale_b_mem.size()) ? gemmini_state.mx_scale_b_mem[b_off] : 0x7f;
              int e = (int)sa + (int)sb - 127;
              uint8_t s_code = (e < 0) ? 0 : (e > 254 ? 254 : (uint8_t)e);
              float s = fpe8m0_decode(s_code);
              float scaled = bf16_round(Ct[r][c] * s);
              const size_t idx = smem_base + (size_t)(i*TM + r) * N_DIM + (j*TN + c);
              if (idx >= gemmini_state.mx_smem.size()) continue;
              float prev = bf16_to_f32(gemmini_state.mx_smem[idx]);
              gemmini_state.mx_smem[idx] = f32_to_bf16_rne(bf16_accum_add(prev, scaled));
            }
        }
      }
    }

    // FP6 requant post-pass: when out_mx_fmt == 1 project each BF16 value
    // onto the per-row C_lut and pack the resulting 4-bit LUT index in HW-tiled
    // layout (byte (m/2, j): low nibble for m=2r, high for m=2r+1).
    // Symmetric 4-bit-LUT requant output. Which sub-format is written is chosen by (mx_out_fmt, altfmt):
    //   fp8/code0 + altfmt1 -> E5M2 (log2_pmax=16); fp6/code1 + altfmt0 -> E3M2 (4); + altfmt1 -> E2M3 (2).
    // All three pack 4-bit LUT indices (nibble-packed, HW-tiled) via the per-row C_lut nearest-finder.
    const bool alt_out       = gemmini_state.mx_fp8_altfmt != 0;
    const bool out_e5m2      = (gemmini_state.mx_out_fmt == 0) && alt_out;
    // E4M3-quad: code0/altfmt0 requant output, but we are in the LUT branch (lut_en set), so it emits
    // 4-bit LUT indices like the others. E4M3-single (non-lut) never reaches here (handled 8-bit above).
    const bool out_e4m3_quad = (gemmini_state.mx_out_fmt == 0) && !alt_out;
    const bool out_e2m3      = (gemmini_state.mx_out_fmt == 1) && alt_out;
    const bool out_e3m2      = (gemmini_state.mx_out_fmt == 1) && !alt_out;
    if (out_e5m2 || out_e4m3_quad || out_e2m3 || out_e3m2) {
      const int GROUP_OUT = 32;
      const int N_blocks  = N_DIM / GROUP_OUT;
      // log2_pmax = 0 (_po2 convention) for every nibble/LUT output so a chained requant result normalizes
      // into [1,2) and stays within the next matmul's accumulator/finder range (was emax = 1<<(e_bits-1)).
      const int log2_pmax = 0;
      const reg_t scale_dram = gemmini_state.mx_scale_dram;
      for (int m = 0; m < M_DIM; m++) {
        const size_t lut_idx = (size_t)(m >> G);
        const uint8_t *lut_codes = &gemmini_state.mx_lut_c[lut_idx * 16];
        for (int bi = 0; bi < N_blocks; bi++) {
          float vals[32];
          float max_abs = 0.0f;
          for (int jj = 0; jj < GROUP_OUT; jj++) {
            const int j = bi * GROUP_OUT + jj;
            float v = bf16_to_f32(gemmini_state.mx_smem[smem_base + (size_t)m * N_DIM + j]);
            vals[jj] = v;
            float a = fabsf(v);
            if (a > max_abs) max_abs = a;
          }
          uint8_t scale_code;
          if (max_abs == 0.0f) {
            scale_code = 0;
          } else {
            int max_exp = (int)floorf(log2f(max_abs));
            int s = (max_exp - log2_pmax) + 127;
            if (s < 0) s = 0;
            if (s > 254) s = 254;
            scale_code = (uint8_t)s;
          }
          if (scale_dram != 0) {
            p->get_mmu()->store<uint8_t>(scale_dram + (reg_t)m * N_blocks + bi, scale_code);
          }
          // C8.1 scale residency: also write the act-scale window in TRANSPOSED [GN][M] layout
          // (a_off = block*M + row), so the next matmul reads these as its A-scales in place -- no
          // DRAM round-trip / SW reload. Runs in the STORE phase (after this matmul's compute has
          // finished reading the current A-scales), so no read/write race on Spike. Gated flag.
          if (gemmini_state.mx_loop_scale_resident) {
            const size_t a_off_out = (size_t)bi * (size_t)M_DIM + (size_t)m;
            if (a_off_out >= gemmini_state.mx_scale_a_mem.size())
              gemmini_state.mx_scale_a_mem.resize(a_off_out + 1, 0x7f);
            gemmini_state.mx_scale_a_mem[a_off_out] = scale_code;
          }
          float scale = fpe8m0_decode(scale_code);
          for (int jj = 0; jj < GROUP_OUT; jj++) {
            const int j = bi * GROUP_OUT + jj;
            float scaled = vals[jj] / scale;
            uint16_t scaled_bf16 = f32_to_bf16_rne(scaled);
            uint8_t elem_code = out_e5m2      ? bf16_bits_to_e5m2_code(scaled_bf16)
                              : out_e4m3_quad ? fp8_e4m3_to_code(bf16_to_f32(scaled_bf16))
                              : out_e2m3      ? bf16_bits_to_fp6_e2m3_code(scaled_bf16)
                                              : bf16_bits_to_fp6_e3m2_code(scaled_bf16);
            uint8_t code = (uint8_t)(out_e5m2      ? fp8_e5m2_nearest_finder(elem_code, lut_codes)
                                   : out_e4m3_quad ? fp8_e4m3_nearest_finder(elem_code, lut_codes)
                                   : out_e2m3      ? fp6e2m3_nearest_finder(elem_code, lut_codes)
                                                   : fp6e3m2_nearest_finder(elem_code, lut_codes));
            const size_t byte_pos = (size_t)(m >> 1) * N_DIM + j;
            const size_t u16_idx  = smem_base + byte_pos / 2;
            uint16_t cur = gemmini_state.mx_smem[u16_idx];
            uint8_t byte = (byte_pos & 1) ? ((cur >> 8) & 0xFF) : (cur & 0xFF);
            if (m & 1) byte = (uint8_t)((byte & 0x0F) | ((code & 0xF) << 4));
            else       byte = (uint8_t)((byte & 0xF0) |  (code & 0xF));
            if (byte_pos & 1) cur = (uint16_t)((cur & 0x00FF) | ((uint16_t)byte << 8));
            else              cur = (uint16_t)((cur & 0xFF00) |  (uint16_t)byte);
            gemmini_state.mx_smem[u16_idx] = cur;
          }
        }
      }
    }
    deposit_to_spad(M_DIM, N_DIM);
    return;
  }

  if (actf == 2) {
    // FP4 ACTIVATION (quad, 2 rows/lane). WEIGHT is quad (nibble, TN=32) OR E4M3-single (direct 8-bit,
    // TN=16 -> 32x16 dual-throughput tile, mode2). wgt_single = fp8/code0, altfmt0, no weight LUT.
    const bool wgt_single = (wgtf == 0) && !gemmini_state.mx_wgt_altfmt && !gemmini_state.mx_lut_b_loaded;
    const int TM = 2*DIM;
    const int TN = wgt_single ? DIM : 2*DIM;
    const uint32_t B_sp = gemmini_state.mx_loop_b_spad - (uint32_t)TK * TJ * DIM;
    const int M_DIM = TI * TM;
    const int N_DIM = TJ * TN;
    clear_smem_if_overwrite(M_DIM, N_DIM);

    for (uint16_t k_outer = 0; k_outer < TK; k_outer++) {
      const size_t group = (size_t)(k_outer * DIM) / GROUP;
      for (uint16_t j = 0; j < TJ; j++) {
        for (uint16_t i = 0; i < TI; i++) {
          const uint32_t A_t = A_sp + (i * TK + k_outer) * DIM;
          const uint32_t B_t = B_sp + (k_outer * TJ + j) * DIM;
          std::vector<std::vector<float>> Ct(TM, std::vector<float>(TN, 0.0f));
          for (int kk = 0; kk < DIM; kk++) {
            float A_col[2*DIM], B_row[2*DIM];
            for (int m = 0; m < TM; m++) {
              uint8_t byte = (uint8_t)gemmini_state.spad.at(A_t + (m >> 1)).at(kk);
              uint8_t nib = (m & 1) ? ((byte >> 4) & 0xF) : (byte & 0xF);
              A_col[m] = fp4_e2m1_decode(nib);
            }
            for (int n = 0; n < TN; n++) {
              if (wgt_single) {
                B_row[n] = fp8_e4m3_decode((uint8_t)gemmini_state.spad.at(B_t + kk).at(n));
              } else {
                uint8_t byte = (uint8_t)gemmini_state.spad.at(B_t + kk).at(n >> 1);
                uint8_t nib = (n & 1) ? ((byte >> 4) & 0xF) : (byte & 0xF);
                B_row[n] = decode_B_nib(nib, j * TN + n);
              }
            }
            const int ae = acc_e[kk], am = acc_m[kk];
            for (int r = 0; r < TM; r++)
              for (int c = 0; c < TN; c++) {
                float p  = mx_product_quantize_trunc(A_col[r] * B_row[c], prod_e, prod_m);
                float Cq = fp_quantize_rne(Ct[r][c], ae, am);
                float pq = fp_quantize_rne(p, ae, am);
                Ct[r][c] = fp_add_exact(Cq, pq, ae, am);
              }
          }
          for (int r = 0; r < TM; r++)
            for (int c = 0; c < TN; c++) {
              const size_t a_off = gemmini_state.mx_scale_act_sel * 4096 + group * (size_t)M_DIM + (size_t)(i*TM + r);
              const size_t b_off = gemmini_state.mx_scale_wgt_sel * 4096 + group * (size_t)N_DIM + (size_t)(j*TN + c);
              const uint8_t sa = (a_off < gemmini_state.mx_scale_a_mem.size()) ? gemmini_state.mx_scale_a_mem[a_off] : 0x7f;
              const uint8_t sb = (b_off < gemmini_state.mx_scale_b_mem.size()) ? gemmini_state.mx_scale_b_mem[b_off] : 0x7f;
              int e = (int)sa + (int)sb - 127;
              uint8_t s_code = (e < 0) ? 0 : (e > 254 ? 254 : (uint8_t)e);
              float s = fpe8m0_decode(s_code);
              float scaled = bf16_round(Ct[r][c] * s);
              const size_t idx = smem_base + (size_t)(i*TM + r) * N_DIM + (j*TN + c);
              if (idx >= gemmini_state.mx_smem.size()) continue;
              float prev = bf16_to_f32(gemmini_state.mx_smem[idx]);
              gemmini_state.mx_smem[idx] = f32_to_bf16_rne(bf16_accum_add(prev, scaled));
            }
        }
      }
    }

    // FP4 requant post-pass: when out_mx_fmt == 2 we replace the BF16 tile
    // contents in mx_smem with packed 4-bit FP4 codes in HW-tiled layout
    // (byte at (m/2, j): low nibble = code for m=2r, high = m=2r+1), and emit
    // per-row per-N-group e8m0 scale codes to user DRAM at mx_scale_dram.
    if (gemmini_state.mx_out_fmt == 2) {
      const int GROUP_OUT = 32;
      const int N_blocks  = N_DIM / GROUP_OUT;
      const int log2_pmax = 0;  // _po2 convention (was 2) so chained FP4 requant output stays in range
      const reg_t scale_dram = gemmini_state.mx_scale_dram;
      for (int m = 0; m < M_DIM; m++) {
        for (int bi = 0; bi < N_blocks; bi++) {
          float vals[32];
          float max_abs = 0.0f;
          for (int j = bi * GROUP_OUT; j < (bi + 1) * GROUP_OUT; j++) {
            const size_t idx = smem_base + (size_t)m * N_DIM + j;
            float v = bf16_to_f32(gemmini_state.mx_smem[idx]);
            vals[j - bi * GROUP_OUT] = v;
            float a = fabsf(v);
            if (a > max_abs) max_abs = a;
          }
          uint8_t scale_code;
          if (max_abs == 0.0f) {
            scale_code = 0;
          } else {
            int max_exp = (int)floorf(log2f(max_abs));
            int s = (max_exp - log2_pmax) + 127;
            if (s < 0) s = 0;
            if (s > 254) s = 254;
            scale_code = (uint8_t)s;
          }
          if (scale_dram != 0) {
            p->get_mmu()->store<uint8_t>(scale_dram + (reg_t)m * N_blocks + bi, scale_code);
          }
          // C8.1 scale residency: also write the act-scale window in TRANSPOSED [GN][M] layout
          // (a_off = block*M + row), so the next matmul reads these as its A-scales in place -- no
          // DRAM round-trip / SW reload. Runs in the STORE phase (after this matmul's compute has
          // finished reading the current A-scales), so no read/write race on Spike. Gated flag.
          if (gemmini_state.mx_loop_scale_resident) {
            const size_t a_off_out = (size_t)bi * (size_t)M_DIM + (size_t)m;
            if (a_off_out >= gemmini_state.mx_scale_a_mem.size())
              gemmini_state.mx_scale_a_mem.resize(a_off_out + 1, 0x7f);
            gemmini_state.mx_scale_a_mem[a_off_out] = scale_code;
          }
          float scale = fpe8m0_decode(scale_code);
          for (int jj = 0; jj < GROUP_OUT; jj++) {
            const int j = bi * GROUP_OUT + jj;
            // Match Python: q_bf16_rne(block / scale) then hw_bf16_to_e2m1.
            uint16_t scaled_bf16 = f32_to_bf16_rne(vals[jj] / scale);
            uint8_t code = mx::bf16_bits_to_fp4_e2m1_code(scaled_bf16);
            // HW-tiled: byte (m/2, j) holds (m even => low nibble, m odd => high).
            const size_t byte_pos = (size_t)(m >> 1) * N_DIM + j;
            const size_t u16_idx  = smem_base + byte_pos / 2;
            uint16_t cur = gemmini_state.mx_smem[u16_idx];
            uint8_t byte = (byte_pos & 1) ? ((cur >> 8) & 0xFF) : (cur & 0xFF);
            if (m & 1) byte = (uint8_t)((byte & 0x0F) | ((code & 0xF) << 4));
            else       byte = (uint8_t)((byte & 0xF0) |  (code & 0xF));
            if (byte_pos & 1) cur = (uint16_t)((cur & 0x00FF) | ((uint16_t)byte << 8));
            else              cur = (uint16_t)((cur & 0xFF00) |  (uint16_t)byte);
            gemmini_state.mx_smem[u16_idx] = cur;
          }
        }
      }
    }
    deposit_to_spad(M_DIM, N_DIM);
    return;
  }
}

void gemmini_t::loop_conv_ws(reg_t rs1, reg_t rs2) {
  const bool no_bias = rs1 & 1;
  const bool wrot180 = (rs1 >> 1) & 1;
  const bool trans_output_1203 = (rs1 >> 2) & 1;
  const bool trans_weight_1203 = (rs1 >> 3) & 1;
  const bool trans_weight_0132 = (rs1 >> 4) & 1;
  const bool trans_input_3120 = (rs1 >> 5) & 1;
  const bool dw = (rs1 >> 6) & 1;
  uint8_t max_pixels_per_row = (rs1 >> 8) & 0xFF;
  const bool no_pool = rs2 & 1;
  const bool downsample = (rs2 >> 1) & 1;
  const bool input_dilated = (rs2 >> 2) & 1;
  const bool activation = (rs2 >> 3) & 3;
  uint8_t a_spad_id = (rs1 >> 18) & 0b11;
  uint8_t b_spad_id = (rs1 >> 16) & 0b11;

  if (max_pixels_per_row == 0)
    max_pixels_per_row = 1;

#ifndef HAS_FIRST_LAYER_OPTIMIZATIONS
  assert(max_pixels_per_row <= 1, "If Gemmini is built without first-layer optimizations, then 'max_pixels_per_row' cannot be larger than 1\n");
#endif

  const uint16_t batch_size = gemmini_state.loop_conv_ws_batch_size;
  const uint16_t in_col_dim = gemmini_state.loop_conv_ws_in_col_dim;
  const uint16_t in_row_dim = gemmini_state.loop_conv_ws_in_row_dim;
  const uint16_t in_channels = gemmini_state.loop_conv_ws_in_channels;
  const uint16_t out_channels = gemmini_state.loop_conv_ws_out_channels;
  const uint16_t in_stride = gemmini_state.loop_conv_ws_in_stride;
  const uint16_t out_stride = gemmini_state.loop_conv_ws_out_stride;
  const uint16_t weight_stride = gemmini_state.loop_conv_ws_weight_stride;
  const uint16_t out_col_dim = gemmini_state.loop_conv_ws_out_col_dim;
  const uint16_t pool_out_col_dim = gemmini_state.loop_conv_ws_pool_out_col_dim;
  const uint16_t out_row_dim = gemmini_state.loop_conv_ws_out_row_dim;
  const uint16_t pool_out_row_dim = gemmini_state.loop_conv_ws_pool_out_row_dim;
  const uint16_t stride = gemmini_state.loop_conv_ws_stride;
  const uint16_t padding = gemmini_state.loop_conv_ws_padding;
  const uint16_t kernel_dim = gemmini_state.loop_conv_ws_kernel_dim;
  const uint16_t kernel_dilation = gemmini_state.loop_conv_ws_kernel_dilation;
  const uint16_t pool_size = gemmini_state.loop_conv_ws_pool_size;
  const uint16_t pool_stride = gemmini_state.loop_conv_ws_pool_stride;
  const uint16_t pool_padding = gemmini_state.loop_conv_ws_pool_padding;
  const uint16_t batches = gemmini_state.loop_conv_ws_batches;
  const uint16_t porows = gemmini_state.loop_conv_ws_porows;
  const uint16_t pocols = gemmini_state.loop_conv_ws_pocols;
  const uint16_t pochs = gemmini_state.loop_conv_ws_pochs;
  const uint16_t krows = gemmini_state.loop_conv_ws_krows;
  const uint16_t kcols = gemmini_state.loop_conv_ws_kcols;
  const uint16_t kchs = gemmini_state.loop_conv_ws_kchs;
  const uint16_t lpad = gemmini_state.loop_conv_ws_lpad;
  const uint16_t rpad = gemmini_state.loop_conv_ws_rpad;
  const uint16_t upad = gemmini_state.loop_conv_ws_upad;
  const uint16_t dpad = gemmini_state.loop_conv_ws_dpad;
  const uint16_t plpad = gemmini_state.loop_conv_ws_plpad;
  const uint16_t prad = gemmini_state.loop_conv_ws_prad;
  const uint16_t pupad = gemmini_state.loop_conv_ws_pupad;
  const uint16_t pdpad = gemmini_state.loop_conv_ws_pdpad;
  const uint16_t orows = gemmini_state.loop_conv_ws_orows;
  const uint16_t ocols = gemmini_state.loop_conv_ws_ocols;
  const uint64_t weights = gemmini_state.loop_conv_ws_weights;
  const uint64_t output = gemmini_state.loop_conv_ws_output;
  const uint64_t bias = gemmini_state.loop_conv_ws_bias;
  const uint64_t input = gemmini_state.loop_conv_ws_input;

  const uint16_t ochs = pochs;

  assert(!input_dilated || stride == 1);

  // Calculate image dimensions
  // Note: "irows" and "icols" includes padding
  const int16_t dilated_krows = krows + (kernel_dilation - 1)*(krows - 1);
  const int16_t dilated_kcols = kcols + (kernel_dilation - 1)*(kcols - 1);
  const int16_t irows_without_dilation = orows * stride + dilated_krows - 1; // - 2 * padding;
  const int16_t icols_without_dilation = ocols * stride + dilated_kcols - 1; // - 2 * padding;
  const int16_t irows_unpadded_without_dilation = irows_without_dilation - upad - dpad;
  const int16_t icols_unpadded_without_dilation = icols_without_dilation - lpad - rpad;
  const int16_t ichs = kchs;

#define UNDILATED(x) (((x) + (input_dilated)) >> (input_dilated))

  const int16_t irows_unpadded = input_dilated ? (irows_unpadded_without_dilation+1)/2 : irows_unpadded_without_dilation;
  const int16_t icols_unpadded = input_dilated ? (icols_unpadded_without_dilation+1)/2 : icols_unpadded_without_dilation;

  const int16_t irows = input_dilated ? irows_unpadded + UNDILATED(upad) + UNDILATED(dpad) : irows_without_dilation;
  const int16_t icols = input_dilated ? icols_unpadded + UNDILATED(lpad) + UNDILATED(rpad) : icols_without_dilation;

  const int out_channels_per_bank = ochs / DIM + (ochs % DIM != 0);
  const int in_channels_per_bank = kchs / DIM + (kchs % DIM != 0);
  const int B_rows = trans_weight_0132 ?
      in_channels_per_bank * kcols * krows * ochs :
      out_channels_per_bank * kcols * krows * kchs;

  static uint32_t D_sp_addr_row = 0;
  static uint32_t C_sp_addr_row = 0;

  uint32_t A_sp_addr_start = 0;
  uint32_t B_sp_addr_start = BANK_NUM * BANK_ROWS / 2 - B_rows;
  const uint32_t D_sp_addr_start = (1 << (ADDR_LEN - 1)) + D_sp_addr_row;
  const uint32_t C_sp_addr_start = (3 << (ADDR_LEN - 2)) + C_sp_addr_row;
  if(a_spad_id == 2) A_sp_addr_start = (BANK_NUM * BANK_ROWS) / 2;
  if(b_spad_id == 2) B_sp_addr_start = (BANK_NUM * BANK_ROWS) - B_rows;
  if (bias != 0) {
    D_sp_addr_row = (D_sp_addr_row + ACC_ROWS / 2) % ACC_ROWS;
  }

  if (output != 0) {
    C_sp_addr_row = (C_sp_addr_row + ACC_ROWS / 2) % ACC_ROWS;
  }

  const uint32_t GARBAGE_ADDR = ~0;

  // mvin bias
  if (bias != 0) {
    // TODO we probably don't need quite this many nested loops for this part

    const int max_ochs_per_mvin = ochs < MAX_BLOCK_LEN_ACC * DIM ? ochs :
      MAX_BLOCK_LEN_ACC * DIM;

    // gemmini_extended4_config_ld(0, MVIN_SCALE_IDENTITY, false, batches * orows * ocols, 2);
    config(((uint64_t)scale_t_to_scale_t_bits(MVIN_SCALE_IDENTITY) << 32) |
      ((uint64_t)(batches * orows * ocols) << 16) |
      (1 << 8) |
      (2 << 3) | 1,
      0);

    for (int b = 0; b < batches; b++)
      for (int orow = 0; orow < orows; orow++)
        for (int ocol = 0; ocol < ocols; ocol += DIM) {
          const int I = ocols - ocol > DIM ? DIM : ocols - ocol;

          for (int och = 0; och < ochs; och += max_ochs_per_mvin) {
            const int J = ochs - och > max_ochs_per_mvin ? max_ochs_per_mvin : ochs - och;

            const uint32_t D_sp_addr = D_sp_addr_start + (och / DIM) * batches * orows * ocols + b * orows * ocols + orow * ocols + ocol;

            mvin(no_bias ? 0 : bias + och * sizeof(acc_t),
              ((uint64_t)I << 48) | ((uint64_t)J << 32) | D_sp_addr,
              2);
          }
        }
  }

#define DS(x) ((x) >> (downsample))
#define US(x) ((x) << (downsample))

  // mvin input
  if(input != 0){
    int16_t max_chs_per_mvin = ichs < MAX_BLOCK_LEN * DIM ? ichs :
      MAX_BLOCK_LEN * DIM;
    if (trans_input_3120) {
      max_chs_per_mvin = batches < MAX_BLOCK_LEN * DIM ? batches :
        MAX_BLOCK_LEN * DIM;
    }

    const uint32_t dram_stride = trans_input_3120 ?
      batch_size * sizeof(elem_t) :
      in_stride * sizeof(elem_t);

    const int spad_stride = trans_input_3120 ?
      ichs * DS(irows) * DS(icols) :
      batches * DS(irows) * DS(icols);

    // gemmini_extended5_config_ld(dram_stride << downsample, MVIN_SCALE_IDENTITY, false, spad_stride, max_pixels_per_row, 0);
    config(((uint64_t)scale_t_to_scale_t_bits(MVIN_SCALE_IDENTITY) << 32) |
      ((uint64_t)(spad_stride) << 16) |
      ((uint64_t)(max_pixels_per_row) << 8) |
      (0 << 3) | 1,
      US(dram_stride));

    const int b_it = trans_input_3120 ? max_chs_per_mvin : 1;
    const int ich_it = trans_input_3120 ? 1 : max_chs_per_mvin;

    for (int16_t b = 0; b < batches; b += b_it)
      for (int16_t irow = -UNDILATED(upad); irow < irows_unpadded + UNDILATED(dpad); irow += US(1)) {
        const int16_t irow_padded = irow + UNDILATED(upad);

        for (int16_t icol = -UNDILATED(lpad); icol < icols_unpadded + UNDILATED(rpad);) {
          // TODO There might be some unnecessary mvins here at the edge of the image

          int16_t I = icols_unpadded - icol > US(DIM) ? US(DIM) : icols_unpadded - icol;

          if (icol < 0) {
            I = -icol > DIM ? DIM : -icol;
          } else if (icol >= icols_unpadded) {
            I = icols_unpadded + UNDILATED(rpad) - icol > DIM ? DIM : icols_unpadded + UNDILATED(rpad) - icol;
          }

          const int16_t icol_padded = icol + UNDILATED(lpad);

          for (int16_t ich = 0; ich < ichs; ich += ich_it) {
            int16_t K = ichs - ich > max_chs_per_mvin ?
              max_chs_per_mvin : ichs - ich;
            if (trans_input_3120) {
              K = batches - b > max_chs_per_mvin ?
                max_chs_per_mvin : batches - b;
            }

            uint32_t A_sp_addr = A_sp_addr_start + (ich / DIM) * spad_stride + b * DS(irows) * DS(icols) + DS(irow_padded) * DS(icols) + DS(icol_padded);
            if (trans_input_3120) {
              A_sp_addr = A_sp_addr_start + (b / DIM) * spad_stride + ich * DS(irows) * DS(icols) + DS(irow_padded) * DS(icols) + DS(icol_padded);
            }

            const bool is_zeros = irow < 0 || irow >= irows_unpadded || icol < 0 || icol >= icols_unpadded;

            uint64_t in = input + ((b*in_row_dim*in_col_dim + irow*in_col_dim + icol) * in_stride + ich) * sizeof(elem_t);
            if (is_zeros) {
              in = 0;
            } else if (trans_input_3120) {
              in = input + ((ich*in_row_dim*in_col_dim + irow*in_col_dim + icol) * batch_size + b) * sizeof(elem_t);
            }

            // gemmini_extended_mvin(in,
            //     A_sp_addr,
            //     K, I);
            mvin(in,
              ((uint64_t)(DS(I)) << 48) | ((uint64_t)K << 32) | A_sp_addr,
              0);
          }

          icol += I;
        }
      }
  }

  // mvin weights
  if (weights != 0){
    uint16_t max_chs_per_mvin = ochs < MAX_BLOCK_LEN * DIM ? ochs :
      MAX_BLOCK_LEN * DIM;
    if (trans_weight_0132) {
      max_chs_per_mvin = kchs < MAX_BLOCK_LEN * DIM ? kchs :
          MAX_BLOCK_LEN * DIM;
    }

    size_t dram_stride = weight_stride * sizeof(elem_t);
    if (dw) {
      dram_stride = sizeof(elem_t);
    } else if (trans_weight_1203) {
      dram_stride = kernel_dim * kernel_dim * out_channels * sizeof(elem_t);
    } else if (trans_weight_0132) {
      dram_stride = in_channels * sizeof(elem_t);
    }

    const size_t spad_block_stride = trans_weight_0132 ?
      krows * kcols * ochs : krows * kcols * kchs;

    // gemmini_extended4_config_ld(out_channels * sizeof(elem_t), MVIN_SCALE_IDENTITY, false, krows * kcols * kchs, 1);
    config(((uint64_t)scale_t_to_scale_t_bits(MVIN_SCALE_IDENTITY) << 32) |
      ((uint64_t)(spad_block_stride) << 16) |
      (1 << 8) |
      (1 << 3) | 1,
      dram_stride);

    const size_t och_it = trans_weight_0132 ? DIM : max_chs_per_mvin;
    const size_t kch_it = trans_weight_0132 ? max_chs_per_mvin : DIM;

    for (uint16_t och = 0; och < ochs; och += och_it) {
      for (uint16_t krow = 0; krow < krows; krow++)
        for (uint16_t kcol = 0; kcol < kcols; kcol++)
          for (uint16_t kch = 0; kch < kchs; kch += kch_it) {
            uint16_t K = kchs - kch > DIM ? DIM : kchs - kch;
            uint16_t J = ochs - och > max_chs_per_mvin ? max_chs_per_mvin : ochs - och;
            if (trans_weight_0132) {
              K = ochs - och > DIM ? DIM : ochs - och;
              J = kchs - kch > max_chs_per_mvin ? max_chs_per_mvin : kchs - kch;
            }

            uint32_t B_sp_addr = B_sp_addr_start + (och / DIM) * krows * kcols * kchs + krow * kcols * kchs + kcol * kchs + kch;
            if (trans_weight_0132) {
              B_sp_addr = B_sp_addr_start + (kch / DIM) * krows * kcols * ochs + krow * kcols * ochs + kcol * ochs + och;
            }

            auto w = weights + ((krow*kernel_dim*in_channels + kcol*in_channels + kch) * weight_stride + och)*sizeof(elem_t);
            if (dw) {
              w = (weights + krow * kernel_dim + kcol)*sizeof(elem_t);
            } else if (trans_weight_1203) {
              w = weights + ((kch * kernel_dim * kernel_dim  + krow * kernel_dim + kcol) * out_channels + och)*sizeof(elem_t);
            } else if (trans_weight_0132) {
              w = weights + ((krow * kernel_dim * out_channels + kcol * out_channels + och) * in_channels + kch)*sizeof(elem_t);
            }

            // gemmini_extended_mvin2(w,
            //   B_sp_addr,
            //   J, K);

            mvin(w,
              ((uint64_t)K << 48) | ((uint64_t)J << 32) | B_sp_addr,
              1);
          }
    }
  }

  // Compute
  {
    const int b_it = trans_input_3120 ? DIM : 1;
    const int ocol_it = trans_input_3120 ? 1 : (DIM << input_dilated);

    if (trans_input_3120) {
      // gemmini_extended3_config_ex(0, 0, 0, 0, 0, orows * ocols, irows * icols, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, true);
      const uint16_t a_stride = irows * icols;
      const uint16_t c_stride = orows * ocols;
      const bool set_only_strides = true;
      config(((uint64_t)a_stride << 16) | (set_only_strides << 7) | 0,
        ((uint64_t)c_stride << 48));
    }

    for (uint16_t och = 0; och < ochs; och += DIM) {
      for (uint16_t krow = 0; krow < krows; krow++) {
        for (uint16_t kcol = 0; kcol < kcols; kcol += max_pixels_per_row) {
          for (uint16_t kch = 0; kch < kchs; kch += DIM) {
            bool new_weights = true;

            for (uint16_t b = 0; b < batches; b += b_it) {
              for (uint16_t orow = 0; orow < orows; orow++) {
                if (input_dilated && ((krow * kernel_dilation + orow - upad) % 2 != 0)) {
                  continue;
                }

                for (uint16_t ocol = 0; ocol < ocols;) {
                  if (input_dilated && ((kcol * kernel_dilation + ocol - lpad) % 2 != 0)) {
                    ocol++;
                    continue;
                  }

                  const uint16_t irow = UNDILATED(orow * stride + krow * kernel_dilation);
                  const uint16_t icol = UNDILATED(ocol * stride + kcol * kernel_dilation);

                  const uint32_t C_sp_addr = C_sp_addr_start + (och / DIM) * batches * orows * ocols + b * orows * ocols + orow * ocols + ocol;

                  const uint8_t pixels = kcols - kcol > max_pixels_per_row ?
                    max_pixels_per_row : kcols - kcol;

                  // Over here, construct a new matrix
                  //
                  // Let us assume that we only ever operate on
                  // one pixel in one row.
                  // Thus, krow == kcol == 1
                  //
                  // Then, for every set of I, J, and K values
                  //   - I = ocol
                  //   - J = och
                  //   - K = kch

                  uint16_t I = UNDILATED(ocols - ocol > (DIM << input_dilated) ? (DIM << input_dilated) : ocols - ocol);
                  const uint16_t J = ochs - och > DIM ? DIM : ochs - och;
                  const uint16_t K = pixels * (kchs - kch > DIM ? DIM : kchs - kch);

                  if (trans_input_3120) {
                    I = batches - b > DIM ? DIM : batches - b;
                  }

                  uint32_t A_sp_addr = A_sp_addr_start + (kch / DIM) * batches * DS(irows) * DS(icols) + b * DS(irows) * DS(icols) + DS(irow) * DS(icols) + DS(icol);
                  if (trans_input_3120) {
                    A_sp_addr = A_sp_addr_start + (b / DIM) * kchs * DS(irows) * DS(icols) + kch * DS(irows) * DS(icols) + DS(irow) * DS(icols) + DS(icol);
                  }

                  const int krow_ = wrot180 ? krows - krow - 1 : krow;
                  const int kcol_ = wrot180 ? kcols - kcol - 1 : kcol;

                  uint32_t B_sp_addr = B_sp_addr_start + (och / DIM) * krows * kcols * kchs + krow_ * kcols * kchs + kcol_ * kchs + kch;
                  if (trans_weight_0132) {
                    B_sp_addr = B_sp_addr_start + (kch / DIM) * krows * kcols * ochs + krow_ * kcols * ochs + kcol_ * ochs + och;
                  }

                  const uint32_t pre_sp_addr = new_weights ? B_sp_addr : GARBAGE_ADDR;

                  // perform matmul
                  const uint32_t out_sp_addr = C_sp_addr;

                  /*
                  gemmini_extended_preload(pre_sp_addr, out_sp_addr,
                          J, K, J, I);

                  if (new_weights) {
                    gemmini_extended_compute_preloaded(A_sp_addr, GARBAGE_ADDR, K, I, J, I);
                  } else {
                    gemmini_extended_compute_accumulated(A_sp_addr, GARBAGE_ADDR, K, I, J, I);
                  }
                  */

                  preload(((uint64_t)K << 48) | ((uint64_t)J << 32) | pre_sp_addr,
                      ((uint64_t)I << 48) | ((uint64_t)J << 32) | out_sp_addr);
                  compute(((uint64_t)I << 48) | ((uint64_t)K << 32) | A_sp_addr,
                      ((uint64_t)I << 48) | ((uint64_t)J << 32) | GARBAGE_ADDR, new_weights);

                  ocol += ocol_it;
                  new_weights = false;
                }
              }
            }
          }
        }
      }
    }
  }

#undef DS
#undef US
#undef UNDILATED

  // Mvout results
  if (output != 0 && no_pool) {
    for (uint16_t b = 0; b < batches; b++)
      for (uint16_t orow = 0; orow < orows; orow++)
        for (uint16_t ocol = 0; ocol < ocols; ocol += DIM) {
          const uint16_t I = ocols - ocol > DIM ? DIM : ocols - ocol;

          for (uint16_t och = 0; och < ochs; och += DIM) {
            const uint16_t J = ochs - och > DIM ? DIM : ochs - och;

            const uint32_t C_sp_addr = C_sp_addr_start + (och / DIM) * batches * orows * ocols + b * orows * ocols + orow * ocols + ocol;

            auto out = output + ((b*out_row_dim*out_col_dim + orow*out_col_dim + ocol) * out_stride + och) * sizeof(elem_t);
            if (trans_output_1203) {
              out = output + ((orow*out_col_dim*batch_size + ocol*batch_size + b) * out_channels + och) * sizeof(elem_t);
            }

            mvout(out,
                ((uint64_t)I << 48) | ((uint64_t)J << 32) | C_sp_addr);
          }
        }
  } else if (output != 0 && !no_pool) {
    auto acc_scale = gemmini_state.acc_shift;

    // gemmini_extended2_config_st(out_channels * sizeof(elem_t), act, scale, pool_stride, pool_size, pool_out_dim, porows, pocols, orows, ocols, pupad, plpad);
    config(
      ((uint64_t)ocols << 56) |
      ((uint64_t)orows << 48) |
      ((uint64_t)pocols << 40) |
      ((uint64_t)porows << 32) |
      ((uint64_t)pool_out_col_dim << 24) |
      ((uint64_t)plpad << 10) |
      ((uint64_t)pupad << 8) |
      ((uint64_t)pool_size << 6) |
      ((uint64_t)pool_stride << 4) |
      (activation << 2) |
      2,
      ((uint64_t)(acc_scale_t_to_acc_scale_t_bits(acc_scale)) << 32) |
      (out_stride * sizeof(elem_t)));

    for (int b = 0; b < batches; b++) {
      for (int poch = 0; poch < pochs; poch += DIM) {
        const int channels = poch + DIM >= pochs ? pochs - poch : DIM;

        const uint32_t C_sp_addr = C_sp_addr_start + (poch / DIM) * batches * orows * ocols + b * orows * ocols;

        mvout(output + ((b * pool_out_row_dim * pool_out_col_dim)*out_stride + poch) * sizeof(elem_t),
          ((uint64_t)channels << 32) | C_sp_addr);
      }
    }

    // gemmini_extended_config_st(out_channels * sizeof(elem_t), act, scale);
    config(
      (activation << 2) |
      2,
      ((uint64_t)(acc_scale_t_to_acc_scale_t_bits(acc_scale)) << 32) |
      out_stride * sizeof(elem_t));
  }
}

void gemmini_t::loop_conv_ws_config_1(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_conv_ws_batch_size = rs1 & 0xFFFF;
  gemmini_state.loop_conv_ws_in_row_dim = (rs1 >> 16) & 0xFFFF;
  gemmini_state.loop_conv_ws_in_channels = (rs1 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_out_channels = (rs1 >> 48) & 0xFFFF;

  gemmini_state.loop_conv_ws_out_row_dim = rs2 & 0xFFFF;
  gemmini_state.loop_conv_ws_pool_out_row_dim = (rs2 >> 16) & 0xFFFF;
  gemmini_state.loop_conv_ws_out_col_dim = (rs2 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_stride = (rs2 >> 48) & 0xFF;
  gemmini_state.loop_conv_ws_padding = (rs2 >> 56) & 0xFF;
}

void gemmini_t::loop_conv_ws_config_2(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_conv_ws_kernel_dim = (rs1 >> 48) & 0xFFFF;
  gemmini_state.loop_conv_ws_pool_out_col_dim = (rs1 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_pool_size = (rs1 >> 16) & 0xFFFF;
  gemmini_state.loop_conv_ws_pool_stride = (rs1 >> 8) & 0xFF;
  gemmini_state.loop_conv_ws_pool_padding = rs1 & 0xFF;

  gemmini_state.loop_conv_ws_batches = (rs2 >> 48) & 0xFFFF;
  gemmini_state.loop_conv_ws_porows = (rs2 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_pocols = (rs2 >> 16)  & 0xFFFF;
  gemmini_state.loop_conv_ws_pochs = rs2 & 0xFFFF;
}

void gemmini_t::loop_conv_ws_config_3(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_conv_ws_krows = (rs1 >> 48) & 0xFFFF;
  gemmini_state.loop_conv_ws_kcols = (rs1 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_kchs = (rs1 >> 16) & 0xFFFF;
  gemmini_state.loop_conv_ws_lpad = rs1 & 0xFFFF;

  gemmini_state.loop_conv_ws_rpad = (rs2 >> 48) & 0xFFFF;
  gemmini_state.loop_conv_ws_upad = (rs2 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_dpad = (rs2 >> 24) & 0xFF;
  gemmini_state.loop_conv_ws_plpad = (rs2 >> 16) & 0xFF;
  gemmini_state.loop_conv_ws_in_col_dim = rs2 & 0xFFFF;
}

void gemmini_t::loop_conv_ws_config_4(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_conv_ws_orows = (rs1  >> 48) & 0xFFFF;
  gemmini_state.loop_conv_ws_prad = (rs1 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_pupad = (rs1 >> 21) & 0xFF;
  gemmini_state.loop_conv_ws_pdpad = (rs1 >> 10) & 0xFF;
  gemmini_state.loop_conv_ws_kernel_dilation = rs1 & 0xFF;

  gemmini_state.loop_conv_ws_in_stride = (rs2 >> 48) & 0xFFFF;
  gemmini_state.loop_conv_ws_weight_stride = (rs2 >> 32) & 0xFFFF;
  gemmini_state.loop_conv_ws_out_stride = (rs2 >> 16) & 0xFFFF;
  gemmini_state.loop_conv_ws_ocols = rs2 & 0xFFFF;
}

void gemmini_t::loop_conv_ws_config_5(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_conv_ws_weights = rs1;
  gemmini_state.loop_conv_ws_output = rs2;
}

void gemmini_t::loop_conv_ws_config_6(reg_t rs1, reg_t rs2) {
  gemmini_state.loop_conv_ws_bias = rs1;
  gemmini_state.loop_conv_ws_input = rs2;
}

reg_t gemmini_t::CUSTOMFN(XCUSTOM_ACC)(rocc_insn_t insn, reg_t xs1, reg_t xs2) {
  if (!gemmini_state.resetted) {
    reset();
  }
  if (perf.on_cmd(p, insn.funct, xs1, xs2)) return 0;   // perf mode: timed, data work skipped (gemmini_perf.cc)
  if (gemmini_state.op_in_progress)
    counter_increment_random();

  // RTL LoopMatmul clears the A-scale reuse record on any command that is not a loop command.
  {
    const unsigned f = insn.funct;
    const bool loop_cmd = (f >= loop_ws_funct && f <= loop_ws_config_strides_DC_funct) ||
                          f == loop_ws_config_spad_AB_funct || f == loop_ws_config_spad_C_funct ||
                          f == loop_ws_config_scales_funct || f == loop_ws_config_scale_strides_funct;
    if (!loop_cmd) gemmini_state.mx_asc_valid[0] = gemmini_state.mx_asc_valid[1] = false;
  }

  if (insn.funct == mvin_funct) {
    mvin(xs1, xs2, 0);
  } else if (insn.funct == mvin2_funct) {
    mvin(xs1, xs2, 1);
  } else if (insn.funct == mvin3_funct) {
    mvin(xs1, xs2, 2);
  } else if (insn.funct == mvout_funct) {
    mvout(xs1, xs2);
  } else if (insn.funct == preload_funct) {
    preload(xs1, xs2);
  } else if (insn.funct == config_funct) {
    config(xs1, xs2);
  } else if (insn.funct == compute_preloaded_funct) {
    compute(xs1, xs2, true);
  } else if (insn.funct == compute_accumulated_funct) {
    compute(xs1, xs2, false);
  } else if (insn.funct == loop_ws_config_bounds_funct) {
    loop_ws_config_bounds(xs1, xs2);
  } else if (insn.funct == loop_ws_config_addrs_AB_funct) {
    loop_ws_config_addrs_AB(xs1, xs2);
  } else if (insn.funct == loop_ws_config_addrs_DC_funct) {
    loop_ws_config_addrs_DC(xs1, xs2);
  } else if (insn.funct == loop_ws_config_strides_AB_funct) {
    loop_ws_config_strides_AB(xs1, xs2);
  } else if (insn.funct == loop_ws_config_strides_DC_funct) {
    loop_ws_config_strides_DC(xs1, xs2);
  } else if (insn.funct == loop_ws_funct) {
    const bool mx_spad = (xs2 >> 9) & 0x1;
    if (mx_spad) {
      mx_loop_ws_spad(xs1, xs2);
    } else if (gemmini_state.mx_scales_used || gemmini_state.loop_ws_A_sc != 0) {
      mx_loop_ws_dram(xs1, xs2);
    } else {
      loop_ws(xs1, xs2);
    }
    // every LOOP_WS takes the next LoopMatmul slot; loop-managed scale config is per loop
    gemmini_state.mx_loop_slot ^= 1;
    gemmini_state.loop_ws_A_sc = gemmini_state.loop_ws_B_sc = 0;
  } else if (insn.funct == mvout_spad_funct) {
    mvout_spad(xs1, xs2);
  } else if (insn.funct == loop_ws_config_spad_AB_funct) {
    loop_ws_config_spad_AB(xs1, xs2);
  } else if (insn.funct == loop_ws_config_spad_C_funct) {
    loop_ws_config_spad_C(xs1, xs2);
  } else if (insn.funct == mxquant_config_mvout_funct) {
    mxquant_config_mvout(xs1, xs2);
  } else if (insn.funct == mx_load_scales_funct) {
    mx_load_scales(xs1, xs2);
  } else if (insn.funct == mx_read_smem_funct) {
    mx_read_smem(xs1, xs2);
  } else if (insn.funct == mx_load_lut_funct) {
    mx_load_lut(xs1, xs2);
  } else if (insn.funct == loop_ws_config_scales_funct) {
    loop_ws_config_scales(xs1, xs2);
  } else if (insn.funct == loop_ws_config_scale_strides_funct) {
    loop_ws_config_scale_strides(xs1, xs2);
  } else if (insn.funct == vpu_exec_funct) {
    vpu_exec(xs1, xs2);
  } else if (insn.funct == spad_requant_funct) {
    spad_requant(xs1, xs2);
  } else if (insn.funct == mx_lut_disable_funct) {
    gemmini_state.mx_lut_en = 0;   // G1: clear runtime LUT-usage flag
    gemmini_state.mx_lut_a_loaded = 0; gemmini_state.mx_lut_b_loaded = 0;
  } else if (insn.funct == loop_conv_ws_config_1_funct) {
    loop_conv_ws_config_1(xs1, xs2);
  } else if (insn.funct == loop_conv_ws_config_2_funct) {
    loop_conv_ws_config_2(xs1, xs2);
  } else if (insn.funct == loop_conv_ws_config_3_funct) {
    loop_conv_ws_config_3(xs1, xs2);
  } else if (insn.funct == loop_conv_ws_config_4_funct) {
    loop_conv_ws_config_4(xs1, xs2);
  } else if (insn.funct == loop_conv_ws_config_5_funct) {
    loop_conv_ws_config_5(xs1, xs2);
  } else if (insn.funct == loop_conv_ws_config_6_funct) {
    loop_conv_ws_config_6(xs1, xs2);
  } else if (insn.funct == loop_conv_ws_funct) {
    loop_conv_ws(xs1, xs2);
  } else if (insn.funct == counter_op_funct) {
    return counter_operation(xs1);
  }
  //==========================================================================
  // gemmini-cisc opcodes
  //==========================================================================
  /*
  else if (insn.funct == config_cisc_ex_funct) {
    config(xs1, xs2);
  }
  else if (insn.funct == config_addr_AB_funct) {
    gemmini_state.a_addr = xs1;
    gemmini_state.b_addr = xs2;
  }
  else if (insn.funct == config_addr_CD_funct ){
    gemmini_state.c_addr = xs1;
    gemmini_state.d_addr = xs2;
  }
  else if (insn.funct == config_size0_funct ){
    gemmini_state.m = xs1;
    gemmini_state.n = xs2;
  }
  else if (insn.funct == config_size1_funct ){
    gemmini_state.k = xs1;
  }
  else if (insn.funct == config_repeating_bias_funct){
    gemmini_state.repeating_bias = (bool)xs1;
  }
  else if (insn.funct == config_reset_funct) {
    reset();
  }
  else if (insn.funct == compute_cisc_funct) {
    compute_cisc();
  }
  */
  //==========================================================================
  else if (insn.funct == flush_funct) {
    dprintf("GEMMINI: flush\n");
  } else if (insn.funct == fence_funct) {
    dprintf("GEMMINI: fence\n");
  } else {
    dprintf("GEMMINI: encountered unknown instruction with funct: %d\n", insn.funct);
    illegal_instruction(*p);
  }
  gemmini_state.op_in_progress = (insn.funct != flush_funct);
  return 0;
}

#if defined(HAS_MVIN_SCALE) || defined(HAS_MVIN_ACC_SCALE)
scale_t_bits gemmini_t::scale_t_to_scale_t_bits(scale_t scale) {
    union {
        scale_t scale;
        scale_t_bits bits;
    } un;

    un.scale = scale;
    return un.bits;
}

scale_t gemmini_t::scale_t_bits_to_scale_t(scale_t_bits bits) {
    union {
        scale_t scale;
        scale_t_bits bits;
    } un;

    un.bits = bits;
    return un.scale;
}
#endif

acc_scale_t_bits gemmini_t::acc_scale_t_to_acc_scale_t_bits(acc_scale_t scale) {
    union {
        acc_scale_t scale;
        acc_scale_t_bits bits;
    } un;

    un.scale = scale;
    return un.bits;
}

acc_scale_t gemmini_t::acc_scale_t_bits_to_acc_scale_t(acc_scale_t_bits bits) {
    union {
        acc_scale_t scale;
        acc_scale_t_bits bits;
    } un;

    un.bits = bits;
    return un.scale;
}

// Applying activation from PE post-shifted output to scratchpad (for OS dataflow)
// or from accumulator to DRAM (after shifting, for WS dataflow)
elem_t gemmini_t::apply_activation(elem_t value, enum gemmini_state_t::Activation act) {
  if (act == gemmini_state_t::RELU) {
    return value > 0 ? static_cast<elem_t>(value) : static_cast<elem_t>(0);
  } else {
    return static_cast<elem_t>(value);
  }
}

elem_t gemmini_t::apply_activation_sys(elem_t value) {
  return apply_activation(value, gemmini_state.sys_act);
}

elem_t gemmini_t::apply_activation_acc(elem_t value) {
  return apply_activation(value, gemmini_state.acc_act);
}

acc_t apply_igelu(acc_t q, acc_t qb, acc_t qc) {
  const acc_t q_sign = q < 0 ? -1 : 1;
  const acc_t q_clipped = abs(q) > (-qb) ? (-qb) : abs(q);
  const acc_t q_poly = (q_clipped + qb)*(q_clipped + qb) + qc;
  const acc_t q_erf = q_sign * q_poly;

  return q * (q_erf + qc);
}

acc_t apply_iexp(acc_t q, acc_t qb, acc_t qc, acc_t qln2, acc_t qln2_inv) {
#ifdef ELEM_T_IS_FLOAT
  const acc_t z = (acc_t) (-q * qln2_inv) / (1 << 16);
#else
  const acc_t z = (acc_t) (-q * qln2_inv) >> 16;
#endif
  const acc_t qp = q + z * qln2;
  const acc_t q_exp = (qp + qb) * (qp + qb) + qc;
#ifdef ELEM_T_IS_FLOAT
  return q_exp / std::pow(2, z);
#else
  return q_exp >> z;
#endif
}

acc_t gemmini_t::apply_pre_activation_acc(acc_t value) {
  if (gemmini_state.acc_act == gemmini_state_t::IGELU) {
    return apply_igelu(value, gemmini_state.igelu_qb, gemmini_state.igelu_qc);
  } else if (gemmini_state.acc_act == gemmini_state_t::LAYERNORM) {
    const auto stat_id = gemmini_state.norm_stat_id;
    const auto norm_mean = gemmini_state.norm_mean[stat_id];
    const auto norm_inv_stddev = gemmini_state.norm_inv_stddev[stat_id];
    return (value - norm_mean) * norm_inv_stddev;
  } else if (gemmini_state.acc_act == gemmini_state_t::SOFTMAX) {
    const auto stat_id = gemmini_state.norm_stat_id;
    const auto norm_max = gemmini_state.norm_max[stat_id];
    const auto norm_inv_sum_exp = gemmini_state.norm_inv_sum_exp[stat_id];
    return acc_scale(apply_iexp(value - norm_max, gemmini_state.igelu_qb, gemmini_state.igelu_qc,
        gemmini_state.qln2, gemmini_state.qln2_inv), norm_inv_sum_exp);
  } else {
    return value;
  }
}

bool gemmini_t::apply_norm(const acc_t * x, size_t len, enum gemmini_state_t::NormCmd cmd) {
  // The return value is whether or not the command should write to main memory

  const auto stat_id = gemmini_state.norm_stat_id;

  auto& norm_sum = gemmini_state.norm_sum[stat_id];
  auto& norm_count = gemmini_state.norm_count[stat_id];
  auto& norm_mean = gemmini_state.norm_mean[stat_id];
  auto& norm_inv_stddev = gemmini_state.norm_inv_stddev[stat_id];
  auto& norm_max = gemmini_state.norm_max[stat_id];
  auto& norm_running_max = gemmini_state.norm_running_max[stat_id];
  auto& norm_inv_sum_exp = gemmini_state.norm_inv_sum_exp[stat_id];
  auto& norm_reset = gemmini_state.norm_reset[stat_id];

  if (norm_reset) {
    norm_sum = 0;
    norm_count = 0;
    norm_running_max = -2147483648;
  }

  norm_reset = cmd == gemmini_state_t::RESET || cmd == gemmini_state_t::MEAN || cmd == gemmini_state_t::INV_STDDEV;

  if (cmd == gemmini_state_t::SUM || cmd == gemmini_state_t::MEAN) {
    for (size_t i = 0; i < len; i++)
      norm_sum += x[i];
    norm_count += len;
  } else if (cmd == gemmini_state_t::VARIANCE || cmd == gemmini_state_t::INV_STDDEV) {
    for (size_t i = 0; i < len; i++)
      norm_sum += (x[i] - norm_mean)*(x[i] - norm_mean);
    norm_count += len;
  } else if (cmd == gemmini_state_t::MAX) {
    for (size_t i = 0; i < len; i++) {
      norm_running_max = x[i] > norm_running_max ? x[i] : norm_running_max;
    }
  } else if (cmd == gemmini_state_t::SUM_EXP || cmd == gemmini_state_t::INV_SUM_EXP) {
    norm_max = norm_running_max;
    for (size_t i = 0; i < len; i++) {
      norm_sum += apply_iexp(x[i] - norm_max, gemmini_state.igelu_qb, gemmini_state.igelu_qc,
          gemmini_state.qln2, gemmini_state.qln2_inv);
    }
  }

  if (cmd == gemmini_state_t::MEAN) {
    norm_mean = norm_sum / norm_count;
  } else if (cmd == gemmini_state_t::INV_STDDEV) {
    acc_t variance = norm_sum / norm_count;
    acc_t norm_stddev = sqrt((double)variance);
    if (variance == 0) norm_stddev = 1;
    norm_inv_stddev = (acc_scale_t)1.0 / (acc_scale_t)norm_stddev;
  } else if (cmd == gemmini_state_t::INV_SUM_EXP) {
    norm_running_max = -2147483648;
    norm_inv_sum_exp = ((acc_scale_t) 127.0) / norm_sum;
  }

  return cmd == gemmini_state_t::RESET;
}

enum gemmini_state_t::NormCmd gemmini_t::non_terminating_norm_cmd(enum gemmini_state_t::NormCmd cmd) {
  if (cmd == gemmini_state_t::RESET)
    cmd = gemmini_state_t::RESET;
  else if (cmd == gemmini_state_t::MEAN)
    cmd = gemmini_state_t::SUM;
  else if (cmd == gemmini_state_t::INV_STDDEV)
    cmd = gemmini_state_t::VARIANCE;
  else if (cmd == gemmini_state_t::INV_SUM_EXP)
    cmd = gemmini_state_t::SUM_EXP;
  return cmd;
}

#ifdef HAS_MVIN_SCALE
elem_t gemmini_t::mvin_scale(elem_t value, scale_t scale) {
  acc_t scaled = MVIN_SCALE(value, scale);

#ifndef ELEM_T_IS_FLOAT
  // Saturate and cast element
  const auto elem_t_max = std::numeric_limits<elem_t>::max();
  const auto elem_t_min = std::numeric_limits<elem_t>::min();
  scaled = scaled > elem_t_max ? elem_t_max : (scaled < elem_t_min ? elem_t_min : scaled);
#endif

  return scaled;
}
#endif

#ifdef HAS_MVIN_ACC_SCALE
acc_t gemmini_t::mvin_scale_acc(acc_t value, scale_acc_t scale) {
  acc_t scaled = MVIN_SCALE_ACC(value, scale);

#ifndef ELEM_T_IS_FLOAT
  // Saturate and cast element
  const auto elem_t_max = std::numeric_limits<acc_t>::max();
  const auto elem_t_min = std::numeric_limits<acc_t>::min();
  scaled = scaled > elem_t_max ? elem_t_max : (scaled < elem_t_min ? elem_t_min : scaled);
#endif

  return scaled;
}
#endif

elem_t gemmini_t::acc_scale(acc_t value, acc_scale_t scale) {
  acc_t scaled = ACC_SCALE(value, scale);

#ifndef ELEM_T_IS_FLOAT
  // Saturate and cast element
  const auto elem_t_max = std::numeric_limits<elem_t>::max();
  const auto elem_t_min = std::numeric_limits<elem_t>::min();
  scaled = scaled > elem_t_max ? elem_t_max : (scaled < elem_t_min ? elem_t_min : scaled);
#endif

  return scaled;
}

elem_t gemmini_t::sys_shift(acc_t value, unsigned int shift) {
  acc_t shifted = ROUNDING_RIGHT_SHIFT(value, shift);

#ifndef ELEM_T_IS_FLOAT
  // Saturate and cast element
  const auto elem_t_max = std::numeric_limits<elem_t>::max();
  const auto elem_t_min = std::numeric_limits<elem_t>::min();
  shifted = shifted > elem_t_max ? elem_t_max : (shifted < elem_t_min ? elem_t_min : shifted);
#endif

  return shifted;
}

#ifdef ELEM_T_IS_FLOAT
elem_t gemmini_t::elem_t_bits_to_elem_t(elem_t_bits x) {
  union {
    elem_t_bits b;
    elem_t f;
  } un;

  un.b = x;
  return un.f;
}

elem_t_bits gemmini_t::elem_t_to_elem_t_bits(elem_t x) {
  union {
    elem_t_bits b;
    elem_t f;
  } un;

  un.f = x;
  return un.b;
}

acc_t gemmini_t::acc_t_bits_to_acc_t(acc_t_bits x) {
  union {
    acc_t_bits b;
    acc_t f;
  } un;

  un.b = x;
  return un.f;
}

acc_t_bits gemmini_t::acc_t_to_acc_t_bits(acc_t x) {
  union {
    acc_t_bits b;
    acc_t f;
  } un;

  un.f = x;
  return un.b;
}
#endif

void gemmini_t::counter_increment(unsigned int counter_id) {
  for (size_t i = 0; i < NUM_COUNTERS; i++) {
    if (gemmini_state.counter_config[i] == counter_id) {
      gemmini_state.counter_val[i]++;
      break;
    }
  }
}
void gemmini_t::counter_increment_random() {
  // So basically, once any Gemmini command is executed, the counter will increments every time a Gemmini command got called
  // until we hit a counter reset
  for (size_t i = 0; i < NUM_COUNTERS; i++) {
    gemmini_state.counter_val[i] += rand() & 0x1ff; // So that the increment < 512
  }
  for (size_t i = 0; i < NUM_EXTERNAL_COUNTERS; i++) {
    gemmini_state.counter_external[i] = rand() & 0xf; // So that the increment < 16
  }
}

static reg_t gemmini_custom(processor_t* p, insn_t insn, reg_t pc) {
  gemmini_t* gemmini = static_cast<gemmini_t*>(p->get_extension("gemmini"));
  rocc_insn_union_t u;
  state_t* state = p->get_state();
  gemmini->set_processor(p);
  u.i = insn;
  reg_t xs1 = u.r.xs1 ? state->XPR[insn.rs1()] : -1;
  reg_t xs2 = u.r.xs2 ? state->XPR[insn.rs2()] : -1;
  reg_t xd = gemmini->CUSTOMFN(XCUSTOM_ACC)(u.r, xs1, xs2);
  if (u.r.xd) {
    state->log_reg_write[insn.rd() << 4] = {xd, 0};
    state->XPR.write(insn.rd(), xd);
  }
  return pc+4;
}

std::vector<insn_desc_t> gemmini_t::get_instructions(const processor_t &p)
{
  std::vector<insn_desc_t> insns;
  push_custom_insn(insns, ROCC_OPCODE3, ROCC_OPCODE_MASK, ILLEGAL_INSN_FUNC, gemmini_custom);
  perf.on_register(p, insns);   // perf / both: fence + rdcycle see modelled time; CPU-store tracing from here
  return insns;
}

std::vector<disasm_insn_t*> gemmini_t::get_disasms(const processor_t *p)
{
  std::vector<disasm_insn_t*> insns;
  return insns;
}
