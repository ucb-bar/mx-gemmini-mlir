builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/sigmoid_projection19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<37x37xf32>, %1: tensor<19x37xf32>) -> tensor<19x37xf32> {
    %2 = tensor.empty() : tensor<19x37xf32>
    %3 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1 : tensor<19x37xf32>) outs(%2 : tensor<19x37xf32>) attrs =  {prov.region_id = "sigmoid_0", prov._pattern_hint = "sigmoid", prov.op = "sigmoid", prov.family = "elementwise", prov.aten = "aten.sigmoid.default", prov.orig_dtype = "float32"} {
    ^bb0(%4: f32, %5: f32):
      %6 = arith.constant 1.000000e+00 : f32
      %7 = arith.negf %4 : f32
      %8 = math.exp %7 : f32
      %9 = arith.addf %6, %8 : f32
      %10 = arith.divf %6, %9 : f32
      linalg.yield %10 : f32
    } -> tensor<19x37xf32>
    %11 = tensor.empty() : tensor<19x37xf32>
    %12 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1, %3 : tensor<19x37xf32>, tensor<19x37xf32>) outs(%11 : tensor<19x37xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb1(%13: f32, %14: f32, %15: f32):
      %16 = arith.mulf %13, %14 : f32
      linalg.yield %16 : f32
    } -> tensor<19x37xf32>
    %17 = tensor.empty() : tensor<37x37xf32>
    %18 = linalg.transpose ins(%0:tensor<37x37xf32>) outs(%17:tensor<37x37xf32>) permutation = [1, 0]
    %19 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} 0.000000e+00 : f32
    %20 = tensor.splat %19 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} : tensor<19x37xf32>
    %21 = linalg.matmul {prov.region_id = "matmul_0", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up", prov.transposed_b = "true"} ins(%1, %18 : tensor<19x37xf32>, tensor<37x37xf32>) outs(%20 : tensor<19x37xf32>) -> tensor<19x37xf32>
    %22 = tensor.empty() : tensor<19x37xf32>
    %23 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%12, %21 : tensor<19x37xf32>, tensor<19x37xf32>) outs(%22 : tensor<19x37xf32>) attrs =  {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb2(%24: f32, %25: f32, %26: f32):
      %27 = arith.mulf %24, %25 : f32
      linalg.yield %27 : f32
    } -> tensor<19x37xf32>
    func.return %23 : tensor<19x37xf32>
  }
}