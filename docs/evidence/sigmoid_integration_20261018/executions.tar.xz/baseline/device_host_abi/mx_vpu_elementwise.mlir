builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/sigmoid_projection19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<37x37xf32>, %1: tensor<19x37xf32>) -> tensor<19x37xf32> {
    %2 = tensor.empty() : tensor<19x37xf32>
    %3 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%1 : tensor<19x37xf32>) outs(%2 : tensor<19x37xf32>) attrs =  {prov.region_id = "sigmoid_0", prov._pattern_hint = "sigmoid", prov.op = "sigmoid", prov.family = "elementwise", prov.aten = "aten.sigmoid.default", prov.orig_dtype = "float32"} {
    ^bb0(%4: f32, %5: f32):
      %6 = arith.constant 1.000000e+00 : f32
      %7 = arith.negf %4 : f32
      %8 = math.exp %7 : f32
      %9 = arith.addf %6, %8 : f32
      %10 = arith.divf %6, %9 : f32
      linalg.yield %10 : f32
    } -> tensor<19x37xf32>
    %11 = tensor.empty() : tensor<19x37xf32>
    %12 = tensor.empty() : tensor<37x37xf32>
    %13 = linalg.transpose ins(%0:tensor<37x37xf32>) outs(%12:tensor<37x37xf32>) permutation = [1, 0]
    %14 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} 0.000000e+00 : f32
    %15 = tensor.splat %14 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} : tensor<19x37xf32>
    %16 = func.call @merlin_dev_mx_gemmini_0(%1, %13, %15) : (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %17 = tensor.empty() : tensor<19x37xf32>
    %18 = tensor.empty() : tensor<19x37xf32>
    %19 = func.call @mx_vpu_mul_chain_f32_19_37(%1, %3, %16, %18) : (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    func.return %19 : tensor<19x37xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_19_37", function_type = (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}