#include <stdint.h>
typedef struct { void *allocated, *aligned; intptr_t offset;
                 intptr_t sizes[2], strides[2]; } mx_memref_2d;
extern void mx_vpu_sigmoid_f32_19_37_kernel(const float *, float *);
mx_memref_2d mx_vpu_sigmoid_f32_19_37(
    void *a_alloc,
    void *a_aligned,
    intptr_t a_off,
    intptr_t a_s0,
    intptr_t a_s1,
    intptr_t a_st0,
    intptr_t a_st1,
    void *b_alloc,
    void *b_aligned,
    intptr_t b_off,
    intptr_t b_s0,
    intptr_t b_s1,
    intptr_t b_st0,
    intptr_t b_st1) {
  if (!a_aligned || !b_aligned || a_off < 0 || b_off < 0 ||
      a_s0 != 19 ||
      a_s1 != 37 ||
      b_s0 != 19 ||
      b_s1 != 37 ||
      a_st0 != 37 ||
      a_st1 != 1 ||
      b_st0 != 37 ||
      b_st1 != 1) __builtin_trap();
  mx_vpu_sigmoid_f32_19_37_kernel((const float *)a_aligned + a_off,
           (float *)b_aligned + b_off);
  return (mx_memref_2d){b_alloc, b_aligned, b_off,
                              {19, 37}, {37, 1}};
}
void _mlir_ciface_mx_vpu_sigmoid_f32_19_37(mx_memref_2d *result,
                          const mx_memref_2d *a,
                          const mx_memref_2d *b) {
  if (!result || !a || !b) __builtin_trap();
  mx_memref_2d returned = mx_vpu_sigmoid_f32_19_37(
      a->allocated, a->aligned, a->offset, a->sizes[0], a->sizes[1], a->strides[0], a->strides[1],
      b->allocated, b->aligned, b->offset, b->sizes[0], b->sizes[1], b->strides[0], b->strides[1]);
  volatile mx_memref_2d *destination = (volatile mx_memref_2d *)result;
  destination->allocated = returned.allocated;
  destination->aligned = returned.aligned;
  destination->offset = returned.offset;
  destination->sizes[0] = returned.sizes[0];
  destination->sizes[1] = returned.sizes[1];
  destination->strides[0] = returned.strides[0];
  destination->strides[1] = returned.strides[1];
}
