unsigned char mx_catalog_workspace[15424] __attribute__((aligned(64)));
