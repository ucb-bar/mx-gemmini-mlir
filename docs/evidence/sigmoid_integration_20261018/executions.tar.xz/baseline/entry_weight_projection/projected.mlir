"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>) -> tensor<19x37xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>):
    %1 = "tensor.empty"() : () -> tensor<19x37xf32>
    %2 = "func.call"(%0, %1) <{callee = @mx_vpu_sigmoid_f32_19_37}> : (tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %3 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} : () -> f32
    %4 = "tensor.splat"(%3) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} : (f32) -> tensor<19x37xf32>
    %5 = "tensor.empty"() : () -> tensor<37x37xf32>
    %6 = "func.call"(%0, %5, %4) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %7 = "tensor.empty"() : () -> tensor<19x37xf32>
    %8 = "func.call"(%0, %2, %6, %7) <{callee = @mx_vpu_mul_chain_f32_19_37}> : (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    "func.return"(%8) : (tensor<19x37xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_19_37", function_type = (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_sigmoid_f32_19_37", function_type = (tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/sigmoid_projection19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()