builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/sigmoid_projection19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<37x37xf32>, %1: tensor<19x37xf32>) -> tensor<19x37xf32> {
    %2 = tensor.empty() : tensor<19x37xf32>
    %3 = tensor.empty() : tensor<19x37xf32>
    %4 = tensor.empty() : tensor<37x37xf32>
    %5 = linalg.transpose ins(%0:tensor<37x37xf32>) outs(%4:tensor<37x37xf32>) permutation = [1, 0]
    %6 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} 0.000000e+00 : f32
    %7 = tensor.splat %6 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} : tensor<19x37xf32>
    %8 = func.call @merlin_dev_mx_gemmini_0(%1, %5, %7) : (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %9 = tensor.empty() : tensor<19x37xf32>
    %10 = tensor.empty() : tensor<19x37xf32>
    %11 = func.call @mx_vpu_sigmoid_mul_chain_f32_gate_first_19_37(%1, %8, %10) : (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    func.return %11 : tensor<19x37xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_sigmoid_mul_chain_f32_gate_first_19_37", function_type = (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}