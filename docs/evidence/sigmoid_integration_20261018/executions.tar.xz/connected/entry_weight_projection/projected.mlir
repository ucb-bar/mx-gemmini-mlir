"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>) -> tensor<19x37xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>):
    %1 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} : () -> f32
    %2 = "tensor.splat"(%1) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "up", prov.fqn = "up"} : (f32) -> tensor<19x37xf32>
    %3 = "tensor.empty"() : () -> tensor<37x37xf32>
    %4 = "func.call"(%0, %3, %2) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %5 = "tensor.empty"() : () -> tensor<19x37xf32>
    %6 = "func.call"(%0, %4, %5) <{callee = @mx_vpu_sigmoid_mul_chain_f32_gate_first_19_37}> : (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>
    "func.return"(%6) : (tensor<19x37xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_sigmoid_mul_chain_f32_gate_first_19_37", function_type = (tensor<19x37xf32>, tensor<19x37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/sigmoid_projection19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()