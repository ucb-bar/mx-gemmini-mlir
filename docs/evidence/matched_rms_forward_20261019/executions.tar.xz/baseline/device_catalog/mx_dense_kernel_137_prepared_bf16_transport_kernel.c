/* MX dense f32 adapter: FP8, qualified 160x5632x2048 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_2(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_137_fixed_codes[];
extern const uint8_t mx_dense_kernel_137_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_137_prepared_bf16_transport_kernel(const uint8_t *lhs, uint16_t *out) {
  if (!lhs || !out) __builtin_trap();
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 0);
  const uint8_t *activation = lhs;
  const uint8_t *activation_scales = lhs + 327680u;
  mx_issue_2(activation, activation_scales, mx_dense_kernel_137_fixed_codes, mx_dense_kernel_137_fixed_scales,
                  out, scratch_output_scales);
}
