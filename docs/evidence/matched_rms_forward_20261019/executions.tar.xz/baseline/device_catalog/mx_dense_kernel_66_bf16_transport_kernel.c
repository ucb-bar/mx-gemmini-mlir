/* MX dense f32 adapter: FP8, qualified 160x2048x2048 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_0(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_66_fixed_codes[];
extern const uint8_t mx_dense_kernel_66_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_66_bf16_transport_kernel(const float *lhs, const float *rhs, uint16_t *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 0);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 327680);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 337920);
  if (mx_pack_activation_f32(lhs, 160u, 2048u, MX_RUNTIME_FP8,
                             activation, activation_scales)) __builtin_trap();
  mx_issue_0(activation, activation_scales, mx_dense_kernel_66_fixed_codes, mx_dense_kernel_66_fixed_scales,
                  out, scratch_output_scales);
}
