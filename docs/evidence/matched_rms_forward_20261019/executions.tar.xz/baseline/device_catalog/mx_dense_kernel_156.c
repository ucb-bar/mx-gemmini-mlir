/* MX dense f32 adapter: FP8, qualified 160x64x160 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_6(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_156_slice(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 0);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 25600);
  uint8_t *weight = (uint8_t *)(mx_catalog_workspace + 26432);
  uint8_t *weight_scales = (uint8_t *)(mx_catalog_workspace + 36672);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 36992);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 57472);
  if (mx_pack_activation_f32(lhs, 160u, 160u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      mx_pack_weight_f32(rhs, 160u, 64u, MX_RUNTIME_FP8,
                         weight, weight_scales)) __builtin_trap();
  mx_issue_6(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 160u; ++row)
    for (uint32_t col = 0; col < 64u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 64u + col] << 16;
      out[(size_t)row * 64u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void mx_dense_kernel_156(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 32u; ++batch)
    mx_dense_kernel_156_slice(lhs + batch * 160u * 160u,
                   rhs + batch * 160u * 64u,
                   out + batch * 160u * 64u);
}
