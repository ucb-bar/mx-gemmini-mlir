#include <stdint.h>
extern float evaluate(float),expf(float);extern const float input[],perf_input[];
void console_init(void);void htif_puts(const char*);void htif_putd(long);void htif_putc(char);void htif_line_flush(int);void htif_exit(int) __attribute__((noreturn));
static volatile float sink;static uint32_t bits(float x){union{float f;uint32_t u;}a={.f=x};return a.u;}
static unsigned long cycles(void){unsigned long x;__asm__ volatile("rdcycle %0":"=r"(x));return x;}
int main(int hart){if(hart)for(;;);console_init();unsigned errors=0;unsigned long rm;__asm__ volatile("frrm %0":"=r"(rm));errors+=rm!=0;
for(unsigned i=0;i<4123;i++)errors+=bits(evaluate(input[i]))!=bits(expf(input[i]));
for(unsigned iteration=0;iteration<4;iteration++)for(unsigned variant=0;variant<2;variant++){unsigned long start=cycles();if(variant)for(unsigned i=0;i<5120;i++)sink=evaluate(perf_input[i]);else for(unsigned i=0;i<5120;i++)sink=expf(perf_input[i]);unsigned long end=cycles();htif_puts("CYCLES ");htif_putd(iteration);htif_putc(' ');htif_putd(variant);htif_putc(' ');htif_putd(end-start);htif_putc('\n');}
htif_puts("ERRORS ");htif_putd(errors);htif_putc('\n');htif_line_flush(1);htif_exit(errors?2:0);}
