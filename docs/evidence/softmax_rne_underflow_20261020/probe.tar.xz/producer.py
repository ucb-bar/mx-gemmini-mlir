"""Compare emitted RNE underflow branch with the pinned Rocket libm endpoint."""
from pathlib import Path
import hashlib,json,os,subprocess,re
import numpy as np
from xdsl.dialects import builtin,func
from xdsl.ir import Block,Region
from merlin.llvmlower.cpu_softmax import build_libm_softmax_exp_rne
from merlin.llvmlower.entry_weight_projection import module_text
from merlin.llvmlower.lower import lower_model_file
repo=Path.cwd(); root=repo.parent/'.tmp/stitched_baseline_20261019'; r=root/'exp_rne_underflow_target_probe1';r.mkdir(exist_ok=False)
base=root/'compiler_tinyllama_host_softmax_f32_residual1';job=json.loads((root/'compiler-libm-finite-softmax-f32-residual-job.json').read_text());recipe=json.loads((base/'compilation_recipe.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=Block(arg_types=[builtin.f32]);ops,value=build_libm_softmax_exp_rne(b.args[0],domain='nonpositive',rounding_mode='rne',floating_effects='unobserved');b.add_ops([*ops,func.ReturnOp(value)]);module=builtin.ModuleOp([func.FuncOp('evaluate',([builtin.f32],[builtin.f32]),Region(b))]);module.verify();(r/'model.mlir').write_text(module_text(module));lower=lower_model_file(r/'model.mlir',r/'lower',targets=(),textual=True)
rng=np.random.default_rng(21);edges=np.array([-np.inf,-np.finfo(np.float32).max,-104.,-103.972084,-103.9,-87.3,-1.,-0.,0.],np.float32)
with np.errstate(over='ignore'): inputs=np.concatenate([edges,np.nextafter(edges,np.float32(-np.inf)),np.nextafter(edges,np.float32(0)), -rng.uniform(0,160,4096).astype('f4')])
perf=-rng.uniform(0,20,(32,160)).astype('f4');perf[:,80:]=-np.finfo(np.float32).max;inputs.astype('<f4').tofile(r/'input.bin');perf.astype('<f4').tofile(r/'perf_input.bin')
(r/'data.S').write_text('.section .rodata\n.balign 64\n.global input\ninput:\n.incbin "'+str(r/'input.bin')+'"\n.balign 64\n.global perf_input\nperf_input:\n.incbin "'+str(r/'perf_input.bin')+'"\n')
(r/'main.c').write_text('''#include <stdint.h>
extern float evaluate(float),expf(float);extern const float input[],perf_input[];
void console_init(void);void htif_puts(const char*);void htif_putd(long);void htif_putc(char);void htif_line_flush(int);void htif_exit(int) __attribute__((noreturn));
static volatile float sink;static uint32_t bits(float x){union{float f;uint32_t u;}a={.f=x};return a.u;}
static unsigned long cycles(void){unsigned long x;__asm__ volatile("rdcycle %0":"=r"(x));return x;}
int main(int hart){if(hart)for(;;);console_init();unsigned errors=0;unsigned long rm;__asm__ volatile("frrm %0":"=r"(rm));errors+=rm!=0;
for(unsigned i=0;i<INPUT_COUNT;i++)errors+=bits(evaluate(input[i]))!=bits(expf(input[i]));
for(unsigned iteration=0;iteration<4;iteration++)for(unsigned variant=0;variant<2;variant++){unsigned long start=cycles();if(variant)for(unsigned i=0;i<5120;i++)sink=evaluate(perf_input[i]);else for(unsigned i=0;i<5120;i++)sink=expf(perf_input[i]);unsigned long end=cycles();htif_puts("CYCLES ");htif_putd(iteration);htif_putc(' ');htif_putd(variant);htif_putc(' ');htif_putd(end-start);htif_putc('\\n');}
htif_puts("ERRORS ");htif_putd(errors);htif_putc('\\n');htif_line_flush(1);htif_exit(errors?2:0);}
'''.replace('INPUT_COUNT',str(inputs.size)))
commands=[]
clang=recipe['commands'][0]['argv'][0];gcc=recipe['commands'][-1]['argv'][0];flags=['-O2','-ffreestanding','-fno-builtin','-march=rv64gc','-mabi=lp64d','-mcmodel=medany'];commands.append([clang,'--target=riscv64-unknown-elf',*flags[2:],'-O2','-c',str(lower.ll_path),'-o',str(r/'model.o')])
for name in ['main.c','data.S']:commands.append([gcc,*flags,'-c',str(r/name),'-o',str(r/(Path(name).stem+'.o'))])
libm=Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools/riscv64-unknown-elf/lib/libm.a')
commands.append([gcc,*flags,'-nostdlib','-nostartfiles','-T',str(repo.parent/'merlin/merlin/runtime/baremetal/spike/model_link.ld'),str(r/'main.o'),str(r/'data.o'),str(r/'model.o'),*[str(base/(n+'.o')) for n in ['crt','console','libc_min','malloc','mlir_rt']],str(base/'host_math/host_math.o'),'-Wl,--wrap=expf',str(libm),'-lgcc','-o',str(r/'probe.elf')])
for i,c in enumerate(commands):
 with (r/f'command{i}.log').open('wb') as log:subprocess.run(c,stdout=log,stderr=subprocess.STDOUT,check=True)
ext=job['command'][job['command'].index('--spike-extlib')+1];command=['/scratch/agustin/projects/chipyard/.conda-env/riscv-tools/bin/spike','--isa=rv64gc_zicntr','--extlib='+ext,'--extension=gemmini','-m0x80000000:0x1c0000000',str(r/'probe.elf')];commands.append(command);(r/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
with (r/'spike.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=os.environ|job['environment']|{'GEMMINI_PERF_OUT':str(r/'perf.txt')},check=True,timeout=120)
s=(r/'spike.log').read_text();assert 'ERRORS 0\n' in s;cycles={str(v):[int(c) for i,x,c in re.findall(r'^CYCLES (\d+) (\d+) (\d+)$',s,re.M) if int(x)==v] for v in [0,1]};assert all(len(x)==4 for x in cycles.values());result={'passed':True,'scope':'scalar exponential target probe only; no full-model speedup claim','input_count':int(inputs.size),'performance_input_count':int(perf.size),'performance_underflow_fraction':.5,'rounding_mode':'rne','floating_effects':'unobserved','all_compared_return_words_equal':True,'cycles':cycles,'input_sha256':sha(r/'input.bin'),'performance_input_sha256':sha(r/'perf_input.bin'),'elf_sha256':sha(r/'probe.elf'),'libm_sha256':sha(libm),'host_math_object_sha256':sha(base/'host_math/host_math.o'),'spike_sha256':sha(command[0]),'extension_sha256':sha(ext)};(r/'comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
