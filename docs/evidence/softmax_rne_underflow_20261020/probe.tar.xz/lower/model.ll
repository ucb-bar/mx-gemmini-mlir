; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"

; Function Attrs: memory(none)
declare float @expf(float) #0

define float @evaluate(float %0) {
  %2 = fcmp ole float %0, -1.040000e+02
  br i1 %2, label %3, label %4

3:                                                ; preds = %1
  br label %6

4:                                                ; preds = %1
  %5 = call float @expf(float %0)
  br label %6

6:                                                ; preds = %3, %4
  %7 = phi float [ %5, %4 ], [ 0.000000e+00, %3 ]
  br label %8

8:                                                ; preds = %6
  ret float %7
}

define float @_mlir_ciface_evaluate(float %0) {
  %2 = call float @evaluate(float %0)
  ret float %2
}

attributes #0 = { memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
