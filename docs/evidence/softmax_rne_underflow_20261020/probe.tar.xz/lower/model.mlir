"builtin.module"() ({
  "func.func"() <{sym_name = "evaluate", function_type = (f32) -> f32}> ({
  ^bb0(%0: f32):
    %1 = "arith.constant"() <{value = -1.040000e+02 : f32}> : () -> f32
    %2 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %3 = "arith.cmpf"(%0, %1) <{predicate = 5 : i64, fastmath = #arith.fastmath<none>}> : (f32, f32) -> i1
    %4 = "scf.if"(%3) ({
      "scf.yield"(%2) : (f32) -> ()
    }, {
      %5 = "math.exp"(%0) <{fastmath = #arith.fastmath<none>}> : (f32) -> f32
      "scf.yield"(%5) : (f32) -> ()
    }) : (i1) -> f32
    "func.return"(%4) : (f32) -> ()
  }) {llvm.emit_c_interface} : () -> ()
}) : () -> ()
