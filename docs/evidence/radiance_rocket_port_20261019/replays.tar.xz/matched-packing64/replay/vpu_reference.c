#include "vpu_ref.h"
void reference_exp(const uint16_t *a, uint16_t *b, uint32_t n) {
  for (uint32_t i=0; i<n; i++) b[i]=vpu_exp(a[i]);
}
