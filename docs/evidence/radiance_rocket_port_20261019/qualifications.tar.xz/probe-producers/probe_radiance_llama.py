import pathlib,sys,importlib.util,json,shutil,subprocess,os,re,hashlib
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent; SRC=ROOT/'radiance-latest-5866983682';OUT=ROOT/sys.argv[1];OUT.mkdir()
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo),str(repo.parent/'merlin/src'),str(repo.parent/'model2mlir')]
spec=importlib.util.spec_from_file_location('radiance_data',SRC/'kernels/nightly/llama_e2e/gen_data.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
instances=[];OriginalMem=g.Mem
class Mem(OriginalMem):
 def __init__(self,name):super().__init__(name);instances.append(self)
g.Mem=Mem
# Redirect golden's build and intermediates into this fresh output directory.
gold_dir=OUT/'golden';gold_dir.mkdir()
for p in (SRC/'lib/golden').iterdir():shutil.copyfile(p,gold_dir/p.name)
spec=importlib.util.spec_from_file_location('golden',gold_dir/'golden.py');gold=importlib.util.module_from_spec(spec);spec.loader.exec_module(gold);sys.modules['golden']=gold
g.HERE=OUT/'generator'; g.HERE.mkdir()
sys.argv=[str(SRC/'kernels/nightly/llama_e2e/gen_data.py'),'--model','smoke','--attn','gemm','--debug-l0','--out',str(OUT/'data'),'--header',str(OUT/'llama_data.h')]
g.main();mem=instances[0]
(OUT/'program.json').write_text(json.dumps({'arena':mem.arena,'blobs':{r:len(b) for r,b in mem.blobs.items()}},indent=2))
header=(OUT/'llama_data.h').read_text(); checks=[]
# Generated check records are read as data; no compiler-owned model is used.
for name,dev,ref,n,scale,kind,tol in re.findall(r'\{"([^"]+)", (0x[0-9a-f]+)u, (0x[0-9a-f]+)u, (\d+)u, (\d+), (\d+), (\d+)u\}',header):
 address,ref,n,kind=int(dev,16),int(ref,16),int(n),int(kind); size=n*(1 if kind else 2)
 region=next(r for r in (1,2,3) if g.REGION_BASE[r]<=ref<g.REGION_END[r]);off=ref-g.REGION_BASE[region]
 refbytes=bytes(mem.blobs[region][off:off+size]);assert len(refbytes)==size
 checks.append({'name':name,'address':address,'bytes':size,'golden':refbytes.hex(),'kind':'bytes' if kind else 'bf16','tolerance':int(tol)})
(OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
config='#include "llama_data.h"\nstruct RkCheck { uint32_t address,bytes; };\n'
config+=f'#define RK_NCHECKS {len(checks)}\nstatic const struct RkCheck RK_CHECKS[]={{\n'+''.join(f'{{{c["address"]}u,{c["bytes"]}u}},\n' for c in checks)+'};\n'
assembly='.section .data\n'
for r in (1,2,3):
 size=mem.arena[r]-g.REGION_BASE[r];blob=max(len(mem.blobs[r]),256);assert size>=blob
 config+=f'#define RK_REGION{r}_BYTES {size}u\n'
 assembly+=f'.balign 64\n.global rk_guard{r}a\nrk_guard{r}a:\n.fill 64,1,0xa5\n.global rk_region{r}\nrk_region{r}:\n.incbin "data/llama.region{r}.bin"\n.zero {size-blob}\n.global rk_guard{r}b\nrk_guard{r}b:\n.fill 64,1,0xa5\n'
assembly+='.section .note.GNU-stack,"",@progbits\n';(OUT/'data.S').write_text(assembly);(OUT/'rocket_data.h').write_text(config)
shutil.copyfile(repo/'tools/fixtures/radiance_rocket_llama.c',OUT/'driver.c')
startup=pathlib.Path('/scratch/agustin/projects/chipyard-mx/generators/gemmini/software/gemmini-rocc-tests/riscv-tests/benchmarks/common');riscv=pathlib.Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools');cc=riscv/'bin/riscv64-unknown-elf-gcc'
flags=['-DPREALLOCATE=1','-DMULTITHREAD=1','-DBAREMETAL=1','-DSPIKE_SIM','-mcmodel=medany','-O2','-ffreestanding','-fno-fast-math','-fno-math-errno','-ffp-contract=off','-fno-common','-fno-builtin','-fno-tree-loop-distribute-patterns','-march=rv64gc','-mabi=lp64d','-std=gnu11','-I',str(OUT),'-I',str(ROOT/'pinned-rocc-source'),'-I',str(startup),'-I',str(startup.parent.parent),'-I',str(startup.parent.parent/'env')]
commands=[]
def run(cmd,label,env=None):
 cmd=list(map(str,cmd));commands.append(cmd)
 with (OUT/(label+'.log')).open('wb') as f:subprocess.run(cmd,cwd=OUT,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=1800)
objects=[]
for i,p in enumerate([OUT/'driver.c',OUT/'data.S',*sorted(startup.glob('*.c')),*sorted(startup.glob('*.S'))]):
 obj=OUT/f'part{i}.o';run([cc,*flags,'-c',p,'-o',obj],f'compile{i}');objects.append(obj)
elf=OUT/'session.elf';run([cc,'-nostdlib','-nostartfiles','-static','-T',startup/'test.ld',*objects,'-lm','-lgcc','-o',elf],'link')
extlib=repo/'docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so'
env=os.environ|{'GEMMINI_MODE':'both','GEMMINI_PERF_CONFIG':'e4m3_vpu','GEMMINI_PERF_SET':'mem.host_tracking=0','GEMMINI_PERF_OUT':str(OUT/'perf.txt')}
run([riscv/'bin/spike','--isa=rv64gc_zicntr','--extlib='+str(extlib),'--extension=gemmini',elf],'spike',env)
console=(OUT/'spike.log').read_text();assert console.count('PORT_DONE')==1;assert 'MODEL DEADLOCK' not in console
observed={}
for line in console.splitlines():
 if not line.startswith('PORT_BYTES '):continue
 _,index,offset,count,*words=line.split();index,offset,count=map(int,(index,offset,count));a=observed.setdefault(index,bytearray());assert offset==len(a) and count==len(words);a.extend(int(w,16) for w in words)
results=[]
for i,c in enumerate(checks):
 a=bytes(observed[i]);b=bytes.fromhex(c['golden']);assert len(a)==len(b)==c['bytes'];(OUT/f'observed{i}.bin').write_bytes(a)
 mismatch=sum(x!=y for x,y in zip(a,b));row={'name':c['name'],'byte_mismatches':mismatch,'bytes':len(a)}
 if c['kind']=='bf16':
  f=lambda raw:(np.frombuffer(raw,'<u2').astype(np.uint32)<<16).view('f4')
  x,y=f(a),f(b);row|={'word_mismatches':int(np.count_nonzero(x!=y)),'max_abs':float(np.max(np.abs(x-y))),'rmse':float(np.sqrt(np.mean((x-y)**2))),'all_finite':bool(np.isfinite(x).all())}
 results.append(row)
 print(row,flush=True)
report={'scope':'random smoke model; source phase program port; not TinyLlama performance','results':results,'commands':commands,'total':re.findall(r'^PORT_TOTAL .+$',console,re.M)}
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
