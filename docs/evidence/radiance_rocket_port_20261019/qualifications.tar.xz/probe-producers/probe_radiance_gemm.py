import pathlib, sys, hashlib, importlib.util, json, os, subprocess, shutil
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT/'radiance-latest-5866983682'
OUT=ROOT/sys.argv[1]; OUT.mkdir()
M,N,K=map(int,sys.argv[2:5]); TM=M; TK=min(K,256)
spec=importlib.util.spec_from_file_location('radiance_data',SRC/'kernels/nightly/llama_e2e/gen_data.py'); gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen)
rng=np.random.default_rng(79)
ac,asc=gen.mx_quant(rng.normal(size=(M,K)).astype('f4')); bc,bsc=gen.mx_quant(rng.normal(size=(N,K)).astype('f4'))
b,bs=gen.pack_b(bc.T,bsc.T,TK);a,ass=gen.pack_a(ac,asc,TM,TK)
golden_dir=OUT/'golden';golden_dir.mkdir()
for p in (SRC/'lib/golden').iterdir(): shutil.copyfile(p,golden_dir/p.name)
spec=importlib.util.spec_from_file_location('radiance_golden',golden_dir/'golden.py'); gold=importlib.util.module_from_spec(spec);spec.loader.exec_module(gold)
golden=gold.mx_matmul(ac,bc.T,asc.T,bsc.T,M,N,K,tmpdir=OUT/'oracle')
arrays={'activation':ac,'activation_scales':asc.T,'weight':bc.T,'weight_scales':bsc.T,'golden_bf16':golden,'rk_a':a,'rk_as':ass,'rk_b':b,'rk_bs':bs}
payload=bytearray(); offsets={}
for name,arr in arrays.items():
 payload.extend(bytes(-len(payload)%64));offsets[name]=len(payload);payload.extend(np.ascontiguousarray(arr).tobytes())
(OUT/'payload.bin').write_bytes(payload)
(OUT/'payload.S').write_text('.section .rodata\n.balign 64\n.global payload\npayload:\n.incbin "payload.bin"\n.section .note.GNU-stack,"",@progbits\n')
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo),str(repo.parent/'merlin/src'),str(repo.parent/'model2mlir')]
from mx_gemmini_support.scheduled_native_issuer import emit_scheduled_native_issuer
from mx_gemmini_support.target_profile import load_profile
from tools.measure_native_kernel_pair import check_output
profile=load_profile(repo/'profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json')
schedule=emit_scheduled_native_issuer(profile,(M,N,K),precision='FP8',symbol='compiler_issue',tile_policy='movement')
(OUT/'compiler.c').write_text(schedule.issuer.source)
config={'PAIR_WORDS':M*N,'PAIR_TRIALS':3,'OFFSET_A':offsets['activation'],'OFFSET_AS':offsets['activation_scales'],'OFFSET_B':offsets['weight'],'OFFSET_BS':offsets['weight_scales'],'OFFSET_GOLD':offsets['golden_bf16']}
(OUT/'pair_config.h').write_text(''.join(f'#define {k} {v}\n' for k,v in config.items()))
shutil.copyfile(repo/'tools/fixtures/native_kernel_pair_driver.c',OUT/'driver.c')
header=(SRC/'lib/include/nightly/mx.h').read_text();header=header.replace('#include <mu_intrinsics.h>','')
header=header.replace('constexpr uint32_t ACC_ROWS = 256;', 'constexpr uint32_t ACC_ROWS = 512;')
start=header.index('/* GPU-local DRAM address');end=header.index('/* ---- configuration')
transport='''/* Rocket port: CPU physical addresses and RoCC replace Muon MMIO. */
static inline uint64_t host_addr(const void *p) { return (uint64_t)(uintptr_t)p; }
static inline uint64_t host_addr(uint32_t a) { return a; }
static inline void st32(uint32_t addr, uint32_t v) { __builtin_trap(); }
static inline uint32_t ld32(uint32_t addr) { __builtin_trap(); return 0; }
__attribute__((always_inline)) static inline void cmd(uint32_t funct, uint64_t rs1, uint64_t rs2) {
 asm volatile(".insn r 0x7b, 3, %2, x0, %0, %1" :: "r"(rs1), "r"(rs2), "i"(funct) : "memory");
}
static inline void fence() { asm volatile("fence" ::: "memory"); }
static inline uint32_t loops_issued() { __builtin_trap(); return 0; }
constexpr uint32_t RETIRED = CTRL + 0x38;
'''
header=header[:start]+transport+header[end:];(OUT/'rocket_mx.h').write_text(header)
kernel=(SRC/'kernels/nightly/llama_e2e/kernel.cpp').read_text();start=kernel.index('static uint32_t scale_sink');end=kernel.index('// =================================== Muon row operations')
section=kernel[start:end]
preamble='#include "rocket_mx.h"\nconstexpr uint32_t WARPS=4, NC=1, LL_TN=64;\n#define NIGHTLY_MX_LOOPS_SMEM (8000u * 16u)\n'
wrapper='\nextern "C" void native_issue(const void *,const void *,const void *,const void *,const void *c,const void *) {\nextern const unsigned char payload[];\nuint32_t d[32]={1,0};\n'
values=[f'(uintptr_t)(payload+{offsets[n]})' for n in ('rk_a','rk_as')]+['0','0']+[f'(uintptr_t)(payload+{offsets[n]})' for n in ('rk_b','rk_bs')]+['0','0','(uintptr_t)c','0',str(N*2),str(TM*N*2),'1',str(M//TM),str(N//64),str(K//TK),str(TM),str(TK)]
wrapper+=''.join(f'd[{i+2}]=(uint32_t)({v});\n' for i,v in enumerate(values))
wrapper+='mx::flush_tlb();mx::lut_disable();mx::config_ex(mx::FP8,mx::FP8,mx::BF16);gemm(d,0);\n}\n'
(OUT/'radiance.cpp').write_text(preamble+section+wrapper)
startup=pathlib.Path('/scratch/agustin/projects/chipyard-mx/generators/gemmini/software/gemmini-rocc-tests/riscv-tests/benchmarks/common')
riscv=pathlib.Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools')
flags=['-DPREALLOCATE=1','-DMULTITHREAD=1','-DBAREMETAL=1','-DSPIKE_SIM','-mcmodel=medany','-O2','-ffreestanding','-fno-fast-math','-ffp-contract=off','-fno-common','-fno-builtin','-fno-tree-loop-distribute-patterns','-march=rv64gc','-mabi=lp64d','-I',str(OUT),'-I',str(ROOT/'pinned-rocc-source'),'-I',str(startup),'-I',str(startup.parent.parent),'-I',str(startup.parent.parent/'env')]
commands=[]
def run(cmd,label,env=None):
 cmd=list(map(str,cmd));commands.append(cmd)
 with (OUT/(label+'.log')).open('wb') as f: subprocess.run(cmd,cwd=OUT,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=1800)
objects=[]
for i,p in enumerate([OUT/'radiance.cpp',OUT/'compiler.c',OUT/'payload.S',*sorted(startup.glob('*.c')),*sorted(startup.glob('*.S'))]):
 obj=OUT/f'part{i}.o';cc=riscv/('bin/riscv64-unknown-elf-g++' if p.suffix=='.cpp' else 'bin/riscv64-unknown-elf-gcc');run([cc,*flags,'-c',p,'-o',obj],f'compile{i}');objects.append(obj)
report={'scope':'radiance_latest_llama_gemm_Rocket_transport_port','shape_mnk':[M,N,K],'compiler_tiles':schedule.chunks,'offsets':offsets,'runs':[],'commands':commands}
for first in (0,1):
 cc=riscv/'bin/riscv64-unknown-elf-gcc';obj=OUT/f'driver{first}.o';elf=OUT/f'pair{first}.elf'
 run([cc,*flags,f'-DPAIR_COMPILER_FIRST={first}','-c',OUT/'driver.c','-o',obj],f'driver{first}')
 run([cc,'-nostdlib','-nostartfiles','-static','-T',startup/'test.ld',*objects,obj,'-lm','-lgcc','-o',elf],f'link{first}')
 env=os.environ|{'GEMMINI_MODE':'both','GEMMINI_PERF_CONFIG':'e4m3_vpu','GEMMINI_PERF_SET':'mem.host_tracking=0','GEMMINI_PERF_OUT':str(OUT/f'perf{first}.txt')}
 run([riscv/'bin/spike','--isa=rv64gc_zicntr','--extlib='+str(repo/'docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so'),'--extension=gemmini',elf],f'spike{first}',env)
 observations=check_output((OUT/f'spike{first}.log').read_text(),golden.tobytes(),3); report['runs'].append({'compiler_first':bool(first),'checks':observations});print(observations,flush=True)
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
