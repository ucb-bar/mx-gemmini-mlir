#include "rocket_mx.h"
constexpr uint32_t WARPS=4, NC=1, LL_TN=64;
#define NIGHTLY_MX_LOOPS_SMEM (8000u * 16u)
static uint32_t scale_sink[64] __attribute__((aligned(64)));   // dummy requantizer flush address
static uint32_t acc_parity = 0;                                // accumulator half of the next tile

struct GemmDesc {
  uint32_t a, asc, a_bs, asc_bs, b, bsc, b_bs, bsc_bs, c, c_bs, c_rs, c_ms, batch, MT, NT, KS, TM, TK;
};

// loads of step g (tile t0 + g / KS, k-step g % KS) into scratchpad buffer `buf`
__attribute__((always_inline)) static inline void gemm_loads(const GemmDesc &q, uint32_t t0, uint32_t g, uint32_t buf) {
  const uint32_t t = t0 + g / q.KS, s = g % q.KS;
  const uint32_t nt = t % q.NT, mt = (t / q.NT) % q.MT, bt = t / (q.NT * q.MT);
  const uint32_t A_ROWS = q.TM * q.TK / 16, B_ROWS = q.TK * LL_TN / 16;
  const uint32_t asc_step = q.TM * q.TK / 32, bsc_step = q.TK * LL_TN / 32;
  mx::set_ab_dram(mx::host_addr(q.a + bt * q.a_bs + (mt * q.KS + s) * q.TM * q.TK),
                  mx::host_addr(q.b + bt * q.b_bs + (s * q.NT + nt) * q.TK * LL_TN), q.TK, LL_TN);
  mx::loop_ws_spad(q.TM / 16, 4, q.TK / 16, buf * A_ROWS, 2 * A_ROWS + (buf + 1) * B_ROWS, 0, false, false,
                   {false, false, true, true, true});
  mx::load_scales(mx::host_addr(q.asc + bt * q.asc_bs + (mt * q.KS + s) * asc_step), asc_step, false,
                  buf ? mx::SF_BUF1 : 0);
  mx::load_scales(mx::host_addr(q.bsc + bt * q.bsc_bs + (nt * q.KS + s) * bsc_step), bsc_step, true,
                  buf ? mx::SF_BUF1 : 0);
}

// accumulator half `half` (tile t) -> C in DRAM, row-major bf16 with row stride c_rs
__attribute__((always_inline)) static inline void gemm_mvout(const GemmDesc &q, uint32_t t, uint32_t half) {
  const uint32_t nt = t % q.NT, mt = (t / q.NT) % q.MT, bt = t / (q.NT * q.MT);
  const uint64_t base = mx::host_addr(q.c + bt * q.c_bs + mt * q.c_ms + nt * LL_TN * 2);
  for (uint32_t i = 0; i < q.TM / 16; i++) {
    mx::mvout_acc(base + (uint64_t)i * 16 * q.c_rs, half * mx::ACC_HALF + i * 16, 16, 16, 0);
    mx::mvout_acc(base + (uint64_t)i * 16 * q.c_rs + 64, half * mx::ACC_HALF + i * 16, 16, 16, 1);
  }
}

// Fused GEMMs (d[20] = kind: 1 SILU, 2 ROPE, 3 PRENORM accumulation): while the GEMM thread runs, warps 1.. work on
// C tiles as they land.  The GEMM thread publishes, per tile, the LOOP_WS whose retirement proves the tile's mvout
// landed (the next loop issued after it), the retire counter itself once per k-step (so the workers poll SMEM, not the
// MMIO path the GEMM thread issues on), and DONE after its final fence.  Tiles split over clusters in pairs (one head;
// G_j, U_j).  All of it lives above every phase's SMEM map, next to the loop count.
enum : uint32_t { FUSE_SILU = 1, FUSE_ROPE = 2, FUSE_NORM = 3 };
constexpr uint32_t FUSE_DONE_SM = NIGHTLY_MX_LOOPS_SMEM + 4, FUSE_RET_SM = NIGHTLY_MX_LOOPS_SMEM + 8;
constexpr uint32_t FUSE_TAB_SM = NIGHTLY_MX_LOOPS_SMEM + 12, FUSE_SS_SM = 0x1FC00;   // FUSE_SS: PRENORM row sums
constexpr uint32_t FUSE_TAB_MAX = (FUSE_SS_SM - FUSE_TAB_SM) / 4;
constexpr uint32_t FUSE_STAGE_SM = 0x18000, FUSE_STAGE_BYTES = 0x1000;   // above the GEMM's A / B buffers (6144 rows)
static_assert(FUSE_STAGE_SM + (WARPS - 1) * FUSE_STAGE_BYTES <= NIGHTLY_MX_LOOPS_SMEM, "fused SMEM");

__attribute__((noinline)) static void gemm(const volatile uint32_t *d, uint32_t tb) {
  GemmDesc q;
  q.a = d[2]; q.asc = d[3]; q.a_bs = d[4]; q.asc_bs = d[5]; q.b = d[6]; q.bsc = d[7]; q.b_bs = d[8];
  q.bsc_bs = d[9]; q.c = d[10]; q.c_bs = d[11]; q.c_rs = d[12]; q.c_ms = d[13]; q.batch = d[14];
  q.MT = d[15]; q.NT = d[16]; q.KS = d[17]; q.TM = d[18]; q.TK = d[19];
  const uint32_t total = q.batch * q.MT * q.NT;
  const bool fused = d[20] != 0 && (d[20] != FUSE_NORM || NC == 1);   // fused: tile pairs stay on one cluster
  const uint32_t t0 = fused ? 2 * (total / 2 * tb / NC) : total * tb / NC;
  const uint32_t t1 = fused ? 2 * (total / 2 * (tb + 1) / NC) : total * (tb + 1) / NC;
  if (t0 == t1) {
    if (fused) mx::st32(FUSE_DONE_SM, 1);
    return;
  }
  const uint32_t I = q.TM / 16, KT = q.TK / 16;
  const uint32_t A_ROWS = q.TM * q.TK / 16, B_ROWS = q.TK * LL_TN / 16;
  mx::config_ld(q.TK, 0);
  mx::config_ld(LL_TN, 1);
  mx::config_st(q.c_rs);
  const uint32_t G = (t1 - t0) * q.KS;
  gemm_loads(q, t0, 0, 0);
  for (uint32_t g = 0; g < G; g++) {
    const uint32_t s = g % q.KS, buf = g & 1u;
    const bool last = s == q.KS - 1;
#if defined(LL_GEMM_FENCE) && LL_GEMM_FENCE
    // safe mode: everything issued so far (this step's loads included) has completed before its computes
    if (g > 0) mx::fence();
#endif
    // the config waits for this buffer's scale loads and is ordered with the computes
    mx::config_scale(I, 4, KT, buf, buf, mx::host_addr(scale_sink));
    mx::loop_ws_spad(I, 4, KT, buf * A_ROWS, 2 * A_ROWS + (buf + 1) * B_ROWS, 0, s > 0, last,
                     {true, true, true, false, true});
    // step g+1 into the other buffer: the reservation station orders the mvins after the computes of step
    // g-1 that read it; the scale loads wait until loop g is unrolled, when step g-1 has executed
    if (g + 1 < G) gemm_loads(q, t0, g + 1, buf ^ 1u);
    // the previous tile's stores go behind this tile's first compute
    if (s == 0 && g > 0) {
      const uint32_t t = t0 + g / q.KS - 1;
      gemm_mvout(q, t, (acc_parity + (t - t0)) & 1u);
      if (fused) mx::st32(FUSE_TAB_SM + 4 * (t - t0), mx::loops_issued() + 1);
    }
    if (fused) mx::st32(FUSE_RET_SM, mx::ld32(mx::RETIRED));
  }
  gemm_mvout(q, t1 - 1, (acc_parity + (t1 - 1 - t0)) & 1u);
  mx::fence();                                           // computes done, C stores acknowledged
  acc_parity ^= (t1 - t0) & 1u;
  if (fused) mx::st32(FUSE_DONE_SM, 1);
}


extern "C" void native_issue(const void *,const void *,const void *,const void *,const void *c,const void *) {
extern const unsigned char payload[];
uint32_t d[32]={1,0};
d[2]=(uint32_t)((uintptr_t)(payload+117760));
d[3]=(uint32_t)((uintptr_t)(payload+150528));
d[4]=(uint32_t)(0);
d[5]=(uint32_t)(0);
d[6]=(uint32_t)((uintptr_t)(payload+151552));
d[7]=(uint32_t)((uintptr_t)(payload+217088));
d[8]=(uint32_t)(0);
d[9]=(uint32_t)(0);
d[10]=(uint32_t)((uintptr_t)c);
d[11]=(uint32_t)(0);
d[12]=(uint32_t)(256);
d[13]=(uint32_t)(16384);
d[14]=(uint32_t)(1);
d[15]=(uint32_t)(1);
d[16]=(uint32_t)(2);
d[17]=(uint32_t)(2);
d[18]=(uint32_t)(64);
d[19]=(uint32_t)(256);
mx::flush_tlb();mx::lut_disable();mx::config_ex(mx::FP8,mx::FP8,mx::BF16);gemm(d,0);
}
