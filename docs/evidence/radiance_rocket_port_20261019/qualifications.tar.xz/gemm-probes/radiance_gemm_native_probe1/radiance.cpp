#include "rocket_mx.h"
constexpr uint32_t WARPS=4, NC=1, LL_TN=64;
#define NIGHTLY_MX_LOOPS_SMEM (8000u * 16u)

static inline void rocket_gemm(const volatile uint32_t *d) {
 const uint32_t MT=d[15], NT=d[16], KS=d[17], TM=d[18], TK=d[19];
 const uint32_t astep=TM*TK/32, bstep=TK*64/32;
 mx::config_ld(TK,0);mx::config_ld(64,1);mx::config_st(d[12]);
 for (uint32_t bt=0;bt<d[14];bt++)
  for (uint32_t mt=0;mt<MT;mt++)
   for (uint32_t nt=0;nt<NT;nt++)
    for (uint32_t k=0;k<KS;k++) {
     const uint64_t a=d[2]+bt*d[4]+(mt*KS+k)*TM*TK;
     const uint64_t as=d[3]+bt*d[5]+(mt*KS+k)*astep;
     const uint64_t b=d[6]+bt*d[8]+(k*NT+nt)*TK*64;
     const uint64_t bs=d[7]+bt*d[9]+(nt*KS+k)*bstep;
     const uint64_t c=d[10]+bt*d[11]+mt*d[13]+nt*64*2;
     mx::cmd(mx::LOOP_WS_CONFIG_SCALES,as,bs);
     mx::cmd(mx::LOOP_WS_CONFIG_SCALE_STRIDES,TM,64);
     mx::cmd(mx::LOOP_WS_CONFIG_BOUNDS,0,((uint64_t)(TK/16)<<32)|(4ull<<16)|(TM/16));
     mx::set_ab_dram(a,b,TK,64);
     mx::cmd(mx::LOOP_WS_CONFIG_ADDRS_DC,0,k==KS-1?c:0);
     mx::cmd(mx::LOOP_WS_CONFIG_STRIDES_DC,0,d[12]/2);
     const uint32_t half=1+(((((bt*MT+mt)*NT+nt)*KS+k))&1);
     mx::cmd(mx::LOOP_WS,(1ull<<18)|((uint64_t)half<<16)|(k>0),0);
    }
 mx::fence();
}

extern "C" void native_issue(const void *,const void *,const void *,const void *,const void *c,const void *) {
extern const unsigned char payload[];
uint32_t d[32]={1,0};
d[2]=(uint32_t)((uintptr_t)(payload+117760));
d[3]=(uint32_t)((uintptr_t)(payload+150528));
d[4]=(uint32_t)(0);
d[5]=(uint32_t)(0);
d[6]=(uint32_t)((uintptr_t)(payload+151552));
d[7]=(uint32_t)((uintptr_t)(payload+217088));
d[8]=(uint32_t)(0);
d[9]=(uint32_t)(0);
d[10]=(uint32_t)((uintptr_t)c);
d[11]=(uint32_t)(0);
d[12]=(uint32_t)(256);
d[13]=(uint32_t)(16384);
d[14]=(uint32_t)(1);
d[15]=(uint32_t)(1);
d[16]=(uint32_t)(2);
d[17]=(uint32_t)(2);
d[18]=(uint32_t)(64);
d[19]=(uint32_t)(256);
mx::flush_tlb();mx::lut_disable();mx::config_ex(mx::FP8,mx::FP8,mx::BF16);rocket_gemm(d);
}
