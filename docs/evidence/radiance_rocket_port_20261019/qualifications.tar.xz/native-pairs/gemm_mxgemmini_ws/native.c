#include "mx_native.h"
void native_issue(const void *a,const void *asc,const void *b,const void *bsc,const void *c,const void *scratch) {
  (void)scratch; if (mxn_matmul_ex(a,2048,b,64,(uint16_t *)c,64,asc,256,bsc,64,256,2048,64,0,0)) __builtin_trap();
  gemmini_fence();
}
