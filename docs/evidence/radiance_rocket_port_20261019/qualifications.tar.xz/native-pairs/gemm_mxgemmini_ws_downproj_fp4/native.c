#include "mx_native.h"
void native_issue(const void *a,const void *asc,const void *b,const void *bsc,const void *c,const void *scratch) {
  (void)scratch; if (mxn_matmul_fp4(a,5632,b,32,(uint16_t *)c,64,asc,256,bsc,64,256,5632,64)) __builtin_trap();
  gemmini_fence();
}
