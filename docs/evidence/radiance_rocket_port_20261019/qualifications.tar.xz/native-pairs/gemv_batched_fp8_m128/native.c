#include "mx_native.h"
void native_issue(const void *a,const void *asc,const void *b,const void *bsc,const void *c,const void *scratch) {
  (void)scratch; if (mxn_matmul_ex(a,2048,b,128,(uint16_t *)c,128,asc,128,bsc,128,128,2048,128,0,0)) __builtin_trap();
  gemmini_fence();
}
