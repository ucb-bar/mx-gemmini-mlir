#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_issue_411(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(256))), "r"(UINT64_C(0x0010001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(512))), "r"(UINT64_C(0x0010001000000020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(768))), "r"(UINT64_C(0x0004001000000030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(256))), "r"(UINT64_C(0x0010001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(512))), "r"(UINT64_C(0x0010001000001020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(768))), "r"(UINT64_C(0x0004001000001030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000d20004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0010001000002010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(512))), "r"(UINT64_C(0x0010001000002020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(768))), "r"(UINT64_C(0x0004001000002030)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_a[416] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_b[416] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_c[416] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 411; base += 411) {
    uint32_t count = 411 - base;
    if (count > 411) count = 411;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_a[index] = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_b[index] = 0;
        continue;
      }
      uint32_t word = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_narrow(lhs[(base + index)]);
      
      mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_a[index] = (uint16_t)word;
      mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_b[index] = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_narrow(rhs[(((base + index) / 137u % 3u) * 1u)]);
      
    }
    const void *a = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_a, *b = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_b, *c = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_c;
    switch (count) {
    case 411: mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_issue_411(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_widen(mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0_c[index]);
  }
}

#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_issue_411(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(256))), "r"(UINT64_C(0x0010001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(512))), "r"(UINT64_C(0x0010001000000020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(768))), "r"(UINT64_C(0x0004001000000030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(256))), "r"(UINT64_C(0x0010001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(512))), "r"(UINT64_C(0x0010001000001020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(768))), "r"(UINT64_C(0x0004001000001030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000d20004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0010001000002010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(512))), "r"(UINT64_C(0x0010001000002020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(768))), "r"(UINT64_C(0x0004001000002030)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_a[416] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_b[416] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_c[416] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 411; base += 411) {
    uint32_t count = 411 - base;
    if (count > 411) count = 411;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_a[index] = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_b[index] = 0;
        continue;
      }
      uint32_t word = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_narrow(lhs[(base + index)]);
      
      mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_a[index] = (uint16_t)word;
      mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_b[index] = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_narrow(rhs[(((base + index) % 137u) * 1u)]);
      
    }
    const void *a = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_a, *b = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_b, *c = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_c;
    switch (count) {
    case 411: mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_issue_411(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_widen(mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1_c[index]);
  }
}

void mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_materialized(const float *a, const float *b, const float *c,
            float *middle, float *output) {
          mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul0(a,b,middle); mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_mul1(middle,c,output);
        }
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void chain_issue_411(const void *a, const void *b, const void *c, const void *m, const void *o) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)a + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)a + UINT64_C(256))), "r"(UINT64_C(0x0010001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)a + UINT64_C(512))), "r"(UINT64_C(0x0010001000000020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)a + UINT64_C(768))), "r"(UINT64_C(0x0004001000000030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)b + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)b + UINT64_C(256))), "r"(UINT64_C(0x0010001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)b + UINT64_C(512))), "r"(UINT64_C(0x0010001000001020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)b + UINT64_C(768))), "r"(UINT64_C(0x0004001000001030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000d20004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)c + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)c + UINT64_C(256))), "r"(UINT64_C(0x0010001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)c + UINT64_C(512))), "r"(UINT64_C(0x0010001000001020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)c + UINT64_C(768))), "r"(UINT64_C(0x0004001000001030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000d00004002000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)o + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)o + UINT64_C(256))), "r"(UINT64_C(0x0010001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)o + UINT64_C(512))), "r"(UINT64_C(0x0010001000000020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)o + UINT64_C(768))), "r"(UINT64_C(0x0004001000000030)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

        static uint16_t aa[416] __attribute__((aligned(64)));
        static uint16_t bb[416] __attribute__((aligned(64)));
        static uint16_t cc[416] __attribute__((aligned(64)));
        static uint16_t rr[416] __attribute__((aligned(64)));
        static uint16_t chain_pack(float x, unsigned *safe) {
          union {float f; uint32_t u;} word; word.f=x;
          *safe &= (word.u & 0x7fffffffu) <= 1577058304u;
          word.u+=0x7fffu+((word.u>>16)&1u); return word.u>>16;
        }
        void mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_run(const float *a,const float *b,const float *c,float *middle,float *output) {
          if(!a || !b || !c || !middle || !output) __builtin_trap();
          for(uint32_t base=0;base<411;base+=411) {
            uint32_t count=411-base;
            if(count>411) count=411;
            unsigned safe=1;
            for(uint32_t i=0;i<(count+7u)/8u*8u;++i) {
              aa[i]=i<count ? chain_pack(a[base+i],&safe) : 0;
              bb[i]=i<count ? chain_pack(b[(((base + i) / 137u % 3u) * 1u)],&safe) : 0;
              cc[i]=i<count ? chain_pack(c[(((base + i) % 137u) * 1u)],&safe) : 0;
            }
            if(!safe) { mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_materialized(a,b,c,middle,output); return; }
            switch(count) { case 411: chain_issue_411(aa,bb,cc,rr,rr); break; default: __builtin_trap(); }
            for(uint32_t i=0;i<count;++i) {
              union {float f; uint32_t u;} word; word.u=(uint32_t)rr[i]<<16;
              output[base+i]=word.f;
            }
          }
        }

void mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel(const float *a, const float *b, const float *c, float *o) {
      static float middle[411] __attribute__((aligned(64)));
      mx_vpu_mul_chain_f32_1_3_137_inputs_1_3_137_axes_0_1_2__1_3_1_axes_0_1_2__137_axes_2_middle1_kernel_run(a,b,c,middle,o);
    }
