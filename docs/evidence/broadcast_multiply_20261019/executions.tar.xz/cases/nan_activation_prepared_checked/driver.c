#include <stdint.h>
      #include <stdio.h>
      extern const unsigned char payload[];
      void run_chain(const float *,const float *,const float *,float *,float *);
      void __attribute__((noreturn)) tohost_exit(uintptr_t);
      static float middle[24579] __attribute__((aligned(64)));
      static float output[24579] __attribute__((aligned(64)));
      uintptr_t handle_trap(uintptr_t cause,uintptr_t pc,uintptr_t regs[32]) {
        (void)regs; printf("REFUSAL_TRAP cause=%lu pc=%lu\n",(unsigned long)cause,(unsigned long)pc);
        tohost_exit(77);
      }
      int main(void) {
        const float *a=(const float *)payload,*b=a+3,*c=b+24579;
        printf("REFUSAL_BEGIN\n"); run_chain(a,b,c,middle,output);
        printf("REFUSAL_RETURNED\n");return 3;
      }
