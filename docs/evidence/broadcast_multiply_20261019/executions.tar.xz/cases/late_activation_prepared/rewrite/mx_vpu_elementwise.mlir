builtin.module {
  func.func @forward(%a: tensor<1x3x8193xf32>, %b: tensor<1x3x1xf32>, %c: tensor<8193xf32>) -> tensor<1x3x8193xf32> {
    %e0 = tensor.empty() : tensor<1x3x8193xf32>
    %e1 = tensor.empty() : tensor<1x3x8193xf32>
    %0 = tensor.empty() : tensor<1x3x8193xf32>
    %o = func.call @mx_vpu_mul_chain_f32_1_3_8193_inputs_1_3_1_axes_0_1_2__1_3_8193_axes_0_1_2__8193_axes_2_middle1(%b, %a, %c, %0) : (tensor<1x3x1xf32>, tensor<1x3x8193xf32>, tensor<8193xf32>, tensor<1x3x8193xf32>) -> tensor<1x3x8193xf32>
    func.return %o : tensor<1x3x8193xf32>
  }
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_1_3_8193_inputs_1_3_1_axes_0_1_2__1_3_8193_axes_0_1_2__8193_axes_2_middle1", function_type = (tensor<1x3x1xf32>, tensor<1x3x8193xf32>, tensor<8193xf32>, tensor<1x3x8193xf32>) -> tensor<1x3x8193xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}