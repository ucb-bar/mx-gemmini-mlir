builtin.module {
  func.func @forward(%a: tensor<1x1x2048xf32>, %b: tensor<1x1x1xf32>, %c: tensor<2048xf32>) -> tensor<1x1x2048xf32> {
    %e0 = tensor.empty() : tensor<1x1x2048xf32>
    %e1 = tensor.empty() : tensor<1x1x2048xf32>
    %0 = tensor.empty() : tensor<1x1x2048xf32>
    %o = func.call @mx_vpu_mul_chain_f32_1_1_2048_inputs_1_1_2048_axes_0_1_2__1_1_1_axes_0_1_2__2048_axes_2_middle1(%a, %b, %c, %0) : (tensor<1x1x2048xf32>, tensor<1x1x1xf32>, tensor<2048xf32>, tensor<1x1x2048xf32>) -> tensor<1x1x2048xf32>
    func.return %o : tensor<1x1x2048xf32>
  }
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_1_1_2048_inputs_1_1_2048_axes_0_1_2__1_1_1_axes_0_1_2__2048_axes_2_middle1", function_type = (tensor<1x1x2048xf32>, tensor<1x1x1xf32>, tensor<2048xf32>, tensor<1x1x2048xf32>) -> tensor<1x1x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}