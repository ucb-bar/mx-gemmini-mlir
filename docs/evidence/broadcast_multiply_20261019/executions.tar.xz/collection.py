import pathlib,json,hashlib,tarfile,io,subprocess,sys
import numpy as np
from merlin.frontends.linalg_mlir import parse_mlir_text
from mx_gemmini_support.merlin_vpu_elementwise import selected_elementwise_sites
from mx_gemmini_support.merlin_connected_multiply import multiply_pairs,chain_adapter,emit_chain_kernel,emit_chain_shim
from mx_gemmini_support.target_profile import load_profile
root=pathlib.Path('../.tmp/mx_model_goal_20261018/broadcast_suite_20261019').resolve()
out=pathlib.Path('docs/evidence/broadcast_multiply_20261019').resolve()
profile=load_profile(pathlib.Path('profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json'))
suite=json.loads((root/'suite.json').read_text());fixed=json.loads((root/'refusal_checked.json').read_text())
selected={name:row for name,row in suite['cases'].items()if row['exit_code']==0};selected.update(fixed)
assert len(selected)==13
members={};semantics={}
def add(name,raw):
 assert name not in members;members[name]=raw
for fixture in {row['fixture']for row in selected.values()}:
 p=root/'captures'/fixture
 for path in sorted(p.iterdir()):
  if path.is_file():add('captures/'+fixture+'/'+path.name,path.read_bytes())
for name,row in selected.items():
 assert row['exit_code']==0
 p=root/name;report=json.loads((p/'receipt.json').read_text());source=(root/'captures'/row['fixture']/'source.mlir').read_text()
 pair,=multiply_pairs(parse_mlir_text(source),selected_elementwise_sites(source,profile),include_broadcasts=True)
 selection={'prepare_broadcasts':report['prepare_broadcasts']}
 _,adapter=chain_adapter(pair,profile,**selection);code,_=emit_chain_kernel(pair,profile,**selection)
 assert (p/'materialized/issue.c').read_text()==adapter.lower(set()).source
 assert (p/'connected/issue.c').read_text()==code
 actual_shim=(p/'connected/shim.c').read_text();assert actual_shim.startswith(emit_chain_shim(pair))
 semantics[name]={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
  'materialized_c_sha256':hashlib.sha256(adapter.lower(set()).source.encode()).hexdigest(),
  'connected_c_sha256':hashlib.sha256(code.encode()).hexdigest(),
  'current_aligned_prepared_bytes':sum(plan.bytes for plan in adapter.broadcast_preparations),
  'raw_prepared_bytes':sum(plan.elements*2 for plan in adapter.broadcast_preparations),
  'current_repeated_preparations_removed':sum(plan.repeated_preparations_removed for plan in adapter.broadcast_preparations)}
 for path in sorted(p.rglob('*')):
  if path.is_file():add('cases/'+name+'/'+path.relative_to(p).as_posix(),path.read_bytes())
 # Bind the actual invocation retained by the outer harness too.
 add('cases/'+name+'/invocation.json',json.dumps(row,indent=2).encode()+b'\n')
for name in ('nan_activation_prepared','nan_weight_prepared'):
 for path in (root/(name+'.log'),root/name/'materialized/spike.log',root/name/'implementation/qualify_stage_multiply_spike.py'):
  add('protocol_correction/'+name+'/'+path.name,path.read_bytes())
add('protocol_correction/original_suite.json',(root/'suite.json').read_bytes())
add('semantic_check_current.json',json.dumps(semantics,indent=2,sort_keys=True).encode()+b'\n')
add('profile.json',pathlib.Path('profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json').read_bytes())
add('capture_broadcast_multiply_probe.py',pathlib.Path('tools/capture_broadcast_multiply_probe.py').read_bytes())
add('collection.py',pathlib.Path(__file__).read_bytes())
archive=out/'executions.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=6)as tar:
 for name,raw in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
manifest={'schema':'mx_gemmini.broadcast_evidence.v1','scope':'paired_compiled_sections_not_a_whole_model_result',
 'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
 'members':{name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}for name,raw in sorted(members.items())},
 'cases':{name:{'fixture':row['fixture']}for name,row in selected.items()}}
(out/'artifacts.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print('retained',len(members),'members',archive.stat().st_size,'bytes',flush=True)
