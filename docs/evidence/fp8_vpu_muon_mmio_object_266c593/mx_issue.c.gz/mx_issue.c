#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 4, "MX Muon MMIO commands require RV32");
/* Muon MX registers live in local shared memory, not global memory. */
#define MX_STORE_SHARED(base, offset, value) __asm__ volatile ("sw.shared %2, %1(%0)" : : "r"((uint32_t)(base)), "I"(offset), "r"((uint32_t)(value)) : "memory")

void mx_issue(const void *activation, const void *activation_scales, const void *output_bf16, const void *scratch_output_scales, const void *weight, const void *weight_scales, uintptr_t mx_control_base) {
  if (((uint64_t)(uintptr_t)activation_scales + UINT64_C(0)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight_scales + UINT64_C(0)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) & ~UINT64_C(0x1ffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight_scales + UINT64_C(128)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation_scales + UINT64_C(128)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0e20b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x000000000001c004);
    uint64_t mx_rs2 = UINT64_C(0x0001000000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100109);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(0)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(0)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(0));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(48));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(64));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(80));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(96));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(160));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(176));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(192));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(208));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(224));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(240));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4256));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4272));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4288));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4304));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4320));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4336));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8352));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8368));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8384));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8400));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8416));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8432));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12448));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12464));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12480));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12496));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12512));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12528));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16448));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16544));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16560));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16576));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16592));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16608));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16624));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20640));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20656));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20672));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20688));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20704));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20720));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24736));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24752));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24768));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24784));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24800));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24816));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28832));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28848));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28864));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28880));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28896));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28912));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(0));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(48));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(64));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(80));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(96));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4128));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4144));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4160));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4176));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4192));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4208));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12320));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12336));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12352));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12368));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12384));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12400));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16448));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(40960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(40976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(40992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x80201000000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000001000080008);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000080000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020008000000800);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(0));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2048));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5120));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5632));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6144));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6656));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7168));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7680));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9728));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11776));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13312));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13824));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14336));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14848));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15360));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15872));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17920));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19968));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22016));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24064));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25600));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27648));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29696));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31744));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33792));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35840));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37888));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39936));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40448));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41984));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44032));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46080));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47616));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49664));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51712));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53760));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55808));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57856));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59904));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61952));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(0)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(128)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(0));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(48));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(64));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(80));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(96));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(160));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(176));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(192));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(208));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(224));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(240));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4256));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4272));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4288));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4304));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4320));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(4336));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8352));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8368));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8384));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8400));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8416));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(8432));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12448));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12464));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12480));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12496));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12512));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(12528));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16448));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16544));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16560));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16576));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16592));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16608));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(16624));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20640));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20656));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20672));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20688));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20704));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(20720));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24736));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24752));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24768));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24784));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24800));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(24816));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28832));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28848));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28864));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28880));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28896));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(28912));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4256));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4272));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4288));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4304));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4320));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4336));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12448));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12464));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12480));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12496));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12512));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12528));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(33008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61600));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61616));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61632));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61648));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61664));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61680));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x80201000000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000001000080008);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000080000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020008000000800);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1792));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3840));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5376));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5888));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6400));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6912));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7424));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7936));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8448));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9984));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12032));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13568));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14080));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14592));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15104));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15616));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16128));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17664));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19712));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21760));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23808));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25856));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27904));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29952));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34048));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37632));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39680));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41728));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43776));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45824));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47872));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49920));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51968));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54016));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56064));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57600));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59648));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61696));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63744));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(128)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(0)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32928));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32944));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32960));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32976));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32992));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(33008));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37024));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37040));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37056));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37072));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37088));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37104));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(40960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(40976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(40992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41120));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41136));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41152));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41168));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41184));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41200));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45216));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45232));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45248));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45264));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45280));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45296));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49312));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49328));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49344));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49360));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49376));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49392));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53408));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53424));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53440));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53456));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53472));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53488));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57504));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57520));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57536));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57552));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57568));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57584));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61600));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61616));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61632));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61648));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61664));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61680));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(0));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(48));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(64));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(80));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(96));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4128));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4144));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4160));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4176));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4192));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4208));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12320));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12336));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12352));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12368));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12384));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12400));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16448));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(40960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(40976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(40992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x80201000000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000001000080008);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000080000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020008000000800);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66048));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69632));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70656));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71168));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71680));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72192));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72704));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73216));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73728));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75776));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77824));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78848));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79360));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79872));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80384));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80896));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81408));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81920));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83968));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86016));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88064));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89600));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91648));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93696));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95744));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97792));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99840));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101888));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103936));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104448));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105984));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108032));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110080));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111616));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113664));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115712));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117760));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119808));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121856));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123904));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125952));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130048));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(128)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(128)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0002000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32928));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32944));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32960));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32976));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(32992));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(33008));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(36992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37024));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37040));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37056));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37072));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37088));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(37104));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(40960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(40976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(40992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41120));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41136));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41152));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41168));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41184));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(41200));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45216));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45232));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45248));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45264));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45280));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(45296));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49312));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49328));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49344));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49360));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49376));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(49392));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53408));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53424));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53440));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53456));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53472));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(53488));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57504));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57520));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57536));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57552));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57568));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(57584));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61600));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61616));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61632));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61648));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61664));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)activation + UINT64_C(61680));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(128));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4256));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4272));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4288));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4304));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4320));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(4336));
    uint64_t mx_rs2 = UINT64_C(0x00100010000038f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(8432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12448));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12464));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12480));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12496));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12512));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(12528));
    uint64_t mx_rs2 = UINT64_C(0x00100010000039f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(16624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20640));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(20720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(24816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(28912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32912));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32960));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(32992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(33008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(36992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(37104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41104));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41152));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(41200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(45296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(49392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53424));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(53488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57472));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(57584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61600));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61616));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61632));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61648));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61664));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)weight + UINT64_C(61680));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = ((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x80201000000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000001000080008);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000080000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020008000000800);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65792));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67328));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67840));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68352));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68864));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69376));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69888));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70400));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70912));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71424));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71936));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72448));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72960));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73472));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73984));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74496));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75008));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75520));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76032));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76544));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77056));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77568));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78080));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78592));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79104));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79616));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80128));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80640));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81152));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81664));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82176));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82688));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83200));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83712));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84224));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84736));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85248));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85760));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86272));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86784));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000a90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87296));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000aa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87808));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ab0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88320));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ac0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88832));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ad0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89344));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ae0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89856));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000af0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90368));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90880));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91392));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91904));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92416));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92928));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93440));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93952));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94464));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94976));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000b90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95488));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ba0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96512));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97024));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97536));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000be0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98048));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000bf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98560));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99072));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99584));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100096));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100608));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101120));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101632));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102144));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102656));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103168));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000c90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103680));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ca0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104192));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104704));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105216));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105728));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ce0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106240));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000cf0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106752));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107264));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107776));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108288));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108800));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109312));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109824));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110336));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110848));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111360));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000d90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111872));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000da0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112384));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000db0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112896));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113408));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000dd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113920));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000de0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114432));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000df0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114944));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115456));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115968));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116480));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116992));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117504));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118016));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118528));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119040));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119552));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120064));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120576));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121088));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121600));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122112));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122624));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123136));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123648));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124160));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124672));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125184));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125696));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126208));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126720));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127232));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127744));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128256));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128768));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129280));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129792));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130304));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = ((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130816));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
}
