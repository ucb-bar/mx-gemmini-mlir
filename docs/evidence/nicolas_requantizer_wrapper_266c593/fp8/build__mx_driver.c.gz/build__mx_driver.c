#include <stdint.h>
#include <stdio.h>
extern const uint8_t activation[];
extern const uint8_t activation_scales[];
extern const uint8_t golden_bf16[];
extern const uint8_t golden_fp8[];
extern const uint8_t golden_output_scales[];
extern const uint8_t nicolas_fp8[];
extern const uint8_t nicolas_output_scales[];
extern const uint8_t output_scales[];
extern const uint8_t weight[];
extern const uint8_t weight_scales[];

static uint8_t output_quantized[4096] __attribute__((aligned(64)));
static uint8_t scratch_output_scales[2048] __attribute__((aligned(64)));

void mx_issue(const void *activation, const void *activation_scales, const void *output_quantized, const void *scratch_output_scales, const void *weight, const void *weight_scales);

int main(void) {
  mx_issue(activation, activation_scales, output_quantized, scratch_output_scales, weight, weight_scales);
  int code_errors = 0;
  int scale_errors = 0;
  for (uint32_t i = 0; i < 4096; ++i) {
    if (output_quantized[i] != nicolas_fp8[i]) {
      if (code_errors < 8)
        printf("CODE MISMATCH %u: got=0x%02x expected=0x%02x\n",
               i, output_quantized[i], nicolas_fp8[i]);
      ++code_errors;
    }
  }
  for (uint32_t i = 0; i < 128; ++i) {
    if (scratch_output_scales[i] != nicolas_output_scales[i]) {
      if (scale_errors < 8)
        printf("SCALE MISMATCH %u: got=0x%02x expected=0x%02x\n",
               i, scratch_output_scales[i], nicolas_output_scales[i]);
      ++scale_errors;
    }
  }
  printf("lowered MX 64x64x64: %d FP8 code mismatches, %d E8M0 scale mismatches\n",
         code_errors, scale_errors);
  return code_errors != 0 || scale_errors != 0;
}
