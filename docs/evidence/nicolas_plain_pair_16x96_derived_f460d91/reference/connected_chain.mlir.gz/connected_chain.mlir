module attributes {mx.profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c",
  mx.contract_sha256 = "043b8140516ce726c389d6c9c26c131faac7ef00dcb24e6d5dbf2e00591db944", mx.policy_sha256 = "9c9d507fb4fe33018cd001f30db6495df57417a5c09f0d556937d27e98a046d7",
  prov.quantization_manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0",
  mx.frontend_mlir_sha256 = "3a5cbaa50b00270bdf7a6c3d6ca5e8af0defb910eb12095b77866465fd5b0dbe",
  mx.runtime_resources_sha256 = "5cf5db4784055cd094451bb777ec4f0f0ae2435e6838a0ff2672eec303645b9a"} {
  func.func @nicolas_plain_chain_96(
      %a1: tensor<16x96xi8>, %a1s: tensor<3x16xi8>,
      %b1: tensor<96x96xi8>, %b1s: tensor<3x96xi8>,
      %b2: tensor<96x96xi8>, %b2s: tensor<3x96xi8>)
      -> (tensor<16x96xi8>, tensor<16x3xi8>) {
    %acc = "mx_gemmini.contract"(%a1, %a1s, %b1, %b1s) {
      site_id = "functional:matmul", activation_format = "fp8_e4m3",
      weight_format = "fp8_e4m3", activation_projection = "direct",
      weight_projection = "direct", pe_mode = 8 : i32, contract_sha256 = "043b8140516ce726c389d6c9c26c131faac7ef00dcb24e6d5dbf2e00591db944", policy_sha256 = "9c9d507fb4fe33018cd001f30db6495df57417a5c09f0d556937d27e98a046d7", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c"}
      : (tensor<16x96xi8>, tensor<3x16xi8>, tensor<96x96xi8>, tensor<3x96xi8>)
      -> tensor<16x96xbf16>
    %c1, %c1s = "mx_gemmini.readout_quantized"(%acc) {
      site_id = "functional:matmul", output_format = "fp8_e4m3", contract_sha256 = "043b8140516ce726c389d6c9c26c131faac7ef00dcb24e6d5dbf2e00591db944", policy_sha256 = "9c9d507fb4fe33018cd001f30db6495df57417a5c09f0d556937d27e98a046d7", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c"}
      : (tensor<16x96xbf16>) -> (tensor<16x96xi8>, tensor<16x3xi8>)
    %c2, %c2s = "mx_gemmini.resident_contract"(%c1, %c1s, %b2, %b2s) {
      site_id = "functional:matmul_1", activation_row = 2048 : i32,
      weight_row = 15808 : i32, output_row = 4096 : i32,
      m = 16 : i32, n = 96 : i32, k = 96 : i32,
      activation_format = "fp8_e4m3", weight_format = "fp8_e4m3",
      output_format = "fp8_e4m3", weight_buffer = "b2_weight",
      weight_scales_buffer = "b2_scales", output_scales_buffer = "c2_scales",
      contract_sha256 = "043b8140516ce726c389d6c9c26c131faac7ef00dcb24e6d5dbf2e00591db944", policy_sha256 = "9c9d507fb4fe33018cd001f30db6495df57417a5c09f0d556937d27e98a046d7", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c"}
      : (tensor<16x96xi8>, tensor<16x3xi8>, tensor<96x96xi8>, tensor<3x96xi8>)
      -> (tensor<16x96xi8>, tensor<16x3xi8>)
    func.return %c2, %c2s : tensor<16x96xi8>, tensor<16x3xi8>
  }
}
