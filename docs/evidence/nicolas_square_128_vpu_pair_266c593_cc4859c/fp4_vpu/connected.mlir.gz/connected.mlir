module attributes {mx.profile_sha256 = "e9e33f134ddd3d0770fe3cec26f89923b2c63ca21c06657d0ae4139c95a0d28d",
  mx.contract_sha256 = "ab0537c863946ed2d67c9563fcb3b27474865d49b466289eb5ba14e767ec1844",
  mx.policy_sha256 = "dc71c668056aac512c42f80f8da1bd92e06c4e3e6460ed1d4fc540e6dcc7f7a3",
  prov.quantization_manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0",
  mx.frontend_mlir_sha256 = "aceb05bb7d1e51e1d616b6b347cb0562bba31e34da321b398063228889d75587",
  mx.runtime_resources_sha256 = "a0a593b19ed951bc7a36d6206f2c0294f2b24b1c5ff24da8f1fe704aacfc6bdf"} {
  func.func @nicolas_connected_vpu_pair(
      %a1: tensor<128x128xi8>, %a1s: tensor<4x128xi8>,
      %b1: tensor<128x128xi8>, %b1s: tensor<4x128xi8>,
      %b2: tensor<128x128xi8>, %b2s: tensor<4x128xi8>)
      -> (tensor<128x128xi8>, tensor<128x4xi8>) {
    %acc = "mx_gemmini.contract"(%a1, %a1s, %b1, %b1s) {
      site_id = "functional:matmul", activation_format = "fp8_e4m3",
      weight_format = "fp8_e4m3", activation_projection = "direct",
      weight_projection = "direct", pe_mode = 8 : i32, contract_sha256 = "ab0537c863946ed2d67c9563fcb3b27474865d49b466289eb5ba14e767ec1844", policy_sha256 = "dc71c668056aac512c42f80f8da1bd92e06c4e3e6460ed1d4fc540e6dcc7f7a3", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "e9e33f134ddd3d0770fe3cec26f89923b2c63ca21c06657d0ae4139c95a0d28d"}
      : (tensor<128x128xi8>, tensor<4x128xi8>, tensor<128x128xi8>, tensor<4x128xi8>)
      -> tensor<128x128xbf16>
    %bf16 = "mx_gemmini.readout_bf16"(%acc) {
      site_id = "functional:matmul", contract_sha256 = "ab0537c863946ed2d67c9563fcb3b27474865d49b466289eb5ba14e767ec1844", policy_sha256 = "dc71c668056aac512c42f80f8da1bd92e06c4e3e6460ed1d4fc540e6dcc7f7a3", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "e9e33f134ddd3d0770fe3cec26f89923b2c63ca21c06657d0ae4139c95a0d28d"}
      : (tensor<128x128xbf16>) -> tensor<128x128xbf16>
    %vpu = "mx_gemmini.vpu_execute"(%bf16) {
      site_id = "functional:matmul", kind = "muls",
      src1_row = 4096 : i32, src2_row = 0 : i32,
      dst_row = 4096 : i32, rows = 2048 : i32,
      reduction_length = 1 : i32, broadcast = false,
      immediate_bf16 = 16384 : i32, contract_sha256 = "ab0537c863946ed2d67c9563fcb3b27474865d49b466289eb5ba14e767ec1844", policy_sha256 = "dc71c668056aac512c42f80f8da1bd92e06c4e3e6460ed1d4fc540e6dcc7f7a3", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "e9e33f134ddd3d0770fe3cec26f89923b2c63ca21c06657d0ae4139c95a0d28d"}
      : (tensor<128x128xbf16>) -> tensor<128x128xbf16>
    %c1, %c1s = "mx_gemmini.spad_requant"(%vpu) {
      site_id = "functional:matmul", source_row = 4096 : i32,
      destination_row = 2048 : i32, m = 128 : i32, n = 128 : i32,
      output_format = "fp8_e4m3", tiled = true, resident = true,
      scale_dram_address = 0 : i64, scale_buffer = "c1_scales", contract_sha256 = "ab0537c863946ed2d67c9563fcb3b27474865d49b466289eb5ba14e767ec1844", policy_sha256 = "dc71c668056aac512c42f80f8da1bd92e06c4e3e6460ed1d4fc540e6dcc7f7a3", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "e9e33f134ddd3d0770fe3cec26f89923b2c63ca21c06657d0ae4139c95a0d28d"}
      : (tensor<128x128xbf16>) -> (tensor<128x128xi8>, tensor<128x4xi8>)
    %c2, %c2s = "mx_gemmini.resident_contract"(%c1, %c1s, %b2, %b2s) {
      site_id = "functional:matmul_1", activation_row = 2048 : i32,
      weight_row = 15360 : i32, output_row = 8192 : i32,
      m = 128 : i32, n = 128 : i32, k = 128 : i32,
      activation_format = "fp8_e4m3", weight_format = "fp8_e4m3",
      output_format = "fp8_e4m3", weight_buffer = "b2_weight",
      weight_scales_buffer = "b2_scales", output_scales_buffer = "c2_scales",
      contract_sha256 = "ab0537c863946ed2d67c9563fcb3b27474865d49b466289eb5ba14e767ec1844", policy_sha256 = "dc71c668056aac512c42f80f8da1bd92e06c4e3e6460ed1d4fc540e6dcc7f7a3", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "e9e33f134ddd3d0770fe3cec26f89923b2c63ca21c06657d0ae4139c95a0d28d"}
      : (tensor<128x128xi8>, tensor<128x4xi8>, tensor<128x128xi8>, tensor<4x128xi8>)
      -> (tensor<128x128xi8>, tensor<128x4xi8>)
    func.return %c2, %c2s : tensor<128x128xi8>, tensor<128x4xi8>
  }
}
