#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void chain_mul_0_issue_137(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x00004a0004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0002001000002010)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t chain_mul_0_a[144] __attribute__((aligned(64)));
static uint16_t chain_mul_0_b[144] __attribute__((aligned(64)));
static uint16_t chain_mul_0_c[144] __attribute__((aligned(64)));
static uint16_t chain_mul_0_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float chain_mul_0_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void chain_mul_0(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 137; base += 137) {
    uint32_t count = 137 - base;
    if (count > 137) count = 137;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        chain_mul_0_a[index] = chain_mul_0_b[index] = 0;
        continue;
      }
      uint32_t word = chain_mul_0_narrow(lhs[(base + index)]);
      chain_mul_0_a[index] = (uint16_t)word;
      chain_mul_0_b[index] = chain_mul_0_narrow(rhs[(base + index)]);
    }
    const void *a = chain_mul_0_a, *b = chain_mul_0_b, *c = chain_mul_0_c;
    switch (count) {
    case 137: chain_mul_0_issue_137(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = chain_mul_0_widen(chain_mul_0_c[index]);
  }
}

#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void chain_mul_1_issue_137(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x00004a0004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0002001000002010)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t chain_mul_1_a[144] __attribute__((aligned(64)));
static uint16_t chain_mul_1_b[144] __attribute__((aligned(64)));
static uint16_t chain_mul_1_c[144] __attribute__((aligned(64)));
static uint16_t chain_mul_1_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float chain_mul_1_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void chain_mul_1(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 137; base += 137) {
    uint32_t count = 137 - base;
    if (count > 137) count = 137;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        chain_mul_1_a[index] = chain_mul_1_b[index] = 0;
        continue;
      }
      uint32_t word = chain_mul_1_narrow(lhs[(base + index)]);
      chain_mul_1_a[index] = (uint16_t)word;
      chain_mul_1_b[index] = chain_mul_1_narrow(rhs[(base + index)]);
    }
    const void *a = chain_mul_1_a, *b = chain_mul_1_b, *c = chain_mul_1_c;
    switch (count) {
    case 137: chain_mul_1_issue_137(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = chain_mul_1_widen(chain_mul_1_c[index]);
  }
}

void materialized_chain(const float *a, const float *b, const float *c,
            float *middle, float *output) {
          chain_mul_0(a,b,middle); chain_mul_1(middle,c,output);
        }

              void run_chain(const float *a,const float *b,const float *c,float *m,float *o) {
                materialized_chain(a,b,c,m,o);
              }
