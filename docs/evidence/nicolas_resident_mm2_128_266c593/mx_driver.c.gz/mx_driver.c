#include <stdint.h>
#include <stdio.h>
extern const uint8_t b2_scales[];
extern const uint8_t b2_weight[];
extern const uint8_t c1_act_scales[];
extern const uint8_t c1_tiled[];
extern const uint8_t c2_codes_ref[];
extern const uint8_t c2_scales_ref[];
static uint8_t c2_scales[512] __attribute__((aligned(64)));
static uint8_t c2_tiled[16384] __attribute__((aligned(64)));
void mx_issue(const void *b2_scales, const void *b2_weight, const void *c1_act_scales, const void *c1_tiled, const void *c2_scales, const void *c2_tiled);

int main(void) {
  mx_issue(b2_scales, b2_weight, c1_act_scales, c1_tiled, c2_scales, c2_tiled);
  int codes = 0, scales = 0;
  for (uint32_t row = 0; row < 128; ++row)
    for (uint32_t col = 0; col < 128; ++col) {
      uint32_t tiled = (((row / 16) * 8 + col / 16) * 16 + row % 16) * 16 + col % 16;
      codes += c2_tiled[tiled] != c2_codes_ref[row * 128 + col];
    }
  for (uint32_t i = 0; i < 512; ++i)
    scales += c2_scales[i] != c2_scales_ref[i];
  printf("lowered resident MM2 128x128: %d FP8 code mismatches, %d E8M0 scale mismatches\n",
         codes, scales);
  return codes || scales;
}
