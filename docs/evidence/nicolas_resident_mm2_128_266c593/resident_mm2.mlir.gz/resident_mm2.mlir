module attributes {mx.profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c",
  mx.contract_sha256 = "043b8140516ce726c389d6c9c26c131faac7ef00dcb24e6d5dbf2e00591db944", mx.policy_sha256 = "337976347539b12cfe11d643ccced28ebc35a3507fc603163601c16dcefc3258",
  prov.quantization_manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0"} {
  func.func @nicolas_resident_mm2(
      %c1: tensor<128x128xi8>, %c1s: tensor<128x4xi8>,
      %b2: tensor<128x128xi8>, %b2s: tensor<4x128xi8>)
      -> (tensor<128x128xi8>, tensor<128x4xi8>) {
    %c2, %c2s = "mx_gemmini.resident_contract"(%c1, %c1s, %b2, %b2s) {
      site_id = "nicolas:chain:mm2", activation_row = 2048 : i32,
      weight_row = 15360 : i32, output_row = 4096 : i32,
      m = 128 : i32, n = 128 : i32, k = 128 : i32,
      activation_format = "fp8_e4m3", weight_format = "fp8_e4m3",
      output_format = "fp8_e4m3", weight_buffer = "b2_weight",
      weight_scales_buffer = "b2_scales", output_scales_buffer = "c2_scales",
      contract_sha256 = "043b8140516ce726c389d6c9c26c131faac7ef00dcb24e6d5dbf2e00591db944", policy_sha256 = "337976347539b12cfe11d643ccced28ebc35a3507fc603163601c16dcefc3258", manifest_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0", profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c"}
      : (tensor<128x128xi8>, tensor<128x4xi8>, tensor<128x128xi8>, tensor<4x128xi8>)
      -> (tensor<128x128xi8>, tensor<128x4xi8>)
    func.return %c2, %c2s : tensor<128x128xi8>, tensor<128x4xi8>
  }
}
