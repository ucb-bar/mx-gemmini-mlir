builtin.module {
  "schedule.plan"() <{sym_name = "mx_dense_kernel_134_plan", source = #schedule<policy_source kernel_mining>}> ({
    %0 = "schedule.bind"() <{target = "@mx_dense_kernel_134"}> : () -> !schedule.handle
    "schedule.apply_policy"(%0) <{policy = "mx_native_transfer_guarded_dram_loop"}> : (!schedule.handle) -> ()
  }) : () -> ()
}