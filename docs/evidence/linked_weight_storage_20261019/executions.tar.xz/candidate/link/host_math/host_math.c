#include <stdint.h>
extern float __real_expf(float);
extern float __ieee754_expf(float);
float __wrap_expf(float x) {
  union { float f; uint32_t u; } word = { .f = x };
  if (word.u == 4286578688u) { word.u = 0u; return word.f; }
  if ((word.u & 0x7fffffffu) <= 1117782016u) return __ieee754_expf(x);
  return __real_expf(x);
}
