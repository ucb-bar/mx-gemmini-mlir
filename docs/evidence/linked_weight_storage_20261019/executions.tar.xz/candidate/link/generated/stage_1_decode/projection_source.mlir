"builtin.module"() ({
  "func.func"() <{sym_name = "merlin_stage_1_decode", function_type = (tensor<32x32xf32>, tensor<32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> (tensor<16x32xf32>, tensor<16x32xf32>)}> ({
  ^bb0(%0: tensor<32x32xf32>, %1: tensor<32xf32>, %2: tensor<16x32xf32>, %3: tensor<16x32xf32>):
    %4 = "tensor.empty"() : () -> tensor<16x32xf32>
    %5 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.module = "linear"} : () -> f32
    %6 = "linalg.fill"(%5, %4) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb1(%7: f32, %8: f32):
      "linalg.yield"(%7) : (f32) -> ()
    }) {prov.op = "fill", prov.family = "fill", prov.module = "linear"} : (f32, tensor<16x32xf32>) -> tensor<16x32xf32>
    %9 = "tensor.empty"() : () -> tensor<32x32xf32>
    %10 = "func.call"(%2, %9, %6) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %11 = "tensor.empty"() : () -> tensor<16x32xf32>
    %12 = "tensor.empty"() : () -> tensor<16x32xf32>
    %13 = "func.call"(%10, %1, %12) <{callee = @mx_vpu_add_f32_bias_16_32}> : (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %14 = "tensor.empty"() : () -> tensor<16x32xf32>
    %15 = "tensor.empty"() : () -> tensor<16x32xf32>
    %16 = "func.call"(%13, %3, %15) <{callee = @mx_vpu_add_f32_same_16_32}> : (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %17 = "arith.constant"() <{value = 1.250000e-01 : f32}> {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} : () -> f32
    %18 = "tensor.empty"() : () -> tensor<16x32xf32>
    %19 = "tensor.splat"(%17) : (f32) -> tensor<f32>
    %20 = "tensor.empty"() : () -> tensor<16x32xf32>
    %21 = "func.call"(%16, %19, %20) <{callee = @mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_}> : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %22 = "arith.constant"() <{value = 0xff800000 : f32}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : () -> f32
    %23 = "tensor.splat"(%22) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (f32) -> tensor<16xf32>
    %24 = "linalg.reduce"(%21, %23) <{dimensions = array<i64: 1>}> ({
    ^bb2(%25: f32, %26: f32):
      %27 = "arith.maximumf"(%25, %26) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%27) : (f32) -> ()
    }) : (tensor<16x32xf32>, tensor<16xf32>) -> tensor<16xf32>
    %28 = "tensor.expand_shape"(%24) <{reassociation = [[0 : i64, 1 : i64]], static_output_shape = array<i64: 16, 1>}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16xf32>) -> tensor<16x1xf32>
    %29 = "tensor.empty"() : () -> tensor<16x32xf32>
    %30 = "linalg.generic"(%21, %28, %29) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb3(%31: f32, %32: f32, %33: f32):
      %34 = "arith.subf"(%31, %32) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%34) : (f32) -> ()
    }) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16x32xf32>, tensor<16x1xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %35 = "tensor.empty"() : () -> tensor<16x32xf32>
    %36 = "linalg.generic"(%30, %35) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb4(%37: f32, %38: f32):
      %39 = "math.exp"(%37) <{fastmath = #arith.fastmath<none>}> : (f32) -> f32
      "linalg.yield"(%39) : (f32) -> ()
    }) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %40 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : () -> f32
    %41 = "tensor.splat"(%40) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (f32) -> tensor<16xf32>
    %42 = "linalg.reduce"(%36, %41) <{dimensions = array<i64: 1>}> ({
    ^bb5(%43: f32, %44: f32):
      %45 = "arith.addf"(%43, %44) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%45) : (f32) -> ()
    }) : (tensor<16x32xf32>, tensor<16xf32>) -> tensor<16xf32>
    %46 = "tensor.expand_shape"(%42) <{reassociation = [[0 : i64, 1 : i64]], static_output_shape = array<i64: 16, 1>}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16xf32>) -> tensor<16x1xf32>
    %47 = "tensor.empty"() : () -> tensor<16x32xf32>
    %48 = "linalg.generic"(%36, %46, %47) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb6(%49: f32, %50: f32, %51: f32):
      %52 = "arith.divf"(%49, %50) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%52) : (f32) -> ()
    }) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16x32xf32>, tensor<16x1xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %53 = "arith.constant"() <{value = 5.000000e-01 : f32}> {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} : () -> f32
    %54 = "tensor.empty"() : () -> tensor<16x32xf32>
    %55 = "tensor.splat"(%53) : (f32) -> tensor<f32>
    %56 = "tensor.empty"() : () -> tensor<16x32xf32>
    %57 = "func.call"(%48, %55, %56) <{callee = @mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_}> : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    "func.return"(%48, %57) : (tensor<16x32xf32>, tensor<16x32xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_bias_16_32", function_type = (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_16_32", function_type = (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/guarded_session_fixture_20261019/capture/stages/decode/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()