/* Generated multi-program session API. */
#ifndef MERLIN_SESSION_H
#define MERLIN_SESSION_H
#define MERLIN_SESSION_N_PROGRAMS 2
const char *merlin_session_program_name(int program);
long merlin_session_program_steps(int program);
void merlin_session_reset(void);
int merlin_session_prepare_program(int program);
int merlin_session_run_step(int program, const void *weights, long step, int validate);
long merlin_session_quality_steps(void);
long merlin_session_quality_min_cos_ppm(void);
long merlin_session_quality_max_rel_ppm(void);
long merlin_session_quality_top1(void);
long merlin_session_correctness_steps(void);
long merlin_session_correctness_min_cos_ppm(void);
long merlin_session_correctness_max_rel_ppm(void);
long merlin_session_correctness_top1(void);
void *merlin_session_quality_output(void);
size_t merlin_session_quality_output_elems(void);
long merlin_session_quality_output_lastdim(void);
#endif
