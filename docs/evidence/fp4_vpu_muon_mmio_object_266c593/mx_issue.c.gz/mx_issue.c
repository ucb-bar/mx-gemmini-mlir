#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 4, "MX Muon MMIO commands require RV32");
/* Muon MX registers live in local shared memory, not global memory. */
#define MX_STORE_SHARED(base, offset, value) __asm__ volatile ("sw.shared %2, %1(%0)" : : "r"((uint32_t)(base)), "I"(offset), "r"((uint32_t)(value)) : "memory")

void mx_issue(const void *activation, const void *activation_scales, const void *output_bf16, const void *scratch_output_scales, const void *weight, const void *weight_scales, uintptr_t mx_control_base) {
  if (((uint64_t)(uintptr_t)activation_scales + UINT64_C(0)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight_scales + UINT64_C(0)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(0)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(32)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(48)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(64)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(80)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(96)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4096)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(0)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(32)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(48)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2048)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2064)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2080)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2096)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4096)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & ~UINT64_C(0x1ffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation_scales + UINT64_C(1024)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(1024)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight_scales + UINT64_C(1024)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(1024)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(4336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(8432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(12528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(0)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1024)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1280)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1536)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1792)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2048)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2816)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3072)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3328)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3584)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3840)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4096)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4864)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5120)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5376)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5632)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5888)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6912)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7168)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7424)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7680)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7936)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8960)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9216)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9472)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9728)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9984)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11008)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11264)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11520)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11776)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12032)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12800)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13056)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13312)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13568)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13824)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14080)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14848)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15104)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15360)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15616)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15872)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16896)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17152)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17408)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17664)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17920)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18944)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19200)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19456)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19712)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19968)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20992)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21248)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21504)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21760)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22016)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23040)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23296)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23552)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23808)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24064)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24832)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25088)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25344)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25600)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25856)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26880)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27136)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27392)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27648)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27904)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28928)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29184)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29440)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29696)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29952)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30976)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31232)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31488)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31744)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32000)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight_scales + UINT64_C(128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(128)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(64)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(80)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(96)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(2160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(4208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(6256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(8304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(10352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(12400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(14448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight_scales + UINT64_C(1152)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)weight_scales + UINT64_C(1152)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(16496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(18544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(20592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(22640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(24688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(26736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(28784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30800)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30816)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)weight + UINT64_C(30832)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33024)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33280)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33536)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33792)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34048)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34816)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35072)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35328)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35584)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35840)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36096)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36864)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37120)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37376)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37632)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37888)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38912)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39168)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39424)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39680)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39936)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40960)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41216)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41472)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41728)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41984)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43008)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43264)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43520)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43776)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44032)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44800)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45056)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45312)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45568)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45824)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46080)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46848)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47104)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47360)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47616)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47872)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48896)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49152)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49408)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49664)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49920)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50944)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51200)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51456)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51712)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51968)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52992)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53248)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53504)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53760)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54016)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55040)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55296)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55552)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55808)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56064)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56832)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57088)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57344)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57600)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57856)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58880)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59136)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59392)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59648)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59904)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60928)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61184)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61440)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61696)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61952)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62976)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63232)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63488)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63744)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64000)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65024)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65280)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation_scales + UINT64_C(128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(128)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation_scales + UINT64_C(1152)) >= UINT64_C(0x100000000)) __builtin_trap();
  if ((((uint64_t)(uintptr_t)activation_scales + UINT64_C(1152)) | UINT64_C(0x100000000)) & ~UINT64_C(0xffffffffff)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(16624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(20720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24800)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(24816)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28800)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28816)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28832)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28848)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28864)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28880)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28896)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)activation + UINT64_C(28912)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65536)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65792)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66048)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66816)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67072)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67328)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67584)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67840)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68096)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68864)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69120)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69376)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69632)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69888)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70912)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71168)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71424)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71680)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71936)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72960)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73216)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73472)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73728)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73984)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75008)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75264)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75520)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75776)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76032)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76800)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77056)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77312)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77568)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77824)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78080)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78848)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79104)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79360)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79616)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79872)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80896)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81152)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81408)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81664)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81920)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82944)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83200)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83456)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83712)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83968)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84992)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85248)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85504)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85760)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86016)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87040)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87296)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87552)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87808)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88064)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88832)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89088)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89344)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89600)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89856)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90880)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91136)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91392)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91648)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91904)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92928)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93184)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93440)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93696)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93952)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94976)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95232)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95488)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95744)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96000)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97024)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97280)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97536)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97792)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98048)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98816)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99072)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99328)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99584)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99840)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100096)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100352)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100608)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100864)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101120)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101376)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101632)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101888)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102144)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102400)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102656)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102912)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103168)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103424)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103680)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103936)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104192)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104448)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104704)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104960)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105216)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105472)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105728)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105984)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106240)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106496)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106752)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107008)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107264)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107520)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107776)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108032)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108288)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108544)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108800)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109056)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109312)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109568)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109824)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110080)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110336)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110592)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110848)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111104)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111360)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111616)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111872)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112128)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112384)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112640)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112896)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113152)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113408)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113664)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113920)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114176)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114432)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114688)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114944)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115200)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115456)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115712)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115968)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116224)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116480)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116736)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116992)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117248)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117504)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117760)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118016)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118272)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118528)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118784)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119040)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119296)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119552)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119808)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120064)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120320)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120576)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120832)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121088)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121344)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121600)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121856)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122112)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122368)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122624)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122880)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123136)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123392)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123648)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123904)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124160)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124416)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124672)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124928)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125184)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125440)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125696)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125952)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126208)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126464)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126720)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126976)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127232)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127488)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127744)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128000)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128256)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128512)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128768)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129024)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129280)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129536)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129792)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130048)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130304)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130560)) >= UINT64_C(0x100000000)) __builtin_trap();
  if (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130816)) >= UINT64_C(0x100000000)) __builtin_trap();
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0e20b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x000000000001e804);
    uint64_t mx_rs2 = UINT64_C(0x0001000000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100109);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(0)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(32)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(48)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(64)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(80)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(96)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(0)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(32)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(48)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2048)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2064)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2080)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x40100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x00000200000002b8);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(1024)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(1024)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x3040100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000001000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000003000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000001);
    uint64_t mx_rs2 = UINT64_C(0x0000020000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020002000000200);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(0)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1024)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1280)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1536)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(1792)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2048)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(2816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3072)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3328)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3584)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(3840)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(4864)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5120)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5376)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5632)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(5888)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(6912)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7168)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7424)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7680)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(7936)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(8960)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9216)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9472)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9728)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(9984)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(10752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11008)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11264)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11520)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(11776)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12032)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(12800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13056)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13312)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13568)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(13824)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14080)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(14848)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15104)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15360)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15616)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(15872)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(16896)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17152)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17408)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17664)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(17920)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(18944)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19200)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19456)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19712)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(19968)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(20992)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21248)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21504)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(21760)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22016)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(22784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23040)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23296)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23552)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(23808)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24064)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(24832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25088)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25344)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25600)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(25856)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(26880)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27136)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27392)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27648)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(27904)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(28928)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29184)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29440)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29696)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(29952)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(30976)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31232)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31488)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(31744)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32000)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(128)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(0)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(32)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(48)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(64)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(80)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(96)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(64)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(80)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(96)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x40100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x00000200000002b8);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(1024)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(1152)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(4336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(8432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(12528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x3040100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000001000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000003000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000001);
    uint64_t mx_rs2 = UINT64_C(0x0000020000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020002000000200);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(32768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33024)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33280)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33536)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(33792)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34048)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(34816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35072)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35328)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35584)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(35840)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(36864)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37120)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37376)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37632)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(37888)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(38912)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39168)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39424)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39680)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(39936)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(40960)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41216)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41472)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41728)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(41984)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(42752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43008)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43264)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43520)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(43776)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44032)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(44800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45056)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45312)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45568)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(45824)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46080)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(46848)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47104)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47360)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47616)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(47872)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(48896)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49152)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49408)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49664)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(49920)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(50944)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51200)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51456)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51712)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(51968)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(52992)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53248)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53504)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(53760)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54016)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(54784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55040)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55296)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55552)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(55808)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56064)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(56832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57088)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57344)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57600)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(57856)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(58880)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59136)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59392)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59648)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(59904)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(60928)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61184)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61440)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61696)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(61952)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(62976)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63232)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63488)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(63744)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64000)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(64768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65024)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65280)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(128)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(0)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(32)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(48)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2048)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2064)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2080)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x40100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x00000200000002b8);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(1152)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(1024)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28848)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28864)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28880)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28896)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28912)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x3040100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000001000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000003000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000001);
    uint64_t mx_rs2 = UINT64_C(0x0000020000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020002000000200);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65536)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(65792)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66048)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(66816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67072)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67328)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67584)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(67840)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(68864)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69120)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69376)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69632)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(69888)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(70912)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71168)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71424)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71680)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(71936)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(72960)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73216)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73472)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73728)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(73984)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(74752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75008)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75264)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75520)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(75776)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76032)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(76800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77056)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77312)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77568)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(77824)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78080)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(78848)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79104)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79360)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79616)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(79872)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(80896)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81152)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81408)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81664)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(81920)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(82944)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83200)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83456)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83712)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(83968)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(84992)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85248)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85504)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(85760)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86016)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(86784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87040)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87296)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87552)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(87808)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88064)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(88832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89088)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89344)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89600)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(89856)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(90880)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91136)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91392)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91648)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(91904)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(92928)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93184)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93440)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93696)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(93952)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(94976)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95232)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95488)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(95744)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96000)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(96768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97024)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97280)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97536)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(97792)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98048)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(128)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(128)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001000100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000000f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000001f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(64)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(80)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(96)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(2160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(4208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(6256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(8304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(10352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(12400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(14448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000003ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x40100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000004000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x00000200000002b8);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)activation_scales + UINT64_C(1152)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)weight_scales + UINT64_C(1152)) | UINT64_C(0x100000000)) & UINT64_C(0xffffffffff)) | UINT64_C(0x1000000000000));
    uint64_t mx_rs2 = UINT64_C(0x0001200100000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001020);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001030);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001040);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001050);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001060);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(16624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001070);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001090);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(20720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000010f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001100);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001110);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001120);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001130);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001140);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001150);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001160);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(24816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001170);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001180);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000001190);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28848)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28864)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28880)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28896)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)activation + UINT64_C(28912)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000011f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000100101);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000080);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(16496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(18544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002e90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ea0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(20592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002eb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ec0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ed0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ee0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(22640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ef0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f00);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f10);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f20);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(24688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f30);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f40);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f50);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f60);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(26736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f70);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f80);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002f90);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fa0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(28784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fb0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fc0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fd0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002fe0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)weight + UINT64_C(30832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000002ff0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0420b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = (((((uint64_t)(uintptr_t)scratch_output_scales + UINT64_C(0)) | UINT64_C(0x100000000)) & UINT64_C(0x1ffffffff)) | UINT64_C(0x3040100800000000));
    uint64_t mx_rs2 = UINT64_C(0x0000000000000001);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3420b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000000);
    uint64_t mx_rs2 = UINT64_C(0x0000000800040004);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1220b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000001000);
    uint64_t mx_rs2 = UINT64_C(0x0000000000003000);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x3020b07b));
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000001);
    uint64_t mx_rs2 = UINT64_C(0x0000020000000238);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x1020b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0020002000000200);
    uint64_t mx_rs2 = UINT64_C(0x0000000040000024);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x4220b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
  {
    uint64_t mx_rs1 = UINT64_C(0x0000000000000002);
    uint64_t mx_rs2 = UINT64_C(0x0000000000000010);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0020b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000200);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000210);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(98816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000220);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99072)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000230);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99328)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000240);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99584)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000250);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(99840)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000260);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100096)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000270);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100352)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000280);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100608)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000290);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(100864)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101120)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101376)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101632)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(101888)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102144)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000002f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102400)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000300);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102656)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000310);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(102912)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000320);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103168)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000330);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103424)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000340);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103680)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000350);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(103936)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000360);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104192)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000370);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104448)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000380);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104704)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000390);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(104960)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105216)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105472)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105728)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(105984)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106240)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000003f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106496)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000400);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(106752)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000410);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107008)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000420);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107264)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000430);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107520)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000440);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(107776)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000450);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108032)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000460);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108288)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000470);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108544)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000480);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(108800)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000490);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109056)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109312)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109568)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(109824)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110080)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110336)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000004f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110592)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000500);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(110848)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000510);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111104)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000520);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111360)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000530);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111616)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000540);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(111872)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000550);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112128)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000560);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112384)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000570);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112640)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000580);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(112896)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000590);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113152)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113408)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113664)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(113920)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114176)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114432)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000005f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114688)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000600);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(114944)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000610);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115200)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000620);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115456)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000630);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115712)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000640);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(115968)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000650);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116224)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000660);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116480)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000670);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116736)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000680);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(116992)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000690);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117248)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117504)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(117760)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118016)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118272)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118528)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000006f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(118784)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000700);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119040)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000710);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119296)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000720);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119552)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000730);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(119808)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000740);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120064)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000750);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120320)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000760);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120576)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000770);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(120832)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000780);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121088)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000790);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121344)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121600)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(121856)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122112)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122368)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122624)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000007f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(122880)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000800);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123136)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000810);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123392)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000820);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123648)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000830);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(123904)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000840);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124160)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000850);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124416)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000860);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124672)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000870);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(124928)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000880);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125184)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000890);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125440)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125696)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(125952)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126208)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126464)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126720)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000008f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(126976)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000900);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127232)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000910);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127488)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000920);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(127744)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000930);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128000)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000940);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128256)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000950);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128512)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000960);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(128768)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000970);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129024)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000980);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129280)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x0010001000000990);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129536)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009a0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(129792)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009b0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130048)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009c0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130304)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009d0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130560)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009e0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  {
    uint64_t mx_rs1 = (((uint64_t)(uintptr_t)output_bf16 + UINT64_C(130816)) | UINT64_C(0x100000000));
    uint64_t mx_rs2 = UINT64_C(0x00100010000009f0);
    MX_STORE_SHARED(mx_control_base, 0x10, mx_rs1);
    MX_STORE_SHARED(mx_control_base, 0x14, mx_rs1 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x18, mx_rs2);
    MX_STORE_SHARED(mx_control_base, 0x1c, mx_rs2 >> 32);
    MX_STORE_SHARED(mx_control_base, 0x00, UINT32_C(0x0620b07b));
  }
  __sync_synchronize();
  __asm__ volatile ("fence.s" ::: "memory");
  for (;;) {
    uint32_t mx_busy;
    __asm__ volatile ("lw.shared %0, %1(%2)" : "=r"(mx_busy) :
                      "I"(0), "r"((uint32_t)(mx_control_base + 0x20)) : "memory");
    if (!mx_busy) break;
    __asm__ volatile ("nop");
  }
}
