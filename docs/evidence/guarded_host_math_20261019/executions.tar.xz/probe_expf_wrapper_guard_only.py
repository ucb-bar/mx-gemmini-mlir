from pathlib import Path
import json,os,subprocess,hashlib
from mx_gemmini_support.target_profile import load_profile,profile_sha256
from merlin.llvmlower.device_build import DeviceRouting,freeze_device_elf_admission,admit_linked_device_elf
from merlin.model_check.admission import service
out=Path(os.environ['TMPDIR'])/'mx_model_goal_20261018/host_expf_wrapper_probe_20261019_admitted';out.mkdir()
startup=Path('/scratch/agustin/projects/chipyard/generators/gemmini/software/gemmini-rocc-tests/riscv-tests/benchmarks/common')
riscv=Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools');cc=riscv/'bin/riscv64-unknown-elf-gcc'
ext=Path('docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so').resolve()
source=r'''#include <stdint.h>
#include <stdio.h>
#include <errno.h>
static int native_errno;int *__errno(void){return &native_errno;}
extern float expf(float);
extern float __ieee754_expf(float);
static uint32_t bits(float x){union{float f;uint32_t u;}v={.f=x};return v.u;}
static float value(uint32_t u){union{float f;uint32_t u;}v={.u=u};return v.f;}
static inline __attribute__((always_inline)) float selected(float x){
  return (bits(x)&0x7fffffffu)<=0x42a00000u ? __ieee754_expf(x) : expf(x);
}
static uint64_t cycle(void){uint64_t r;asm volatile("rdcycle %0":"=r"(r)::"memory");return r;}
static unsigned flags(void){unsigned r;asm volatile("frflags %0":"=r"(r)::"memory");return r;}
static void clear(void){asm volatile("fsflags zero":::"memory");}
static void mode(unsigned m){asm volatile("fsrm %0"::"r"(m):"memory");}
static float input[32768];static uint32_t reference[32768],observed[32768];
__attribute__((noinline)) static uint32_t run_original(void){uint32_t h=2166136261u;for(unsigned i=0;i<32768;++i){float r=expf(input[i]);reference[i]=bits(r);h=(h^bits(r))*16777619u;}return h;}
__attribute__((noinline)) static uint32_t run_selected(void){uint32_t h=2166136261u;for(unsigned i=0;i<32768;++i){float r=selected(input[i]);observed[i]=bits(r);h=(h^bits(r))*16777619u;}return h;}
int main(void){
  unsigned mismatch=0;uint32_t random=0xaca1282au;
  for(unsigned m=0;m<5;++m){
    mode(m);
    for(unsigned i=0;i<131072;++i){
      random^=random<<13;random^=random>>17;random^=random<<5;
      uint32_t u=i<65536?i<<16:random;float x=value(u);
      errno=91;clear();float a=expf(x);unsigned af=flags();int ae=errno;
      errno=91;clear();float b=selected(x);unsigned bf=flags();int be=errno;
      if(bits(a)!=bits(b)||af!=bf||ae!=be){if(mismatch<4)printf("DIFF mode=%u input=%x a=%x b=%x af=%u bf=%u ae=%d be=%d\n",m,u,bits(a),bits(b),af,bf,ae,be);++mismatch;}
    }
  }
  mode(0);printf("QUALIFY cases=655360 mismatch=%u\n",mismatch);if(mismatch)return 5;
  for(unsigned kind=0;kind<3;++kind){
    for(unsigned i=0;i<32768;++i)input[i]=(kind==1 && (i&1))?value(0xff800000u):(kind==2?value(0xff800000u):-(float)(i%4096)/256.0f);
    for(unsigned rep=0;rep<3;++rep){unsigned bad=0;uint64_t t=cycle();uint32_t h=run_original();uint64_t before=cycle()-t;t=cycle();uint32_t g=run_selected();uint64_t after=cycle()-t;for(unsigned i=0;i<32768;++i)bad+=reference[i]!=observed[i];
      printf("EXP kind=%u run=%u original=%lu selected=%lu mismatch=%u hash=%u\n",kind,rep,before,after,bad,h);if(bad||h!=g)return 6;
    }
  }
  printf("DONE\n");return 0;
}'''
(out/'driver.c').write_text(source)
commands=[]
def run(command,label):
 commands.append(command);r=subprocess.run(command,capture_output=True,cwd=out);(out/(label+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,(label,r.returncode)
flags=['-DPREALLOCATE=1','-DMULTITHREAD=1','-DBAREMETAL=1','-mcmodel=medany','-O2','-ffreestanding','-fno-fast-math','-fno-common','-fno-builtin-printf','-fno-builtin-expf','-march=rv64gc_zicntr','-I',str(startup),'-I',str(startup.parent.parent),'-I',str(startup.parent.parent/'env')]
objects=[]
for i,p in enumerate([out/'driver.c',*sorted(startup.glob('*.c')),*sorted(startup.glob('*.S'))]):
 obj=out/f'part{i}.o';run([str(cc),*flags,'-c',str(p.resolve()),'-o',str(obj.resolve())],f'compile{i}');objects.append(obj.resolve())
elf=(out/'section.elf').resolve();run([str(cc),'-nostdlib','-nostartfiles','-static','-T',str(startup/'test.ld'),*map(str,objects),'-lm','-lgcc','-o',str(elf)],'link')
route=DeviceRouting(device='mx_gemmini',package_dir=Path.cwd(),operand_dtype='f32',accum_dtype='bf16',linked_elf_admission=service('mx_gemmini'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
admission=admit_linked_device_elf(route,freeze_device_elf_admission(route),elf=elf,linked_sha256=sha(elf),directory=out)
env=os.environ|{'GEMMINI_MODE':'both','GEMMINI_PERF_CONFIG':'e4m3_vpu','GEMMINI_PERF_SET':'mem.host_tracking=0'}
command=[str(riscv/'bin/spike'),'--isa=rv64gc_zicntr','--extlib='+str(ext),'--extension=gemmini',str(elf)]
(out/'invocation.json').write_text(json.dumps({'commands':commands,'spike_command':command,'environment':{k:v for k,v in env.items()if k.startswith('GEMMINI_')},'admission':admission,'ext_sha':sha(ext),'gcc_sha':sha(cc)},indent=2)+'\n')
with (out/'spike.log').open('wb')as log:r=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
(out/'status.json').write_text(json.dumps({'exit_code':r.returncode,'elf_sha':sha(elf)}));print((out/'spike.log').read_text());assert r.returncode==0
