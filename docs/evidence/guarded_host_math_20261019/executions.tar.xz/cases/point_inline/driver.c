#include <stdint.h>
#include <stdio.h>
#include <errno.h>
static int native_errno;int *__errno(void){return &native_errno;}
extern float expf(float);
extern float __ieee754_expf(float);
static uint32_t bits(float x){union{float f;uint32_t u;}v={.f=x};return v.u;}
static float value(uint32_t u){union{float f;uint32_t u;}v={.u=u};return v.f;}
static inline __attribute__((always_inline)) float selected(float x){
  if(bits(x)==0xff800000u)return 0.0f;
  return (bits(x)&0x7fffffffu)<=0x42a00000u ? __ieee754_expf(x) : expf(x);
}
static uint64_t cycle(void){uint64_t r;asm volatile("rdcycle %0":"=r"(r)::"memory");return r;}
static unsigned flags(void){unsigned r;asm volatile("frflags %0":"=r"(r)::"memory");return r;}
static void clear(void){asm volatile("fsflags zero":::"memory");}
static void mode(unsigned m){asm volatile("fsrm %0"::"r"(m):"memory");}
static float input[32768];static uint32_t reference[32768],observed[32768];
__attribute__((noinline)) static uint32_t run_original(void){uint32_t h=2166136261u;for(unsigned i=0;i<32768;++i){float r=expf(input[i]);reference[i]=bits(r);h=(h^bits(r))*16777619u;}return h;}
__attribute__((noinline)) static uint32_t run_selected(void){uint32_t h=2166136261u;for(unsigned i=0;i<32768;++i){float r=selected(input[i]);observed[i]=bits(r);h=(h^bits(r))*16777619u;}return h;}
int main(void){
  unsigned mismatch=0;uint32_t random=0xaca1282au;
  for(unsigned m=0;m<5;++m){
    mode(m);
    for(unsigned i=0;i<131072;++i){
      random^=random<<13;random^=random>>17;random^=random<<5;
      uint32_t u=i<65536?i<<16:random;float x=value(u);
      errno=91;clear();float a=expf(x);unsigned af=flags();int ae=errno;
      errno=91;clear();float b=selected(x);unsigned bf=flags();int be=errno;
      if(bits(a)!=bits(b)||af!=bf||ae!=be){if(mismatch<4)printf("DIFF mode=%u input=%x a=%x b=%x af=%u bf=%u ae=%d be=%d\n",m,u,bits(a),bits(b),af,bf,ae,be);++mismatch;}
    }
  }
  mode(0);printf("QUALIFY cases=655360 mismatch=%u\n",mismatch);if(mismatch)return 5;
  for(unsigned kind=0;kind<3;++kind){
    for(unsigned i=0;i<32768;++i)input[i]=(kind==1 && (i&1))?value(0xff800000u):(kind==2?value(0xff800000u):-(float)(i%4096)/256.0f);
    for(unsigned rep=0;rep<3;++rep){unsigned bad=0;uint64_t t=cycle();uint32_t h=run_original();uint64_t before=cycle()-t;t=cycle();uint32_t g=run_selected();uint64_t after=cycle()-t;for(unsigned i=0;i<32768;++i)bad+=reference[i]!=observed[i];
      printf("EXP kind=%u run=%u original=%lu selected=%lu mismatch=%u hash=%u\n",kind,rep,before,after,bad,h);if(bad||h!=g)return 6;
    }
  }
  printf("DONE\n");return 0;
}