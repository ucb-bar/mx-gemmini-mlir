from pathlib import Path
import json,tarfile,hashlib,io,subprocess
root=Path('../.tmp/mx_model_goal_20261018');out=Path('docs/evidence/guarded_host_math_20261019');out.mkdir()
final=root/'host_math_guard_final_tool03';cc=Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools/bin');objects={}
for name in ['libm_a-wf_exp.o','libm_a-ef_exp.o','libm_a-sf_finite.o']:
 r=subprocess.run([str(cc/'riscv64-unknown-elf-ar'),'p',str((final/'libm.a').resolve()),name],capture_output=True,check=True);(final/name).write_bytes(r.stdout);objects[name]=hashlib.sha256(r.stdout).hexdigest()
 for flags,label in [(['-dr'],'.disassembly.txt'),(['-s'],'.sections.txt')]:
  r=subprocess.run([str(cc/'riscv64-unknown-elf-objdump'),*flags,str((final/name).resolve())],capture_output=True,check=True);(final/(name+label)).write_bytes(r.stdout)
for symbol in ['run_original','run_selected','__wrap_expf','expf','__ieee754_expf','finitef']:
 r=subprocess.run([str(cc/'riscv64-unknown-elf-objdump'),'-d','--disassemble='+symbol,str((final/'section.elf').resolve())],capture_output=True,check=True);(final/(symbol+'.disassembly.txt')).write_bytes(r.stdout)
(final/'library_review_objects.json').write_text(json.dumps(objects,indent=2)+'\n')
cases={'guard_only_inline':root/'host_expf_wrapper_probe_20261019_admitted','point_inline':root/'host_expf_wrapper_probe_20261019_negative_inf','selected':final}
files={}
def add(name,data):assert name not in files;files[name]=data
for name,directory in cases.items():
 status=json.loads((directory/('receipt.json'if name=='selected'else'status.json')).read_text());assert status['exit_code']==0
 for path in sorted(directory.rglob('*')):
  if path.is_file():add('cases/'+name+'/'+path.relative_to(directory).as_posix(),path.read_bytes())
add('profile.json',Path('profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json').read_bytes())
add('collection.py',Path(__file__).read_bytes())
for name in ['probe_expf_wrapper_guard_only.py','probe_expf_wrapper_negative_inf_inline.py']:
 add(name,(root/name).read_bytes())
archive=out/'executions.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=6)as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(data);tar.addfile(info,io.BytesIO(data))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest={'schema':'mx_gemmini.guarded_math_evidence.v1','scope':'host_call_sections_only','archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'cases':list(cases),'members':{name:{'bytes':len(raw),'sha256':sha(raw)}for name,raw in sorted(files.items())},'elf_reader_sha256':sha(Path('docs/evidence/broadcast_multiply_20261019/verify.py').read_bytes())}
(out/'artifacts.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');(out/'guard.json').write_bytes((final/'guard.json').read_bytes());print(len(files),'members,',archive.stat().st_size,'archive bytes')
