"""Build a full-size FP32 RMS/packing pair with independent scalar quantization."""
from pathlib import Path
import ctypes,json,subprocess,tarfile,hashlib,numpy as np
from mx_gemmini_support.f32_rms_packing import emit_f32_rms_packing
from mx_gemmini_support.runtime_group_preparation import emit_runtime_group_preparation
from mx_gemmini_support.target_profile import load_profile
root=Path(__file__).resolve().parent;repo=Path.cwd();out=root/'f32_rms_packing_pair2';out.mkdir(exist_ok=True)
profile=load_profile(repo/'profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json')
manifest=json.loads((repo/'docs/evidence/mx_compiler_optimization_probes_20261019/artifacts.json').read_text())
with tarfile.open(repo/'docs/evidence/mx_compiler_optimization_probes_20261019/probes.tar.xz','r:xz') as archive:
 quant=archive.extractfile('fp8_pack/old_quant.c').read()
assert hashlib.sha256(quant).hexdigest()==manifest['members']['fp8_pack/old_quant.c']['sha256']
(out/'reference_quant.c').write_bytes(quant)
(out/'runtime_quant.c').write_bytes((repo/'mx_gemmini_support/runtime_quant.c').read_bytes())
(out/'runtime_group_prepare.h').write_text(emit_runtime_group_preparation())
for name in ('runtime_quant.h','runtime_quant_lut.h'):(out/name).write_bytes((repo/'mx_gemmini_support'/name).read_bytes())
rng=np.random.default_rng(119);x=rng.normal(size=(160,2048)).astype('<f4');x[0]=0;x[1]=-np.float32(0);x[2]*=np.float32(1e-20);x[3]*=np.float32(1e18)
g=rng.uniform(-1,2,2048).astype('<f4');g[0]=0
x.tofile(out/'input.bin');g.tofile(out/'gamma.bin')
reference='#include <stdint.h>\n#include <math.h>\n'
for mode in ('ordered','striped16'):
 kernel=emit_f32_rms_packing(profile,rows=160,width=2048,symbol='fused_'+mode,reduction=mode)
 (out/('fused_'+mode+'.c')).write_text(kernel.source)
 summation='for(unsigned col=0;col<2048;++col)sum=sum+square[row*2048+col];' if mode=='ordered' else '''float sums[16]={0};
 for(unsigned lane=0;lane<16;++lane)for(unsigned word=lane;word<1024;word+=128)for(unsigned j=0;j<8;++j){unsigned col=2*(word+16*j);sums[lane]+=square[row*2048+col]+square[row*2048+col+1];}
 for(unsigned lane=0;lane<16;++lane)sum+=sums[lane];'''
 reference+='''static float square[327680],inverse[160],first[327680];
 void reference_'''+mode+'''(const float *x,const float *g,float *out){
 for(unsigned i=0;i<327680;++i)square[i]=x[i]*x[i];
 for(unsigned row=0;row<160;++row){float sum=0;'''+summation+'''
 inverse[row]=1.0f/__builtin_sqrtf(sum/2048.0f+1e-5f);}
 for(unsigned i=0;i<327680;++i)first[i]=x[i]*inverse[i/2048];
 for(unsigned i=0;i<327680;++i)out[i]=g[i%2048]*first[i];}
'''
# Reuse scratch across mutually exclusive reference calls.
reference='static float square[327680],inverse[160],first[327680];\n'+reference.replace('static float square[327680],inverse[160],first[327680];','')
(out/'reference.c').write_text(reference)
subprocess.run(['cc','-O2','-shared','-fPIC','-fno-fast-math','-ffp-contract=off','-DMX_QUANT_REFERENCE','-I',str(out),str(out/'reference.c'),str(out/'reference_quant.c'),'-lm','-o',str(out/'reference.so')],check=True)
lib=ctypes.CDLL(str(out/'reference.so'));div=np.array(2048,np.float32);eps=np.array(1e-5,np.float32)
for mode in ('ordered','striped16'):
 fn=getattr(lib,'reference_'+mode);fn.argtypes=[ctypes.c_void_p]*3;y=np.empty_like(x);fn(x.ctypes.data,g.ctypes.data,y.ctypes.data)
 expected=np.empty(337920,np.uint8);pack=lib.mx_pack_activation_f32;pack.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_void_p]
 assert pack(y.ctypes.data,160,2048,8,expected.ctypes.data,expected[327680:].ctypes.data)==0
 expected.tofile(out/('expected_'+mode+'.bin'))
(out/'data.S').write_text(''.join('.section .rodata\n.balign 64\n.global '+n+'\n'+n+':\n.incbin "'+str(out/f)+'"\n' for n,f in [('input','input.bin'),('gamma','gamma.bin'),('expected_ordered','expected_ordered.bin'),('expected_striped16','expected_striped16.bin')])+'.section .note.GNU-stack,"",@progbits\n')
(out/'main.c').write_text('''#include <stdint.h>
#include <stdio.h>
#include "runtime_quant.h"
extern const float input[],gamma[];
extern const unsigned char expected_ordered[],expected_striped16[];
extern void reference_ordered(const float *,const float *,float *),reference_striped16(const float *,const float *,float *);
extern void fused_ordered(const float *,const float *,const float *,const float *,uint8_t *),fused_striped16(const float *,const float *,const float *,const float *,uint8_t *);
unsigned char mx_catalog_workspace[8192+64] __attribute__((aligned(64)));
static float normalized[327680];static uint8_t output[337920+128] __attribute__((aligned(64)));
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){float divisor=2048,epsilon=1e-5f;
 for(unsigned mode=0;mode<2;mode++)for(unsigned trial=0;trial<2;trial++)for(unsigned order=0;order<2;order++){
 unsigned role=trial^order;
 for(unsigned i=0;i<sizeof(output);i++)output[i]=0xa5;
 for(unsigned i=0;i<sizeof(mx_catalog_workspace);i++)mx_catalog_workspace[i]=0xa5;
 uint64_t start=ticks();
 if(role){if(mode)fused_striped16(input,gamma,&divisor,&epsilon,output+64);else fused_ordered(input,gamma,&divisor,&epsilon,output+64);}
 else {if(mode)reference_striped16(input,gamma,normalized);else reference_ordered(input,gamma,normalized);
 if(mx_pack_activation_f32(normalized,160,2048,8,output+64,output+64+327680))return 2;}
 uint64_t cycles=ticks()-start;const uint8_t *expected=mode?expected_striped16:expected_ordered;unsigned bad=0;
 for(unsigned i=0;i<337920;i++)bad+=output[i+64]!=expected[i];
 for(unsigned i=0;i<64;i++)bad+=output[i]!=0xa5||output[i+337920+64]!=0xa5||mx_catalog_workspace[8192+i]!=0xa5;
 printf("F32_RMS mode=%u trial=%u role=%u cycles=%lu bad=%u checked=337920\\n",mode,trial,role,(unsigned long)cycles,bad);
 if(bad)return 1;
 for(unsigned offset=0;offset<337920;offset+=32){printf("F32_RMS_BYTES %u %u %u %u 32",mode,trial,role,offset);for(unsigned j=0;j<32;j++)printf(" %02x",output[64+offset+j]);printf("\\n");}
 }
 printf("F32_RMS_DONE\\n");return 0;}
''')
s=(root/'quant_format_pair1/run.py').read_text().replace("for role in ['old','new']:","for role in []:")
s=s.replace("'-fno-fast-math'","'-fno-fast-math','-fno-math-errno'")
s=s.replace("p/'main.c',p/'data.S'","p/'main.c',p/'data.S',p/'fused_ordered.c',p/'fused_striped16.c',p/'reference.c',p/'reference_quant.c'")
s=s.replace("p/'reference.c',p/'reference_quant.c'","p/'reference.c',p/'runtime_quant.c'")
s=s.replace("'-DPREALLOCATE=1'","'-DMX_QUANT_GROUP_WORDS','-DMX_QUANT_INLINE_GROUP','-DPREALLOCATE=1'")
(out/'run.py').write_text(s)
print(out,flush=True)
