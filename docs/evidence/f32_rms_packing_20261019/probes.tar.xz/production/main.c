#include <stdint.h>
#include <stdio.h>
#include "runtime_quant.h"
extern const float input[],gamma[];
extern const unsigned char expected_ordered[],expected_striped16[];
extern void reference_ordered(const float *,const float *,float *),reference_striped16(const float *,const float *,float *);
extern void fused_ordered(const float *,const float *,const float *,const float *,uint8_t *),fused_striped16(const float *,const float *,const float *,const float *,uint8_t *);
unsigned char mx_catalog_workspace[8192+64] __attribute__((aligned(64)));
static float normalized[327680];static uint8_t output[337920+128] __attribute__((aligned(64)));
static uint64_t ticks(void){uint64_t t;asm volatile("rdcycle %0":"=r"(t)::"memory");return t;}
int main(void){float divisor=2048,epsilon=1e-5f;
 for(unsigned mode=0;mode<2;mode++)for(unsigned trial=0;trial<2;trial++)for(unsigned order=0;order<2;order++){
 unsigned role=trial^order;
 for(unsigned i=0;i<sizeof(output);i++)output[i]=0xa5;
 for(unsigned i=0;i<sizeof(mx_catalog_workspace);i++)mx_catalog_workspace[i]=0xa5;
 uint64_t start=ticks();
 if(role){if(mode)fused_striped16(input,gamma,&divisor,&epsilon,output+64);else fused_ordered(input,gamma,&divisor,&epsilon,output+64);}
 else {if(mode)reference_striped16(input,gamma,normalized);else reference_ordered(input,gamma,normalized);
 if(mx_pack_activation_f32(normalized,160,2048,8,output+64,output+64+327680))return 2;}
 uint64_t cycles=ticks()-start;const uint8_t *expected=mode?expected_striped16:expected_ordered;unsigned bad=0;
 for(unsigned i=0;i<337920;i++)bad+=output[i+64]!=expected[i];
 for(unsigned i=0;i<64;i++)bad+=output[i]!=0xa5||output[i+337920+64]!=0xa5||mx_catalog_workspace[8192+i]!=0xa5;
 printf("F32_RMS mode=%u trial=%u role=%u cycles=%lu bad=%u checked=337920\n",mode,trial,role,(unsigned long)cycles,bad);
 if(bad)return 1;
 for(unsigned offset=0;offset<337920;offset+=32){printf("F32_RMS_BYTES %u %u %u %u 32",mode,trial,role,offset);for(unsigned j=0;j<32;j++)printf(" %02x",output[64+offset+j]);printf("\n");}
 }
 printf("F32_RMS_DONE\n");return 0;}
