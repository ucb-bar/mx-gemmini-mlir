#include <stdint.h>
#include <stdint.h>
#include "runtime_quant_lut.h"
static inline int fused_ordered_pack_round(float input,uint16_t *value) {
  union {float f;uint32_t u;} word={.f=input};
  word.u+=0x7fffu+((word.u>>16)&1u);
  *value=word.u>>16;
  return (*value&0x7f80u)==0x7f80u ? -1 : 0;
}
static inline uint16_t fused_ordered_pack_magnitude(uint16_t word) { return word&0x7fffu; }
#include <stddef.h>
#include <stdint.h>
static inline int fused_ordered_pack_prepare(const float *merlin_group_input, size_t merlin_group_stride, uint16_t *merlin_group_words, uint16_t *merlin_group_maximum) {
  uint16_t merlin_group_largest = 0;
  for (size_t merlin_group_offset = 0; merlin_group_offset < 32u; ++merlin_group_offset) {
    uint16_t merlin_group_word;
    if (fused_ordered_pack_round(merlin_group_input[merlin_group_offset * merlin_group_stride], &merlin_group_word)) return -1;
    merlin_group_words[merlin_group_offset] = merlin_group_word;
    uint16_t merlin_group_key = fused_ordered_pack_magnitude(merlin_group_word);
    if (merlin_group_key > merlin_group_largest) merlin_group_largest = merlin_group_key;
  }
  *merlin_group_maximum = merlin_group_largest;
  return 0;
}

static inline int fused_ordered_pack(const float *input,uint32_t first,uint32_t count,
                           uint8_t *codes,uint8_t *scales) {
  if (!input || !codes || !scales || first>=160u || !count || count>160u-first) return -1;
  for (uint32_t group=0; group<64u; ++group)
    for (uint32_t row=0; row<count; ++row) {
      uint16_t values[32],maximum;
      if (fused_ordered_pack_prepare(input+row*2048u+group*32u,1u,values,&maximum)) return -1;
      int exponent=(int)(maximum>>7)-127;
      if (exponent < -23) exponent=-23;
      uint32_t biased_scale=exponent+127;
      scales[group*160u+first+row]=(uint8_t)biased_scale;
      for (uint32_t j=0; j<32; ++j) {
        uint32_t value=values[j],biased=(value>>7)&255u,delta=biased_scale-biased;
        uint8_t code=(value>>15)<<7;
        if (biased && delta<16u) code|=mx_fp8_code_lut[delta][value&127u];
        codes[(first+row)*2048u+group*32u+j]=code;
      }
    }
  return 0;
}

extern unsigned char mx_catalog_workspace[];
void fused_ordered(const float *input,const float *gamma,const float *divisor,const float *epsilon,uint8_t *output){
  if(!input||!gamma||!divisor||!epsilon||!output||*divisor!=2048.0f)__builtin_trap();
  float *values=(float *)mx_catalog_workspace;
  for(uint32_t row=0;row<160u;++row){
    float sum=0.0f;
    for(uint32_t col=0;col<2048u;++col){float x=input[row*2048u+col];sum=sum+x*x;}
    float inverse=1.0f/__builtin_sqrtf(sum/(*divisor)+*epsilon);
    for(uint32_t col=0;col<2048u;++col)values[col]=gamma[col]*(input[row*2048u+col]*inverse);
    if(fused_ordered_pack(values,row,1,output,output+327680u))__builtin_trap();
  }
}
