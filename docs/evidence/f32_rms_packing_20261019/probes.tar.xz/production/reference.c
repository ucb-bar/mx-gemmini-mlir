static float square[327680],inverse[160],first[327680];
#include <stdint.h>
#include <math.h>

 void reference_ordered(const float *x,const float *g,float *out){
 for(unsigned i=0;i<327680;++i)square[i]=x[i]*x[i];
 for(unsigned row=0;row<160;++row){float sum=0;for(unsigned col=0;col<2048;++col)sum=sum+square[row*2048+col];
 inverse[row]=1.0f/__builtin_sqrtf(sum/2048.0f+1e-5f);}
 for(unsigned i=0;i<327680;++i)first[i]=x[i]*inverse[i/2048];
 for(unsigned i=0;i<327680;++i)out[i]=g[i%2048]*first[i];}

 void reference_striped16(const float *x,const float *g,float *out){
 for(unsigned i=0;i<327680;++i)square[i]=x[i]*x[i];
 for(unsigned row=0;row<160;++row){float sum=0;float sums[16]={0};
 for(unsigned lane=0;lane<16;++lane)for(unsigned word=lane;word<1024;word+=128)for(unsigned j=0;j<8;++j){unsigned col=2*(word+16*j);sums[lane]+=square[row*2048+col]+square[row*2048+col+1];}
 for(unsigned lane=0;lane<16;++lane)sum+=sums[lane];
 inverse[row]=1.0f/__builtin_sqrtf(sum/2048.0f+1e-5f);}
 for(unsigned i=0;i<327680;++i)first[i]=x[i]*inverse[i/2048];
 for(unsigned i=0;i<327680;++i)out[i]=g[i%2048]*first[i];}
