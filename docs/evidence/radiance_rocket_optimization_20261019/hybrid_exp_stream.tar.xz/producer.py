"""Measure format-specialized packing with otherwise published forward settings."""
import pathlib,json,tarfile,subprocess,os,sys,hashlib
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path.cwd()
with tarfile.open(repo/'docs/evidence/matched_compact_batch_rhs_forward_20261019/executions.tar.xz','r:xz') as archive:
 original=json.load(archive.extractfile('candidate/job/spec.json'))
command=original['command'][:];command[0]=sys.executable
for flag in ('--reuse-prepacked-data','--reuse-prepacked-object'):
 index=command.index(flag);del command[index:index+2]
inputs=repo.parent/'.tmp/mx_public_docs_audit_20261019/tinyllama-forward-final-inputs'
for flag,path in {'--stage':inputs/'capture','--workdir':root/'compiler_tinyllama_hybrid_exp_stream1','--execution-policy':root/'exp-vpu-policy.json','--host-math-guard':inputs/'guard.json'}.items():command[command.index(flag)+1]=str(path)
for flag in ('--connect-vpu-multiplies','--connect-vpu-sigmoid-multiplies','--connect-vpu-broadcast-multiplies','--prepare-vpu-broadcast-operands','--matrix-vpu-transport','--vpu-matrix-transport'):
 if flag in command:command.remove(flag)
command += ['--vpu-softmax-implementation', 'f32_reduce', '--reuse-prepacked-data', str(root/'compiler_tinyllama_forward_profile1/device_catalog'), '--reuse-prepacked-object', str(root/'compiler_tinyllama_forward_profile1/device_catalog/checkpoint_weights.o')]
command += ['--group-projections','--fuse-softmax-packing','--vpu-sigmoid-implementation','f32_reciprocal']
env=os.environ|original['environment']
env['TMPDIR']=str(repo.parent/'.tmp');env['PYTHONDONTWRITEBYTECODE']='1';env['OMP_NUM_THREADS']='2';env['OPENBLAS_NUM_THREADS']='1'
job=root/'compiler-hybrid-exp-stream-job.json'
record={'status':'running','pid':os.getpid(),'command':command,'cwd':str(repo),'environment':{k:env[k] for k in original['environment']},'producer_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
job.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':record['status'],'pid':record['pid'],'job':str(job)}),flush=True)
with (root/'compiler_hybrid_exp_stream1.log').open('wb') as log:
 result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(status='completed' if result.returncode==0 else 'failed',exit_code=result.returncode);job.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
