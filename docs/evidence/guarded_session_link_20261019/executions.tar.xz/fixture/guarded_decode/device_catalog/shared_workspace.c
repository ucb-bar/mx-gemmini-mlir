unsigned char mx_catalog_workspace[3648] __attribute__((aligned(64)));
