builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/guarded_session_fixture_20261019/capture/stages/decode/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<32x32xf32>, %1: tensor<32xf32>, %2: tensor<16x32xf32>, %3: tensor<16x32xf32>) -> (tensor<16x32xf32>, tensor<16x32xf32>) {
    %4 = tensor.empty() : tensor<32x32xf32>
    %5 = linalg.transpose ins(%0:tensor<32x32xf32>) outs(%4:tensor<32x32xf32>) permutation = [1, 0]
    %6 = tensor.empty() : tensor<16x32xf32>
    %7 = arith.constant {prov.module = "linear"} 0.000000e+00 : f32
    %8 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "linear"} ins(%7 : f32) outs(%6 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %9 = func.call @merlin_dev_mx_gemmini_0(%2, %5, %8) : (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %10 = tensor.empty() : tensor<16x32xf32>
    %11 = tensor.empty() : tensor<16x32xf32>
    %12 = func.call @mx_vpu_add_f32_bias_16_32(%9, %1, %11) : (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %13 = tensor.empty() : tensor<16x32xf32>
    %14 = tensor.empty() : tensor<16x32xf32>
    %15 = func.call @mx_vpu_add_f32_same_16_32(%12, %3, %14) : (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %16 = arith.constant {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} 1.250000e-01 : f32
    %17 = tensor.empty() : tensor<16x32xf32>
    %18 = tensor.splat %16 : tensor<f32>
    %19 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> ()>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%15, %18 : tensor<16x32xf32>, tensor<f32>) outs(%17 : tensor<16x32xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb0(%20: f32, %21: f32, %22: f32):
      %23 = arith.mulf %20, %21 : f32
      linalg.yield %23 : f32
    } -> tensor<16x32xf32>
    %24 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0xff800000 : f32
    %25 = tensor.splat %24 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %26 = linalg.reduce ins(%19:tensor<16x32xf32>) outs(%25:tensor<16xf32>) dimensions = [1]
    (%27: f32, %28: f32) {
      %29 = arith.maximumf %27, %28 : f32
      linalg.yield %29 : f32
    }
    %30 = tensor.expand_shape %26 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %31 = tensor.empty() : tensor<16x32xf32>
    %32 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%19, %30 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%31 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb1(%33: f32, %34: f32, %35: f32):
      %36 = arith.subf %33, %34 : f32
      linalg.yield %36 : f32
    } -> tensor<16x32xf32>
    %37 = tensor.empty() : tensor<16x32xf32>
    %38 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%32 : tensor<16x32xf32>) outs(%37 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb2(%39: f32, %40: f32):
      %41 = math.exp %39 : f32
      linalg.yield %41 : f32
    } -> tensor<16x32xf32>
    %42 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0.000000e+00 : f32
    %43 = tensor.splat %42 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %44 = linalg.reduce ins(%38:tensor<16x32xf32>) outs(%43:tensor<16xf32>) dimensions = [1]
    (%45: f32, %46: f32) {
      %47 = arith.addf %45, %46 : f32
      linalg.yield %47 : f32
    }
    %48 = tensor.expand_shape %44 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %49 = tensor.empty() : tensor<16x32xf32>
    %50 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%38, %48 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%49 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb3(%51: f32, %52: f32, %53: f32):
      %54 = arith.divf %51, %52 : f32
      linalg.yield %54 : f32
    } -> tensor<16x32xf32>
    %55 = arith.constant {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} 5.000000e-01 : f32
    %56 = tensor.empty() : tensor<16x32xf32>
    %57 = tensor.splat %55 : tensor<f32>
    %58 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> ()>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%50, %57 : tensor<16x32xf32>, tensor<f32>) outs(%56 : tensor<16x32xf32>) attrs =  {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} {
    ^bb4(%59: f32, %60: f32, %61: f32):
      %62 = arith.addf %59, %60 : f32
      linalg.yield %62 : f32
    } -> tensor<16x32xf32>
    func.return %50, %58 : tensor<16x32xf32>, tensor<16x32xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_bias_16_32", function_type = (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_16_32", function_type = (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}