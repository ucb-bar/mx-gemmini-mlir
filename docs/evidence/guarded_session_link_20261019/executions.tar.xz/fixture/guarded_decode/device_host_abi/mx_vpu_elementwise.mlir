builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/guarded_session_fixture_20261019/capture/stages/decode/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<32x32xf32>, %1: tensor<32xf32>, %2: tensor<16x32xf32>, %3: tensor<16x32xf32>) -> (tensor<16x32xf32>, tensor<16x32xf32>) {
    %4 = tensor.empty() : tensor<32x32xf32>
    %5 = linalg.transpose ins(%0:tensor<32x32xf32>) outs(%4:tensor<32x32xf32>) permutation = [1, 0]
    %6 = tensor.empty() : tensor<16x32xf32>
    %7 = arith.constant {prov.module = "linear"} 0.000000e+00 : f32
    %8 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "linear"} ins(%7 : f32) outs(%6 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %9 = func.call @merlin_dev_mx_gemmini_0(%2, %5, %8) : (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %10 = tensor.empty() : tensor<16x32xf32>
    %11 = tensor.empty() : tensor<16x32xf32>
    %12 = func.call @mx_vpu_add_f32_bias_16_32(%9, %1, %11) : (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %13 = tensor.empty() : tensor<16x32xf32>
    %14 = tensor.empty() : tensor<16x32xf32>
    %15 = func.call @mx_vpu_add_f32_same_16_32(%12, %3, %14) : (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %16 = arith.constant {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} 1.250000e-01 : f32
    %17 = tensor.empty() : tensor<16x32xf32>
    %18 = tensor.splat %16 : tensor<f32>
    %19 = tensor.empty() : tensor<16x32xf32>
    %20 = func.call @mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(%15, %18, %19) : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %21 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0xff800000 : f32
    %22 = tensor.splat %21 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %23 = linalg.reduce ins(%20:tensor<16x32xf32>) outs(%22:tensor<16xf32>) dimensions = [1]
    (%24: f32, %25: f32) {
      %26 = arith.maximumf %24, %25 : f32
      linalg.yield %26 : f32
    }
    %27 = tensor.expand_shape %23 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %28 = tensor.empty() : tensor<16x32xf32>
    %29 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%20, %27 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%28 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb0(%30: f32, %31: f32, %32: f32):
      %33 = arith.subf %30, %31 : f32
      linalg.yield %33 : f32
    } -> tensor<16x32xf32>
    %34 = tensor.empty() : tensor<16x32xf32>
    %35 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%29 : tensor<16x32xf32>) outs(%34 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb1(%36: f32, %37: f32):
      %38 = math.exp %36 : f32
      linalg.yield %38 : f32
    } -> tensor<16x32xf32>
    %39 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0.000000e+00 : f32
    %40 = tensor.splat %39 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %41 = linalg.reduce ins(%35:tensor<16x32xf32>) outs(%40:tensor<16xf32>) dimensions = [1]
    (%42: f32, %43: f32) {
      %44 = arith.addf %42, %43 : f32
      linalg.yield %44 : f32
    }
    %45 = tensor.expand_shape %41 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %46 = tensor.empty() : tensor<16x32xf32>
    %47 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%35, %45 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%46 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb2(%48: f32, %49: f32, %50: f32):
      %51 = arith.divf %48, %49 : f32
      linalg.yield %51 : f32
    } -> tensor<16x32xf32>
    %52 = arith.constant {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} 5.000000e-01 : f32
    %53 = tensor.empty() : tensor<16x32xf32>
    %54 = tensor.splat %52 : tensor<f32>
    %55 = tensor.empty() : tensor<16x32xf32>
    %56 = func.call @mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(%47, %54, %55) : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    func.return %47, %56 : tensor<16x32xf32>, tensor<16x32xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_bias_16_32", function_type = (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_16_32", function_type = (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}