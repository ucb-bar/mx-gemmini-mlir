; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_xf32_1 = private constant float 1.250000e-01, align 64
@__constant_xf32 = private constant float 5.000000e-01, align 64
@__constant_16x1xf32_0 = private constant [16 x [1 x float]] [[1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000], [1 x float] [float 0xFFF0000000000000]], align 64
@__constant_16x1xf32 = private constant [16 x [1 x float]] zeroinitializer, align 64

declare void @free(ptr)

declare ptr @malloc(i64)

; Function Attrs: memory(none)
declare float @expf(float) #0

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18, ptr %19, ptr %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25, ptr %26, ptr %27, i64 %28, i64 %29, i64 %30, i64 %31, i64 %32) {
  %34 = call ptr @malloc(i64 2112)
  %35 = ptrtoint ptr %34 to i64
  %36 = add i64 %35, 63
  %37 = urem i64 %36, 64
  %38 = sub i64 %36, %37
  %39 = inttoptr i64 %38 to ptr
  br label %40

40:                                               ; preds = %52, %33
  %41 = phi i64 [ %53, %52 ], [ 0, %33 ]
  %42 = icmp slt i64 %41, 16
  br i1 %42, label %43, label %54

43:                                               ; preds = %40
  br label %44

44:                                               ; preds = %47, %43
  %45 = phi i64 [ %51, %47 ], [ 0, %43 ]
  %46 = icmp slt i64 %45, 32
  br i1 %46, label %47, label %52

47:                                               ; preds = %44
  %48 = mul nuw nsw i64 %41, 32
  %49 = add nuw nsw i64 %48, %45
  %50 = getelementptr inbounds nuw float, ptr %39, i64 %49
  store float 0.000000e+00, ptr %50, align 4
  %51 = add i64 %45, 1
  br label %44

52:                                               ; preds = %44
  %53 = add i64 %41, 1
  br label %40

54:                                               ; preds = %40
  %55 = call ptr @malloc(i64 4160)
  %56 = ptrtoint ptr %55 to i64
  %57 = add i64 %56, 63
  %58 = urem i64 %57, 64
  %59 = sub i64 %57, %58
  %60 = inttoptr i64 %59 to ptr
  %61 = call ptr @malloc(i64 2112)
  %62 = ptrtoint ptr %61 to i64
  %63 = add i64 %62, 63
  %64 = urem i64 %63, 64
  %65 = sub i64 %63, %64
  %66 = inttoptr i64 %65 to ptr
  %67 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_0(ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11, ptr %55, ptr %60, i64 0, i64 32, i64 32, i64 32, i64 1, ptr %61, ptr %66, i64 0, i64 16, i64 32, i64 32, i64 1)
  %68 = call ptr @malloc(i64 2112)
  %69 = ptrtoint ptr %68 to i64
  %70 = add i64 %69, 63
  %71 = urem i64 %70, 64
  %72 = sub i64 %70, %71
  %73 = inttoptr i64 %72 to ptr
  %74 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, 0
  %75 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, 1
  %76 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, 2
  %77 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, 3, 0
  %78 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, 3, 1
  %79 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, 4, 0
  %80 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, 4, 1
  %81 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_add_f32_bias_16_32(ptr %74, ptr %75, i64 %76, i64 %77, i64 %78, i64 %79, i64 %80, ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %68, ptr %73, i64 0, i64 16, i64 32, i64 32, i64 1)
  %82 = call ptr @malloc(i64 2112)
  %83 = ptrtoint ptr %82 to i64
  %84 = add i64 %83, 63
  %85 = urem i64 %84, 64
  %86 = sub i64 %84, %85
  %87 = inttoptr i64 %86 to ptr
  %88 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %81, 0
  %89 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %81, 1
  %90 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %81, 2
  %91 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %81, 3, 0
  %92 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %81, 3, 1
  %93 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %81, 4, 0
  %94 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %81, 4, 1
  %95 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_add_f32_same_16_32(ptr %88, ptr %89, i64 %90, i64 %91, i64 %92, i64 %93, i64 %94, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18, ptr %82, ptr %87, i64 0, i64 16, i64 32, i64 32, i64 1)
  %96 = call ptr @malloc(i64 2112)
  %97 = ptrtoint ptr %96 to i64
  %98 = add i64 %97, 63
  %99 = urem i64 %98, 64
  %100 = sub i64 %98, %99
  %101 = inttoptr i64 %100 to ptr
  %102 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, 0
  %103 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, 1
  %104 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, 2
  %105 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, 3, 0
  %106 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, 3, 1
  %107 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, 4, 0
  %108 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, 4, 1
  %109 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr %102, ptr %103, i64 %104, i64 %105, i64 %106, i64 %107, i64 %108, ptr inttoptr (i64 3735928559 to ptr), ptr @__constant_xf32_1, i64 0, ptr %96, ptr %101, i64 0, i64 16, i64 32, i64 32, i64 1)
  %110 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %109, 1
  %111 = call ptr @malloc(i64 128)
  %112 = ptrtoint ptr %111 to i64
  %113 = add i64 %112, 63
  %114 = urem i64 %113, 64
  %115 = sub i64 %113, %114
  %116 = inttoptr i64 %115 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr %116, ptr @__constant_16x1xf32_0, i64 64, i1 false)
  br label %117

117:                                              ; preds = %142, %54
  %118 = phi i64 [ %143, %142 ], [ 0, %54 ]
  %119 = icmp slt i64 %118, 16
  br i1 %119, label %120, label %144

120:                                              ; preds = %117
  br label %121

121:                                              ; preds = %140, %120
  %122 = phi i64 [ %141, %140 ], [ 0, %120 ]
  %123 = icmp slt i64 %122, 1
  br i1 %123, label %124, label %142

124:                                              ; preds = %121
  br label %125

125:                                              ; preds = %128, %124
  %126 = phi i64 [ %139, %128 ], [ 0, %124 ]
  %127 = icmp slt i64 %126, 32
  br i1 %127, label %128, label %140

128:                                              ; preds = %125
  %129 = mul nuw nsw i64 %118, 32
  %130 = mul nuw nsw i64 %122, 32
  %131 = add nuw nsw i64 %129, %130
  %132 = add nuw nsw i64 %131, %126
  %133 = getelementptr inbounds nuw float, ptr %110, i64 %132
  %134 = load float, ptr %133, align 4
  %135 = add nuw nsw i64 %118, %122
  %136 = getelementptr inbounds nuw float, ptr %116, i64 %135
  %137 = load float, ptr %136, align 4
  %138 = call float @llvm.maximum.f32(float %134, float %137)
  store float %138, ptr %136, align 4
  %139 = add i64 %126, 1
  br label %125

140:                                              ; preds = %125
  %141 = add i64 %122, 1
  br label %121

142:                                              ; preds = %121
  %143 = add i64 %118, 1
  br label %117

144:                                              ; preds = %117
  br label %145

145:                                              ; preds = %164, %144
  %146 = phi i64 [ %165, %164 ], [ 0, %144 ]
  %147 = icmp slt i64 %146, 16
  br i1 %147, label %148, label %166

148:                                              ; preds = %145
  br label %149

149:                                              ; preds = %152, %148
  %150 = phi i64 [ %163, %152 ], [ 0, %148 ]
  %151 = icmp slt i64 %150, 32
  br i1 %151, label %152, label %164

152:                                              ; preds = %149
  %153 = mul nuw nsw i64 %146, 32
  %154 = add nuw nsw i64 %153, %150
  %155 = getelementptr inbounds nuw float, ptr %110, i64 %154
  %156 = load float, ptr %155, align 4
  %157 = add nuw nsw i64 %146, 0
  %158 = getelementptr inbounds nuw float, ptr %116, i64 %157
  %159 = load float, ptr %158, align 4
  %160 = fsub float %156, %159
  %161 = call float @expf(float %160)
  %162 = getelementptr inbounds nuw float, ptr %39, i64 %154
  store float %161, ptr %162, align 4
  %163 = add i64 %150, 1
  br label %149

164:                                              ; preds = %149
  %165 = add i64 %146, 1
  br label %145

166:                                              ; preds = %145
  %167 = call ptr @malloc(i64 128)
  %168 = ptrtoint ptr %167 to i64
  %169 = add i64 %168, 63
  %170 = urem i64 %169, 64
  %171 = sub i64 %169, %170
  %172 = inttoptr i64 %171 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr %172, ptr @__constant_16x1xf32, i64 64, i1 false)
  br label %173

173:                                              ; preds = %198, %166
  %174 = phi i64 [ %199, %198 ], [ 0, %166 ]
  %175 = icmp slt i64 %174, 16
  br i1 %175, label %176, label %200

176:                                              ; preds = %173
  br label %177

177:                                              ; preds = %196, %176
  %178 = phi i64 [ %197, %196 ], [ 0, %176 ]
  %179 = icmp slt i64 %178, 1
  br i1 %179, label %180, label %198

180:                                              ; preds = %177
  br label %181

181:                                              ; preds = %184, %180
  %182 = phi i64 [ %195, %184 ], [ 0, %180 ]
  %183 = icmp slt i64 %182, 32
  br i1 %183, label %184, label %196

184:                                              ; preds = %181
  %185 = mul nuw nsw i64 %174, 32
  %186 = mul nuw nsw i64 %178, 32
  %187 = add nuw nsw i64 %185, %186
  %188 = add nuw nsw i64 %187, %182
  %189 = getelementptr inbounds nuw float, ptr %39, i64 %188
  %190 = load float, ptr %189, align 4
  %191 = add nuw nsw i64 %174, %178
  %192 = getelementptr inbounds nuw float, ptr %172, i64 %191
  %193 = load float, ptr %192, align 4
  %194 = fadd float %190, %193
  store float %194, ptr %192, align 4
  %195 = add i64 %182, 1
  br label %181

196:                                              ; preds = %181
  %197 = add i64 %178, 1
  br label %177

198:                                              ; preds = %177
  %199 = add i64 %174, 1
  br label %173

200:                                              ; preds = %173
  br label %201

201:                                              ; preds = %219, %200
  %202 = phi i64 [ %220, %219 ], [ 0, %200 ]
  %203 = icmp slt i64 %202, 16
  br i1 %203, label %204, label %221

204:                                              ; preds = %201
  br label %205

205:                                              ; preds = %208, %204
  %206 = phi i64 [ %218, %208 ], [ 0, %204 ]
  %207 = icmp slt i64 %206, 32
  br i1 %207, label %208, label %219

208:                                              ; preds = %205
  %209 = mul nuw nsw i64 %202, 32
  %210 = add nuw nsw i64 %209, %206
  %211 = getelementptr inbounds nuw float, ptr %39, i64 %210
  %212 = load float, ptr %211, align 4
  %213 = add nuw nsw i64 %202, 0
  %214 = getelementptr inbounds nuw float, ptr %172, i64 %213
  %215 = load float, ptr %214, align 4
  %216 = fdiv float %212, %215
  %217 = getelementptr inbounds nuw float, ptr %20, i64 %210
  store float %216, ptr %217, align 4
  %218 = add i64 %206, 1
  br label %205

219:                                              ; preds = %205
  %220 = add i64 %202, 1
  br label %201

221:                                              ; preds = %201
  %222 = call ptr @malloc(i64 2112)
  %223 = ptrtoint ptr %222 to i64
  %224 = add i64 %223, 63
  %225 = urem i64 %224, 64
  %226 = sub i64 %224, %225
  %227 = inttoptr i64 %226 to ptr
  %228 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr %19, ptr %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25, ptr inttoptr (i64 3735928559 to ptr), ptr @__constant_xf32, i64 0, ptr %222, ptr %227, i64 0, i64 16, i64 32, i64 32, i64 1)
  %229 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %228, 3, 0
  %230 = mul i64 %229, 1
  %231 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %228, 3, 1
  %232 = mul i64 %230, %231
  %233 = mul i64 %232, 4
  %234 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %228, 1
  %235 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %228, 2
  %236 = getelementptr float, ptr %234, i64 %235
  %237 = getelementptr float, ptr %27, i64 %28
  call void @llvm.memcpy.p0.p0.i64(ptr %237, ptr %236, i64 %233, i1 false)
  %238 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %109, 0
  %239 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %228, 0
  %240 = call ptr @malloc(i64 112)
  %241 = call ptr @malloc(i64 14)
  %242 = call ptr @malloc(i64 0)
  %243 = ptrtoint ptr %39 to i64
  store i64 %243, ptr %240, align 8
  %244 = ptrtoint ptr %60 to i64
  %245 = getelementptr inbounds nuw i64, ptr %240, i32 1
  store i64 %244, ptr %245, align 8
  %246 = ptrtoint ptr %66 to i64
  %247 = getelementptr inbounds nuw i64, ptr %240, i32 2
  store i64 %246, ptr %247, align 8
  %248 = ptrtoint ptr %75 to i64
  %249 = getelementptr inbounds nuw i64, ptr %240, i32 3
  store i64 %248, ptr %249, align 8
  %250 = ptrtoint ptr %73 to i64
  %251 = getelementptr inbounds nuw i64, ptr %240, i32 4
  store i64 %250, ptr %251, align 8
  %252 = ptrtoint ptr %89 to i64
  %253 = getelementptr inbounds nuw i64, ptr %240, i32 5
  store i64 %252, ptr %253, align 8
  %254 = ptrtoint ptr %87 to i64
  %255 = getelementptr inbounds nuw i64, ptr %240, i32 6
  store i64 %254, ptr %255, align 8
  %256 = ptrtoint ptr %103 to i64
  %257 = getelementptr inbounds nuw i64, ptr %240, i32 7
  store i64 %256, ptr %257, align 8
  %258 = ptrtoint ptr %101 to i64
  %259 = getelementptr inbounds nuw i64, ptr %240, i32 8
  store i64 %258, ptr %259, align 8
  %260 = ptrtoint ptr %110 to i64
  %261 = getelementptr inbounds nuw i64, ptr %240, i32 9
  store i64 %260, ptr %261, align 8
  %262 = ptrtoint ptr %116 to i64
  %263 = getelementptr inbounds nuw i64, ptr %240, i32 10
  store i64 %262, ptr %263, align 8
  %264 = ptrtoint ptr %172 to i64
  %265 = getelementptr inbounds nuw i64, ptr %240, i32 11
  store i64 %264, ptr %265, align 8
  %266 = ptrtoint ptr %227 to i64
  %267 = getelementptr inbounds nuw i64, ptr %240, i32 12
  store i64 %266, ptr %267, align 8
  %268 = ptrtoint ptr %234 to i64
  %269 = getelementptr inbounds nuw i64, ptr %240, i32 13
  store i64 %268, ptr %269, align 8
  store i1 true, ptr %241, align 1
  %270 = getelementptr inbounds nuw i1, ptr %241, i32 1
  store i1 true, ptr %270, align 1
  %271 = getelementptr inbounds nuw i1, ptr %241, i32 2
  store i1 true, ptr %271, align 1
  %272 = getelementptr inbounds nuw i1, ptr %241, i32 3
  store i1 true, ptr %272, align 1
  %273 = getelementptr inbounds nuw i1, ptr %241, i32 4
  store i1 true, ptr %273, align 1
  %274 = getelementptr inbounds nuw i1, ptr %241, i32 5
  store i1 true, ptr %274, align 1
  %275 = getelementptr inbounds nuw i1, ptr %241, i32 6
  store i1 true, ptr %275, align 1
  %276 = getelementptr inbounds nuw i1, ptr %241, i32 7
  store i1 true, ptr %276, align 1
  %277 = getelementptr inbounds nuw i1, ptr %241, i32 8
  store i1 true, ptr %277, align 1
  %278 = getelementptr inbounds nuw i1, ptr %241, i32 9
  store i1 true, ptr %278, align 1
  %279 = getelementptr inbounds nuw i1, ptr %241, i32 10
  store i1 true, ptr %279, align 1
  %280 = getelementptr inbounds nuw i1, ptr %241, i32 11
  store i1 true, ptr %280, align 1
  %281 = getelementptr inbounds nuw i1, ptr %241, i32 12
  store i1 true, ptr %281, align 1
  %282 = getelementptr inbounds nuw i1, ptr %241, i32 13
  store i1 true, ptr %282, align 1
  %283 = call ptr @malloc(i64 14)
  %284 = call ptr @malloc(i64 0)
  call void @dealloc_helper(ptr %240, ptr %240, i64 0, i64 14, i64 1, ptr %242, ptr %242, i64 0, i64 0, i64 1, ptr %241, ptr %241, i64 0, i64 14, i64 1, ptr %283, ptr %283, i64 0, i64 14, i64 1, ptr %284, ptr %284, i64 0, i64 0, i64 1)
  call void @free(ptr %284)
  call void @free(ptr %242)
  call void @free(ptr %241)
  call void @free(ptr %240)
  %285 = load i1, ptr %283, align 1
  br i1 %285, label %286, label %287

286:                                              ; preds = %221
  call void @free(ptr %34)
  br label %287

287:                                              ; preds = %286, %221
  %288 = getelementptr inbounds nuw i1, ptr %283, i32 1
  %289 = load i1, ptr %288, align 1
  br i1 %289, label %290, label %291

290:                                              ; preds = %287
  call void @free(ptr %55)
  br label %291

291:                                              ; preds = %290, %287
  %292 = getelementptr inbounds nuw i1, ptr %283, i32 2
  %293 = load i1, ptr %292, align 1
  br i1 %293, label %294, label %295

294:                                              ; preds = %291
  call void @free(ptr %61)
  br label %295

295:                                              ; preds = %294, %291
  %296 = getelementptr inbounds nuw i1, ptr %283, i32 3
  %297 = load i1, ptr %296, align 1
  br i1 %297, label %298, label %299

298:                                              ; preds = %295
  call void @free(ptr %74)
  br label %299

299:                                              ; preds = %298, %295
  %300 = getelementptr inbounds nuw i1, ptr %283, i32 4
  %301 = load i1, ptr %300, align 1
  br i1 %301, label %302, label %303

302:                                              ; preds = %299
  call void @free(ptr %68)
  br label %303

303:                                              ; preds = %302, %299
  %304 = getelementptr inbounds nuw i1, ptr %283, i32 5
  %305 = load i1, ptr %304, align 1
  br i1 %305, label %306, label %307

306:                                              ; preds = %303
  call void @free(ptr %88)
  br label %307

307:                                              ; preds = %306, %303
  %308 = getelementptr inbounds nuw i1, ptr %283, i32 6
  %309 = load i1, ptr %308, align 1
  br i1 %309, label %310, label %311

310:                                              ; preds = %307
  call void @free(ptr %82)
  br label %311

311:                                              ; preds = %310, %307
  %312 = getelementptr inbounds nuw i1, ptr %283, i32 7
  %313 = load i1, ptr %312, align 1
  br i1 %313, label %314, label %315

314:                                              ; preds = %311
  call void @free(ptr %102)
  br label %315

315:                                              ; preds = %314, %311
  %316 = getelementptr inbounds nuw i1, ptr %283, i32 8
  %317 = load i1, ptr %316, align 1
  br i1 %317, label %318, label %319

318:                                              ; preds = %315
  call void @free(ptr %96)
  br label %319

319:                                              ; preds = %318, %315
  %320 = getelementptr inbounds nuw i1, ptr %283, i32 9
  %321 = load i1, ptr %320, align 1
  br i1 %321, label %322, label %323

322:                                              ; preds = %319
  call void @free(ptr %238)
  br label %323

323:                                              ; preds = %322, %319
  %324 = getelementptr inbounds nuw i1, ptr %283, i32 10
  %325 = load i1, ptr %324, align 1
  br i1 %325, label %326, label %327

326:                                              ; preds = %323
  call void @free(ptr %111)
  br label %327

327:                                              ; preds = %326, %323
  %328 = getelementptr inbounds nuw i1, ptr %283, i32 11
  %329 = load i1, ptr %328, align 1
  br i1 %329, label %330, label %331

330:                                              ; preds = %327
  call void @free(ptr %167)
  br label %331

331:                                              ; preds = %330, %327
  %332 = getelementptr inbounds nuw i1, ptr %283, i32 12
  %333 = load i1, ptr %332, align 1
  br i1 %333, label %334, label %335

334:                                              ; preds = %331
  call void @free(ptr %222)
  br label %335

335:                                              ; preds = %334, %331
  %336 = getelementptr inbounds nuw i1, ptr %283, i32 13
  %337 = load i1, ptr %336, align 1
  call void @free(ptr %283)
  br i1 %337, label %338, label %339

338:                                              ; preds = %335
  call void @free(ptr %239)
  br label %339

339:                                              ; preds = %338, %335
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1, ptr %2, ptr %3, ptr %4) {
  %6 = load { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %0, align 8
  %7 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %6, 0
  %8 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %6, 1
  %9 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %6, 2
  %10 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %6, 3, 0
  %11 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %6, 4, 0
  %12 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %13 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, 0
  %14 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, 1
  %15 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, 2
  %16 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, 3, 0
  %17 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, 3, 1
  %18 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, 4, 0
  %19 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, 4, 1
  %20 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, align 8
  %21 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, 0
  %22 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, 1
  %23 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, 2
  %24 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, 3, 0
  %25 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, 3, 1
  %26 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, 4, 0
  %27 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, 4, 1
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, align 8
  %29 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, 0
  %30 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, 1
  %31 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, 2
  %32 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, 3, 0
  %33 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, 3, 1
  %34 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, 4, 0
  %35 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, 4, 1
  %36 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %4, align 8
  %37 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, 0
  %38 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, 1
  %39 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, 2
  %40 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, 3, 0
  %41 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, 3, 1
  %42 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, 4, 0
  %43 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, 4, 1
  call void @forward(ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, ptr %13, ptr %14, i64 %15, i64 %16, i64 %17, i64 %18, i64 %19, ptr %21, ptr %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27, ptr %29, ptr %30, i64 %31, i64 %32, i64 %33, i64 %34, i64 %35, ptr %37, ptr %38, i64 %39, i64 %40, i64 %41, i64 %42, i64 %43)
  ret void
}

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_add_f32_bias_16_32(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18) {
  %20 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, ptr %1, 1
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %2, 2
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %3, 3, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %5, 4, 0
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %4, 3, 1
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %6, 4, 1
  %28 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, ptr %28, align 8
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %7, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, ptr %8, 1
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, i64 %9, 2
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %10, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %11, 4, 0
  %34 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, ptr %34, align 8
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %12, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, ptr %13, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %14, 2
  %38 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, i64 %15, 3, 0
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %38, i64 %17, 4, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, i64 %16, 3, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %18, 4, 1
  %42 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, ptr %42, align 8
  call void @_mlir_ciface_mx_vpu_add_f32_bias_16_32(ptr %20, ptr %28, ptr %34, ptr %42)
  %43 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %20, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %43
}

declare void @_mlir_ciface_mx_vpu_add_f32_bias_16_32(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_add_f32_same_16_32(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_mx_vpu_add_f32_same_16_32(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_mx_vpu_add_f32_same_16_32(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16) {
  %18 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %19 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, ptr %1, 1
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, i64 %2, 2
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %3, 3, 0
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %5, 4, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %4, 3, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %6, 4, 1
  %26 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, ptr %26, align 8
  %27 = insertvalue { ptr, ptr, i64 } poison, ptr %7, 0
  %28 = insertvalue { ptr, ptr, i64 } %27, ptr %8, 1
  %29 = insertvalue { ptr, ptr, i64 } %28, i64 %9, 2
  %30 = alloca { ptr, ptr, i64 }, i64 1, align 8
  store { ptr, ptr, i64 } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %10, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %11, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %12, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %13, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %15, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %14, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %16, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  call void @_mlir_ciface_mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr %18, ptr %26, ptr %30, ptr %38)
  %39 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %18, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %39
}

declare void @_mlir_ciface_mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16) {
  %18 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %19 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, ptr %1, 1
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, i64 %2, 2
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %3, 3, 0
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %5, 4, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %4, 3, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %6, 4, 1
  %26 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, ptr %26, align 8
  %27 = insertvalue { ptr, ptr, i64 } poison, ptr %7, 0
  %28 = insertvalue { ptr, ptr, i64 } %27, ptr %8, 1
  %29 = insertvalue { ptr, ptr, i64 } %28, i64 %9, 2
  %30 = alloca { ptr, ptr, i64 }, i64 1, align 8
  store { ptr, ptr, i64 } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %10, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %11, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %12, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %13, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %15, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %14, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %16, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  call void @_mlir_ciface_mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr %18, ptr %26, ptr %30, ptr %38)
  %39 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %18, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %39
}

declare void @_mlir_ciface_mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(ptr, ptr, ptr, ptr)

define void @dealloc_helper(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24) {
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %27 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, ptr %6, 1
  %28 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %27, i64 %7, 2
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %28, i64 %8, 3, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, ptr %1, 1
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %2, 2
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %3, 3, 0
  %34 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 3
  %35 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %34, ptr %35, align 8
  %36 = getelementptr [1 x i64], ptr %35, i32 0, i32 0
  %37 = load i64, ptr %36, align 8
  %38 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, 3
  %39 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %38, ptr %39, align 8
  %40 = getelementptr [1 x i64], ptr %39, i32 0, i32 0
  %41 = load i64, ptr %40, align 8
  br label %42

42:                                               ; preds = %45, %25
  %43 = phi i64 [ %47, %45 ], [ 0, %25 ]
  %44 = icmp slt i64 %43, %41
  br i1 %44, label %45, label %48

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i1, ptr %21, i64 %43
  store i1 false, ptr %46, align 1
  %47 = add i64 %43, 1
  br label %42

48:                                               ; preds = %42
  br label %49

49:                                               ; preds = %84, %48
  %50 = phi i64 [ %87, %84 ], [ 0, %48 ]
  %51 = icmp slt i64 %50, %37
  br i1 %51, label %52, label %88

52:                                               ; preds = %49
  %53 = getelementptr inbounds nuw i64, ptr %1, i64 %50
  %54 = load i64, ptr %53, align 8
  %55 = getelementptr inbounds nuw i1, ptr %11, i64 %50
  %56 = load i1, ptr %55, align 1
  br label %57

57:                                               ; preds = %69, %52
  %58 = phi i64 [ %72, %69 ], [ 0, %52 ]
  %59 = phi i1 [ %71, %69 ], [ true, %52 ]
  %60 = icmp slt i64 %58, %41
  br i1 %60, label %61, label %73

61:                                               ; preds = %57
  %62 = getelementptr inbounds nuw i64, ptr %6, i64 %58
  %63 = load i64, ptr %62, align 8
  %64 = icmp eq i64 %63, %54
  br i1 %64, label %65, label %69

65:                                               ; preds = %61
  %66 = getelementptr inbounds nuw i1, ptr %21, i64 %58
  %67 = load i1, ptr %66, align 1
  %68 = or i1 %67, %56
  store i1 %68, ptr %66, align 1
  br label %69

69:                                               ; preds = %65, %61
  %70 = icmp ne i64 %63, %54
  %71 = and i1 %59, %70
  %72 = add i64 %58, 1
  br label %57

73:                                               ; preds = %57
  br label %74

74:                                               ; preds = %78, %73
  %75 = phi i64 [ %83, %78 ], [ 0, %73 ]
  %76 = phi i1 [ %82, %78 ], [ %59, %73 ]
  %77 = icmp slt i64 %75, %50
  br i1 %77, label %78, label %84

78:                                               ; preds = %74
  %79 = getelementptr inbounds nuw i64, ptr %1, i64 %75
  %80 = load i64, ptr %79, align 8
  %81 = icmp ne i64 %80, %54
  %82 = and i1 %76, %81
  %83 = add i64 %75, 1
  br label %74

84:                                               ; preds = %74
  %85 = and i1 %76, %56
  %86 = getelementptr inbounds nuw i1, ptr %16, i64 %50
  store i1 %85, ptr %86, align 1
  %87 = add i64 %50, 1
  br label %49

88:                                               ; preds = %49
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
