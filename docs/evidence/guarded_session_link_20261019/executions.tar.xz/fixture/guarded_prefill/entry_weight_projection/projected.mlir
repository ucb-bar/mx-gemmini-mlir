"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> (tensor<16x32xf32>, tensor<16x32xf32>)}> ({
  ^bb0(%0: tensor<32xf32>, %1: tensor<16x32xf32>, %2: tensor<16x32xf32>):
    %3 = "tensor.empty"() : () -> tensor<16x32xf32>
    %4 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.module = "linear"} : () -> f32
    %5 = "linalg.fill"(%4, %3) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb1(%6: f32, %7: f32):
      "linalg.yield"(%6) : (f32) -> ()
    }) {prov.op = "fill", prov.family = "fill", prov.module = "linear"} : (f32, tensor<16x32xf32>) -> tensor<16x32xf32>
    %8 = "tensor.empty"() : () -> tensor<32x32xf32>
    %9 = "func.call"(%1, %8, %5) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %10 = "tensor.empty"() : () -> tensor<16x32xf32>
    %11 = "func.call"(%9, %0, %10) <{callee = @mx_vpu_add_f32_bias_16_32}> : (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %12 = "tensor.empty"() : () -> tensor<16x32xf32>
    %13 = "func.call"(%11, %2, %12) <{callee = @mx_vpu_add_f32_same_16_32}> : (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %14 = "arith.constant"() <{value = 1.250000e-01 : f32}> {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} : () -> f32
    %15 = "tensor.splat"(%14) : (f32) -> tensor<f32>
    %16 = "tensor.empty"() : () -> tensor<16x32xf32>
    %17 = "func.call"(%13, %15, %16) <{callee = @mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_}> : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %18 = "arith.constant"() <{value = 0xff800000 : f32}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : () -> f32
    %19 = "tensor.splat"(%18) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (f32) -> tensor<16xf32>
    %20 = "linalg.reduce"(%17, %19) <{dimensions = array<i64: 1>}> ({
    ^bb2(%21: f32, %22: f32):
      %23 = "arith.maximumf"(%21, %22) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%23) : (f32) -> ()
    }) : (tensor<16x32xf32>, tensor<16xf32>) -> tensor<16xf32>
    %24 = "tensor.expand_shape"(%20) <{reassociation = [[0 : i64, 1 : i64]], static_output_shape = array<i64: 16, 1>}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16xf32>) -> tensor<16x1xf32>
    %25 = "tensor.empty"() : () -> tensor<16x32xf32>
    %26 = "linalg.generic"(%17, %24, %25) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb3(%27: f32, %28: f32, %29: f32):
      %30 = "arith.subf"(%27, %28) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%30) : (f32) -> ()
    }) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16x32xf32>, tensor<16x1xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %31 = "tensor.empty"() : () -> tensor<16x32xf32>
    %32 = "linalg.generic"(%26, %31) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb4(%33: f32, %34: f32):
      %35 = "math.exp"(%33) <{fastmath = #arith.fastmath<none>}> : (f32) -> f32
      "linalg.yield"(%35) : (f32) -> ()
    }) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %36 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : () -> f32
    %37 = "tensor.splat"(%36) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (f32) -> tensor<16xf32>
    %38 = "linalg.reduce"(%32, %37) <{dimensions = array<i64: 1>}> ({
    ^bb5(%39: f32, %40: f32):
      %41 = "arith.addf"(%39, %40) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%41) : (f32) -> ()
    }) : (tensor<16x32xf32>, tensor<16xf32>) -> tensor<16xf32>
    %42 = "tensor.expand_shape"(%38) <{reassociation = [[0 : i64, 1 : i64]], static_output_shape = array<i64: 16, 1>}> {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16xf32>) -> tensor<16x1xf32>
    %43 = "tensor.empty"() : () -> tensor<16x32xf32>
    %44 = "linalg.generic"(%32, %42, %43) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb6(%45: f32, %46: f32, %47: f32):
      %48 = "arith.divf"(%45, %46) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%48) : (f32) -> ()
    }) {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : (tensor<16x32xf32>, tensor<16x1xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %49 = "arith.constant"() <{value = 5.000000e-01 : f32}> {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} : () -> f32
    %50 = "tensor.splat"(%49) : (f32) -> tensor<f32>
    %51 = "tensor.empty"() : () -> tensor<16x32xf32>
    %52 = "func.call"(%44, %50, %51) <{callee = @mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_}> : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    "func.return"(%44, %52) : (tensor<16x32xf32>, tensor<16x32xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_bias_16_32", function_type = (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_16_32", function_type = (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/guarded_session_fixture_20261019/capture/stages/prefill/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()