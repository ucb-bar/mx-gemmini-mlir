builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/guarded_session_fixture_20261019/capture/stages/prefill/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<32x32xf32>, %1: tensor<32xf32>, %2: tensor<16x32xf32>, %3: tensor<16x32xf32>) -> (tensor<16x32xf32>, tensor<16x32xf32>) {
    %4 = tensor.empty() : tensor<16x32xf32>
    %5 = arith.constant {prov.module = "linear"} 0.000000e+00 : f32
    %6 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "linear"} ins(%5 : f32) outs(%4 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %7 = tensor.empty() : tensor<32x32xf32>
    %8 = func.call @merlin_dev_mx_gemmini_0(%2, %7, %6) : (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %9 = tensor.empty() : tensor<16x32xf32>
    %10 = tensor.empty() : tensor<16x32xf32>
    %11 = func.call @mx_vpu_add_f32_bias_16_32(%8, %1, %10) : (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %12 = tensor.empty() : tensor<16x32xf32>
    %13 = tensor.empty() : tensor<16x32xf32>
    %14 = func.call @mx_vpu_add_f32_same_16_32(%11, %3, %13) : (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %15 = arith.constant {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} 1.250000e-01 : f32
    %16 = tensor.empty() : tensor<16x32xf32>
    %17 = tensor.splat %15 : tensor<f32>
    %18 = tensor.empty() : tensor<16x32xf32>
    %19 = func.call @mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(%14, %17, %18) : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    %20 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0xff800000 : f32
    %21 = tensor.splat %20 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %22 = linalg.reduce ins(%19:tensor<16x32xf32>) outs(%21:tensor<16xf32>) dimensions = [1]
    (%23: f32, %24: f32) {
      %25 = arith.maximumf %23, %24 : f32
      linalg.yield %25 : f32
    }
    %26 = tensor.expand_shape %22 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %27 = tensor.empty() : tensor<16x32xf32>
    %28 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%19, %26 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%27 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb0(%29: f32, %30: f32, %31: f32):
      %32 = arith.subf %29, %30 : f32
      linalg.yield %32 : f32
    } -> tensor<16x32xf32>
    %33 = tensor.empty() : tensor<16x32xf32>
    %34 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%28 : tensor<16x32xf32>) outs(%33 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb1(%35: f32, %36: f32):
      %37 = math.exp %35 : f32
      linalg.yield %37 : f32
    } -> tensor<16x32xf32>
    %38 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0.000000e+00 : f32
    %39 = tensor.splat %38 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %40 = linalg.reduce ins(%34:tensor<16x32xf32>) outs(%39:tensor<16xf32>) dimensions = [1]
    (%41: f32, %42: f32) {
      %43 = arith.addf %41, %42 : f32
      linalg.yield %43 : f32
    }
    %44 = tensor.expand_shape %40 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %45 = tensor.empty() : tensor<16x32xf32>
    %46 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%34, %44 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%45 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb2(%47: f32, %48: f32, %49: f32):
      %50 = arith.divf %47, %48 : f32
      linalg.yield %50 : f32
    } -> tensor<16x32xf32>
    %51 = arith.constant {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} 5.000000e-01 : f32
    %52 = tensor.empty() : tensor<16x32xf32>
    %53 = tensor.splat %51 : tensor<f32>
    %54 = tensor.empty() : tensor<16x32xf32>
    %55 = func.call @mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_(%46, %53, %54) : (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>
    func.return %46, %55 : tensor<16x32xf32>, tensor<16x32xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<16x32xf32>, tensor<32x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_bias_16_32", function_type = (tensor<16x32xf32>, tensor<32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_16_32", function_type = (tensor<16x32xf32>, tensor<16x32xf32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_lf32_rf32_16_32_lhs_16_32_laxes_0_1_rhs_scalar_axes_", function_type = (tensor<16x32xf32>, tensor<f32>, tensor<16x32xf32>) -> tensor<16x32xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}