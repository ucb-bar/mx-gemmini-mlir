import json
import os
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
task = base.parent.parent
repo = task / 'mx-gemmini-mlir'
spec = json.loads((base / 'detached_full160_20261019/rms_reverse_control/spec.json').read_text())
env = os.environ.copy()
env.update(spec['environment'])
python = spec['command'][0]
root = base / 'guarded_session_fixture_20261019'
root.mkdir(exist_ok=False)
capture = root / 'capture'
profile = repo / 'profiles/gemmini-mx-cleanup-266c593/MxE4M3Fp4VpuGemminiRocketConfig.json'
guard = base / 'detached_full160_20261019/rms_guarded_math/guard.json'
riscv = Path('/scratch/agustin/projects/chipyard/.conda-env/riscv-tools')
extlib = repo / 'docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so'

def run(label, args):
    command = [python, '-m', *map(str, args)]
    (root / (label + '.command.json')).write_text(json.dumps(command, indent=2) + '\n')
    with (root / (label + '.log')).open('w') as out:
        result = subprocess.run(command, cwd=repo, env=env, stdout=out, stderr=subprocess.STDOUT)
    print(label, result.returncode, flush=True)
    if result.returncode:
        print((root / (label + '.log')).read_text()[-6000:], flush=True)
        sys.exit(result.returncode)

run('capture', ['tools.prepare_projected_session_fixture', '--out-dir', capture, '--profile', profile, '--host-softmax'])
for role in ('native', 'guarded'):
    for program in ('prefill', 'decode'):
        args = ['tools.build_merlin_stage', '--stage', capture / 'stages' / program,
                '--workdir', root / (role + '_' + program), '--profile', profile,
                '--merlin-src', task / 'merlin/src', '--llvm-install', '/scratch/agustin/projects/oscar-merlin/third_party/llvm-install',
                '--riscv-root', riscv, '--execution-policy', capture / (program + '_policy.json'),
                '--prepack-checkpoint-weights', '--prune-unused-checkpoint-weights', '--structural-elf-admission']
        if role == 'guarded':
            args += ['--host-math-guard', guard]
        run(role + '_' + program, args)
    args = ['tools.link_merlin_session', '--session-root', capture, '--workdir', root / (role + '_link'),
            '--stage-build', 'prefill=' + str(root / (role + '_prefill')),
            '--stage-build', 'decode=' + str(root / (role + '_decode')),
            '--profile', profile, '--merlin-src', task / 'merlin/src', '--riscv-root', riscv,
            '--dump-output', 'prefill:0', '--dump-output', 'decode:0', '--structural-elf-admission', '--measure-preparation']
    if role == 'guarded':
        args += ['--host-math-guard', guard]
    run(role + '_link', args)
    run(role + '_run', ['tools.run_linked_merlin_session', '--session-root', capture,
                       '--link-receipt', root / (role + '_link/mx_session_link.json'),
                       '--merlin-src', task / 'merlin/src', '--riscv-root', riscv,
                       '--spike-extlib', extlib, '--out-dir', root / (role + '_run'),
                       '--timeout-s', '600', '--perf-config', 'e4m3_vpu', '--perf-set', 'mem.host_tracking=0'])
print('ALL COMPLETED', flush=True)
