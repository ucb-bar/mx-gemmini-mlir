"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<6x19x37xf32>, tensor<2x23x37xf32>) -> tensor<6x19x23xf32>}> ({
  ^bb0(%0: tensor<6x19x37xf32>, %1: tensor<2x23x37xf32>):
    %2 = "tensor.collapse_shape"(%1) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]]}> {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : (tensor<2x23x37xf32>) -> tensor<1702xf32>
    %3 = "tensor.expand_shape"(%2) <{reassociation = [[0 : i64, 1 : i64, 2 : i64, 3 : i64]], static_output_shape = array<i64: 2, 1, 23, 37>}> {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : (tensor<1702xf32>) -> tensor<2x1x23x37xf32>
    %4 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : () -> f32
    %5 = "tensor.splat"(%4) {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : (f32) -> tensor<6x19x23xf32>
    %6 = "tensor.collapse_shape"(%3) <{reassociation = [[0 : i64, 1 : i64, 2 : i64, 3 : i64]]}> : (tensor<2x1x23x37xf32>) -> tensor<1702xf32>
    %7 = "tensor.expand_shape"(%6) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 2, 23, 37>}> : (tensor<1702xf32>) -> tensor<2x23x37xf32>
    %8 = "tensor.empty"() : () -> tensor<2x37x23xf32>
    %9 = "linalg.transpose"(%7, %8) <{permutation = array<i64: 0, 2, 1>}> ({
    ^bb1(%10: f32, %11: f32):
      "linalg.yield"(%10) : (f32) -> ()
    }) : (tensor<2x23x37xf32>, tensor<2x37x23xf32>) -> tensor<2x37x23xf32>
    %12 = "func.call"(%0, %9, %5) <{callee = @mx_compact_repeated_rhs_0}> : (tensor<6x19x37xf32>, tensor<2x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>
    "func.return"(%12) : (tensor<6x19x23xf32>) -> ()
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "mx_compact_repeated_rhs_0", function_type = (tensor<6x19x37xf32>, tensor<2x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {merlin.repeated_batch_input = "{\22argument\22: 1, \22compact_input\22: true, \22provider_obligation\22: \22original_results_rounding_effects_refusal_and_synchronous_private_preparation\22, \22repeat\22: 3}", llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/repeated_batch_matmul_tail_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()