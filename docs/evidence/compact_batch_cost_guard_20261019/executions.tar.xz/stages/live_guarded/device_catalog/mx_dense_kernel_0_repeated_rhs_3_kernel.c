/* MX dense f32 adapter: FP8, qualified 32x32x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_0(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern unsigned char mx_catalog_workspace[];

static void mx_dense_kernel_0_repeated_rhs_3_kernel_slice(const float *lhs, const float *rhs, float *out, unsigned prepare_weight) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  float *padded_b = (float *)(mx_catalog_workspace + 8192);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 16384);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 18432);
  uint8_t *weight = (uint8_t *)(mx_catalog_workspace + 18496);
  uint8_t *weight_scales = (uint8_t *)(mx_catalog_workspace + 20544);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 20608);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 22656);
  for (size_t i = 0; i < 2048u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 19u; ++row)
    for (size_t col = 0; col < 37u; ++col)
      padded_a[row * 64u + col] = lhs[row * 37u + col];
  if (prepare_weight) {
  for (size_t i = 0; i < 2048u; ++i) padded_b[i] = 0;
  for (size_t row = 0; row < 37u; ++row)
    for (size_t col = 0; col < 23u; ++col)
      padded_b[row * 32u + col] = rhs[row * 23u + col];
  }
  if (mx_pack_activation_f32(padded_a, 32u, 64u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      (prepare_weight && mx_pack_weight_f32(padded_b, 64u, 32u, MX_RUNTIME_FP8,
                         weight, weight_scales))) __builtin_trap();
  mx_issue_0(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 19u; ++row)
    for (uint32_t col = 0; col < 23u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 32u + col] << 16;
      out[(size_t)row * 23u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void mx_dense_kernel_0_repeated_rhs_3_kernel(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 6u; ++batch)
    mx_dense_kernel_0_repeated_rhs_3_kernel_slice(lhs + batch * 19u * 37u,
                   rhs + batch * 37u * 23u,
                   out + batch * 19u * 23u, batch % 3u == 0u);
}
