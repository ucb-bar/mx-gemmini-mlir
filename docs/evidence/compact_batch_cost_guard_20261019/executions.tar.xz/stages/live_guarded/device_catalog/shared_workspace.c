unsigned char mx_catalog_workspace[24704] __attribute__((aligned(64)));
