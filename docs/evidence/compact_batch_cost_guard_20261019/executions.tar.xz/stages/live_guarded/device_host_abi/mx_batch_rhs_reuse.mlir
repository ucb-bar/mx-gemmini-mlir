builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/compact_batch_live_rhs_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<6x19x37xf32>, %1: tensor<2x23x37xf32>) -> (tensor<6x19x23xf32>, tensor<6x37x23xf32>) {
    %2 = tensor.collapse_shape %1 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : tensor<2x23x37xf32> into tensor<1702xf32>
    %3 = tensor.expand_shape %2 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] output_shape [2, 1, 23, 37] {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : tensor<1702xf32> into tensor<2x1x23x37xf32>
    %4 = tensor.empty() : tensor<2x3x23x37xf32>
    %5 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%3 : tensor<2x1x23x37xf32>) outs(%4 : tensor<2x3x23x37xf32>) attrs =  {prov.region_id = "expand_0", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32"} {
    ^bb0(%6: f32, %7: f32):
      linalg.yield %6 : f32
    } -> tensor<2x3x23x37xf32>
    %8 = tensor.collapse_shape %5 [[0 : i64, 1 : i64, 2 : i64, 3 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<2x3x23x37xf32> into tensor<5106xf32>
    %9 = tensor.expand_shape %8 [[0 : i64, 1 : i64, 2 : i64]] output_shape [6, 23, 37] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<5106xf32> into tensor<6x23x37xf32>
    %10 = tensor.empty() : tensor<6x37x23xf32>
    %11 = linalg.transpose ins(%9:tensor<6x23x37xf32>) outs(%10:tensor<6x37x23xf32>) permutation = [0, 2, 1]
    %12 = arith.constant {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} 0.000000e+00 : f32
    %13 = tensor.splat %12 {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : tensor<6x19x23xf32>
    %14 = func.call @mx_repeated_rhs_0(%0, %11, %13) : (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>
    func.return %14, %11 : tensor<6x19x23xf32>, tensor<6x37x23xf32>
  }
  "func.func"() <{sym_name = "mx_repeated_rhs_0", function_type = (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {merlin.repeated_batch_input = "{\22argument\22: 1, \22provider_obligation\22: \22original_results_rounding_effects_refusal_and_synchronous_private_preparation\22, \22repeat\22: 3}"} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}