/* MX dense f32 adapter: FP8, qualified 128x320x320 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_8(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_54_fixed_codes[];
extern const uint8_t mx_dense_kernel_54_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_54_prepared_bf16_transport_kernel(const uint8_t *lhs, uint16_t *out) {
  if (!lhs || !out) __builtin_trap();
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 0);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 81920);
  const uint8_t *activation = lhs;
  const uint8_t *activation_scales = lhs + 40960u;
  mx_issue_8(activation, activation_scales, mx_dense_kernel_54_fixed_codes, mx_dense_kernel_54_fixed_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 113u; ++row)
    for (uint32_t col = 0; col < 320u; ++col)
      out[(size_t)row * 320u + col] = output_bf16[(size_t)row * 320u + col];
}
