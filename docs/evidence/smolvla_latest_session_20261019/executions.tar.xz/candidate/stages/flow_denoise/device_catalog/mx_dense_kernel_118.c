/* MX dense f32 adapter: FP8, qualified 64x128x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_12(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_118_slice(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  float *padded_b = (float *)(mx_catalog_workspace + 16384);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 49152);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 53248);
  uint8_t *weight = (uint8_t *)(mx_catalog_workspace + 53376);
  uint8_t *weight_scales = (uint8_t *)(mx_catalog_workspace + 61568);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 61824);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 78208);
  for (size_t i = 0; i < 4096u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 50u; ++row)
    for (size_t col = 0; col < 64u; ++col)
      padded_a[row * 64u + col] = lhs[row * 64u + col];
  for (size_t i = 0; i < 8192u; ++i) padded_b[i] = 0;
  for (size_t row = 0; row < 64u; ++row)
    for (size_t col = 0; col < 113u; ++col)
      padded_b[row * 128u + col] = rhs[row * 113u + col];
  if (mx_pack_activation_f32(padded_a, 64u, 64u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      mx_pack_weight_f32(padded_b, 64u, 128u, MX_RUNTIME_FP8,
                         weight, weight_scales)) __builtin_trap();
  mx_issue_12(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 50u; ++row)
    for (uint32_t col = 0; col < 113u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 128u + col] << 16;
      out[(size_t)row * 113u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void mx_dense_kernel_118(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 15u; ++batch)
    mx_dense_kernel_118_slice(lhs + batch * 50u * 64u,
                   rhs + batch * 64u * 113u,
                   out + batch * 50u * 113u);
}
