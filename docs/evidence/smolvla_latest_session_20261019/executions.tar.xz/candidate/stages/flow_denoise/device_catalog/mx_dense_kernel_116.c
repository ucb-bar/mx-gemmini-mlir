/* MX dense f32 adapter: FP8, qualified 64x176x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_10(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_116_slice(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  float *padded_b = (float *)(mx_catalog_workspace + 16384);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 61440);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 65536);
  uint8_t *weight = (uint8_t *)(mx_catalog_workspace + 65664);
  uint8_t *weight_scales = (uint8_t *)(mx_catalog_workspace + 76928);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 77312);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 99840);
  for (size_t i = 0; i < 4096u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 50u; ++row)
    for (size_t col = 0; col < 64u; ++col)
      padded_a[row * 64u + col] = lhs[row * 64u + col];
  for (size_t i = 0; i < 11264u; ++i) padded_b[i] = 0;
  for (size_t row = 0; row < 64u; ++row)
    for (size_t col = 0; col < 163u; ++col)
      padded_b[row * 176u + col] = rhs[row * 163u + col];
  if (mx_pack_activation_f32(padded_a, 64u, 64u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      mx_pack_weight_f32(padded_b, 64u, 176u, MX_RUNTIME_FP8,
                         weight, weight_scales)) __builtin_trap();
  mx_issue_10(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 50u; ++row)
    for (uint32_t col = 0; col < 163u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 176u + col] << 16;
      out[(size_t)row * 163u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void mx_dense_kernel_116(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 15u; ++batch)
    mx_dense_kernel_116_slice(lhs + batch * 50u * 64u,
                   rhs + batch * 64u * 163u,
                   out + batch * 50u * 163u);
}
