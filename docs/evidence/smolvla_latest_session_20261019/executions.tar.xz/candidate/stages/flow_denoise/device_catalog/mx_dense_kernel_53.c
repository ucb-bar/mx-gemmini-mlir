/* MX dense f32 adapter: FP8, qualified 128x320x320 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_8(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_53_fixed_codes[];
extern const uint8_t mx_dense_kernel_53_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_53(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 163840);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 204800);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 206080);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 288000);
  for (size_t i = 0; i < 40960u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 113u; ++row)
    for (size_t col = 0; col < 320u; ++col)
      padded_a[row * 320u + col] = lhs[row * 320u + col];
  if (mx_pack_activation_f32(padded_a, 128u, 320u, MX_RUNTIME_FP8,
                             activation, activation_scales)) __builtin_trap();
  mx_issue_8(activation, activation_scales, mx_dense_kernel_53_fixed_codes, mx_dense_kernel_53_fixed_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 113u; ++row)
    for (uint32_t col = 0; col < 320u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 320u + col] << 16;
      out[(size_t)row * 320u + col] = word.value;
    }
}
