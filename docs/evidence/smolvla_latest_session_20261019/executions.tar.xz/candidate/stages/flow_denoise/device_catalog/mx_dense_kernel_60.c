/* MX dense f32 adapter: FP8, qualified 64x320x736 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_4(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_60_fixed_codes[];
extern const uint8_t mx_dense_kernel_60_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_60(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 188416);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 235520);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 236992);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 277952);
  for (size_t i = 0; i < 47104u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 50u; ++row)
    for (size_t col = 0; col < 720u; ++col)
      padded_a[row * 736u + col] = lhs[row * 720u + col];
  if (mx_pack_activation_f32(padded_a, 64u, 736u, MX_RUNTIME_FP8,
                             activation, activation_scales)) __builtin_trap();
  mx_issue_4(activation, activation_scales, mx_dense_kernel_60_fixed_codes, mx_dense_kernel_60_fixed_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 50u; ++row)
    for (uint32_t col = 0; col < 320u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 320u + col] << 16;
      out[(size_t)row * 320u + col] = word.value;
    }
}
