/* MX dense f32 adapter: FP8, qualified 64x64x128 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_13(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_119_slice(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  float *padded_b = (float *)(mx_catalog_workspace + 32768);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 65536);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 73728);
  uint8_t *weight = (uint8_t *)(mx_catalog_workspace + 73984);
  uint8_t *weight_scales = (uint8_t *)(mx_catalog_workspace + 82176);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 82432);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 90624);
  for (size_t i = 0; i < 8192u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 50u; ++row)
    for (size_t col = 0; col < 113u; ++col)
      padded_a[row * 128u + col] = lhs[row * 113u + col];
  for (size_t i = 0; i < 8192u; ++i) padded_b[i] = 0;
  for (size_t row = 0; row < 113u; ++row)
    for (size_t col = 0; col < 64u; ++col)
      padded_b[row * 64u + col] = rhs[row * 64u + col];
  if (mx_pack_activation_f32(padded_a, 64u, 128u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      mx_pack_weight_f32(padded_b, 128u, 64u, MX_RUNTIME_FP8,
                         weight, weight_scales)) __builtin_trap();
  mx_issue_13(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 50u; ++row)
    for (uint32_t col = 0; col < 64u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 64u + col] << 16;
      out[(size_t)row * 64u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void mx_dense_kernel_119(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 15u; ++batch)
    mx_dense_kernel_119_slice(lhs + batch * 50u * 113u,
                   rhs + batch * 113u * 64u,
                   out + batch * 50u * 64u);
}
