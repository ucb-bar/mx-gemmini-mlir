/* MX dense f32 adapter: FP8, qualified 64x64x192 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_11(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_117_slice(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  float *padded_b = (float *)(mx_catalog_workspace + 49152);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 98304);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 110592);
  uint8_t *weight = (uint8_t *)(mx_catalog_workspace + 110976);
  uint8_t *weight_scales = (uint8_t *)(mx_catalog_workspace + 123264);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 123648);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 131840);
  for (size_t i = 0; i < 12288u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 50u; ++row)
    for (size_t col = 0; col < 163u; ++col)
      padded_a[row * 192u + col] = lhs[row * 163u + col];
  for (size_t i = 0; i < 12288u; ++i) padded_b[i] = 0;
  for (size_t row = 0; row < 163u; ++row)
    for (size_t col = 0; col < 64u; ++col)
      padded_b[row * 64u + col] = rhs[row * 64u + col];
  if (mx_pack_activation_f32(padded_a, 64u, 192u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      mx_pack_weight_f32(padded_b, 192u, 64u, MX_RUNTIME_FP8,
                         weight, weight_scales)) __builtin_trap();
  mx_issue_11(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 50u; ++row)
    for (uint32_t col = 0; col < 64u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 64u + col] << 16;
      out[(size_t)row * 64u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void mx_dense_kernel_117(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 15u; ++batch)
    mx_dense_kernel_117_slice(lhs + batch * 50u * 163u,
                   rhs + batch * 163u * 64u,
                   out + batch * 50u * 64u);
}
