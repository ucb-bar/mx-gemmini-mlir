/* MX dense f32 adapter: FP8, qualified 64x960x736 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_3(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_45_fixed_codes[];
extern const uint8_t mx_dense_kernel_45_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_45_prepared_bf16_transport_kernel(const uint8_t *lhs, uint16_t *out) {
  if (!lhs || !out) __builtin_trap();
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 0);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 122880);
  const uint8_t *activation = lhs;
  const uint8_t *activation_scales = lhs + 47104u;
  mx_issue_3(activation, activation_scales, mx_dense_kernel_45_fixed_codes, mx_dense_kernel_45_fixed_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 50u; ++row)
    for (uint32_t col = 0; col < 960u; ++col)
      out[(size_t)row * 960u + col] = output_bf16[(size_t)row * 960u + col];
}
