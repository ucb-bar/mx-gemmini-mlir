; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7, i64 %8, ptr %9, ptr %10, i64 %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, i64 %17) {
  %19 = mul i64 %3, 1
  %20 = mul i64 %19, %4
  %21 = mul i64 %20, %5
  %22 = mul i64 %21, 4
  %23 = getelementptr float, ptr %1, i64 %2
  %24 = getelementptr float, ptr %10, i64 %11
  call void @llvm.memcpy.p0.p0.i64(ptr %24, ptr %23, i64 %22, i1 false)
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1) {
  %3 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %0, align 8
  %4 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 0
  %5 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 1
  %6 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 2
  %7 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 3, 0
  %8 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 3, 1
  %9 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 3, 2
  %10 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 4, 0
  %11 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 4, 1
  %12 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %3, 4, 2
  %13 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %1, align 8
  %14 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 0
  %15 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 1
  %16 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 2
  %17 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 3, 0
  %18 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 3, 1
  %19 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 3, 2
  %20 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 4, 0
  %21 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 4, 1
  %22 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %13, 4, 2
  call void @forward(ptr %4, ptr %5, i64 %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11, i64 %12, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20, i64 %21, i64 %22)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
