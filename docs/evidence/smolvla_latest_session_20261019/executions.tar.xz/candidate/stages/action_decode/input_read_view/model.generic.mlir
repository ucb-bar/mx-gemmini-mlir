"builtin.module"() ({
  "func.func"() <{function_type = (tensor<1x50x32xf32>) -> tensor<1x50x32xf32>, sym_name = "forward"}> ({
  ^bb0(%arg0: tensor<1x50x32xf32>):
    "func.return"(%arg0) : (tensor<1x50x32xf32>) -> ()
  }) : () -> ()
}) {prov.level = "linalg-on-tensors", prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/captures/smolvla/smolvla_session/stages/action_decode/weights.safetensors"} : () -> ()
