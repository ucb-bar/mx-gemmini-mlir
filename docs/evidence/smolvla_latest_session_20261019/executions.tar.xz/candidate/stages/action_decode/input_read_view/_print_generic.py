import sys
from torch_mlir import ir
src, dst = sys.argv[1], sys.argv[2]
ctx = ir.Context()
ctx.allow_unregistered_dialects = True
mod = ir.Module.parse(open(src).read(), ctx)
with ctx:
    txt = mod.operation.get_asm(print_generic_op_form=True, large_elements_limit=None,
                                assume_verified=True)
open(dst, 'w').write(txt)
print('OK generic-form reprint', len(txt), 'bytes')
