/* MX dense f32 adapter: FP8, qualified 16x32x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_0(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_0_fixed_codes[];
extern const uint8_t mx_dense_kernel_0_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_0_bf16_transport_kernel(const float *lhs, const float *rhs, uint16_t *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  float *padded_a = (float *)(mx_catalog_workspace + 0);
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 4096);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 5120);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 5184);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 6208);
  for (uint32_t i = 0; i < 16u * 64u; ++i) padded_a[i] = 0.0f;
  for (uint32_t row = 0; row < 1u; ++row)
    for (uint32_t col = 0; col < 37u; ++col)
      padded_a[(size_t)row * 64u + col] = lhs[(size_t)row * 37u + col];
  if (mx_pack_activation_f32(padded_a, 16u, 64u, MX_RUNTIME_FP8,
                             activation, activation_scales)) __builtin_trap();
  mx_issue_0(activation, activation_scales, mx_dense_kernel_0_fixed_codes, mx_dense_kernel_0_fixed_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 1u; ++row)
    for (uint32_t col = 0; col < 23u; ++col)
      out[(size_t)row * 23u + col] = output_bf16[(size_t)row * 32u + col];
}
