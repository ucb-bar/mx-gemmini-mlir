builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_bias/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<1x37xf32>, %2: tensor<23xf32>) -> tensor<1x1x23xf32> {
    %3 = tensor.empty() : tensor<37x23xf32>
    %4 = linalg.transpose ins(%0:tensor<23x37xf32>) outs(%3:tensor<37x23xf32>) permutation = [1, 0]
    %5 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} 0.000000e+00 : f32
    %6 = tensor.splat %5 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<1x23xf32>
    %7 = linalg.matmul {prov.region_id = "matmul_0", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear", prov.transposed_b = "true"} ins(%1, %4 : tensor<1x37xf32>, tensor<37x23xf32>) outs(%6 : tensor<1x23xf32>) -> tensor<1x23xf32>
    %8 = tensor.collapse_shape %7 [[0 : i64, 1 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<1x23xf32> into tensor<23xf32>
    %9 = tensor.expand_shape %8 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 23] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<23xf32> into tensor<1x1x23xf32>
    %10 = tensor.empty() : tensor<1x1x23xf32>
    %11 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%9, %2 : tensor<1x1x23xf32>, tensor<23xf32>) outs(%10 : tensor<1x1x23xf32>) attrs =  {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} {
    ^bb0(%12: f32, %13: f32, %14: f32):
      %15 = arith.addf %12, %13 : f32
      linalg.yield %15 : f32
    } -> tensor<1x1x23xf32>
    func.return %11 : tensor<1x1x23xf32>
  }
}