builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_bias/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<1x37xf32>, %2: tensor<23xf32>) -> tensor<1x1x23xf32> {
    %3 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} 0.000000e+00 : f32
    %4 = tensor.splat %3 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<1x23xf32>
    %5 = tensor.empty() : tensor<37x23xf32>
    %6 = func.call @merlin_dev_mx_gemmini_0(%1, %5, %4) : (tensor<1x37xf32>, tensor<37x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>
    %7 = tensor.collapse_shape %6 [[0 : i64, 1 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<1x23xf32> into tensor<23xf32>
    %8 = tensor.expand_shape %7 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 23] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<23xf32> into tensor<1x1x23xf32>
    %9 = tensor.empty() : tensor<1x1x23xf32>
    %10 = tensor.empty() : tensor<1x1x23xf32>
    %11 = func.call @mx_vpu_add_f32_bias_1_1_23(%8, %2, %10) : (tensor<1x1x23xf32>, tensor<23xf32>, tensor<1x1x23xf32>) -> tensor<1x1x23xf32>
    func.return %11 : tensor<1x1x23xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x37xf32>, tensor<37x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_bias_1_1_23", function_type = (tensor<1x1x23xf32>, tensor<23xf32>, tensor<1x1x23xf32>) -> tensor<1x1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}