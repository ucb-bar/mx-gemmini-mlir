unsigned char mx_catalog_workspace[8256] __attribute__((aligned(64)));
