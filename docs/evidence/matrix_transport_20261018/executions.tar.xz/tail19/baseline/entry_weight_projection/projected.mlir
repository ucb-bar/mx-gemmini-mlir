"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>, %1: tensor<1x19x23xf32>):
    %2 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : () -> f32
    %3 = "tensor.splat"(%2) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : (f32) -> tensor<19x23xf32>
    %4 = "tensor.empty"() : () -> tensor<37x23xf32>
    %5 = "func.call"(%0, %4, %3) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %6 = "tensor.collapse_shape"(%5) <{reassociation = [[0 : i64, 1 : i64]]}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<19x23xf32>) -> tensor<437xf32>
    %7 = "tensor.expand_shape"(%6) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 1, 19, 23>}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<437xf32>) -> tensor<1x19x23xf32>
    %8 = "tensor.empty"() : () -> tensor<1x19x23xf32>
    %9 = "func.call"(%1, %7, %8) <{callee = @mx_vpu_add_f32_same_1_19_23}> : (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    "func.return"(%9) : (tensor<1x19x23xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()