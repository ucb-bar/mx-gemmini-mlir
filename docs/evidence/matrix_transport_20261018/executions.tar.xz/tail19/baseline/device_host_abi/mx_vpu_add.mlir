builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<19x37xf32>, %2: tensor<1x19x23xf32>) -> tensor<1x19x23xf32> {
    %3 = tensor.empty() : tensor<37x23xf32>
    %4 = linalg.transpose ins(%0:tensor<23x37xf32>) outs(%3:tensor<37x23xf32>) permutation = [1, 0]
    %5 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} 0.000000e+00 : f32
    %6 = tensor.splat %5 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<19x23xf32>
    %7 = func.call @merlin_dev_mx_gemmini_0(%1, %4, %6) : (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %8 = tensor.collapse_shape %7 [[0 : i64, 1 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<19x23xf32> into tensor<437xf32>
    %9 = tensor.expand_shape %8 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 19, 23] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<437xf32> into tensor<1x19x23xf32>
    %10 = tensor.empty() : tensor<1x19x23xf32>
    %11 = tensor.empty() : tensor<1x19x23xf32>
    %12 = func.call @mx_vpu_add_f32_same_1_19_23(%2, %9, %11) : (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    func.return %12 : tensor<1x19x23xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}