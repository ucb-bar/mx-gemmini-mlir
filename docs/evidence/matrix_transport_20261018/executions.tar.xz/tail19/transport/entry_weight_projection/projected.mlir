"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>, %1: tensor<1x19x23xf32>):
    %2 = "tensor.empty"() : () -> tensor<37x23xf32>
    %3 = "tensor.empty"() : () -> tensor<19x23xbf16>
    %4 = "func.call"(%0, %2, %3) <{callee = @mx_dense_kernel_0_bf16_transport}> : (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xbf16>) -> tensor<19x23xbf16>
    %5 = "tensor.collapse_shape"(%4) <{reassociation = [[0 : i64, 1 : i64]]}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<19x23xbf16>) -> tensor<437xbf16>
    %6 = "tensor.expand_shape"(%5) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 1, 19, 23>}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<437xbf16>) -> tensor<1x19x23xbf16>
    %7 = "tensor.empty"() : () -> tensor<1x19x23xf32>
    %8 = "func.call"(%1, %6, %7) <{callee = @mx_vpu_add_f32_same_1_19_23_bf16_input1}> : (tensor<1x19x23xf32>, tensor<1x19x23xbf16>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    "func.return"(%8) : (tensor<1x19x23xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_bf16_transport", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xbf16>) -> tensor<19x23xbf16>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23_bf16_input1", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xbf16>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()