#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_issue_2048(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(256))), "r"(UINT64_C(0x0010001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(512))), "r"(UINT64_C(0x0010001000000020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(768))), "r"(UINT64_C(0x0010001000000030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(1024))), "r"(UINT64_C(0x0010001000000040)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(1280))), "r"(UINT64_C(0x0010001000000050)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(1536))), "r"(UINT64_C(0x0010001000000060)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(1792))), "r"(UINT64_C(0x0010001000000070)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(2048))), "r"(UINT64_C(0x0010001000000080)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(2304))), "r"(UINT64_C(0x0010001000000090)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(2560))), "r"(UINT64_C(0x00100010000000a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(2816))), "r"(UINT64_C(0x00100010000000b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(3072))), "r"(UINT64_C(0x00100010000000c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(3328))), "r"(UINT64_C(0x00100010000000d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(3584))), "r"(UINT64_C(0x00100010000000e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(3840))), "r"(UINT64_C(0x00100010000000f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(256))), "r"(UINT64_C(0x0010001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(512))), "r"(UINT64_C(0x0010001000001020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(768))), "r"(UINT64_C(0x0010001000001030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(1024))), "r"(UINT64_C(0x0010001000001040)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(1280))), "r"(UINT64_C(0x0010001000001050)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(1536))), "r"(UINT64_C(0x0010001000001060)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(1792))), "r"(UINT64_C(0x0010001000001070)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(2048))), "r"(UINT64_C(0x0010001000001080)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(2304))), "r"(UINT64_C(0x0010001000001090)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(2560))), "r"(UINT64_C(0x00100010000010a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(2816))), "r"(UINT64_C(0x00100010000010b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(3072))), "r"(UINT64_C(0x00100010000010c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(3328))), "r"(UINT64_C(0x00100010000010d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(3584))), "r"(UINT64_C(0x00100010000010e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(3840))), "r"(UINT64_C(0x00100010000010f0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0004020004000000)), "r"(UINT64_C(0x0000000000000020)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0010001000002010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(512))), "r"(UINT64_C(0x0010001000002020)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(768))), "r"(UINT64_C(0x0010001000002030)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1024))), "r"(UINT64_C(0x0010001000002040)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1280))), "r"(UINT64_C(0x0010001000002050)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1536))), "r"(UINT64_C(0x0010001000002060)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(1792))), "r"(UINT64_C(0x0010001000002070)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2048))), "r"(UINT64_C(0x0010001000002080)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2304))), "r"(UINT64_C(0x0010001000002090)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2560))), "r"(UINT64_C(0x00100010000020a0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(2816))), "r"(UINT64_C(0x00100010000020b0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3072))), "r"(UINT64_C(0x00100010000020c0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3328))), "r"(UINT64_C(0x00100010000020d0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3584))), "r"(UINT64_C(0x00100010000020e0)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(3840))), "r"(UINT64_C(0x00100010000020f0)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_a[2048] __attribute__((aligned(64)));
static uint16_t mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_b[2048] __attribute__((aligned(64)));
static uint16_t mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_c[2048] __attribute__((aligned(64)));
static uint16_t mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel(const uint16_t *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 2048; base += 2048) {
    uint32_t count = 2048 - base;
    if (count > 2048) count = 2048;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_a[index] = mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_b[index] = 0;
        continue;
      }
      uint32_t word = lhs[(base + index)];
      if ((word & 0x7f80u) == 0x7f80u && (word & 0x7fu)) __builtin_trap();
      mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_a[index] = (uint16_t)word;
      mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_b[index] = mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_narrow(rhs[(base + index)]);
      
    }
    const void *a = mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_a, *b = mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_b, *c = mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_c;
    switch (count) {
    case 2048: mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_issue_2048(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_widen(mx_vpu_add_f32_same_1_1_2048_bf16_input0_kernel_c[index]);
  }
}
