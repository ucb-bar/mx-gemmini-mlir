kernel mx_issue_0_schedule(activation: i8[90112] read, activation_scales: i8[2816] read, weight: i8[11534336] read, weight_scales: i8[360448] read, output_bf16: i16[32768] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=16, nc=512, kt=128}
  configure()
  for row in 0..1:
    for chunk in 0..4:
      for wave in 0..44:
        native_loop(a=&activation[((row * 90112) + (wave * 128))], b=&weight[((wave * 262144) + (chunk * 512))], c=&output_bf16[((row * 65536) + (chunk * 1024))], asc=&activation_scales[((wave * 64) + (row * 16))], bsc=&weight_scales[((wave * 8192) + (chunk * 512))], write=select(wave == 43, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 176) + (chunk * 44) + wave), 2) + 1))
