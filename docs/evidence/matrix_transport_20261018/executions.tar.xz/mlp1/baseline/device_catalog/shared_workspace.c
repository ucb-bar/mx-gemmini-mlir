unsigned char mx_catalog_workspace[520960] __attribute__((aligned(64)));
