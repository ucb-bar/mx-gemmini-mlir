builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_tiny1/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<2048x5632xf32>, %1: tensor<1x1x5632xf32>, %2: tensor<1x1x2048xf32>) -> tensor<1x1x2048xf32> {
    %3 = tensor.empty() : tensor<5632x2048xf32>
    %4 = linalg.transpose ins(%0:tensor<2048x5632xf32>) outs(%3:tensor<5632x2048xf32>) permutation = [1, 0]
    %5 = tensor.collapse_shape %1 [[0 : i64, 1 : i64, 2 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<1x1x5632xf32> into tensor<5632xf32>
    %6 = tensor.expand_shape %5 [[0 : i64, 1 : i64]] output_shape [1, 5632] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<5632xf32> into tensor<1x5632xf32>
    %7 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} 0.000000e+00 : f32
    %8 = tensor.splat %7 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<1x2048xf32>
    %9 = func.call @merlin_dev_mx_gemmini_0(%6, %4, %8) : (tensor<1x5632xf32>, tensor<5632x2048xf32>, tensor<1x2048xf32>) -> tensor<1x2048xf32>
    %10 = tensor.collapse_shape %9 [[0 : i64, 1 : i64]] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<1x2048xf32> into tensor<2048xf32>
    %11 = tensor.expand_shape %10 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 1, 2048] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<2048xf32> into tensor<1x1x2048xf32>
    %12 = tensor.empty() : tensor<1x1x2048xf32>
    %13 = tensor.empty() : tensor<1x1x2048xf32>
    %14 = func.call @mx_vpu_add_f32_same_1_1_2048(%2, %11, %13) : (tensor<1x1x2048xf32>, tensor<1x1x2048xf32>, tensor<1x1x2048xf32>) -> tensor<1x1x2048xf32>
    func.return %14 : tensor<1x1x2048xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x5632xf32>, tensor<5632x2048xf32>, tensor<1x2048xf32>) -> tensor<1x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_1_2048", function_type = (tensor<1x1x2048xf32>, tensor<1x1x2048xf32>, tensor<1x1x2048xf32>) -> tensor<1x1x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}