unsigned char mx_catalog_workspace[1586688] __attribute__((aligned(64)));
