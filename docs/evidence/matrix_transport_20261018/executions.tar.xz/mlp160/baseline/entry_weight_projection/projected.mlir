"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<1x160x5632xf32>, tensor<1x160x2048xf32>) -> tensor<1x160x2048xf32>}> ({
  ^bb0(%0: tensor<1x160x5632xf32>, %1: tensor<1x160x2048xf32>):
    %2 = "tensor.collapse_shape"(%0) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]]}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : (tensor<1x160x5632xf32>) -> tensor<901120xf32>
    %3 = "tensor.expand_shape"(%2) <{reassociation = [[0 : i64, 1 : i64]], static_output_shape = array<i64: 160, 5632>}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : (tensor<901120xf32>) -> tensor<160x5632xf32>
    %4 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : () -> f32
    %5 = "tensor.splat"(%4) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : (f32) -> tensor<160x2048xf32>
    %6 = "tensor.empty"() : () -> tensor<5632x2048xf32>
    %7 = "func.call"(%3, %6, %5) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<160x5632xf32>, tensor<5632x2048xf32>, tensor<160x2048xf32>) -> tensor<160x2048xf32>
    %8 = "tensor.collapse_shape"(%7) <{reassociation = [[0 : i64, 1 : i64]]}> {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : (tensor<160x2048xf32>) -> tensor<327680xf32>
    %9 = "tensor.expand_shape"(%8) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 1, 160, 2048>}> {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : (tensor<327680xf32>) -> tensor<1x160x2048xf32>
    %10 = "tensor.empty"() : () -> tensor<1x160x2048xf32>
    %11 = "func.call"(%1, %9, %10) <{callee = @mx_vpu_add_f32_same_1_160_2048}> : (tensor<1x160x2048xf32>, tensor<1x160x2048xf32>, tensor<1x160x2048xf32>) -> tensor<1x160x2048xf32>
    "func.return"(%11) : (tensor<1x160x2048xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<160x5632xf32>, tensor<5632x2048xf32>, tensor<160x2048xf32>) -> tensor<160x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_160_2048", function_type = (tensor<1x160x2048xf32>, tensor<1x160x2048xf32>, tensor<1x160x2048xf32>) -> tensor<1x160x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_tiny160/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()