builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_shared/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<23x37xf32>, %2: tensor<19x37xf32>, %3: tensor<1x19x23xf32>) -> tensor<1x19x46xf32> {
    %4 = tensor.empty() : tensor<37x23xf32>
    %5 = linalg.transpose ins(%0:tensor<23x37xf32>) outs(%4:tensor<37x23xf32>) permutation = [1, 0]
    %6 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} 0.000000e+00 : f32
    %7 = tensor.splat %6 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<19x23xf32>
    %8 = func.call @merlin_dev_mx_gemmini_0(%2, %5, %7) : (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %9 = tensor.collapse_shape %8 [[0 : i64, 1 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<19x23xf32> into tensor<437xf32>
    %10 = tensor.expand_shape %9 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 19, 23] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<437xf32> into tensor<1x19x23xf32>
    %11 = tensor.empty() : tensor<37x23xf32>
    %12 = linalg.transpose ins(%1:tensor<23x37xf32>) outs(%11:tensor<37x23xf32>) permutation = [1, 0]
    %13 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "second", prov.fqn = "second"} 0.000000e+00 : f32
    %14 = tensor.splat %13 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "second", prov.fqn = "second"} : tensor<19x23xf32>
    %15 = func.call @merlin_dev_mx_gemmini_1(%2, %12, %14) : (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %16 = tensor.collapse_shape %15 [[0 : i64, 1 : i64]] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<19x23xf32> into tensor<437xf32>
    %17 = tensor.expand_shape %16 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 19, 23] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<437xf32> into tensor<1x19x23xf32>
    %18 = tensor.empty() : tensor<1x19x23xf32>
    %19 = tensor.empty() : tensor<1x19x23xf32>
    %20 = func.call @mx_vpu_add_f32_same_1_19_23(%3, %10, %19) : (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    %21 = tensor.empty() : tensor<1x19x23xf32>
    %22 = tensor.empty() : tensor<1x19x23xf32>
    %23 = func.call @mx_vpu_add_f32_same_1_19_23(%3, %17, %22) : (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    %24 = tensor.concat dim(2) %20, %23 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x46xf32>
    func.return %24 : tensor<1x19x46xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}