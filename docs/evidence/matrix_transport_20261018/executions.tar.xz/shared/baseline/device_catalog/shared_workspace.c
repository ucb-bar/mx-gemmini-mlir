unsigned char mx_catalog_workspace[14400] __attribute__((aligned(64)));
