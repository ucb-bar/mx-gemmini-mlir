"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>, tensor<1x19x23xf32>) -> tensor<1x19x46xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>, %1: tensor<1x19x23xf32>):
    %2 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : () -> f32
    %3 = "tensor.splat"(%2) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : (f32) -> tensor<19x23xf32>
    %4 = "tensor.empty"() : () -> tensor<2112xi8>
    %5 = "func.call"(%0, %4) <{callee = @mx_prepare_a_fp8_m19_k37_pm32_pk64}> : (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>
    %6 = "func.call"(%5, %3) <{callee = @mx_dense_kernel_0_prepared}> : (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %7 = "tensor.collapse_shape"(%6) <{reassociation = [[0 : i64, 1 : i64]]}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<19x23xf32>) -> tensor<437xf32>
    %8 = "tensor.expand_shape"(%7) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 1, 19, 23>}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<437xf32>) -> tensor<1x19x23xf32>
    %9 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "second", prov.fqn = "second"} : () -> f32
    %10 = "tensor.splat"(%9) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "second", prov.fqn = "second"} : (f32) -> tensor<19x23xf32>
    %11 = "func.call"(%5, %10) <{callee = @mx_dense_kernel_1_prepared}> : (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %12 = "tensor.collapse_shape"(%11) <{reassociation = [[0 : i64, 1 : i64]]}> {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<19x23xf32>) -> tensor<437xf32>
    %13 = "tensor.expand_shape"(%12) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 1, 19, 23>}> {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<437xf32>) -> tensor<1x19x23xf32>
    %14 = "tensor.empty"() : () -> tensor<1x19x23xf32>
    %15 = "func.call"(%1, %8, %14) <{callee = @mx_vpu_add_f32_same_1_19_23}> : (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    %16 = "tensor.empty"() : () -> tensor<1x19x23xf32>
    %17 = "func.call"(%1, %13, %16) <{callee = @mx_vpu_add_f32_same_1_19_23}> : (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    %18 = "tensor.concat"(%15, %17) <{dim = 2 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x46xf32>
    "func.return"(%18) : (tensor<1x19x46xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m19_k37_pm32_pk64", function_type = (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_shared/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()