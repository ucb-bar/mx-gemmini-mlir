"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>, tensor<1x19x23xf32>) -> tensor<1x19x46xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>, %1: tensor<1x19x23xf32>):
    %2 = "tensor.empty"() : () -> tensor<2112xi8>
    %3 = "func.call"(%0, %2) <{callee = @mx_prepare_a_fp8_m19_k37_pm32_pk64}> : (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>
    %4 = "tensor.empty"() : () -> tensor<19x23xbf16>
    %5 = "func.call"(%3, %4) <{callee = @mx_dense_kernel_0_prepared_bf16_transport}> : (tensor<2112xi8>, tensor<19x23xbf16>) -> tensor<19x23xbf16>
    %6 = "tensor.collapse_shape"(%5) <{reassociation = [[0 : i64, 1 : i64]]}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<19x23xbf16>) -> tensor<437xbf16>
    %7 = "tensor.expand_shape"(%6) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 1, 19, 23>}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<437xbf16>) -> tensor<1x19x23xbf16>
    %8 = "tensor.empty"() : () -> tensor<19x23xbf16>
    %9 = "func.call"(%3, %8) <{callee = @mx_dense_kernel_1_prepared_bf16_transport}> : (tensor<2112xi8>, tensor<19x23xbf16>) -> tensor<19x23xbf16>
    %10 = "tensor.collapse_shape"(%9) <{reassociation = [[0 : i64, 1 : i64]]}> {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<19x23xbf16>) -> tensor<437xbf16>
    %11 = "tensor.expand_shape"(%10) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 1, 19, 23>}> {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<437xbf16>) -> tensor<1x19x23xbf16>
    %12 = "tensor.empty"() : () -> tensor<1x19x23xf32>
    %13 = "func.call"(%1, %7, %12) <{callee = @mx_vpu_add_f32_same_1_19_23_bf16_input1}> : (tensor<1x19x23xf32>, tensor<1x19x23xbf16>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    %14 = "tensor.empty"() : () -> tensor<1x19x23xf32>
    %15 = "func.call"(%1, %11, %14) <{callee = @mx_vpu_add_f32_same_1_19_23_bf16_input1}> : (tensor<1x19x23xf32>, tensor<1x19x23xbf16>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>
    %16 = "tensor.concat"(%13, %15) <{dim = 2 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x46xf32>
    "func.return"(%16) : (tensor<1x19x46xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m19_k37_pm32_pk64", function_type = (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared_bf16_transport", function_type = (tensor<2112xi8>, tensor<19x23xbf16>) -> tensor<19x23xbf16>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_add_f32_same_1_19_23_bf16_input1", function_type = (tensor<1x19x23xf32>, tensor<1x19x23xbf16>, tensor<1x19x23xf32>) -> tensor<1x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared_bf16_transport", function_type = (tensor<2112xi8>, tensor<19x23xbf16>) -> tensor<19x23xbf16>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_shared/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()