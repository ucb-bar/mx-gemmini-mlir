builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/matrix_residual_shared/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<23x37xf32>, %2: tensor<19x37xf32>, %3: tensor<1x19x23xf32>) -> tensor<1x19x46xf32> {
    %4 = tensor.empty() : tensor<37x23xf32>
    %5 = linalg.transpose ins(%0:tensor<23x37xf32>) outs(%4:tensor<37x23xf32>) permutation = [1, 0]
    %6 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} 0.000000e+00 : f32
    %7 = tensor.splat %6 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} : tensor<19x23xf32>
    %8 = linalg.matmul {prov.region_id = "matmul_0", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear", prov.transposed_b = "true"} ins(%2, %5 : tensor<19x37xf32>, tensor<37x23xf32>) outs(%7 : tensor<19x23xf32>) -> tensor<19x23xf32>
    %9 = tensor.collapse_shape %8 [[0 : i64, 1 : i64]] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<19x23xf32> into tensor<437xf32>
    %10 = tensor.expand_shape %9 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 19, 23] {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<437xf32> into tensor<1x19x23xf32>
    %11 = tensor.empty() : tensor<37x23xf32>
    %12 = linalg.transpose ins(%1:tensor<23x37xf32>) outs(%11:tensor<37x23xf32>) permutation = [1, 0]
    %13 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "second", prov.fqn = "second"} 0.000000e+00 : f32
    %14 = tensor.splat %13 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "second", prov.fqn = "second"} : tensor<19x23xf32>
    %15 = linalg.matmul {prov.region_id = "matmul_1", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "second", prov.fqn = "second", prov.transposed_b = "true"} ins(%2, %12 : tensor<19x37xf32>, tensor<37x23xf32>) outs(%14 : tensor<19x23xf32>) -> tensor<19x23xf32>
    %16 = tensor.collapse_shape %15 [[0 : i64, 1 : i64]] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<19x23xf32> into tensor<437xf32>
    %17 = tensor.expand_shape %16 [[0 : i64, 1 : i64, 2 : i64]] output_shape [1, 19, 23] {prov.region_id = "view_1", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : tensor<437xf32> into tensor<1x19x23xf32>
    %18 = tensor.empty() : tensor<1x19x23xf32>
    %19 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%3, %10 : tensor<1x19x23xf32>, tensor<1x19x23xf32>) outs(%18 : tensor<1x19x23xf32>) attrs =  {prov.region_id = "add_0", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} {
    ^bb0(%20: f32, %21: f32, %22: f32):
      %23 = arith.addf %20, %21 : f32
      linalg.yield %23 : f32
    } -> tensor<1x19x23xf32>
    %24 = tensor.empty() : tensor<1x19x23xf32>
    %25 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel"]} ins(%3, %17 : tensor<1x19x23xf32>, tensor<1x19x23xf32>) outs(%24 : tensor<1x19x23xf32>) attrs =  {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} {
    ^bb1(%26: f32, %27: f32, %28: f32):
      %29 = arith.addf %26, %27 : f32
      linalg.yield %29 : f32
    } -> tensor<1x19x23xf32>
    %30 = tensor.concat dim(2) %19, %25 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x19x23xf32>, tensor<1x19x23xf32>) -> tensor<1x19x46xf32>
    func.return %30 : tensor<1x19x46xf32>
  }
}