module attributes {mx.profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c",
  mx.contract_sha256 = "026aa3f9510306aa43b7513a1a27ee610091eacc96af2dd0ce255d9e372b219d", mx.policy_sha256 = "156e2fd304f39fec9bb0dc85216be792d86bd69a199bbcf66956911c1a923880",
  prov.quantization_manifest_sha256 = "5b71b66fdb15fd776958e8d995d15f9aa0ddbbd39892c3cdb27d1ca144c15dd2",
  mx.b2_source_sha256 = "875a0889c489b4f213e15b6f7e55aa6e49b1e7ba46de44c574a33e6b97487af0",
  mx.frontend_mlir_sha256 = "1e2592c8ec4104ca9882a8741b74806de3f6d3860c7b0feb2a628b9a19cf7d37",
  mx.runtime_resources_sha256 = "bab6dbbb7f234b8e0911897e8306322e2ec14127eefb1fc4cd627309002c1024"} {
  func.func @nicolas_rectangular_pair(
      %a1: tensor<64x64xi8>, %a1s: tensor<2x64xi8>,
      %b1: tensor<64x96xi8>, %b1s: tensor<2x96xi8>,
      %b2: tensor<96x32xi8>, %b2s: tensor<3x32xi8>)
      -> (tensor<64x32xi8>, tensor<64x1xi8>) {
    %acc = "mx_gemmini.contract"(%a1, %a1s, %b1, %b1s) {
      site_id = "functional:matmul", activation_format = "fp8_e4m3",
      weight_format = "fp8_e4m3", activation_projection = "direct",
      weight_projection = "direct", pe_mode = 8 : i32, contract_sha256 = "026aa3f9510306aa43b7513a1a27ee610091eacc96af2dd0ce255d9e372b219d", policy_sha256 = "156e2fd304f39fec9bb0dc85216be792d86bd69a199bbcf66956911c1a923880", manifest_sha256 = "5b71b66fdb15fd776958e8d995d15f9aa0ddbbd39892c3cdb27d1ca144c15dd2", profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c"}
      : (tensor<64x64xi8>, tensor<2x64xi8>, tensor<64x96xi8>, tensor<2x96xi8>)
      -> tensor<64x96xbf16>
    %c1, %c1s = "mx_gemmini.readout_quantized"(%acc) {
      site_id = "functional:matmul", output_format = "fp8_e4m3", contract_sha256 = "026aa3f9510306aa43b7513a1a27ee610091eacc96af2dd0ce255d9e372b219d", policy_sha256 = "156e2fd304f39fec9bb0dc85216be792d86bd69a199bbcf66956911c1a923880", manifest_sha256 = "5b71b66fdb15fd776958e8d995d15f9aa0ddbbd39892c3cdb27d1ca144c15dd2", profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c"}
      : (tensor<64x96xbf16>) -> (tensor<64x96xi8>, tensor<64x3xi8>)
    %c2, %c2s = "mx_gemmini.resident_contract"(%c1, %c1s, %b2, %b2s) {
      site_id = "functional:matmul_1", activation_row = 2048 : i32,
      weight_row = 16192 : i32, output_row = 4096 : i32,
      m = 64 : i32, n = 32 : i32, k = 96 : i32,
      activation_format = "fp8_e4m3", weight_format = "fp8_e4m3",
      output_format = "fp8_e4m3", weight_buffer = "b2_weight",
      weight_scales_buffer = "b2_scales", output_scales_buffer = "c2_scales",
      contract_sha256 = "026aa3f9510306aa43b7513a1a27ee610091eacc96af2dd0ce255d9e372b219d", policy_sha256 = "156e2fd304f39fec9bb0dc85216be792d86bd69a199bbcf66956911c1a923880", manifest_sha256 = "5b71b66fdb15fd776958e8d995d15f9aa0ddbbd39892c3cdb27d1ca144c15dd2", profile_sha256 = "bf54ac354c298cc71db23598f569fda73b9b2e46df5f7683bdac17a94fac0e3c"}
      : (tensor<64x96xi8>, tensor<64x3xi8>, tensor<96x32xi8>, tensor<3x32xi8>)
      -> (tensor<64x32xi8>, tensor<64x1xi8>)
    func.return %c2, %c2s : tensor<64x32xi8>, tensor<64x1xi8>
  }
}
