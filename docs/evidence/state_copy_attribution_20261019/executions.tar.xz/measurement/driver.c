#include <stdint.h>
#include "model_gen.h"
void console_init(void);void htif_puts(const char*);void htif_putd(long);void htif_exit(int);
void merlin_invoke(void **d){(void)d;}
static unsigned char a0[7209088] __attribute__((aligned(64)));static unsigned char b0[7209088] __attribute__((aligned(64)));static unsigned char a1[304] __attribute__((aligned(64)));static unsigned char b1[304] __attribute__((aligned(64)));
static const int input_args[]={ 49,50 };
static const int output_indices[]={ 1,2 };
static uint64_t cycle(void){uint64_t r;asm volatile("rdcycle %0":"=r"(r)::"memory");return r;}
int main(void){console_init();void *in[MERLIN_N_ARGS]={0},*out[MERLIN_N_OUTPUTS]={0};
in[49]=a0+64;in[50]=a1+64;out[1]=b0+64;out[2]=b1+64;
for(unsigned run=0;run<4;++run){unsigned calls=run<3?1:32;
for(size_t i=0;i<7209088;++i){a0[i]=0xa5;b0[i]=0xa5;} for(size_t i=0;i<7208960;++i){a0[i+64]=0;b0[i+64]=(unsigned char)(i*17+0*31+run);}for(size_t i=0;i<304;++i){a1[i]=0xa5;b1[i]=0xa5;} for(size_t i=0;i<176;++i){a1[i+64]=0;b1[i+64]=(unsigned char)(i*17+1*31+run);}
uint64_t begin=cycle();int status=0;for(unsigned i=0;i<calls;++i)status|=merlin_commit_state(MERLIN_ARGS,MERLIN_N_ARGS,in,out,2,input_args,output_indices);
uint64_t elapsed=cycle()-begin;unsigned bad=0;for(size_t i=0;i<7208960;++i)bad+=a0[i+64]!=b0[i+64]||b0[i+64]!=(unsigned char)(i*17+0*31+run);for(size_t i=0;i<64;++i)bad+=a0[i]!=0xa5||b0[i]!=0xa5||a0[7208960+64+i]!=0xa5||b0[7208960+64+i]!=0xa5;for(size_t i=0;i<176;++i)bad+=a1[i+64]!=b1[i+64]||b1[i+64]!=(unsigned char)(i*17+1*31+run);for(size_t i=0;i<64;++i)bad+=a1[i]!=0xa5||b1[i]!=0xa5||a1[176+64+i]!=0xa5||b1[176+64+i]!=0xa5;
htif_puts("STATE_COPY run=");htif_putd(run);htif_puts(" calls=");htif_putd(calls);htif_puts(" cycles=");htif_putd(elapsed);htif_puts(" bad=");htif_putd(bad);htif_puts("\n");if(status||bad)htif_exit(3);
}htif_puts("DONE\n");htif_exit(0);return 0;}
