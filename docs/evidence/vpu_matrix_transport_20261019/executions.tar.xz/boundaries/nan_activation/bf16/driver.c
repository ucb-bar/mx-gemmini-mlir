#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void produce(const float *,const float *,const float *,uint16_t *);
void __attribute__((noreturn)) tohost_exit(uintptr_t);
static uint16_t storage[24643] __attribute__((aligned(64)));
static float word_float(uint32_t bits){union{float f;uint32_t u;}w;w.u=bits;return w.f;}
static uint32_t word_bits(float value){union{float f;uint32_t u;}w;w.f=value;return w.u;}
static uint32_t raw(unsigned i){return storage[i];}
static void dump(void) {
  unsigned guard=0,low=0;
  for(unsigned i=0;i<32;++i)guard+=raw(i)!=42405u ||
    raw(24611u+i)!=42405u;
  for(unsigned i=0;i<24579;++i) {
    if(i%32u==0)printf("WORDS_CHUNK %u ",i);
    uint32_t word=raw(i+32);low|=0;
    printf("%04x ",(unsigned)(word));
    if(i%32u==31u || i==24578u)printf("\n");
  }
  printf("WORDS_STATUS guard=%u low_bits=%u\n",guard,low);
}
uintptr_t handle_trap(uintptr_t cause,uintptr_t pc,uintptr_t regs[32]) {
  (void)regs;dump();printf("REFUSAL_TRAP cause=%lu pc=%lu\n",(unsigned long)cause,(unsigned long)pc);
  tohost_exit(77);
}
int main(void) {
  for(unsigned i=0;i<24643;++i)storage[i]=0xa5a5u;
  const float *a=(const float *)payload,*b=a+3,*c=b+24579;
  printf("BEGIN\n");produce(a,b,c,storage+32);
  dump();printf("DONE\n");return 0;
}
