#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void produce(const float *,const float *,const float *,float *);
void __attribute__((noreturn)) tohost_exit(uintptr_t);
static float storage[443] __attribute__((aligned(64)));
static float word_float(uint32_t bits){union{float f;uint32_t u;}w;w.u=bits;return w.f;}
static uint32_t word_bits(float value){union{float f;uint32_t u;}w;w.f=value;return w.u;}
static uint32_t raw(unsigned i){return word_bits(storage[i]);}
static void dump(void) {
  unsigned guard=0,low=0;
  for(unsigned i=0;i<16;++i)guard+=raw(i)!=2779054080u ||
    raw(427u+i)!=2779054080u;
  for(unsigned i=0;i<411;++i) {
    if(i%32u==0)printf("WORDS_CHUNK %u ",i);
    uint32_t word=raw(i+16);low|=word&65535u;
    printf("%04x ",(unsigned)(word>>16));
    if(i%32u==31u || i==410u)printf("\n");
  }
  printf("WORDS_STATUS guard=%u low_bits=%u\n",guard,low);
}
uintptr_t handle_trap(uintptr_t cause,uintptr_t pc,uintptr_t regs[32]) {
  (void)regs;dump();printf("REFUSAL_TRAP cause=%lu pc=%lu\n",(unsigned long)cause,(unsigned long)pc);
  tohost_exit(77);
}
int main(void) {
  for(unsigned i=0;i<443;++i)storage[i]=word_float(0xa5a50000u);
  const float *a=(const float *)payload,*b=a+411,*c=b+3;
  printf("BEGIN\n");produce(a,b,c,storage+16);
  dump();printf("DONE\n");return 0;
}
