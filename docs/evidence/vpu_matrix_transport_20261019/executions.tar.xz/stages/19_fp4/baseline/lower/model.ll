; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_19x23xf32 = private constant [19 x [23 x float]] zeroinitializer, align 64
@__constant_19x41xf32 = private constant [19 x [41 x float]] zeroinitializer, align 64
@__constant_19x17xf32 = private constant [19 x [17 x float]] zeroinitializer, align 64

declare void @free(ptr)

declare void @memrefCopy(i64, ptr, ptr)

declare ptr @malloc(i64)

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18, ptr %19, ptr %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25) {
  %27 = call ptr @malloc(i64 2876)
  %28 = ptrtoint ptr %27 to i64
  %29 = add i64 %28, 63
  %30 = urem i64 %29, 64
  %31 = sub i64 %29, %30
  %32 = inttoptr i64 %31 to ptr
  %33 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_mul_chain_f32_19_37_inputs_19_37_axes_0_1__19_1_axes_0_1__37_axes_1_middle0(ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18, ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %27, ptr %32, i64 0, i64 19, i64 37, i64 37, i64 1)
  %34 = call ptr @malloc(i64 1152)
  %35 = ptrtoint ptr %34 to i64
  %36 = add i64 %35, 63
  %37 = urem i64 %36, 64
  %38 = sub i64 %36, %37
  %39 = inttoptr i64 %38 to ptr
  %40 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, 0
  %41 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, 1
  %42 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, 2
  %43 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, 3, 0
  %44 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, 3, 1
  %45 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, 4, 0
  %46 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, 4, 1
  %47 = call { ptr, ptr, i64, [1 x i64], [1 x i64] } @mx_prepare_a_fp4_m19_k37_pm32_pk64(ptr %40, ptr %41, i64 %42, i64 %43, i64 %44, i64 %45, i64 %46, ptr %34, ptr %39, i64 0, i64 1088, i64 1)
  %48 = call ptr @malloc(i64 1812)
  %49 = ptrtoint ptr %48 to i64
  %50 = add i64 %49, 63
  %51 = urem i64 %50, 64
  %52 = sub i64 %50, %51
  %53 = inttoptr i64 %52 to ptr
  %54 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, 0
  %55 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, 1
  %56 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, 2
  %57 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, 3, 0
  %58 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, 4, 0
  %59 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_0_prepared(ptr %54, ptr %55, i64 %56, i64 %57, i64 %58, ptr %48, ptr %53, i64 0, i64 19, i64 23, i64 23, i64 1)
  %60 = call ptr @malloc(i64 3180)
  %61 = ptrtoint ptr %60 to i64
  %62 = add i64 %61, 63
  %63 = urem i64 %62, 64
  %64 = sub i64 %62, %63
  %65 = inttoptr i64 %64 to ptr
  %66 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_1_prepared(ptr %54, ptr %55, i64 %56, i64 %57, i64 %58, ptr %60, ptr %65, i64 0, i64 19, i64 41, i64 41, i64 1)
  %67 = call ptr @malloc(i64 1356)
  %68 = ptrtoint ptr %67 to i64
  %69 = add i64 %68, 63
  %70 = urem i64 %69, 64
  %71 = sub i64 %69, %70
  %72 = inttoptr i64 %71 to ptr
  %73 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_2_prepared(ptr %54, ptr %55, i64 %56, i64 %57, i64 %58, ptr %67, ptr %72, i64 0, i64 19, i64 17, i64 17, i64 1)
  %74 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %19, 0
  %75 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %74, ptr %20, 1
  %76 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %75, i64 0, 2
  %77 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %76, i64 19, 3, 0
  %78 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %77, i64 81, 4, 0
  %79 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %78, i64 23, 3, 1
  %80 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %79, i64 1, 4, 1
  %81 = call ptr @llvm.stacksave.p0()
  %82 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %59, ptr %82, align 8
  %83 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %82, 1
  %84 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %80, ptr %84, align 8
  %85 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %84, 1
  %86 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %83, ptr %86, align 8
  %87 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %85, ptr %87, align 8
  call void @memrefCopy(i64 4, ptr %86, ptr %87)
  call void @llvm.stackrestore.p0(ptr %81)
  %88 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %75, i64 23, 2
  %89 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %88, i64 19, 3, 0
  %90 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %89, i64 81, 4, 0
  %91 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %90, i64 41, 3, 1
  %92 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %91, i64 1, 4, 1
  %93 = call ptr @llvm.stacksave.p0()
  %94 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %66, ptr %94, align 8
  %95 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %94, 1
  %96 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, ptr %96, align 8
  %97 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %96, 1
  %98 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %95, ptr %98, align 8
  %99 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %97, ptr %99, align 8
  call void @memrefCopy(i64 4, ptr %98, ptr %99)
  call void @llvm.stackrestore.p0(ptr %93)
  %100 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %75, i64 64, 2
  %101 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %100, i64 19, 3, 0
  %102 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %101, i64 81, 4, 0
  %103 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %102, i64 17, 3, 1
  %104 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %103, i64 1, 4, 1
  %105 = call ptr @llvm.stacksave.p0()
  %106 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %73, ptr %106, align 8
  %107 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %106, 1
  %108 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %104, ptr %108, align 8
  %109 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %108, 1
  %110 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %107, ptr %110, align 8
  %111 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %109, ptr %111, align 8
  call void @memrefCopy(i64 4, ptr %110, ptr %111)
  call void @llvm.stackrestore.p0(ptr %105)
  %112 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %59, 0
  %113 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %59, 1
  %114 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %66, 0
  %115 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %66, 1
  %116 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %73, 0
  %117 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %73, 1
  %118 = call ptr @malloc(i64 80)
  %119 = call ptr @malloc(i64 10)
  %120 = call ptr @malloc(i64 0)
  %121 = ptrtoint ptr %32 to i64
  store i64 %121, ptr %118, align 8
  %122 = ptrtoint ptr %41 to i64
  %123 = getelementptr inbounds nuw i64, ptr %118, i32 1
  store i64 %122, ptr %123, align 8
  %124 = ptrtoint ptr %39 to i64
  %125 = getelementptr inbounds nuw i64, ptr %118, i32 2
  store i64 %124, ptr %125, align 8
  %126 = ptrtoint ptr %55 to i64
  %127 = getelementptr inbounds nuw i64, ptr %118, i32 3
  store i64 %126, ptr %127, align 8
  %128 = ptrtoint ptr %53 to i64
  %129 = getelementptr inbounds nuw i64, ptr %118, i32 4
  store i64 %128, ptr %129, align 8
  %130 = ptrtoint ptr %113 to i64
  %131 = getelementptr inbounds nuw i64, ptr %118, i32 5
  store i64 %130, ptr %131, align 8
  %132 = ptrtoint ptr %65 to i64
  %133 = getelementptr inbounds nuw i64, ptr %118, i32 6
  store i64 %132, ptr %133, align 8
  %134 = ptrtoint ptr %115 to i64
  %135 = getelementptr inbounds nuw i64, ptr %118, i32 7
  store i64 %134, ptr %135, align 8
  %136 = ptrtoint ptr %72 to i64
  %137 = getelementptr inbounds nuw i64, ptr %118, i32 8
  store i64 %136, ptr %137, align 8
  %138 = ptrtoint ptr %117 to i64
  %139 = getelementptr inbounds nuw i64, ptr %118, i32 9
  store i64 %138, ptr %139, align 8
  store i1 true, ptr %119, align 1
  %140 = getelementptr inbounds nuw i1, ptr %119, i32 1
  store i1 true, ptr %140, align 1
  %141 = getelementptr inbounds nuw i1, ptr %119, i32 2
  store i1 true, ptr %141, align 1
  %142 = getelementptr inbounds nuw i1, ptr %119, i32 3
  store i1 true, ptr %142, align 1
  %143 = getelementptr inbounds nuw i1, ptr %119, i32 4
  store i1 true, ptr %143, align 1
  %144 = getelementptr inbounds nuw i1, ptr %119, i32 5
  store i1 true, ptr %144, align 1
  %145 = getelementptr inbounds nuw i1, ptr %119, i32 6
  store i1 true, ptr %145, align 1
  %146 = getelementptr inbounds nuw i1, ptr %119, i32 7
  store i1 true, ptr %146, align 1
  %147 = getelementptr inbounds nuw i1, ptr %119, i32 8
  store i1 true, ptr %147, align 1
  %148 = getelementptr inbounds nuw i1, ptr %119, i32 9
  store i1 true, ptr %148, align 1
  %149 = call ptr @malloc(i64 10)
  %150 = call ptr @malloc(i64 0)
  call void @dealloc_helper(ptr %118, ptr %118, i64 0, i64 10, i64 1, ptr %120, ptr %120, i64 0, i64 0, i64 1, ptr %119, ptr %119, i64 0, i64 10, i64 1, ptr %149, ptr %149, i64 0, i64 10, i64 1, ptr %150, ptr %150, i64 0, i64 0, i64 1)
  call void @free(ptr %150)
  call void @free(ptr %120)
  call void @free(ptr %119)
  call void @free(ptr %118)
  %151 = load i1, ptr %149, align 1
  br i1 %151, label %152, label %153

152:                                              ; preds = %26
  call void @free(ptr %27)
  br label %153

153:                                              ; preds = %152, %26
  %154 = getelementptr inbounds nuw i1, ptr %149, i32 1
  %155 = load i1, ptr %154, align 1
  br i1 %155, label %156, label %157

156:                                              ; preds = %153
  call void @free(ptr %40)
  br label %157

157:                                              ; preds = %156, %153
  %158 = getelementptr inbounds nuw i1, ptr %149, i32 2
  %159 = load i1, ptr %158, align 1
  br i1 %159, label %160, label %161

160:                                              ; preds = %157
  call void @free(ptr %34)
  br label %161

161:                                              ; preds = %160, %157
  %162 = getelementptr inbounds nuw i1, ptr %149, i32 3
  %163 = load i1, ptr %162, align 1
  br i1 %163, label %164, label %165

164:                                              ; preds = %161
  call void @free(ptr %54)
  br label %165

165:                                              ; preds = %164, %161
  %166 = getelementptr inbounds nuw i1, ptr %149, i32 4
  %167 = load i1, ptr %166, align 1
  br i1 %167, label %168, label %169

168:                                              ; preds = %165
  call void @free(ptr %48)
  br label %169

169:                                              ; preds = %168, %165
  %170 = getelementptr inbounds nuw i1, ptr %149, i32 5
  %171 = load i1, ptr %170, align 1
  br i1 %171, label %172, label %173

172:                                              ; preds = %169
  call void @free(ptr %112)
  br label %173

173:                                              ; preds = %172, %169
  %174 = getelementptr inbounds nuw i1, ptr %149, i32 6
  %175 = load i1, ptr %174, align 1
  br i1 %175, label %176, label %177

176:                                              ; preds = %173
  call void @free(ptr %60)
  br label %177

177:                                              ; preds = %176, %173
  %178 = getelementptr inbounds nuw i1, ptr %149, i32 7
  %179 = load i1, ptr %178, align 1
  br i1 %179, label %180, label %181

180:                                              ; preds = %177
  call void @free(ptr %114)
  br label %181

181:                                              ; preds = %180, %177
  %182 = getelementptr inbounds nuw i1, ptr %149, i32 8
  %183 = load i1, ptr %182, align 1
  br i1 %183, label %184, label %185

184:                                              ; preds = %181
  call void @free(ptr %67)
  br label %185

185:                                              ; preds = %184, %181
  %186 = getelementptr inbounds nuw i1, ptr %149, i32 9
  %187 = load i1, ptr %186, align 1
  call void @free(ptr %149)
  br i1 %187, label %188, label %189

188:                                              ; preds = %185
  call void @free(ptr %116)
  br label %189

189:                                              ; preds = %188, %185
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1, ptr %2, ptr %3) {
  %5 = load { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %0, align 8
  %6 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %5, 0
  %7 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %5, 1
  %8 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %5, 2
  %9 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %5, 3, 0
  %10 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %5, 4, 0
  %11 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %12 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 0
  %13 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 1
  %14 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 2
  %15 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 0
  %16 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 1
  %17 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 0
  %18 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 1
  %19 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, align 8
  %20 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, 0
  %21 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, 1
  %22 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, 2
  %23 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, 3, 0
  %24 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, 3, 1
  %25 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, 4, 0
  %26 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, 4, 1
  %27 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, align 8
  %28 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, 0
  %29 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, 1
  %30 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, 2
  %31 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, 3, 0
  %32 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, 3, 1
  %33 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, 4, 0
  %34 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, 4, 1
  call void @forward(ptr %6, ptr %7, i64 %8, i64 %9, i64 %10, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, ptr %28, ptr %29, i64 %30, i64 %31, i64 %32, i64 %33, i64 %34)
  ret void
}

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_vpu_mul_chain_f32_19_37_inputs_19_37_axes_0_1__19_1_axes_0_1__37_axes_1_middle0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, ptr %19, ptr %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25) {
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, ptr %1, 1
  %30 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, i64 %2, 2
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %30, i64 %3, 3, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, i64 %5, 4, 0
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %4, 3, 1
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %6, 4, 1
  %35 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, ptr %35, align 8
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, ptr %8, 1
  %38 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, i64 %9, 2
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %38, i64 %10, 3, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, i64 %12, 4, 0
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %11, 3, 1
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %13, 4, 1
  %43 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, ptr %43, align 8
  %44 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %14, 0
  %45 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %44, ptr %15, 1
  %46 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %45, i64 %16, 2
  %47 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, i64 %17, 3, 0
  %48 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, i64 %18, 4, 0
  %49 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, ptr %49, align 8
  %50 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %19, 0
  %51 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %50, ptr %20, 1
  %52 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %51, i64 %21, 2
  %53 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %52, i64 %22, 3, 0
  %54 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %53, i64 %24, 4, 0
  %55 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %54, i64 %23, 3, 1
  %56 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %55, i64 %25, 4, 1
  %57 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %56, ptr %57, align 8
  call void @_mlir_ciface_mx_vpu_mul_chain_f32_19_37_inputs_19_37_axes_0_1__19_1_axes_0_1__37_axes_1_middle0(ptr %27, ptr %35, ptr %43, ptr %49, ptr %57)
  %58 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %27, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %58
}

declare void @_mlir_ciface_mx_vpu_mul_chain_f32_19_37_inputs_19_37_axes_0_1__19_1_axes_0_1__37_axes_1_middle0(ptr, ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [1 x i64], [1 x i64] } @mx_prepare_a_fp4_m19_k37_pm32_pk64(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %17, i64 %5, 4, 0
  %19 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %18, i64 %4, 3, 1
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, i64 %6, 4, 1
  %21 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %21, align 8
  %22 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %7, 0
  %23 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %22, ptr %8, 1
  %24 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %23, i64 %9, 2
  %25 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %24, i64 %10, 3, 0
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %25, i64 %11, 4, 0
  %27 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_prepare_a_fp4_m19_k37_pm32_pk64(ptr %13, ptr %21, ptr %27)
  %28 = load { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [1 x i64], [1 x i64] } %28
}

declare void @_mlir_ciface_mx_prepare_a_fp4_m19_k37_pm32_pk64(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_0_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_0_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_0_prepared(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_1_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_1_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_1_prepared(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_2_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_2_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_2_prepared(ptr, ptr, ptr)

define void @dealloc_helper(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24) {
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %27 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, ptr %6, 1
  %28 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %27, i64 %7, 2
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %28, i64 %8, 3, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, ptr %1, 1
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %2, 2
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %3, 3, 0
  %34 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 3
  %35 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %34, ptr %35, align 8
  %36 = getelementptr [1 x i64], ptr %35, i32 0, i32 0
  %37 = load i64, ptr %36, align 8
  %38 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, 3
  %39 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %38, ptr %39, align 8
  %40 = getelementptr [1 x i64], ptr %39, i32 0, i32 0
  %41 = load i64, ptr %40, align 8
  br label %42

42:                                               ; preds = %45, %25
  %43 = phi i64 [ %47, %45 ], [ 0, %25 ]
  %44 = icmp slt i64 %43, %41
  br i1 %44, label %45, label %48

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i1, ptr %21, i64 %43
  store i1 false, ptr %46, align 1
  %47 = add i64 %43, 1
  br label %42

48:                                               ; preds = %42
  br label %49

49:                                               ; preds = %84, %48
  %50 = phi i64 [ %87, %84 ], [ 0, %48 ]
  %51 = icmp slt i64 %50, %37
  br i1 %51, label %52, label %88

52:                                               ; preds = %49
  %53 = getelementptr inbounds nuw i64, ptr %1, i64 %50
  %54 = load i64, ptr %53, align 8
  %55 = getelementptr inbounds nuw i1, ptr %11, i64 %50
  %56 = load i1, ptr %55, align 1
  br label %57

57:                                               ; preds = %69, %52
  %58 = phi i64 [ %72, %69 ], [ 0, %52 ]
  %59 = phi i1 [ %71, %69 ], [ true, %52 ]
  %60 = icmp slt i64 %58, %41
  br i1 %60, label %61, label %73

61:                                               ; preds = %57
  %62 = getelementptr inbounds nuw i64, ptr %6, i64 %58
  %63 = load i64, ptr %62, align 8
  %64 = icmp eq i64 %63, %54
  br i1 %64, label %65, label %69

65:                                               ; preds = %61
  %66 = getelementptr inbounds nuw i1, ptr %21, i64 %58
  %67 = load i1, ptr %66, align 1
  %68 = or i1 %67, %56
  store i1 %68, ptr %66, align 1
  br label %69

69:                                               ; preds = %65, %61
  %70 = icmp ne i64 %63, %54
  %71 = and i1 %59, %70
  %72 = add i64 %58, 1
  br label %57

73:                                               ; preds = %57
  br label %74

74:                                               ; preds = %78, %73
  %75 = phi i64 [ %83, %78 ], [ 0, %73 ]
  %76 = phi i1 [ %82, %78 ], [ %59, %73 ]
  %77 = icmp slt i64 %75, %50
  br i1 %77, label %78, label %84

78:                                               ; preds = %74
  %79 = getelementptr inbounds nuw i64, ptr %1, i64 %75
  %80 = load i64, ptr %79, align 8
  %81 = icmp ne i64 %80, %54
  %82 = and i1 %76, %81
  %83 = add i64 %75, 1
  br label %74

84:                                               ; preds = %74
  %85 = and i1 %76, %56
  %86 = getelementptr inbounds nuw i1, ptr %16, i64 %50
  store i1 %85, ptr %86, align 1
  %87 = add i64 %50, 1
  br label %49

88:                                               ; preds = %49
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #0

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
