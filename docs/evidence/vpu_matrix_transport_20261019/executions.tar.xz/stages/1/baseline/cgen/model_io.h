/* Generated. Embedded runtime inputs. */
#ifndef MERLIN_MODEL_IO_H
#define MERLIN_MODEL_IO_H
#include <math.h>
#include <string.h>
static float merlin_in_4[] = {1.6098803281784058,1.3383569717407227,0.5895667672157288,1.3059152364730835,-1.3655122518539429,-0.4768339991569519,1.2708852291107178,-1.0914214849472046,1.6241992712020874,-0.013705763034522533,1.01625657081604,-1.6383823156356812,1.85966157913208,-0.9810473322868347,0.10260196775197983,-0.6798282861709595,-1.3933354616165161,-1.6121433973312378,0.7243394255638123,0.06944548338651657,1.0800124406814575,-0.5387327671051025,-2.6022918224334717,2.50187611579895,-0.521579921245575,-0.797866940498352,0.03303767368197441,-1.1093497276306152,0.08098263293504715,0.06550299376249313,-1.3928269147872925,-1.2964529991149902,1.7459124326705933,-0.3721848726272583,0.2715313732624054,0.30020105838775635,2.394916296005249};
static float merlin_in_5[] = {-0.11743059754371643};
static _Alignas(64) unsigned char merlin_out_0[324];
static void *MERLIN_INPUT_PTR[MERLIN_N_ARGS] = {0,(void*)merlin_in_4,(void*)merlin_in_5,0};
static void *MERLIN_OUTPUT_PTR[MERLIN_N_OUTPUTS] = {(void*)merlin_out_0};
static const int MERLIN_STATE_INPUT_ARGS[1] = {0};
static const int MERLIN_STATE_OUTPUT_INDICES[1] = {0};
static void merlin_reset_session(void) {
}
static void merlin_prepare_step(long step) {
  long s = step % MERLIN_SESSION_STEPS;
  (void)s;
}
typedef struct {
  long steps; double min_cos; double max_rel; long top1;
} merlin_trajectory_metrics_t;
static merlin_trajectory_metrics_t merlin_correctness_metrics = {0, 1.0, 0.0, 0};
static merlin_trajectory_metrics_t merlin_quality_metrics = {0, 1.0, 0.0, 0};
static void merlin_compare_trajectory(const float *got, const float *ref, long n,
                                      merlin_trajectory_metrics_t *metrics) {
  double dot = 0.0, gn = 0.0, rn = 0.0, rmax = 0.0, errmax = 0.0;
  long gi = 0, ri = 0;
  for (long i = 0; i < n; i++) {
    double g = got[i], r = ref[i], e = fabs(g - r);
    dot += g * r; gn += g * g; rn += r * r;
    if (fabs(r) > rmax) rmax = fabs(r); if (e > errmax) errmax = e;
    if (got[i] > got[gi]) gi = i; if (ref[i] > ref[ri]) ri = i;
  }
  double denom = sqrt(gn) * sqrt(rn);
  double cos = denom > 0.0 ? dot / denom : (gn == rn ? 1.0 : 0.0);
  double rel = rmax > 0.0 ? errmax / rmax : errmax;
  if (cos < metrics->min_cos) metrics->min_cos = cos;
  if (rel > metrics->max_rel) metrics->max_rel = rel;
  if (gi == ri) metrics->top1++; metrics->steps++;
}
static void merlin_validate_step(long step) {
  (void)step;
}
static long merlin_correctness_steps(void) { return merlin_correctness_metrics.steps; }
static long merlin_correctness_min_cos_ppm(void) {
  return (long)(merlin_correctness_metrics.min_cos * 1000000.0);
}
static long merlin_correctness_max_rel_ppm(void) {
  return (long)(merlin_correctness_metrics.max_rel * 1000000.0);
}
static long merlin_correctness_top1(void) { return merlin_correctness_metrics.top1; }
static long merlin_quality_steps(void) { return merlin_quality_metrics.steps; }
static long merlin_quality_min_cos_ppm(void) {
  return (long)(merlin_quality_metrics.min_cos * 1000000.0);
}
static long merlin_quality_max_rel_ppm(void) {
  return (long)(merlin_quality_metrics.max_rel * 1000000.0);
}
static long merlin_quality_top1(void) { return merlin_quality_metrics.top1; }
#endif
