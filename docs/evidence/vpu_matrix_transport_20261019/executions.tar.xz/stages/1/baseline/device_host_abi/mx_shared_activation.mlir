builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/reverse_projection_1_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<41x37xf32>, %2: tensor<17x37xf32>, %3: tensor<37xf32>, %4: tensor<1x37xf32>, %5: tensor<1x1xf32>) -> tensor<1x81xf32> {
    %6 = tensor.empty() : tensor<1x37xf32>
    %7 = tensor.empty() : tensor<1x37xf32>
    %8 = tensor.empty() : tensor<1x37xf32>
    %9 = func.call @mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0(%4, %5, %3, %8) : (tensor<1x37xf32>, tensor<1x1xf32>, tensor<37xf32>, tensor<1x37xf32>) -> tensor<1x37xf32>
    %10 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %11 = tensor.splat %10 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : tensor<1x23xf32>
    %12 = tensor.empty() : tensor<37x23xf32>
    %13 = tensor.empty() : tensor<1056xi8>
    %14 = func.call @mx_prepare_a_fp8_m1_k37_pm16_pk64(%9, %13) : (tensor<1x37xf32>, tensor<1056xi8>) -> tensor<1056xi8>
    %15 = func.call @mx_dense_kernel_0_prepared(%14, %11) : (tensor<1056xi8>, tensor<1x23xf32>) -> tensor<1x23xf32>
    %16 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %17 = tensor.splat %16 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : tensor<1x41xf32>
    %18 = tensor.empty() : tensor<37x41xf32>
    %19 = func.call @mx_dense_kernel_1_prepared(%14, %17) : (tensor<1056xi8>, tensor<1x41xf32>) -> tensor<1x41xf32>
    %20 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %21 = tensor.splat %20 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : tensor<1x17xf32>
    %22 = tensor.empty() : tensor<37x17xf32>
    %23 = func.call @mx_dense_kernel_2_prepared(%14, %21) : (tensor<1056xi8>, tensor<1x17xf32>) -> tensor<1x17xf32>
    %24 = tensor.concat dim(1) %15, %19, %23 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x23xf32>, tensor<1x41xf32>, tensor<1x17xf32>) -> tensor<1x81xf32>
    func.return %24 : tensor<1x81xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x37xf32>, tensor<37x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<1x37xf32>, tensor<37x41xf32>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<1x37xf32>, tensor<37x17xf32>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0", function_type = (tensor<1x37xf32>, tensor<1x1xf32>, tensor<37xf32>, tensor<1x37xf32>) -> tensor<1x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m1_k37_pm16_pk64", function_type = (tensor<1x37xf32>, tensor<1056xi8>) -> tensor<1056xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<1056xi8>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<1056xi8>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<1056xi8>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}