builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/reverse_projection_1_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<41x37xf32>, %2: tensor<17x37xf32>, %3: tensor<37xf32>, %4: tensor<1x37xf32>, %5: tensor<1x1xf32>) -> tensor<1x81xf32> {
    %6 = tensor.empty() : tensor<1x37xf32>
    %7 = tensor.empty() : tensor<1x37xf32>
    %8 = tensor.empty() : tensor<1x37xf32>
    %9 = func.call @mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0(%4, %5, %3, %8) : (tensor<1x37xf32>, tensor<1x1xf32>, tensor<37xf32>, tensor<1x37xf32>) -> tensor<1x37xf32>
    %10 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %11 = tensor.splat %10 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : tensor<1x23xf32>
    %12 = tensor.empty() : tensor<37x23xf32>
    %13 = func.call @merlin_dev_mx_gemmini_0(%9, %12, %11) : (tensor<1x37xf32>, tensor<37x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>
    %14 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %15 = tensor.splat %14 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : tensor<1x41xf32>
    %16 = tensor.empty() : tensor<37x41xf32>
    %17 = func.call @merlin_dev_mx_gemmini_1(%9, %16, %15) : (tensor<1x37xf32>, tensor<37x41xf32>, tensor<1x41xf32>) -> tensor<1x41xf32>
    %18 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %19 = tensor.splat %18 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : tensor<1x17xf32>
    %20 = tensor.empty() : tensor<37x17xf32>
    %21 = func.call @merlin_dev_mx_gemmini_2(%9, %20, %19) : (tensor<1x37xf32>, tensor<37x17xf32>, tensor<1x17xf32>) -> tensor<1x17xf32>
    %22 = tensor.concat dim(1) %13, %17, %21 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x23xf32>, tensor<1x41xf32>, tensor<1x17xf32>) -> tensor<1x81xf32>
    func.return %22 : tensor<1x81xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x37xf32>, tensor<37x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<1x37xf32>, tensor<37x41xf32>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<1x37xf32>, tensor<37x17xf32>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0", function_type = (tensor<1x37xf32>, tensor<1x1xf32>, tensor<37xf32>, tensor<1x37xf32>) -> tensor<1x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}