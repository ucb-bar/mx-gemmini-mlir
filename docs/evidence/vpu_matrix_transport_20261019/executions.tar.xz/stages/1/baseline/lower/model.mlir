"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<37xf32>, tensor<1x37xf32>, tensor<1x1xf32>) -> tensor<1x81xf32>}> ({
  ^bb0(%0: tensor<37xf32>, %1: tensor<1x37xf32>, %2: tensor<1x1xf32>):
    %3 = "tensor.empty"() : () -> tensor<1x37xf32>
    %4 = "func.call"(%1, %2, %0, %3) <{callee = @mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0}> : (tensor<1x37xf32>, tensor<1x1xf32>, tensor<37xf32>, tensor<1x37xf32>) -> tensor<1x37xf32>
    %5 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : () -> f32
    %6 = "tensor.splat"(%5) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : (f32) -> tensor<1x23xf32>
    %7 = "tensor.empty"() : () -> tensor<1056xi8>
    %8 = "func.call"(%4, %7) <{callee = @mx_prepare_a_fp8_m1_k37_pm16_pk64}> : (tensor<1x37xf32>, tensor<1056xi8>) -> tensor<1056xi8>
    %9 = "func.call"(%8, %6) <{callee = @mx_dense_kernel_0_prepared}> : (tensor<1056xi8>, tensor<1x23xf32>) -> tensor<1x23xf32>
    %10 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : () -> f32
    %11 = "tensor.splat"(%10) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : (f32) -> tensor<1x41xf32>
    %12 = "func.call"(%8, %11) <{callee = @mx_dense_kernel_1_prepared}> : (tensor<1056xi8>, tensor<1x41xf32>) -> tensor<1x41xf32>
    %13 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : () -> f32
    %14 = "tensor.splat"(%13) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : (f32) -> tensor<1x17xf32>
    %15 = "func.call"(%8, %14) <{callee = @mx_dense_kernel_2_prepared}> : (tensor<1056xi8>, tensor<1x17xf32>) -> tensor<1x17xf32>
    %16 = "tensor.concat"(%9, %12, %15) <{dim = 1 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x23xf32>, tensor<1x41xf32>, tensor<1x17xf32>) -> tensor<1x81xf32>
    "func.return"(%16) : (tensor<1x81xf32>) -> ()
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x37xf32>, tensor<37x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<1x37xf32>, tensor<37x41xf32>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<1x37xf32>, tensor<37x17xf32>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0", function_type = (tensor<1x37xf32>, tensor<1x1xf32>, tensor<37xf32>, tensor<1x37xf32>) -> tensor<1x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m1_k37_pm16_pk64", function_type = (tensor<1x37xf32>, tensor<1056xi8>) -> tensor<1056xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<1056xi8>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<1056xi8>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<1056xi8>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/reverse_projection_1_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()