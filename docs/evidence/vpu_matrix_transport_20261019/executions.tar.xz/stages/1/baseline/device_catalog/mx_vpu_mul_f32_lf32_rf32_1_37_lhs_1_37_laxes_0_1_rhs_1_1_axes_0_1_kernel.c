#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_issue_37(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0005001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0005001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000160004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0005001000002000)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_a[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_b[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_c[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 37; base += 37) {
    uint32_t count = 37 - base;
    if (count > 37) count = 37;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_a[index] = mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_b[index] = 0;
        continue;
      }
      uint32_t word = mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_narrow(lhs[(base + index)]);
      
      mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_a[index] = (uint16_t)word;
      mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_b[index] = mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_narrow(rhs[0u]);
      
    }
    const void *a = mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_a, *b = mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_b, *c = mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_c;
    switch (count) {
    case 37: mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_issue_37(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_widen(mx_vpu_mul_f32_lf32_rf32_1_37_lhs_1_37_laxes_0_1_rhs_1_1_axes_0_1_kernel_c[index]);
  }
}
