#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_issue_37(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0005001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0005001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000160004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0005001000002000)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_a[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_b[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_c[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 37; base += 37) {
    uint32_t count = 37 - base;
    if (count > 37) count = 37;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_a[index] = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_b[index] = 0;
        continue;
      }
      uint32_t word = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_narrow(lhs[(base + index)]);
      
      mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_a[index] = (uint16_t)word;
      mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_b[index] = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_narrow(rhs[0u]);
      
    }
    const void *a = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_a, *b = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_b, *c = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_c;
    switch (count) {
    case 37: mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_issue_37(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_widen(mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0_c[index]);
  }
}

#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_issue_37(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0005001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0005001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000160004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0005001000002000)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_a[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_b[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_c[40] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1(const float *lhs, const float *rhs, uint16_t *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 37; base += 37) {
    uint32_t count = 37 - base;
    if (count > 37) count = 37;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_a[index] = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_b[index] = 0;
        continue;
      }
      uint32_t word = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_narrow(lhs[(base + index)]);
      
      mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_a[index] = (uint16_t)word;
      mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_b[index] = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_narrow(rhs[(((base + index) % 37u) * 1u)]);
      
    }
    const void *a = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_a, *b = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_b, *c = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_c;
    switch (count) {
    case 37: mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_issue_37(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1_c[index];
  }
}

void mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_materialized(const float *a, const float *b, const float *c,
            float *middle, uint16_t *output) {
          mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul0(a,b,middle); mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_mul1(middle,c,output);
        }
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void chain_issue_37(const void *a, const void *b, const void *c, const void *m, const void *o) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)a + UINT64_C(0))), "r"(UINT64_C(0x0005001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)b + UINT64_C(0))), "r"(UINT64_C(0x0005001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000160004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)c + UINT64_C(0))), "r"(UINT64_C(0x0005001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000140004002000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)o + UINT64_C(0))), "r"(UINT64_C(0x0005001000000000)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}
#include <stddef.h>
static uint16_t prepared_b[1] __attribute__((aligned(64)));

        static uint16_t aa[40] __attribute__((aligned(64)));
        static uint16_t bb[40] __attribute__((aligned(64)));
        static uint16_t cc[40] __attribute__((aligned(64)));
        static uint16_t rr[40] __attribute__((aligned(64)));
        static uint16_t chain_pack(float x, unsigned *safe) {
          union {float f; uint32_t u;} word; word.f=x;
          *safe &= (word.u & 0x7fffffffu) <= 1577058304u;
          word.u+=0x7fffu+((word.u>>16)&1u); return word.u>>16;
        }
        void mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_run(const float *a,const float *b,const float *c,float *middle,uint16_t *output) {
          if(!a || !b || !c || !middle || !output) __builtin_trap();
          unsigned prepared_safe=1;
for (size_t prepared_index = 0; prepared_index < 1u; ++prepared_index)
  prepared_b[prepared_index] = chain_pack(b[prepared_index], &prepared_safe);
if(!prepared_safe) { mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_materialized(a,b,c,middle,output); return; }
          for(uint32_t base=0;base<37;base+=37) {
            uint32_t count=37-base;
            if(count>37) count=37;
            unsigned safe=1;
            for(uint32_t i=0;i<(count+7u)/8u*8u;++i) {
              aa[i]=i<count ? chain_pack(a[base+i],&safe) : 0;
              bb[i]=i<count ? prepared_b[0u] : 0;
              cc[i]=i<count ? chain_pack(c[(((base + i) % 37u) * 1u)],&safe) : 0;
            }
            if(!safe) { mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_materialized(a,b,c,middle,output); return; }
            switch(count) { case 37: chain_issue_37(aa,bb,cc,rr,rr); break; default: __builtin_trap(); }
            for(uint32_t i=0;i<count;++i) {
              output[base+i]=rr[i];
            }
          }
        }

void mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel(const float *a, const float *b, const float *c, uint16_t *o) {
      static float middle[37] __attribute__((aligned(64)));
      mx_vpu_mul_chain_f32_1_37_inputs_1_37_axes_0_1__1_1_axes_0_1__37_axes_1_middle0_bf16_output_kernel_run(a,b,c,middle,o);
    }
