#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"
static uint16_t padded[1024] __attribute__((aligned(64)));

void mx_prepare_a_fp8_m1_k37_pm16_pk64_bf16_input_kernel(const uint16_t *lhs, uint8_t *out) {
  if (!lhs || !out) __builtin_trap();
  for (size_t i = 0; i < 1024u; ++i) padded[i] = 0;
  for (size_t row = 0; row < 1u; ++row)
    for (size_t col = 0; col < 37u; ++col)
      padded[row * 64u + col] = lhs[row * 37u + col];
  if (mx_pack_activation_bf16(padded, 16u, 64u,
      MX_RUNTIME_FP8, out, out+1024u)) __builtin_trap();
}
