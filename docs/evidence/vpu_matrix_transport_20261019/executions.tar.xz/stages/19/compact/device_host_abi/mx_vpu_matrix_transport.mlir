builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/reverse_projection_19_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<41x37xf32>, %2: tensor<17x37xf32>, %3: tensor<37xf32>, %4: tensor<19x37xf32>, %5: tensor<19x1xf32>) -> tensor<19x81xf32> {
    %6 = tensor.empty() : tensor<19x37xf32>
    %7 = tensor.empty() : tensor<19x37xf32>
    %8 = tensor.empty() : tensor<19x37xf32>
    %9 = tensor.empty() : tensor<19x37xbf16>
    %10 = func.call @mx_vpu_mul_chain_f32_19_37_inputs_19_37_axes_0_1__19_1_axes_0_1__37_axes_1_middle0_bf16_output(%4, %5, %3, %9) : (tensor<19x37xf32>, tensor<19x1xf32>, tensor<37xf32>, tensor<19x37xbf16>) -> tensor<19x37xbf16>
    %11 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %12 = tensor.splat %11 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : tensor<19x23xf32>
    %13 = tensor.empty() : tensor<37x23xf32>
    %14 = tensor.empty() : tensor<2112xi8>
    %15 = func.call @mx_prepare_a_fp8_m19_k37_pm32_pk64_bf16_input(%10, %14) : (tensor<19x37xbf16>, tensor<2112xi8>) -> tensor<2112xi8>
    %16 = func.call @mx_dense_kernel_0_prepared(%15, %12) : (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %17 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %18 = tensor.splat %17 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : tensor<19x41xf32>
    %19 = tensor.empty() : tensor<37x41xf32>
    %20 = func.call @mx_dense_kernel_1_prepared(%15, %18) : (tensor<2112xi8>, tensor<19x41xf32>) -> tensor<19x41xf32>
    %21 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %22 = tensor.splat %21 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : tensor<19x17xf32>
    %23 = tensor.empty() : tensor<37x17xf32>
    %24 = func.call @mx_dense_kernel_2_prepared(%15, %22) : (tensor<2112xi8>, tensor<19x17xf32>) -> tensor<19x17xf32>
    %25 = tensor.concat dim(1) %16, %20, %24 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<19x23xf32>, tensor<19x41xf32>, tensor<19x17xf32>) -> tensor<19x81xf32>
    func.return %25 : tensor<19x81xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x41xf32>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<19x37xf32>, tensor<37x17xf32>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_19_37_inputs_19_37_axes_0_1__19_1_axes_0_1__37_axes_1_middle0", function_type = (tensor<19x37xf32>, tensor<19x1xf32>, tensor<37xf32>, tensor<19x37xf32>) -> tensor<19x37xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m19_k37_pm32_pk64", function_type = (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<2112xi8>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<2112xi8>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_vpu_mul_chain_f32_19_37_inputs_19_37_axes_0_1__19_1_axes_0_1__37_axes_1_middle0_bf16_output", function_type = (tensor<19x37xf32>, tensor<19x1xf32>, tensor<37xf32>, tensor<19x37xbf16>) -> tensor<19x37xbf16>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m19_k37_pm32_pk64_bf16_input", function_type = (tensor<19x37xbf16>, tensor<2112xi8>) -> tensor<2112xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}