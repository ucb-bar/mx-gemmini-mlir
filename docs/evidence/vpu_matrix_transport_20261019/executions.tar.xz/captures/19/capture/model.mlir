builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/reverse_projection_19_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xf32>, %1: tensor<41x37xf32>, %2: tensor<17x37xf32>, %3: tensor<37xf32>, %4: tensor<19x37xf32>, %5: tensor<19x1xf32>) -> tensor<19x81xf32> {
    %6 = tensor.empty() : tensor<19x37xf32>
    %7 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%4, %5 : tensor<19x37xf32>, tensor<19x1xf32>) outs(%6 : tensor<19x37xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb0(%8: f32, %9: f32, %10: f32):
      %11 = arith.mulf %8, %9 : f32
      linalg.yield %11 : f32
    } -> tensor<19x37xf32>
    %12 = tensor.empty() : tensor<19x37xf32>
    %13 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%7, %3 : tensor<19x37xf32>, tensor<37xf32>) outs(%12 : tensor<19x37xf32>) attrs =  {prov.region_id = "mul_1", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb1(%14: f32, %15: f32, %16: f32):
      %17 = arith.mulf %14, %15 : f32
      linalg.yield %17 : f32
    } -> tensor<19x37xf32>
    %18 = tensor.empty() : tensor<37x23xf32>
    %19 = linalg.transpose ins(%0:tensor<23x37xf32>) outs(%18:tensor<37x23xf32>) permutation = [1, 0]
    %20 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %21 = tensor.splat %20 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : tensor<19x23xf32>
    %22 = linalg.matmul {prov.region_id = "matmul_0", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0", prov.transposed_b = "true"} ins(%13, %19 : tensor<19x37xf32>, tensor<37x23xf32>) outs(%21 : tensor<19x23xf32>) -> tensor<19x23xf32>
    %23 = tensor.empty() : tensor<37x41xf32>
    %24 = linalg.transpose ins(%1:tensor<41x37xf32>) outs(%23:tensor<37x41xf32>) permutation = [1, 0]
    %25 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %26 = tensor.splat %25 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : tensor<19x41xf32>
    %27 = linalg.matmul {prov.region_id = "matmul_1", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1", prov.transposed_b = "true"} ins(%13, %24 : tensor<19x37xf32>, tensor<37x41xf32>) outs(%26 : tensor<19x41xf32>) -> tensor<19x41xf32>
    %28 = tensor.empty() : tensor<37x17xf32>
    %29 = linalg.transpose ins(%2:tensor<17x37xf32>) outs(%28:tensor<37x17xf32>) permutation = [1, 0]
    %30 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %31 = tensor.splat %30 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : tensor<19x17xf32>
    %32 = linalg.matmul {prov.region_id = "matmul_2", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2", prov.transposed_b = "true"} ins(%13, %29 : tensor<19x37xf32>, tensor<37x17xf32>) outs(%31 : tensor<19x17xf32>) -> tensor<19x17xf32>
    %33 = tensor.concat dim(1) %22, %27, %32 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<19x23xf32>, tensor<19x41xf32>, tensor<19x17xf32>) -> tensor<19x81xf32>
    func.return %33 : tensor<19x81xf32>
  }
}