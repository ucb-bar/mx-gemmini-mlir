#include <stddef.h>
#include <stdint.h>
static inline int mx_prepare_group_words(const float *merlin_group_input, size_t merlin_group_stride, uint16_t *merlin_group_words, uint16_t *merlin_group_maximum) {
  uint16_t merlin_group_largest = 0;
  for (size_t merlin_group_offset = 0; merlin_group_offset < 32u; ++merlin_group_offset) {
    uint16_t merlin_group_word;
    if (mx_round_group_word(merlin_group_input[merlin_group_offset * merlin_group_stride], &merlin_group_word)) return -1;
    merlin_group_words[merlin_group_offset] = merlin_group_word;
    uint16_t merlin_group_key = mx_group_word_magnitude(merlin_group_word);
    if (merlin_group_key > merlin_group_largest) merlin_group_largest = merlin_group_key;
  }
  *merlin_group_maximum = merlin_group_largest;
  return 0;
}
#if defined(MX_QUANT_BF16_INPUT)
#include <stddef.h>
#include <stdint.h>
static inline int mx_prepare_bf16_group_words(const uint16_t *merlin_group_input, size_t merlin_group_stride, uint16_t *merlin_group_words, uint16_t *merlin_group_maximum) {
  uint16_t merlin_group_largest = 0;
  for (size_t merlin_group_offset = 0; merlin_group_offset < 32u; ++merlin_group_offset) {
    uint16_t merlin_group_word;
    if (mx_copy_group_word(merlin_group_input[merlin_group_offset * merlin_group_stride], &merlin_group_word)) return -1;
    merlin_group_words[merlin_group_offset] = merlin_group_word;
    uint16_t merlin_group_key = mx_group_word_magnitude(merlin_group_word);
    if (merlin_group_key > merlin_group_largest) merlin_group_largest = merlin_group_key;
  }
  *merlin_group_maximum = merlin_group_largest;
  return 0;
}
#endif
