#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "runtime_quant.h"
extern const unsigned char payload[];
static uint8_t codes[327808] __attribute__((aligned(64)));
static uint8_t scales[10368] __attribute__((aligned(64)));
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
int main(void) {
  const float *wide=(const float *)payload;
  const uint16_t *compact=(const uint16_t *)(payload+1310720);
  const uint8_t *expected=payload+1966080;
  for(unsigned run=0;run<3;++run) for(unsigned order=0;order<2;++order) {
    unsigned variant=order^(run&1u)^0u;
    memset(codes,0xa5,sizeof(codes));memset(scales,0xa5,sizeof(scales));
    uint64_t begin=cycle();
    int status=variant ? mx_pack_activation_bf16(compact,160,2048,8,codes+64,scales+64)
                       : mx_pack_activation_f32(wide,160,2048,8,codes+64,scales+64);
    uint64_t elapsed=cycle()-begin;
    unsigned mismatch=0,guard=0;uint32_t hash=2166136261u;
    for(unsigned i=0;i<327680;++i){mismatch+=codes[i+64]!=expected[i];hash=(hash^codes[i+64])*16777619u;}
    for(unsigned i=0;i<10240;++i){mismatch+=scales[i+64]!=expected[327680+i];hash=(hash^scales[i+64])*16777619u;}
    for(unsigned i=0;i<64;++i)guard+=codes[i]!=0xa5 || codes[327680+64+i]!=0xa5 ||
      scales[i]!=0xa5 || scales[10240+64+i]!=0xa5;
    printf("PACK run=%u variant=%u status=%d cycles=%lu mismatch=%u guard=%u hash=%u\n",
           run,variant,status,elapsed,mismatch,guard,hash);
    if(status!=0 || mismatch || guard)return 3;
  }
  printf("DONE\n");return 0;
}
