builtin.module {
      func.func @forward(%a: tensor<1x32x288xf32>, %b: tensor<1x32x1xf32>, %c: tensor<288xf32>) -> tensor<1x32x288xf32> {
        
          %e0 = "tensor.empty"() : () -> tensor<1x32x288xf32>
          %m = "linalg.generic"(%a, %b, %e0)
            <{indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, 0)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>],
              iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>,
                                #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
            ^bb0(%x: f32, %y: f32, %init: f32):
              %v = "arith.mulf"(%x, %y) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
              "linalg.yield"(%v) : (f32) -> ()
          }) {prov.region_id = "mul_0", prov.op = "mul", prov.aten = "aten.mul.Tensor"} :
            (tensor<1x32x288xf32>, tensor<1x32x1xf32>, tensor<1x32x288xf32>) -> tensor<1x32x288xf32>
        
          %e1 = "tensor.empty"() : () -> tensor<1x32x288xf32>
          %o = "linalg.generic"(%c, %m, %e1)
            <{indexing_maps = [affine_map<(d0, d1, d2) -> (d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1, d2)>],
              iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>,
                                #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
            ^bb0(%x: f32, %y: f32, %init: f32):
              %v = "arith.mulf"(%x, %y) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
              "linalg.yield"(%v) : (f32) -> ()
          }) {prov.region_id = "mul_1", prov.op = "mul", prov.aten = "aten.mul.Tensor"} :
            (tensor<288xf32>, tensor<1x32x288xf32>, tensor<1x32x288xf32>) -> tensor<1x32x288xf32>
        
        func.return %o : tensor<1x32x288xf32>
      }
    }