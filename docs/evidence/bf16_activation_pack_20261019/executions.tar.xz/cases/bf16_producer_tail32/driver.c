#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "runtime_quant.h"
extern const unsigned char payload[];

void pack_producer_f32(const float *,const float *,const float *,float *);
void pack_producer_bf16(const float *,const float *,const float *,uint16_t *);
static float wide_storage[9248] __attribute__((aligned(64)));
static uint16_t compact_storage[9280] __attribute__((aligned(64)));

static uint8_t codes[4736] __attribute__((aligned(64)));
static uint8_t scales[416] __attribute__((aligned(64)));
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
int main(void) {
  float *wide=wide_storage+16; uint16_t *compact=compact_storage+32;
  const float *a=(const float *)payload,*b=a+9216,*c=b+32;
  const uint16_t *golden=(const uint16_t *)(payload+75008);
  const uint8_t *expected=payload+93440;
  for(unsigned run=0;run<3;++run) for(unsigned order=0;order<2;++order) {
    unsigned variant=order^(run&1u)^0u;
    memset(codes,0xa5,sizeof(codes));memset(scales,0xa5,sizeof(scales));
    memset(wide_storage,0xa5,sizeof(wide_storage));memset(compact_storage,0xa5,sizeof(compact_storage));
    uint64_t begin=cycle();
    if(variant)pack_producer_bf16(a,b,c,compact);else pack_producer_f32(a,b,c,wide);
    int status=variant ? mx_pack_activation_bf16(compact,32,288,4,codes+64,scales+64)
                       : mx_pack_activation_f32(wide,32,288,4,codes+64,scales+64);
    uint64_t elapsed=cycle()-begin;
    unsigned mismatch=0,guard=0;uint32_t hash=2166136261u;
    
    for(unsigned i=0;i<9216;++i) {
      union {float f;uint32_t u;} word;word.f=wide[i];
      mismatch+=variant ? compact[i]!=golden[i] : word.u!=((uint32_t)golden[i]<<16);
    }
    const uint8_t *storage=variant ? (const uint8_t *)compact_storage : (const uint8_t *)wide_storage;
    unsigned output_bytes=variant ? 18432u : 36864u;
    for(unsigned i=0;i<64;++i)guard+=storage[i]!=0xa5 || storage[64+output_bytes+i]!=0xa5;

    for(unsigned i=0;i<4608;++i){mismatch+=codes[i+64]!=expected[i];hash=(hash^codes[i+64])*16777619u;}
    for(unsigned i=0;i<288;++i){mismatch+=scales[i+64]!=expected[4608+i];hash=(hash^scales[i+64])*16777619u;}
    for(unsigned i=0;i<64;++i)guard+=codes[i]!=0xa5 || codes[4608+64+i]!=0xa5 ||
      scales[i]!=0xa5 || scales[288+64+i]!=0xa5;
    printf("PACK run=%u variant=%u status=%d cycles=%lu mismatch=%u guard=%u hash=%u\n",
           run,variant,status,elapsed,mismatch,guard,hash);
    if(status!=0 || mismatch || guard)return 3;
  }
  printf("DONE\n");return 0;
}
