"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<160x2048xf32>) -> tensor<160x2560xf32>}> ({
  ^bb0(%0: tensor<160x2048xf32>):
    %1 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : () -> f32
    %2 = "tensor.splat"(%1) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : (f32) -> tensor<160x2048xf32>
    %3 = "tensor.empty"() : () -> tensor<2048x2048xf32>
    %4 = "tensor.empty"() : () -> tensor<337920xi8>
    %5 = "func.call"(%0, %4) <{callee = @mx_prepare_a_fp8_m160_k2048_pm160_pk2048}> : (tensor<160x2048xf32>, tensor<337920xi8>) -> tensor<337920xi8>
    %6 = "func.call"(%5, %3, %2) <{callee = @mx_dense_kernel_0_prepared}> : (tensor<337920xi8>, tensor<2048x2048xf32>, tensor<160x2048xf32>) -> tensor<160x2048xf32>
    %7 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : () -> f32
    %8 = "tensor.splat"(%7) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : (f32) -> tensor<160x256xf32>
    %9 = "tensor.empty"() : () -> tensor<2048x256xf32>
    %10 = "func.call"(%5, %9, %8) <{callee = @mx_dense_kernel_1_prepared}> : (tensor<337920xi8>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>
    %11 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : () -> f32
    %12 = "tensor.splat"(%11) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : (f32) -> tensor<160x256xf32>
    %13 = "tensor.empty"() : () -> tensor<2048x256xf32>
    %14 = "func.call"(%5, %13, %12) <{callee = @mx_dense_kernel_2_prepared}> : (tensor<337920xi8>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>
    %15 = "tensor.concat"(%6, %10, %14) <{dim = 1 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<160x2048xf32>, tensor<160x256xf32>, tensor<160x256xf32>) -> tensor<160x2560xf32>
    "func.return"(%15) : (tensor<160x2560xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<160x2048xf32>, tensor<2048x2048xf32>, tensor<160x2048xf32>) -> tensor<160x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<160x2048xf32>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<160x2048xf32>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m160_k2048_pm160_pk2048", function_type = (tensor<160x2048xf32>, tensor<337920xi8>) -> tensor<337920xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<337920xi8>, tensor<2048x2048xf32>, tensor<160x2048xf32>) -> tensor<160x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<337920xi8>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<337920xi8>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_tiny_qkv160/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()