unsigned char mx_catalog_workspace[995328] __attribute__((aligned(64)));
