builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_tiny_qkv160/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<2048x2048xf32>, %1: tensor<256x2048xf32>, %2: tensor<256x2048xf32>, %3: tensor<160x2048xf32>) -> tensor<160x2560xf32> {
    %4 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %5 = tensor.splat %4 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : tensor<160x2048xf32>
    %6 = tensor.empty() : tensor<2048x2048xf32>
    %7 = tensor.empty() : tensor<337920xi8>
    %8 = func.call @mx_prepare_a_fp8_m160_k2048_pm160_pk2048(%3, %7) : (tensor<160x2048xf32>, tensor<337920xi8>) -> tensor<337920xi8>
    %9 = func.call @mx_dense_kernel_0_prepared(%8, %5) : (tensor<337920xi8>, tensor<160x2048xf32>) -> tensor<160x2048xf32>
    %10 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %11 = tensor.splat %10 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : tensor<160x256xf32>
    %12 = tensor.empty() : tensor<2048x256xf32>
    %13 = func.call @mx_dense_kernel_1_prepared(%8, %11) : (tensor<337920xi8>, tensor<160x256xf32>) -> tensor<160x256xf32>
    %14 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %15 = tensor.splat %14 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : tensor<160x256xf32>
    %16 = tensor.empty() : tensor<2048x256xf32>
    %17 = func.call @mx_dense_kernel_2_prepared(%8, %15) : (tensor<337920xi8>, tensor<160x256xf32>) -> tensor<160x256xf32>
    %18 = tensor.concat dim(1) %9, %13, %17 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<160x2048xf32>, tensor<160x256xf32>, tensor<160x256xf32>) -> tensor<160x2560xf32>
    func.return %18 : tensor<160x2560xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<160x2048xf32>, tensor<2048x2048xf32>, tensor<160x2048xf32>) -> tensor<160x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<160x2048xf32>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<160x2048xf32>, tensor<2048x256xf32>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m160_k2048_pm160_pk2048", function_type = (tensor<160x2048xf32>, tensor<337920xi8>) -> tensor<337920xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<337920xi8>, tensor<160x2048xf32>) -> tensor<160x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<337920xi8>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<337920xi8>, tensor<160x256xf32>) -> tensor<160x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}