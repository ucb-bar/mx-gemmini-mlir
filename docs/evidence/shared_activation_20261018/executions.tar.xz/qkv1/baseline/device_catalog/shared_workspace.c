unsigned char mx_catalog_workspace[232448] __attribute__((aligned(64)));
