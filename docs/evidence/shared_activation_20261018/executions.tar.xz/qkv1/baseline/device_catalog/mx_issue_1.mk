kernel mx_issue_1_schedule(activation: i8[32768] read, activation_scales: i8[1024] read, weight: i8[524288] read, weight_scales: i8[16384] read, output_bf16: i16[4096] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=16, nc=256, kt=256}
  configure()
  for row in 0..1:
    for chunk in 0..1:
      for wave in 0..8:
        native_loop(a=&activation[((row * 32768) + (wave * 256))], b=&weight[((wave * 65536) + (chunk * 256))], c=&output_bf16[((row * 8192) + (chunk * 512))], asc=&activation_scales[((wave * 128) + (row * 16))], bsc=&weight_scales[((wave * 2048) + (chunk * 256))], write=select(wave == 7, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 8) + (chunk * 8) + wave), 2) + 1))
