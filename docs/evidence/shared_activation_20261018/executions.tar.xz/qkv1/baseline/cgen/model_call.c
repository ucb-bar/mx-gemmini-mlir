/* Generated. */
extern void _mlir_ciface_forward(void*,void*);
void merlin_invoke(void **d) { _mlir_ciface_forward(d[0],d[1]); }
