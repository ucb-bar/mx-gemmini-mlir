"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<1x2048xf32>) -> tensor<1x2560xf32>}> ({
  ^bb0(%0: tensor<1x2048xf32>):
    %1 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : () -> f32
    %2 = "tensor.splat"(%1) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : (f32) -> tensor<1x2048xf32>
    %3 = "tensor.empty"() : () -> tensor<2048x2048xf32>
    %4 = "func.call"(%0, %3, %2) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<1x2048xf32>, tensor<2048x2048xf32>, tensor<1x2048xf32>) -> tensor<1x2048xf32>
    %5 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : () -> f32
    %6 = "tensor.splat"(%5) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : (f32) -> tensor<1x256xf32>
    %7 = "tensor.empty"() : () -> tensor<2048x256xf32>
    %8 = "func.call"(%0, %7, %6) <{callee = @merlin_dev_mx_gemmini_1}> : (tensor<1x2048xf32>, tensor<2048x256xf32>, tensor<1x256xf32>) -> tensor<1x256xf32>
    %9 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : () -> f32
    %10 = "tensor.splat"(%9) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : (f32) -> tensor<1x256xf32>
    %11 = "tensor.empty"() : () -> tensor<2048x256xf32>
    %12 = "func.call"(%0, %11, %10) <{callee = @merlin_dev_mx_gemmini_2}> : (tensor<1x2048xf32>, tensor<2048x256xf32>, tensor<1x256xf32>) -> tensor<1x256xf32>
    %13 = "tensor.concat"(%4, %8, %12) <{dim = 1 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x2048xf32>, tensor<1x256xf32>, tensor<1x256xf32>) -> tensor<1x2560xf32>
    "func.return"(%13) : (tensor<1x2560xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x2048xf32>, tensor<2048x2048xf32>, tensor<1x2048xf32>) -> tensor<1x2048xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<1x2048xf32>, tensor<2048x256xf32>, tensor<1x256xf32>) -> tensor<1x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<1x2048xf32>, tensor<2048x256xf32>, tensor<1x256xf32>) -> tensor<1x256xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_tiny_qkv1/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()