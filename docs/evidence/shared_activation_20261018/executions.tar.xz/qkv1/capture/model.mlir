builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_tiny_qkv1/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<2048x2048xf32>, %1: tensor<256x2048xf32>, %2: tensor<256x2048xf32>, %3: tensor<1x2048xf32>) -> tensor<1x2560xf32> {
    %4 = tensor.empty() : tensor<2048x2048xf32>
    %5 = linalg.transpose ins(%0:tensor<2048x2048xf32>) outs(%4:tensor<2048x2048xf32>) permutation = [1, 0]
    %6 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %7 = tensor.splat %6 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : tensor<1x2048xf32>
    %8 = linalg.matmul {prov.region_id = "matmul_0", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0", prov.transposed_b = "true"} ins(%3, %5 : tensor<1x2048xf32>, tensor<2048x2048xf32>) outs(%7 : tensor<1x2048xf32>) -> tensor<1x2048xf32>
    %9 = tensor.empty() : tensor<2048x256xf32>
    %10 = linalg.transpose ins(%1:tensor<256x2048xf32>) outs(%9:tensor<2048x256xf32>) permutation = [1, 0]
    %11 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %12 = tensor.splat %11 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : tensor<1x256xf32>
    %13 = linalg.matmul {prov.region_id = "matmul_1", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1", prov.transposed_b = "true"} ins(%3, %10 : tensor<1x2048xf32>, tensor<2048x256xf32>) outs(%12 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %14 = tensor.empty() : tensor<2048x256xf32>
    %15 = linalg.transpose ins(%2:tensor<256x2048xf32>) outs(%14:tensor<2048x256xf32>) permutation = [1, 0]
    %16 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %17 = tensor.splat %16 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : tensor<1x256xf32>
    %18 = linalg.matmul {prov.region_id = "matmul_2", prov.op = "matmul", prov.family = "contraction", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2", prov.transposed_b = "true"} ins(%3, %15 : tensor<1x2048xf32>, tensor<2048x256xf32>) outs(%17 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %19 = tensor.concat dim(1) %8, %13, %18 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<1x2048xf32>, tensor<1x256xf32>, tensor<1x256xf32>) -> tensor<1x2560xf32>
    func.return %19 : tensor<1x2560xf32>
  }
}