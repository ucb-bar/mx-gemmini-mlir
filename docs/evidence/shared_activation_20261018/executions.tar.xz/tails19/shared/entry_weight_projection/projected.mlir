"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>) -> tensor<19x81xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>):
    %1 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : () -> f32
    %2 = "tensor.splat"(%1) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : (f32) -> tensor<19x23xf32>
    %3 = "tensor.empty"() : () -> tensor<2112xi8>
    %4 = "func.call"(%0, %3) <{callee = @mx_prepare_a_fp8_m19_k37_pm32_pk64}> : (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>
    %5 = "func.call"(%4, %2) <{callee = @mx_dense_kernel_0_prepared}> : (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %6 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : () -> f32
    %7 = "tensor.splat"(%6) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : (f32) -> tensor<19x41xf32>
    %8 = "func.call"(%4, %7) <{callee = @mx_dense_kernel_1_prepared}> : (tensor<2112xi8>, tensor<19x41xf32>) -> tensor<19x41xf32>
    %9 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : () -> f32
    %10 = "tensor.splat"(%9) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : (f32) -> tensor<19x17xf32>
    %11 = "func.call"(%4, %10) <{callee = @mx_dense_kernel_2_prepared}> : (tensor<2112xi8>, tensor<19x17xf32>) -> tensor<19x17xf32>
    %12 = "tensor.concat"(%5, %8, %11) <{dim = 1 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<19x23xf32>, tensor<19x41xf32>, tensor<19x17xf32>) -> tensor<19x81xf32>
    "func.return"(%12) : (tensor<19x81xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x41xf32>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<19x37xf32>, tensor<37x17xf32>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m19_k37_pm32_pk64", function_type = (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<2112xi8>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<2112xi8>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_projection_19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()