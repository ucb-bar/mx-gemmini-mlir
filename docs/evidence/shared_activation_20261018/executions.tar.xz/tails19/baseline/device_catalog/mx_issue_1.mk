kernel mx_issue_1_schedule(activation: i8[2048] read, activation_scales: i8[64] read, weight: i8[3072] read, weight_scales: i8[96] read, output_bf16: i16[1536] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=32, nc=16, kt=64}
  configure()
  for row in 0..1:
    for chunk in 0..3:
      for wave in 0..1:
        native_loop(a=&activation[((row * 2048) + (wave * 64))], b=&weight[((wave * 3072) + (chunk * 16))], c=&output_bf16[((row * 3072) + (chunk * 32))], asc=&activation_scales[((wave * 64) + (row * 32))], bsc=&weight_scales[((wave * 96) + (chunk * 16))], write=select(wave == 0, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 3) + chunk + wave), 2) + 1))
