"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>) -> tensor<19x81xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>):
    %1 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : () -> f32
    %2 = "tensor.splat"(%1) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.0"} : (f32) -> tensor<19x23xf32>
    %3 = "tensor.empty"() : () -> tensor<37x23xf32>
    %4 = "func.call"(%0, %3, %2) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %5 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : () -> f32
    %6 = "tensor.splat"(%5) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.1"} : (f32) -> tensor<19x41xf32>
    %7 = "tensor.empty"() : () -> tensor<37x41xf32>
    %8 = "func.call"(%0, %7, %6) <{callee = @merlin_dev_mx_gemmini_1}> : (tensor<19x37xf32>, tensor<37x41xf32>, tensor<19x41xf32>) -> tensor<19x41xf32>
    %9 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : () -> f32
    %10 = "tensor.splat"(%9) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "float32", prov.module = "projections", prov.fqn = "projections.2"} : (f32) -> tensor<19x17xf32>
    %11 = "tensor.empty"() : () -> tensor<37x17xf32>
    %12 = "func.call"(%0, %11, %10) <{callee = @merlin_dev_mx_gemmini_2}> : (tensor<19x37xf32>, tensor<37x17xf32>, tensor<19x17xf32>) -> tensor<19x17xf32>
    %13 = "tensor.concat"(%4, %8, %12) <{dim = 1 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "float32"} : (tensor<19x23xf32>, tensor<19x41xf32>, tensor<19x17xf32>) -> tensor<19x81xf32>
    "func.return"(%13) : (tensor<19x81xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x41xf32>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<19x37xf32>, tensor<37x17xf32>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_projection_19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()