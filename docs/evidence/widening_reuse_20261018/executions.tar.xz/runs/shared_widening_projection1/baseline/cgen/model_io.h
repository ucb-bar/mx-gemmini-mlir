/* Generated. Embedded runtime inputs. */
#ifndef MERLIN_MODEL_IO_H
#define MERLIN_MODEL_IO_H
#include <math.h>
#include <string.h>
static float merlin_in_3[] = {-1.5986323356628418,0.8908558487892151,-1.5661351680755615,0.31272149085998535,-0.30387863516807556,2.366269588470459,-0.8544811606407166,-0.39272430539131165,0.08050857484340668,2.099802255630493,1.1108683347702026,-0.5868803858757019,1.0333284139633179,0.1452922374010086,1.7187186479568481,-0.9554607272148132,-1.9941654205322266,0.6392813324928284,0.07216093689203262,-0.6206647157669067,0.401736319065094,-0.24587613344192505,0.3221394419670105,-0.3228243291378021,0.8286460638046265,2.221287250518799,0.9108383655548096,0.0061192926950752735,-0.5937952995300293,-1.2803016901016235,0.59780353307724,-0.003453452605754137,-0.42395129799842834,-0.04927072301506996,-0.33743101358413696,-0.07148811966180801,-0.6976681351661682};
static _Alignas(64) unsigned char merlin_out_0[324];
static void *MERLIN_INPUT_PTR[MERLIN_N_ARGS] = {(void*)merlin_in_3,0};
static void *MERLIN_OUTPUT_PTR[MERLIN_N_OUTPUTS] = {(void*)merlin_out_0};
static const int MERLIN_STATE_INPUT_ARGS[1] = {0};
static const int MERLIN_STATE_OUTPUT_INDICES[1] = {0};
static void merlin_reset_session(void) {
}
static void merlin_prepare_step(long step) {
  long s = step % MERLIN_SESSION_STEPS;
  (void)s;
}
typedef struct {
  long steps; double min_cos; double max_rel; long top1;
} merlin_trajectory_metrics_t;
static merlin_trajectory_metrics_t merlin_correctness_metrics = {0, 1.0, 0.0, 0};
static merlin_trajectory_metrics_t merlin_quality_metrics = {0, 1.0, 0.0, 0};
static void merlin_compare_trajectory(const float *got, const float *ref, long n,
                                      merlin_trajectory_metrics_t *metrics) {
  double dot = 0.0, gn = 0.0, rn = 0.0, rmax = 0.0, errmax = 0.0;
  long gi = 0, ri = 0;
  for (long i = 0; i < n; i++) {
    double g = got[i], r = ref[i], e = fabs(g - r);
    dot += g * r; gn += g * g; rn += r * r;
    if (fabs(r) > rmax) rmax = fabs(r); if (e > errmax) errmax = e;
    if (got[i] > got[gi]) gi = i; if (ref[i] > ref[ri]) ri = i;
  }
  double denom = sqrt(gn) * sqrt(rn);
  double cos = denom > 0.0 ? dot / denom : (gn == rn ? 1.0 : 0.0);
  double rel = rmax > 0.0 ? errmax / rmax : errmax;
  if (cos < metrics->min_cos) metrics->min_cos = cos;
  if (rel > metrics->max_rel) metrics->max_rel = rel;
  if (gi == ri) metrics->top1++; metrics->steps++;
}
static void merlin_validate_step(long step) {
  (void)step;
}
static long merlin_correctness_steps(void) { return merlin_correctness_metrics.steps; }
static long merlin_correctness_min_cos_ppm(void) {
  return (long)(merlin_correctness_metrics.min_cos * 1000000.0);
}
static long merlin_correctness_max_rel_ppm(void) {
  return (long)(merlin_correctness_metrics.max_rel * 1000000.0);
}
static long merlin_correctness_top1(void) { return merlin_correctness_metrics.top1; }
static long merlin_quality_steps(void) { return merlin_quality_metrics.steps; }
static long merlin_quality_min_cos_ppm(void) {
  return (long)(merlin_quality_metrics.min_cos * 1000000.0);
}
static long merlin_quality_max_rel_ppm(void) {
  return (long)(merlin_quality_metrics.max_rel * 1000000.0);
}
static long merlin_quality_top1(void) { return merlin_quality_metrics.top1; }
#endif
