unsigned char mx_catalog_workspace[8768] __attribute__((aligned(64)));
