kernel mx_issue_1_schedule(activation: i8[1024] read, activation_scales: i8[32] read, weight: i8[3072] read, weight_scales: i8[96] read, output_bf16: i16[768] write, scratch_output_scales: i8[2048] read)
  attrs {precision=FP8, tm=16, nc=16, kt=64}
  configure()
  for row in 0..1:
    for chunk in 0..3:
      for wave in 0..1:
        native_loop(a=&activation[((row * 1024) + (wave * 64))], b=&weight[((wave * 3072) + (chunk * 16))], c=&output_bf16[((row * 1536) + (chunk * 32))], asc=&activation_scales[((wave * 32) + (row * 16))], bsc=&weight_scales[((wave * 96) + (chunk * 16))], write=select(wave == 0, 1, 0), accumulate=select(wave == 0, 0, 1), slot=(mod(((row * 3) + chunk + wave), 2) + 1))
