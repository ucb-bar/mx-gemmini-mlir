; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_1x23xf32 = private constant [1 x [23 x float]] zeroinitializer, align 64
@__constant_1x41xf32 = private constant [1 x [41 x float]] zeroinitializer, align 64
@__constant_1x17xf32 = private constant [1 x [17 x float]] zeroinitializer, align 64

declare void @free(ptr)

declare ptr @malloc(i64)

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13) {
  %15 = call ptr @malloc(i64 138)
  %16 = ptrtoint ptr %15 to i64
  %17 = add i64 %16, 63
  %18 = urem i64 %17, 64
  %19 = sub i64 %17, %18
  %20 = inttoptr i64 %19 to ptr
  br label %21

21:                                               ; preds = %36, %14
  %22 = phi i64 [ %37, %36 ], [ 0, %14 ]
  %23 = icmp slt i64 %22, 1
  br i1 %23, label %24, label %38

24:                                               ; preds = %21
  br label %25

25:                                               ; preds = %28, %24
  %26 = phi i64 [ %35, %28 ], [ 0, %24 ]
  %27 = icmp slt i64 %26, 37
  br i1 %27, label %28, label %36

28:                                               ; preds = %25
  %29 = mul nuw nsw i64 %22, 37
  %30 = add nuw nsw i64 %29, %26
  %31 = getelementptr inbounds nuw float, ptr %1, i64 %30
  %32 = load float, ptr %31, align 4
  %33 = fptrunc float %32 to bfloat
  %34 = getelementptr inbounds nuw bfloat, ptr %20, i64 %30
  store bfloat %33, ptr %34, align 2
  %35 = add i64 %26, 1
  br label %25

36:                                               ; preds = %25
  %37 = add i64 %22, 1
  br label %21

38:                                               ; preds = %21
  %39 = call ptr @malloc(i64 212)
  %40 = ptrtoint ptr %39 to i64
  %41 = add i64 %40, 63
  %42 = urem i64 %41, 64
  %43 = sub i64 %41, %42
  %44 = inttoptr i64 %43 to ptr
  br label %45

45:                                               ; preds = %60, %38
  %46 = phi i64 [ %61, %60 ], [ 0, %38 ]
  %47 = icmp slt i64 %46, 1
  br i1 %47, label %48, label %62

48:                                               ; preds = %45
  br label %49

49:                                               ; preds = %52, %48
  %50 = phi i64 [ %59, %52 ], [ 0, %48 ]
  %51 = icmp slt i64 %50, 37
  br i1 %51, label %52, label %60

52:                                               ; preds = %49
  %53 = mul nuw nsw i64 %46, 37
  %54 = add nuw nsw i64 %53, %50
  %55 = getelementptr inbounds nuw bfloat, ptr %20, i64 %54
  %56 = load bfloat, ptr %55, align 2
  %57 = fpext bfloat %56 to float
  %58 = getelementptr inbounds nuw float, ptr %44, i64 %54
  store float %57, ptr %58, align 4
  %59 = add i64 %50, 1
  br label %49

60:                                               ; preds = %49
  %61 = add i64 %46, 1
  br label %45

62:                                               ; preds = %45
  %63 = call ptr @malloc(i64 3468)
  %64 = ptrtoint ptr %63 to i64
  %65 = add i64 %64, 63
  %66 = urem i64 %65, 64
  %67 = sub i64 %65, %66
  %68 = inttoptr i64 %67 to ptr
  %69 = call ptr @malloc(i64 156)
  %70 = ptrtoint ptr %69 to i64
  %71 = add i64 %70, 63
  %72 = urem i64 %71, 64
  %73 = sub i64 %71, %72
  %74 = inttoptr i64 %73 to ptr
  %75 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_0(ptr %39, ptr %44, i64 0, i64 1, i64 37, i64 37, i64 1, ptr %63, ptr %68, i64 0, i64 37, i64 23, i64 23, i64 1, ptr %69, ptr %74, i64 0, i64 1, i64 23, i64 23, i64 1)
  %76 = call ptr @malloc(i64 110)
  %77 = ptrtoint ptr %76 to i64
  %78 = add i64 %77, 63
  %79 = urem i64 %78, 64
  %80 = sub i64 %78, %79
  %81 = inttoptr i64 %80 to ptr
  br label %82

82:                                               ; preds = %98, %62
  %83 = phi i64 [ %99, %98 ], [ 0, %62 ]
  %84 = icmp slt i64 %83, 1
  br i1 %84, label %85, label %100

85:                                               ; preds = %82
  br label %86

86:                                               ; preds = %89, %85
  %87 = phi i64 [ %97, %89 ], [ 0, %85 ]
  %88 = icmp slt i64 %87, 23
  br i1 %88, label %89, label %98

89:                                               ; preds = %86
  %90 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %75, 1
  %91 = mul nuw nsw i64 %83, 23
  %92 = add nuw nsw i64 %91, %87
  %93 = getelementptr inbounds nuw float, ptr %90, i64 %92
  %94 = load float, ptr %93, align 4
  %95 = fptrunc float %94 to bfloat
  %96 = getelementptr inbounds nuw bfloat, ptr %81, i64 %92
  store bfloat %95, ptr %96, align 2
  %97 = add i64 %87, 1
  br label %86

98:                                               ; preds = %86
  %99 = add i64 %83, 1
  br label %82

100:                                              ; preds = %82
  call void @free(ptr %69)
  call void @free(ptr %63)
  br label %101

101:                                              ; preds = %116, %100
  %102 = phi i64 [ %117, %116 ], [ 0, %100 ]
  %103 = icmp slt i64 %102, 1
  br i1 %103, label %104, label %118

104:                                              ; preds = %101
  br label %105

105:                                              ; preds = %108, %104
  %106 = phi i64 [ %115, %108 ], [ 0, %104 ]
  %107 = icmp slt i64 %106, 37
  br i1 %107, label %108, label %116

108:                                              ; preds = %105
  %109 = mul nuw nsw i64 %102, 37
  %110 = add nuw nsw i64 %109, %106
  %111 = getelementptr inbounds nuw bfloat, ptr %20, i64 %110
  %112 = load bfloat, ptr %111, align 2
  %113 = fpext bfloat %112 to float
  %114 = getelementptr inbounds nuw float, ptr %44, i64 %110
  store float %113, ptr %114, align 4
  %115 = add i64 %106, 1
  br label %105

116:                                              ; preds = %105
  %117 = add i64 %102, 1
  br label %101

118:                                              ; preds = %101
  %119 = call ptr @malloc(i64 6132)
  %120 = ptrtoint ptr %119 to i64
  %121 = add i64 %120, 63
  %122 = urem i64 %121, 64
  %123 = sub i64 %121, %122
  %124 = inttoptr i64 %123 to ptr
  %125 = call ptr @malloc(i64 228)
  %126 = ptrtoint ptr %125 to i64
  %127 = add i64 %126, 63
  %128 = urem i64 %127, 64
  %129 = sub i64 %127, %128
  %130 = inttoptr i64 %129 to ptr
  %131 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_1(ptr %39, ptr %44, i64 0, i64 1, i64 37, i64 37, i64 1, ptr %119, ptr %124, i64 0, i64 37, i64 41, i64 41, i64 1, ptr %125, ptr %130, i64 0, i64 1, i64 41, i64 41, i64 1)
  %132 = call ptr @malloc(i64 146)
  %133 = ptrtoint ptr %132 to i64
  %134 = add i64 %133, 63
  %135 = urem i64 %134, 64
  %136 = sub i64 %134, %135
  %137 = inttoptr i64 %136 to ptr
  br label %138

138:                                              ; preds = %154, %118
  %139 = phi i64 [ %155, %154 ], [ 0, %118 ]
  %140 = icmp slt i64 %139, 1
  br i1 %140, label %141, label %156

141:                                              ; preds = %138
  br label %142

142:                                              ; preds = %145, %141
  %143 = phi i64 [ %153, %145 ], [ 0, %141 ]
  %144 = icmp slt i64 %143, 41
  br i1 %144, label %145, label %154

145:                                              ; preds = %142
  %146 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %131, 1
  %147 = mul nuw nsw i64 %139, 41
  %148 = add nuw nsw i64 %147, %143
  %149 = getelementptr inbounds nuw float, ptr %146, i64 %148
  %150 = load float, ptr %149, align 4
  %151 = fptrunc float %150 to bfloat
  %152 = getelementptr inbounds nuw bfloat, ptr %137, i64 %148
  store bfloat %151, ptr %152, align 2
  %153 = add i64 %143, 1
  br label %142

154:                                              ; preds = %142
  %155 = add i64 %139, 1
  br label %138

156:                                              ; preds = %138
  call void @free(ptr %125)
  call void @free(ptr %119)
  br label %157

157:                                              ; preds = %172, %156
  %158 = phi i64 [ %173, %172 ], [ 0, %156 ]
  %159 = icmp slt i64 %158, 1
  br i1 %159, label %160, label %174

160:                                              ; preds = %157
  br label %161

161:                                              ; preds = %164, %160
  %162 = phi i64 [ %171, %164 ], [ 0, %160 ]
  %163 = icmp slt i64 %162, 37
  br i1 %163, label %164, label %172

164:                                              ; preds = %161
  %165 = mul nuw nsw i64 %158, 37
  %166 = add nuw nsw i64 %165, %162
  %167 = getelementptr inbounds nuw bfloat, ptr %20, i64 %166
  %168 = load bfloat, ptr %167, align 2
  %169 = fpext bfloat %168 to float
  %170 = getelementptr inbounds nuw float, ptr %44, i64 %166
  store float %169, ptr %170, align 4
  %171 = add i64 %162, 1
  br label %161

172:                                              ; preds = %161
  %173 = add i64 %158, 1
  br label %157

174:                                              ; preds = %157
  call void @free(ptr %15)
  %175 = call ptr @malloc(i64 2580)
  %176 = ptrtoint ptr %175 to i64
  %177 = add i64 %176, 63
  %178 = urem i64 %177, 64
  %179 = sub i64 %177, %178
  %180 = inttoptr i64 %179 to ptr
  %181 = call ptr @malloc(i64 132)
  %182 = ptrtoint ptr %181 to i64
  %183 = add i64 %182, 63
  %184 = urem i64 %183, 64
  %185 = sub i64 %183, %184
  %186 = inttoptr i64 %185 to ptr
  %187 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_2(ptr %39, ptr %44, i64 0, i64 1, i64 37, i64 37, i64 1, ptr %175, ptr %180, i64 0, i64 37, i64 17, i64 17, i64 1, ptr %181, ptr %186, i64 0, i64 1, i64 17, i64 17, i64 1)
  %188 = call ptr @malloc(i64 98)
  %189 = ptrtoint ptr %188 to i64
  %190 = add i64 %189, 63
  %191 = urem i64 %190, 64
  %192 = sub i64 %190, %191
  %193 = inttoptr i64 %192 to ptr
  br label %194

194:                                              ; preds = %210, %174
  %195 = phi i64 [ %211, %210 ], [ 0, %174 ]
  %196 = icmp slt i64 %195, 1
  br i1 %196, label %197, label %212

197:                                              ; preds = %194
  br label %198

198:                                              ; preds = %201, %197
  %199 = phi i64 [ %209, %201 ], [ 0, %197 ]
  %200 = icmp slt i64 %199, 17
  br i1 %200, label %201, label %210

201:                                              ; preds = %198
  %202 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %187, 1
  %203 = mul nuw nsw i64 %195, 17
  %204 = add nuw nsw i64 %203, %199
  %205 = getelementptr inbounds nuw float, ptr %202, i64 %204
  %206 = load float, ptr %205, align 4
  %207 = fptrunc float %206 to bfloat
  %208 = getelementptr inbounds nuw bfloat, ptr %193, i64 %204
  store bfloat %207, ptr %208, align 2
  %209 = add i64 %199, 1
  br label %198

210:                                              ; preds = %198
  %211 = add i64 %195, 1
  br label %194

212:                                              ; preds = %194
  call void @free(ptr %181)
  call void @free(ptr %175)
  call void @free(ptr %39)
  %213 = call ptr @malloc(i64 226)
  %214 = ptrtoint ptr %213 to i64
  %215 = add i64 %214, 63
  %216 = urem i64 %215, 64
  %217 = sub i64 %215, %216
  %218 = inttoptr i64 %217 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr %218, ptr %81, i64 46, i1 false)
  call void @free(ptr %76)
  %219 = getelementptr bfloat, ptr %218, i32 23
  call void @llvm.memcpy.p0.p0.i64(ptr %219, ptr %137, i64 82, i1 false)
  call void @free(ptr %132)
  %220 = getelementptr bfloat, ptr %218, i32 64
  call void @llvm.memcpy.p0.p0.i64(ptr %220, ptr %193, i64 34, i1 false)
  call void @free(ptr %188)
  br label %221

221:                                              ; preds = %236, %212
  %222 = phi i64 [ %237, %236 ], [ 0, %212 ]
  %223 = icmp slt i64 %222, 1
  br i1 %223, label %224, label %238

224:                                              ; preds = %221
  br label %225

225:                                              ; preds = %228, %224
  %226 = phi i64 [ %235, %228 ], [ 0, %224 ]
  %227 = icmp slt i64 %226, 81
  br i1 %227, label %228, label %236

228:                                              ; preds = %225
  %229 = mul nuw nsw i64 %222, 81
  %230 = add nuw nsw i64 %229, %226
  %231 = getelementptr inbounds nuw bfloat, ptr %218, i64 %230
  %232 = load bfloat, ptr %231, align 2
  %233 = fpext bfloat %232 to float
  %234 = getelementptr inbounds nuw float, ptr %8, i64 %230
  store float %233, ptr %234, align 4
  %235 = add i64 %226, 1
  br label %225

236:                                              ; preds = %225
  %237 = add i64 %222, 1
  br label %221

238:                                              ; preds = %221
  call void @free(ptr %213)
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1) {
  %3 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, align 8
  %4 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 0
  %5 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 1
  %6 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 2
  %7 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 0
  %8 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 1
  %9 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 0
  %10 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 1
  %11 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %12 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 0
  %13 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 1
  %14 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 2
  %15 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 0
  %16 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 1
  %17 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 0
  %18 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 1
  call void @forward(ptr %4, ptr %5, i64 %6, i64 %7, i64 %8, i64 %9, i64 %10, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18)
  ret void
}

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_1(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_1(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_1(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_2(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_2(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_2(ptr, ptr, ptr, ptr)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
