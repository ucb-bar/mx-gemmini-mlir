; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_1x23xf32 = private constant [1 x [23 x float]] zeroinitializer, align 64
@__constant_1x41xf32 = private constant [1 x [41 x float]] zeroinitializer, align 64
@__constant_1x17xf32 = private constant [1 x [17 x float]] zeroinitializer, align 64

declare void @free(ptr)

declare ptr @malloc(i64)

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13) {
  %15 = call ptr @malloc(i64 212)
  %16 = ptrtoint ptr %15 to i64
  %17 = add i64 %16, 63
  %18 = urem i64 %17, 64
  %19 = sub i64 %17, %18
  %20 = inttoptr i64 %19 to ptr
  br label %21

21:                                               ; preds = %37, %14
  %22 = phi i64 [ %38, %37 ], [ 0, %14 ]
  %23 = icmp slt i64 %22, 1
  br i1 %23, label %24, label %39

24:                                               ; preds = %21
  br label %25

25:                                               ; preds = %28, %24
  %26 = phi i64 [ %36, %28 ], [ 0, %24 ]
  %27 = icmp slt i64 %26, 37
  br i1 %27, label %28, label %37

28:                                               ; preds = %25
  %29 = mul nuw nsw i64 %22, 37
  %30 = add nuw nsw i64 %29, %26
  %31 = getelementptr inbounds nuw float, ptr %1, i64 %30
  %32 = load float, ptr %31, align 4
  %33 = fptrunc float %32 to bfloat
  %34 = fpext bfloat %33 to float
  %35 = getelementptr inbounds nuw float, ptr %20, i64 %30
  store float %34, ptr %35, align 4
  %36 = add i64 %26, 1
  br label %25

37:                                               ; preds = %25
  %38 = add i64 %22, 1
  br label %21

39:                                               ; preds = %21
  %40 = call ptr @malloc(i64 1152)
  %41 = ptrtoint ptr %40 to i64
  %42 = add i64 %41, 63
  %43 = urem i64 %42, 64
  %44 = sub i64 %42, %43
  %45 = inttoptr i64 %44 to ptr
  %46 = call { ptr, ptr, i64, [1 x i64], [1 x i64] } @mx_prepare_a_fp4_m1_k37_pm32_pk64(ptr %15, ptr %20, i64 0, i64 1, i64 37, i64 37, i64 1, ptr %40, ptr %45, i64 0, i64 1088, i64 1)
  %47 = call ptr @malloc(i64 156)
  %48 = ptrtoint ptr %47 to i64
  %49 = add i64 %48, 63
  %50 = urem i64 %49, 64
  %51 = sub i64 %49, %50
  %52 = inttoptr i64 %51 to ptr
  %53 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 0
  %54 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 1
  %55 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 2
  %56 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 3, 0
  %57 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 4, 0
  %58 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_0_prepared(ptr %53, ptr %54, i64 %55, i64 %56, i64 %57, ptr %47, ptr %52, i64 0, i64 1, i64 23, i64 23, i64 1)
  %59 = call ptr @malloc(i64 110)
  %60 = ptrtoint ptr %59 to i64
  %61 = add i64 %60, 63
  %62 = urem i64 %61, 64
  %63 = sub i64 %61, %62
  %64 = inttoptr i64 %63 to ptr
  br label %65

65:                                               ; preds = %81, %39
  %66 = phi i64 [ %82, %81 ], [ 0, %39 ]
  %67 = icmp slt i64 %66, 1
  br i1 %67, label %68, label %83

68:                                               ; preds = %65
  br label %69

69:                                               ; preds = %72, %68
  %70 = phi i64 [ %80, %72 ], [ 0, %68 ]
  %71 = icmp slt i64 %70, 23
  br i1 %71, label %72, label %81

72:                                               ; preds = %69
  %73 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %58, 1
  %74 = mul nuw nsw i64 %66, 23
  %75 = add nuw nsw i64 %74, %70
  %76 = getelementptr inbounds nuw float, ptr %73, i64 %75
  %77 = load float, ptr %76, align 4
  %78 = fptrunc float %77 to bfloat
  %79 = getelementptr inbounds nuw bfloat, ptr %64, i64 %75
  store bfloat %78, ptr %79, align 2
  %80 = add i64 %70, 1
  br label %69

81:                                               ; preds = %69
  %82 = add i64 %66, 1
  br label %65

83:                                               ; preds = %65
  %84 = call ptr @malloc(i64 228)
  %85 = ptrtoint ptr %84 to i64
  %86 = add i64 %85, 63
  %87 = urem i64 %86, 64
  %88 = sub i64 %86, %87
  %89 = inttoptr i64 %88 to ptr
  %90 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_1_prepared(ptr %53, ptr %54, i64 %55, i64 %56, i64 %57, ptr %84, ptr %89, i64 0, i64 1, i64 41, i64 41, i64 1)
  %91 = call ptr @malloc(i64 146)
  %92 = ptrtoint ptr %91 to i64
  %93 = add i64 %92, 63
  %94 = urem i64 %93, 64
  %95 = sub i64 %93, %94
  %96 = inttoptr i64 %95 to ptr
  br label %97

97:                                               ; preds = %113, %83
  %98 = phi i64 [ %114, %113 ], [ 0, %83 ]
  %99 = icmp slt i64 %98, 1
  br i1 %99, label %100, label %115

100:                                              ; preds = %97
  br label %101

101:                                              ; preds = %104, %100
  %102 = phi i64 [ %112, %104 ], [ 0, %100 ]
  %103 = icmp slt i64 %102, 41
  br i1 %103, label %104, label %113

104:                                              ; preds = %101
  %105 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %90, 1
  %106 = mul nuw nsw i64 %98, 41
  %107 = add nuw nsw i64 %106, %102
  %108 = getelementptr inbounds nuw float, ptr %105, i64 %107
  %109 = load float, ptr %108, align 4
  %110 = fptrunc float %109 to bfloat
  %111 = getelementptr inbounds nuw bfloat, ptr %96, i64 %107
  store bfloat %110, ptr %111, align 2
  %112 = add i64 %102, 1
  br label %101

113:                                              ; preds = %101
  %114 = add i64 %98, 1
  br label %97

115:                                              ; preds = %97
  %116 = call ptr @malloc(i64 132)
  %117 = ptrtoint ptr %116 to i64
  %118 = add i64 %117, 63
  %119 = urem i64 %118, 64
  %120 = sub i64 %118, %119
  %121 = inttoptr i64 %120 to ptr
  %122 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_2_prepared(ptr %53, ptr %54, i64 %55, i64 %56, i64 %57, ptr %116, ptr %121, i64 0, i64 1, i64 17, i64 17, i64 1)
  %123 = call ptr @malloc(i64 98)
  %124 = ptrtoint ptr %123 to i64
  %125 = add i64 %124, 63
  %126 = urem i64 %125, 64
  %127 = sub i64 %125, %126
  %128 = inttoptr i64 %127 to ptr
  br label %129

129:                                              ; preds = %145, %115
  %130 = phi i64 [ %146, %145 ], [ 0, %115 ]
  %131 = icmp slt i64 %130, 1
  br i1 %131, label %132, label %147

132:                                              ; preds = %129
  br label %133

133:                                              ; preds = %136, %132
  %134 = phi i64 [ %144, %136 ], [ 0, %132 ]
  %135 = icmp slt i64 %134, 17
  br i1 %135, label %136, label %145

136:                                              ; preds = %133
  %137 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %122, 1
  %138 = mul nuw nsw i64 %130, 17
  %139 = add nuw nsw i64 %138, %134
  %140 = getelementptr inbounds nuw float, ptr %137, i64 %139
  %141 = load float, ptr %140, align 4
  %142 = fptrunc float %141 to bfloat
  %143 = getelementptr inbounds nuw bfloat, ptr %128, i64 %139
  store bfloat %142, ptr %143, align 2
  %144 = add i64 %134, 1
  br label %133

145:                                              ; preds = %133
  %146 = add i64 %130, 1
  br label %129

147:                                              ; preds = %129
  %148 = call ptr @malloc(i64 226)
  %149 = ptrtoint ptr %148 to i64
  %150 = add i64 %149, 63
  %151 = urem i64 %150, 64
  %152 = sub i64 %150, %151
  %153 = inttoptr i64 %152 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr %153, ptr %64, i64 46, i1 false)
  %154 = getelementptr bfloat, ptr %153, i32 23
  call void @llvm.memcpy.p0.p0.i64(ptr %154, ptr %96, i64 82, i1 false)
  %155 = getelementptr bfloat, ptr %153, i32 64
  call void @llvm.memcpy.p0.p0.i64(ptr %155, ptr %128, i64 34, i1 false)
  br label %156

156:                                              ; preds = %171, %147
  %157 = phi i64 [ %172, %171 ], [ 0, %147 ]
  %158 = icmp slt i64 %157, 1
  br i1 %158, label %159, label %173

159:                                              ; preds = %156
  br label %160

160:                                              ; preds = %163, %159
  %161 = phi i64 [ %170, %163 ], [ 0, %159 ]
  %162 = icmp slt i64 %161, 81
  br i1 %162, label %163, label %171

163:                                              ; preds = %160
  %164 = mul nuw nsw i64 %157, 81
  %165 = add nuw nsw i64 %164, %161
  %166 = getelementptr inbounds nuw bfloat, ptr %153, i64 %165
  %167 = load bfloat, ptr %166, align 2
  %168 = fpext bfloat %167 to float
  %169 = getelementptr inbounds nuw float, ptr %8, i64 %165
  store float %168, ptr %169, align 4
  %170 = add i64 %161, 1
  br label %160

171:                                              ; preds = %160
  %172 = add i64 %157, 1
  br label %156

173:                                              ; preds = %156
  %174 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %58, 0
  %175 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %58, 1
  %176 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %90, 0
  %177 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %90, 1
  %178 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %122, 0
  %179 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %122, 1
  %180 = call ptr @malloc(i64 104)
  %181 = call ptr @malloc(i64 13)
  %182 = call ptr @malloc(i64 0)
  %183 = ptrtoint ptr %20 to i64
  store i64 %183, ptr %180, align 8
  %184 = ptrtoint ptr %45 to i64
  %185 = getelementptr inbounds nuw i64, ptr %180, i32 1
  store i64 %184, ptr %185, align 8
  %186 = ptrtoint ptr %54 to i64
  %187 = getelementptr inbounds nuw i64, ptr %180, i32 2
  store i64 %186, ptr %187, align 8
  %188 = ptrtoint ptr %52 to i64
  %189 = getelementptr inbounds nuw i64, ptr %180, i32 3
  store i64 %188, ptr %189, align 8
  %190 = ptrtoint ptr %175 to i64
  %191 = getelementptr inbounds nuw i64, ptr %180, i32 4
  store i64 %190, ptr %191, align 8
  %192 = ptrtoint ptr %64 to i64
  %193 = getelementptr inbounds nuw i64, ptr %180, i32 5
  store i64 %192, ptr %193, align 8
  %194 = ptrtoint ptr %89 to i64
  %195 = getelementptr inbounds nuw i64, ptr %180, i32 6
  store i64 %194, ptr %195, align 8
  %196 = ptrtoint ptr %177 to i64
  %197 = getelementptr inbounds nuw i64, ptr %180, i32 7
  store i64 %196, ptr %197, align 8
  %198 = ptrtoint ptr %96 to i64
  %199 = getelementptr inbounds nuw i64, ptr %180, i32 8
  store i64 %198, ptr %199, align 8
  %200 = ptrtoint ptr %121 to i64
  %201 = getelementptr inbounds nuw i64, ptr %180, i32 9
  store i64 %200, ptr %201, align 8
  %202 = ptrtoint ptr %179 to i64
  %203 = getelementptr inbounds nuw i64, ptr %180, i32 10
  store i64 %202, ptr %203, align 8
  %204 = ptrtoint ptr %128 to i64
  %205 = getelementptr inbounds nuw i64, ptr %180, i32 11
  store i64 %204, ptr %205, align 8
  %206 = ptrtoint ptr %153 to i64
  %207 = getelementptr inbounds nuw i64, ptr %180, i32 12
  store i64 %206, ptr %207, align 8
  store i1 true, ptr %181, align 1
  %208 = getelementptr inbounds nuw i1, ptr %181, i32 1
  store i1 true, ptr %208, align 1
  %209 = getelementptr inbounds nuw i1, ptr %181, i32 2
  store i1 true, ptr %209, align 1
  %210 = getelementptr inbounds nuw i1, ptr %181, i32 3
  store i1 true, ptr %210, align 1
  %211 = getelementptr inbounds nuw i1, ptr %181, i32 4
  store i1 true, ptr %211, align 1
  %212 = getelementptr inbounds nuw i1, ptr %181, i32 5
  store i1 true, ptr %212, align 1
  %213 = getelementptr inbounds nuw i1, ptr %181, i32 6
  store i1 true, ptr %213, align 1
  %214 = getelementptr inbounds nuw i1, ptr %181, i32 7
  store i1 true, ptr %214, align 1
  %215 = getelementptr inbounds nuw i1, ptr %181, i32 8
  store i1 true, ptr %215, align 1
  %216 = getelementptr inbounds nuw i1, ptr %181, i32 9
  store i1 true, ptr %216, align 1
  %217 = getelementptr inbounds nuw i1, ptr %181, i32 10
  store i1 true, ptr %217, align 1
  %218 = getelementptr inbounds nuw i1, ptr %181, i32 11
  store i1 true, ptr %218, align 1
  %219 = getelementptr inbounds nuw i1, ptr %181, i32 12
  store i1 true, ptr %219, align 1
  %220 = call ptr @malloc(i64 13)
  %221 = call ptr @malloc(i64 0)
  call void @dealloc_helper(ptr %180, ptr %180, i64 0, i64 13, i64 1, ptr %182, ptr %182, i64 0, i64 0, i64 1, ptr %181, ptr %181, i64 0, i64 13, i64 1, ptr %220, ptr %220, i64 0, i64 13, i64 1, ptr %221, ptr %221, i64 0, i64 0, i64 1)
  call void @free(ptr %221)
  call void @free(ptr %182)
  call void @free(ptr %181)
  call void @free(ptr %180)
  %222 = load i1, ptr %220, align 1
  br i1 %222, label %223, label %224

223:                                              ; preds = %173
  call void @free(ptr %15)
  br label %224

224:                                              ; preds = %223, %173
  %225 = getelementptr inbounds nuw i1, ptr %220, i32 1
  %226 = load i1, ptr %225, align 1
  br i1 %226, label %227, label %228

227:                                              ; preds = %224
  call void @free(ptr %40)
  br label %228

228:                                              ; preds = %227, %224
  %229 = getelementptr inbounds nuw i1, ptr %220, i32 2
  %230 = load i1, ptr %229, align 1
  br i1 %230, label %231, label %232

231:                                              ; preds = %228
  call void @free(ptr %53)
  br label %232

232:                                              ; preds = %231, %228
  %233 = getelementptr inbounds nuw i1, ptr %220, i32 3
  %234 = load i1, ptr %233, align 1
  br i1 %234, label %235, label %236

235:                                              ; preds = %232
  call void @free(ptr %47)
  br label %236

236:                                              ; preds = %235, %232
  %237 = getelementptr inbounds nuw i1, ptr %220, i32 4
  %238 = load i1, ptr %237, align 1
  br i1 %238, label %239, label %240

239:                                              ; preds = %236
  call void @free(ptr %174)
  br label %240

240:                                              ; preds = %239, %236
  %241 = getelementptr inbounds nuw i1, ptr %220, i32 5
  %242 = load i1, ptr %241, align 1
  br i1 %242, label %243, label %244

243:                                              ; preds = %240
  call void @free(ptr %59)
  br label %244

244:                                              ; preds = %243, %240
  %245 = getelementptr inbounds nuw i1, ptr %220, i32 6
  %246 = load i1, ptr %245, align 1
  br i1 %246, label %247, label %248

247:                                              ; preds = %244
  call void @free(ptr %84)
  br label %248

248:                                              ; preds = %247, %244
  %249 = getelementptr inbounds nuw i1, ptr %220, i32 7
  %250 = load i1, ptr %249, align 1
  br i1 %250, label %251, label %252

251:                                              ; preds = %248
  call void @free(ptr %176)
  br label %252

252:                                              ; preds = %251, %248
  %253 = getelementptr inbounds nuw i1, ptr %220, i32 8
  %254 = load i1, ptr %253, align 1
  br i1 %254, label %255, label %256

255:                                              ; preds = %252
  call void @free(ptr %91)
  br label %256

256:                                              ; preds = %255, %252
  %257 = getelementptr inbounds nuw i1, ptr %220, i32 9
  %258 = load i1, ptr %257, align 1
  br i1 %258, label %259, label %260

259:                                              ; preds = %256
  call void @free(ptr %116)
  br label %260

260:                                              ; preds = %259, %256
  %261 = getelementptr inbounds nuw i1, ptr %220, i32 10
  %262 = load i1, ptr %261, align 1
  br i1 %262, label %263, label %264

263:                                              ; preds = %260
  call void @free(ptr %178)
  br label %264

264:                                              ; preds = %263, %260
  %265 = getelementptr inbounds nuw i1, ptr %220, i32 11
  %266 = load i1, ptr %265, align 1
  br i1 %266, label %267, label %268

267:                                              ; preds = %264
  call void @free(ptr %123)
  br label %268

268:                                              ; preds = %267, %264
  %269 = getelementptr inbounds nuw i1, ptr %220, i32 12
  %270 = load i1, ptr %269, align 1
  call void @free(ptr %220)
  br i1 %270, label %271, label %272

271:                                              ; preds = %268
  call void @free(ptr %148)
  br label %272

272:                                              ; preds = %271, %268
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1) {
  %3 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, align 8
  %4 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 0
  %5 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 1
  %6 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 2
  %7 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 0
  %8 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 1
  %9 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 0
  %10 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 1
  %11 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %12 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 0
  %13 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 1
  %14 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 2
  %15 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 0
  %16 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 1
  %17 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 0
  %18 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 1
  call void @forward(ptr %4, ptr %5, i64 %6, i64 %7, i64 %8, i64 %9, i64 %10, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18)
  ret void
}

define private { ptr, ptr, i64, [1 x i64], [1 x i64] } @mx_prepare_a_fp4_m1_k37_pm32_pk64(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %17, i64 %5, 4, 0
  %19 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %18, i64 %4, 3, 1
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, i64 %6, 4, 1
  %21 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %21, align 8
  %22 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %7, 0
  %23 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %22, ptr %8, 1
  %24 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %23, i64 %9, 2
  %25 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %24, i64 %10, 3, 0
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %25, i64 %11, 4, 0
  %27 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_prepare_a_fp4_m1_k37_pm32_pk64(ptr %13, ptr %21, ptr %27)
  %28 = load { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [1 x i64], [1 x i64] } %28
}

declare void @_mlir_ciface_mx_prepare_a_fp4_m1_k37_pm32_pk64(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_0_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_0_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_0_prepared(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_1_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_1_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_1_prepared(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_2_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_2_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_2_prepared(ptr, ptr, ptr)

define void @dealloc_helper(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24) {
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %27 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, ptr %6, 1
  %28 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %27, i64 %7, 2
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %28, i64 %8, 3, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, ptr %1, 1
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %2, 2
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %3, 3, 0
  %34 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 3
  %35 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %34, ptr %35, align 8
  %36 = getelementptr [1 x i64], ptr %35, i32 0, i32 0
  %37 = load i64, ptr %36, align 8
  %38 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, 3
  %39 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %38, ptr %39, align 8
  %40 = getelementptr [1 x i64], ptr %39, i32 0, i32 0
  %41 = load i64, ptr %40, align 8
  br label %42

42:                                               ; preds = %45, %25
  %43 = phi i64 [ %47, %45 ], [ 0, %25 ]
  %44 = icmp slt i64 %43, %41
  br i1 %44, label %45, label %48

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i1, ptr %21, i64 %43
  store i1 false, ptr %46, align 1
  %47 = add i64 %43, 1
  br label %42

48:                                               ; preds = %42
  br label %49

49:                                               ; preds = %84, %48
  %50 = phi i64 [ %87, %84 ], [ 0, %48 ]
  %51 = icmp slt i64 %50, %37
  br i1 %51, label %52, label %88

52:                                               ; preds = %49
  %53 = getelementptr inbounds nuw i64, ptr %1, i64 %50
  %54 = load i64, ptr %53, align 8
  %55 = getelementptr inbounds nuw i1, ptr %11, i64 %50
  %56 = load i1, ptr %55, align 1
  br label %57

57:                                               ; preds = %69, %52
  %58 = phi i64 [ %72, %69 ], [ 0, %52 ]
  %59 = phi i1 [ %71, %69 ], [ true, %52 ]
  %60 = icmp slt i64 %58, %41
  br i1 %60, label %61, label %73

61:                                               ; preds = %57
  %62 = getelementptr inbounds nuw i64, ptr %6, i64 %58
  %63 = load i64, ptr %62, align 8
  %64 = icmp eq i64 %63, %54
  br i1 %64, label %65, label %69

65:                                               ; preds = %61
  %66 = getelementptr inbounds nuw i1, ptr %21, i64 %58
  %67 = load i1, ptr %66, align 1
  %68 = or i1 %67, %56
  store i1 %68, ptr %66, align 1
  br label %69

69:                                               ; preds = %65, %61
  %70 = icmp ne i64 %63, %54
  %71 = and i1 %59, %70
  %72 = add i64 %58, 1
  br label %57

73:                                               ; preds = %57
  br label %74

74:                                               ; preds = %78, %73
  %75 = phi i64 [ %83, %78 ], [ 0, %73 ]
  %76 = phi i1 [ %82, %78 ], [ %59, %73 ]
  %77 = icmp slt i64 %75, %50
  br i1 %77, label %78, label %84

78:                                               ; preds = %74
  %79 = getelementptr inbounds nuw i64, ptr %1, i64 %75
  %80 = load i64, ptr %79, align 8
  %81 = icmp ne i64 %80, %54
  %82 = and i1 %76, %81
  %83 = add i64 %75, 1
  br label %74

84:                                               ; preds = %74
  %85 = and i1 %76, %56
  %86 = getelementptr inbounds nuw i1, ptr %16, i64 %50
  store i1 %85, ptr %86, align 1
  %87 = add i64 %50, 1
  br label %49

88:                                               ; preds = %49
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
