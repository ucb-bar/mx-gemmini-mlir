"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<1x37xf32>) -> tensor<1x81xf32>}> ({
  ^bb0(%0: tensor<1x37xf32>):
    %1 = "tensor.empty"() : () -> tensor<1x37xbf16>
    %2 = "linalg.generic"(%0, %1) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb1(%3: f32, %4: bf16):
      %5 = "arith.truncf"(%3) : (f32) -> bf16
      "linalg.yield"(%5) : (bf16) -> ()
    }) {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "bfloat16"} : (tensor<1x37xf32>, tensor<1x37xbf16>) -> tensor<1x37xbf16>
    %6 = "tensor.empty"() : () -> tensor<1x37xf32>
    %7 = "linalg.generic"(%2, %6) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb2(%8: bf16, %9: f32):
      %10 = "arith.extf"(%8) : (bf16) -> f32
      "linalg.yield"(%10) : (f32) -> ()
    }) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : (tensor<1x37xbf16>, tensor<1x37xf32>) -> tensor<1x37xf32>
    %11 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : () -> f32
    %12 = "tensor.splat"(%11) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : (f32) -> tensor<1x23xf32>
    %13 = "tensor.empty"() : () -> tensor<1088xi8>
    %14 = "func.call"(%7, %13) <{callee = @mx_prepare_a_fp4_m1_k37_pm32_pk64}> : (tensor<1x37xf32>, tensor<1088xi8>) -> tensor<1088xi8>
    %15 = "func.call"(%14, %12) <{callee = @mx_dense_kernel_0_prepared}> : (tensor<1088xi8>, tensor<1x23xf32>) -> tensor<1x23xf32>
    %16 = "tensor.empty"() : () -> tensor<1x23xbf16>
    %17 = "linalg.generic"(%15, %16) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb3(%18: f32, %19: bf16):
      %20 = "arith.truncf"(%18) : (f32) -> bf16
      "linalg.yield"(%20) : (bf16) -> ()
    }) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : (tensor<1x23xf32>, tensor<1x23xbf16>) -> tensor<1x23xbf16>
    %21 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : () -> f32
    %22 = "tensor.splat"(%21) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : (f32) -> tensor<1x41xf32>
    %23 = "func.call"(%14, %22) <{callee = @mx_dense_kernel_1_prepared}> : (tensor<1088xi8>, tensor<1x41xf32>) -> tensor<1x41xf32>
    %24 = "tensor.empty"() : () -> tensor<1x41xbf16>
    %25 = "linalg.generic"(%23, %24) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb4(%26: f32, %27: bf16):
      %28 = "arith.truncf"(%26) : (f32) -> bf16
      "linalg.yield"(%28) : (bf16) -> ()
    }) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : (tensor<1x41xf32>, tensor<1x41xbf16>) -> tensor<1x41xbf16>
    %29 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : () -> f32
    %30 = "tensor.splat"(%29) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : (f32) -> tensor<1x17xf32>
    %31 = "func.call"(%14, %30) <{callee = @mx_dense_kernel_2_prepared}> : (tensor<1088xi8>, tensor<1x17xf32>) -> tensor<1x17xf32>
    %32 = "tensor.empty"() : () -> tensor<1x17xbf16>
    %33 = "linalg.generic"(%31, %32) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb5(%34: f32, %35: bf16):
      %36 = "arith.truncf"(%34) : (f32) -> bf16
      "linalg.yield"(%36) : (bf16) -> ()
    }) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : (tensor<1x17xf32>, tensor<1x17xbf16>) -> tensor<1x17xbf16>
    %37 = "tensor.concat"(%17, %25, %33) <{dim = 1 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "bfloat16"} : (tensor<1x23xbf16>, tensor<1x41xbf16>, tensor<1x17xbf16>) -> tensor<1x81xbf16>
    %38 = "tensor.empty"() : () -> tensor<1x81xf32>
    %39 = "linalg.generic"(%37, %38) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb6(%40: bf16, %41: f32):
      %42 = "arith.extf"(%40) : (bf16) -> f32
      "linalg.yield"(%42) : (f32) -> ()
    }) {prov.region_id = "dtype_cast_1", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32"} : (tensor<1x81xbf16>, tensor<1x81xf32>) -> tensor<1x81xf32>
    "func.return"(%39) : (tensor<1x81xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<1x37xf32>, tensor<37x23xf32>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<1x37xf32>, tensor<37x41xf32>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<1x37xf32>, tensor<37x17xf32>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp4_m1_k37_pm32_pk64", function_type = (tensor<1x37xf32>, tensor<1088xi8>) -> tensor<1088xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<1088xi8>, tensor<1x23xf32>) -> tensor<1x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<1088xi8>, tensor<1x41xf32>) -> tensor<1x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<1088xi8>, tensor<1x17xf32>) -> tensor<1x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_widening_projection1/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()