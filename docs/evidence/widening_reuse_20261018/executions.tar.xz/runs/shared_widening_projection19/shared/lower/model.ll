; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_19x23xf32 = private constant [19 x [23 x float]] zeroinitializer, align 64
@__constant_19x41xf32 = private constant [19 x [41 x float]] zeroinitializer, align 64
@__constant_19x17xf32 = private constant [19 x [17 x float]] zeroinitializer, align 64

declare void @free(ptr)

declare void @memrefCopy(i64, ptr, ptr)

declare ptr @malloc(i64)

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13) {
  %15 = call ptr @malloc(i64 2876)
  %16 = ptrtoint ptr %15 to i64
  %17 = add i64 %16, 63
  %18 = urem i64 %17, 64
  %19 = sub i64 %17, %18
  %20 = inttoptr i64 %19 to ptr
  br label %21

21:                                               ; preds = %37, %14
  %22 = phi i64 [ %38, %37 ], [ 0, %14 ]
  %23 = icmp slt i64 %22, 19
  br i1 %23, label %24, label %39

24:                                               ; preds = %21
  br label %25

25:                                               ; preds = %28, %24
  %26 = phi i64 [ %36, %28 ], [ 0, %24 ]
  %27 = icmp slt i64 %26, 37
  br i1 %27, label %28, label %37

28:                                               ; preds = %25
  %29 = mul nuw nsw i64 %22, 37
  %30 = add nuw nsw i64 %29, %26
  %31 = getelementptr inbounds nuw float, ptr %1, i64 %30
  %32 = load float, ptr %31, align 4
  %33 = fptrunc float %32 to bfloat
  %34 = fpext bfloat %33 to float
  %35 = getelementptr inbounds nuw float, ptr %20, i64 %30
  store float %34, ptr %35, align 4
  %36 = add i64 %26, 1
  br label %25

37:                                               ; preds = %25
  %38 = add i64 %22, 1
  br label %21

39:                                               ; preds = %21
  %40 = call ptr @malloc(i64 2176)
  %41 = ptrtoint ptr %40 to i64
  %42 = add i64 %41, 63
  %43 = urem i64 %42, 64
  %44 = sub i64 %42, %43
  %45 = inttoptr i64 %44 to ptr
  %46 = call { ptr, ptr, i64, [1 x i64], [1 x i64] } @mx_prepare_a_fp8_m19_k37_pm32_pk64(ptr %15, ptr %20, i64 0, i64 19, i64 37, i64 37, i64 1, ptr %40, ptr %45, i64 0, i64 2112, i64 1)
  %47 = call ptr @malloc(i64 1812)
  %48 = ptrtoint ptr %47 to i64
  %49 = add i64 %48, 63
  %50 = urem i64 %49, 64
  %51 = sub i64 %49, %50
  %52 = inttoptr i64 %51 to ptr
  %53 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 0
  %54 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 1
  %55 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 2
  %56 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 3, 0
  %57 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, 4, 0
  %58 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_0_prepared(ptr %53, ptr %54, i64 %55, i64 %56, i64 %57, ptr %47, ptr %52, i64 0, i64 19, i64 23, i64 23, i64 1)
  %59 = call ptr @malloc(i64 938)
  %60 = ptrtoint ptr %59 to i64
  %61 = add i64 %60, 63
  %62 = urem i64 %61, 64
  %63 = sub i64 %61, %62
  %64 = inttoptr i64 %63 to ptr
  %65 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %59, 0
  %66 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %65, ptr %64, 1
  %67 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %66, i64 0, 2
  %68 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %67, i64 19, 3, 0
  %69 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %68, i64 23, 3, 1
  %70 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %69, i64 23, 4, 0
  %71 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %70, i64 1, 4, 1
  br label %72

72:                                               ; preds = %88, %39
  %73 = phi i64 [ %89, %88 ], [ 0, %39 ]
  %74 = icmp slt i64 %73, 19
  br i1 %74, label %75, label %90

75:                                               ; preds = %72
  br label %76

76:                                               ; preds = %79, %75
  %77 = phi i64 [ %87, %79 ], [ 0, %75 ]
  %78 = icmp slt i64 %77, 23
  br i1 %78, label %79, label %88

79:                                               ; preds = %76
  %80 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %58, 1
  %81 = mul nuw nsw i64 %73, 23
  %82 = add nuw nsw i64 %81, %77
  %83 = getelementptr inbounds nuw float, ptr %80, i64 %82
  %84 = load float, ptr %83, align 4
  %85 = fptrunc float %84 to bfloat
  %86 = getelementptr inbounds nuw bfloat, ptr %64, i64 %82
  store bfloat %85, ptr %86, align 2
  %87 = add i64 %77, 1
  br label %76

88:                                               ; preds = %76
  %89 = add i64 %73, 1
  br label %72

90:                                               ; preds = %72
  %91 = call ptr @malloc(i64 3180)
  %92 = ptrtoint ptr %91 to i64
  %93 = add i64 %92, 63
  %94 = urem i64 %93, 64
  %95 = sub i64 %93, %94
  %96 = inttoptr i64 %95 to ptr
  %97 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_1_prepared(ptr %53, ptr %54, i64 %55, i64 %56, i64 %57, ptr %91, ptr %96, i64 0, i64 19, i64 41, i64 41, i64 1)
  %98 = call ptr @malloc(i64 1622)
  %99 = ptrtoint ptr %98 to i64
  %100 = add i64 %99, 63
  %101 = urem i64 %100, 64
  %102 = sub i64 %100, %101
  %103 = inttoptr i64 %102 to ptr
  %104 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %98, 0
  %105 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %104, ptr %103, 1
  %106 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %105, i64 0, 2
  %107 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, i64 19, 3, 0
  %108 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %107, i64 41, 3, 1
  %109 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %108, i64 41, 4, 0
  %110 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %109, i64 1, 4, 1
  br label %111

111:                                              ; preds = %127, %90
  %112 = phi i64 [ %128, %127 ], [ 0, %90 ]
  %113 = icmp slt i64 %112, 19
  br i1 %113, label %114, label %129

114:                                              ; preds = %111
  br label %115

115:                                              ; preds = %118, %114
  %116 = phi i64 [ %126, %118 ], [ 0, %114 ]
  %117 = icmp slt i64 %116, 41
  br i1 %117, label %118, label %127

118:                                              ; preds = %115
  %119 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %97, 1
  %120 = mul nuw nsw i64 %112, 41
  %121 = add nuw nsw i64 %120, %116
  %122 = getelementptr inbounds nuw float, ptr %119, i64 %121
  %123 = load float, ptr %122, align 4
  %124 = fptrunc float %123 to bfloat
  %125 = getelementptr inbounds nuw bfloat, ptr %103, i64 %121
  store bfloat %124, ptr %125, align 2
  %126 = add i64 %116, 1
  br label %115

127:                                              ; preds = %115
  %128 = add i64 %112, 1
  br label %111

129:                                              ; preds = %111
  %130 = call ptr @malloc(i64 1356)
  %131 = ptrtoint ptr %130 to i64
  %132 = add i64 %131, 63
  %133 = urem i64 %132, 64
  %134 = sub i64 %132, %133
  %135 = inttoptr i64 %134 to ptr
  %136 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_2_prepared(ptr %53, ptr %54, i64 %55, i64 %56, i64 %57, ptr %130, ptr %135, i64 0, i64 19, i64 17, i64 17, i64 1)
  %137 = call ptr @malloc(i64 710)
  %138 = ptrtoint ptr %137 to i64
  %139 = add i64 %138, 63
  %140 = urem i64 %139, 64
  %141 = sub i64 %139, %140
  %142 = inttoptr i64 %141 to ptr
  %143 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %137, 0
  %144 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %143, ptr %142, 1
  %145 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %144, i64 0, 2
  %146 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %145, i64 19, 3, 0
  %147 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %146, i64 17, 3, 1
  %148 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %147, i64 17, 4, 0
  %149 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %148, i64 1, 4, 1
  br label %150

150:                                              ; preds = %166, %129
  %151 = phi i64 [ %167, %166 ], [ 0, %129 ]
  %152 = icmp slt i64 %151, 19
  br i1 %152, label %153, label %168

153:                                              ; preds = %150
  br label %154

154:                                              ; preds = %157, %153
  %155 = phi i64 [ %165, %157 ], [ 0, %153 ]
  %156 = icmp slt i64 %155, 17
  br i1 %156, label %157, label %166

157:                                              ; preds = %154
  %158 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %136, 1
  %159 = mul nuw nsw i64 %151, 17
  %160 = add nuw nsw i64 %159, %155
  %161 = getelementptr inbounds nuw float, ptr %158, i64 %160
  %162 = load float, ptr %161, align 4
  %163 = fptrunc float %162 to bfloat
  %164 = getelementptr inbounds nuw bfloat, ptr %142, i64 %160
  store bfloat %163, ptr %164, align 2
  %165 = add i64 %155, 1
  br label %154

166:                                              ; preds = %154
  %167 = add i64 %151, 1
  br label %150

168:                                              ; preds = %150
  %169 = call ptr @malloc(i64 3142)
  %170 = ptrtoint ptr %169 to i64
  %171 = add i64 %170, 63
  %172 = urem i64 %171, 64
  %173 = sub i64 %171, %172
  %174 = inttoptr i64 %173 to ptr
  %175 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %169, 0
  %176 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %175, ptr %174, 1
  %177 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %176, i64 0, 2
  %178 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %177, i64 19, 3, 0
  %179 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %178, i64 81, 4, 0
  %180 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %179, i64 23, 3, 1
  %181 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %180, i64 1, 4, 1
  %182 = call ptr @llvm.stacksave.p0()
  %183 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %71, ptr %183, align 8
  %184 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %183, 1
  %185 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %181, ptr %185, align 8
  %186 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %185, 1
  %187 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %184, ptr %187, align 8
  %188 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %186, ptr %188, align 8
  call void @memrefCopy(i64 2, ptr %187, ptr %188)
  call void @llvm.stackrestore.p0(ptr %182)
  %189 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %176, i64 23, 2
  %190 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %189, i64 19, 3, 0
  %191 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %190, i64 81, 4, 0
  %192 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %191, i64 41, 3, 1
  %193 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %192, i64 1, 4, 1
  %194 = call ptr @llvm.stacksave.p0()
  %195 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %110, ptr %195, align 8
  %196 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %195, 1
  %197 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %193, ptr %197, align 8
  %198 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %197, 1
  %199 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %196, ptr %199, align 8
  %200 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %198, ptr %200, align 8
  call void @memrefCopy(i64 2, ptr %199, ptr %200)
  call void @llvm.stackrestore.p0(ptr %194)
  %201 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %176, i64 64, 2
  %202 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %201, i64 19, 3, 0
  %203 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %202, i64 81, 4, 0
  %204 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %203, i64 17, 3, 1
  %205 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %204, i64 1, 4, 1
  %206 = call ptr @llvm.stacksave.p0()
  %207 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %149, ptr %207, align 8
  %208 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %207, 1
  %209 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %205, ptr %209, align 8
  %210 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %209, 1
  %211 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %208, ptr %211, align 8
  %212 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %210, ptr %212, align 8
  call void @memrefCopy(i64 2, ptr %211, ptr %212)
  call void @llvm.stackrestore.p0(ptr %206)
  br label %213

213:                                              ; preds = %228, %168
  %214 = phi i64 [ %229, %228 ], [ 0, %168 ]
  %215 = icmp slt i64 %214, 19
  br i1 %215, label %216, label %230

216:                                              ; preds = %213
  br label %217

217:                                              ; preds = %220, %216
  %218 = phi i64 [ %227, %220 ], [ 0, %216 ]
  %219 = icmp slt i64 %218, 81
  br i1 %219, label %220, label %228

220:                                              ; preds = %217
  %221 = mul nuw nsw i64 %214, 81
  %222 = add nuw nsw i64 %221, %218
  %223 = getelementptr inbounds nuw bfloat, ptr %174, i64 %222
  %224 = load bfloat, ptr %223, align 2
  %225 = fpext bfloat %224 to float
  %226 = getelementptr inbounds nuw float, ptr %8, i64 %222
  store float %225, ptr %226, align 4
  %227 = add i64 %218, 1
  br label %217

228:                                              ; preds = %217
  %229 = add i64 %214, 1
  br label %213

230:                                              ; preds = %213
  %231 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %58, 0
  %232 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %58, 1
  %233 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %97, 0
  %234 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %97, 1
  %235 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %136, 0
  %236 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %136, 1
  %237 = call ptr @malloc(i64 104)
  %238 = call ptr @malloc(i64 13)
  %239 = call ptr @malloc(i64 0)
  %240 = ptrtoint ptr %20 to i64
  store i64 %240, ptr %237, align 8
  %241 = ptrtoint ptr %45 to i64
  %242 = getelementptr inbounds nuw i64, ptr %237, i32 1
  store i64 %241, ptr %242, align 8
  %243 = ptrtoint ptr %54 to i64
  %244 = getelementptr inbounds nuw i64, ptr %237, i32 2
  store i64 %243, ptr %244, align 8
  %245 = ptrtoint ptr %52 to i64
  %246 = getelementptr inbounds nuw i64, ptr %237, i32 3
  store i64 %245, ptr %246, align 8
  %247 = ptrtoint ptr %232 to i64
  %248 = getelementptr inbounds nuw i64, ptr %237, i32 4
  store i64 %247, ptr %248, align 8
  %249 = ptrtoint ptr %64 to i64
  %250 = getelementptr inbounds nuw i64, ptr %237, i32 5
  store i64 %249, ptr %250, align 8
  %251 = ptrtoint ptr %96 to i64
  %252 = getelementptr inbounds nuw i64, ptr %237, i32 6
  store i64 %251, ptr %252, align 8
  %253 = ptrtoint ptr %234 to i64
  %254 = getelementptr inbounds nuw i64, ptr %237, i32 7
  store i64 %253, ptr %254, align 8
  %255 = ptrtoint ptr %103 to i64
  %256 = getelementptr inbounds nuw i64, ptr %237, i32 8
  store i64 %255, ptr %256, align 8
  %257 = ptrtoint ptr %135 to i64
  %258 = getelementptr inbounds nuw i64, ptr %237, i32 9
  store i64 %257, ptr %258, align 8
  %259 = ptrtoint ptr %236 to i64
  %260 = getelementptr inbounds nuw i64, ptr %237, i32 10
  store i64 %259, ptr %260, align 8
  %261 = ptrtoint ptr %142 to i64
  %262 = getelementptr inbounds nuw i64, ptr %237, i32 11
  store i64 %261, ptr %262, align 8
  %263 = ptrtoint ptr %174 to i64
  %264 = getelementptr inbounds nuw i64, ptr %237, i32 12
  store i64 %263, ptr %264, align 8
  store i1 true, ptr %238, align 1
  %265 = getelementptr inbounds nuw i1, ptr %238, i32 1
  store i1 true, ptr %265, align 1
  %266 = getelementptr inbounds nuw i1, ptr %238, i32 2
  store i1 true, ptr %266, align 1
  %267 = getelementptr inbounds nuw i1, ptr %238, i32 3
  store i1 true, ptr %267, align 1
  %268 = getelementptr inbounds nuw i1, ptr %238, i32 4
  store i1 true, ptr %268, align 1
  %269 = getelementptr inbounds nuw i1, ptr %238, i32 5
  store i1 true, ptr %269, align 1
  %270 = getelementptr inbounds nuw i1, ptr %238, i32 6
  store i1 true, ptr %270, align 1
  %271 = getelementptr inbounds nuw i1, ptr %238, i32 7
  store i1 true, ptr %271, align 1
  %272 = getelementptr inbounds nuw i1, ptr %238, i32 8
  store i1 true, ptr %272, align 1
  %273 = getelementptr inbounds nuw i1, ptr %238, i32 9
  store i1 true, ptr %273, align 1
  %274 = getelementptr inbounds nuw i1, ptr %238, i32 10
  store i1 true, ptr %274, align 1
  %275 = getelementptr inbounds nuw i1, ptr %238, i32 11
  store i1 true, ptr %275, align 1
  %276 = getelementptr inbounds nuw i1, ptr %238, i32 12
  store i1 true, ptr %276, align 1
  %277 = call ptr @malloc(i64 13)
  %278 = call ptr @malloc(i64 0)
  call void @dealloc_helper(ptr %237, ptr %237, i64 0, i64 13, i64 1, ptr %239, ptr %239, i64 0, i64 0, i64 1, ptr %238, ptr %238, i64 0, i64 13, i64 1, ptr %277, ptr %277, i64 0, i64 13, i64 1, ptr %278, ptr %278, i64 0, i64 0, i64 1)
  call void @free(ptr %278)
  call void @free(ptr %239)
  call void @free(ptr %238)
  call void @free(ptr %237)
  %279 = load i1, ptr %277, align 1
  br i1 %279, label %280, label %281

280:                                              ; preds = %230
  call void @free(ptr %15)
  br label %281

281:                                              ; preds = %280, %230
  %282 = getelementptr inbounds nuw i1, ptr %277, i32 1
  %283 = load i1, ptr %282, align 1
  br i1 %283, label %284, label %285

284:                                              ; preds = %281
  call void @free(ptr %40)
  br label %285

285:                                              ; preds = %284, %281
  %286 = getelementptr inbounds nuw i1, ptr %277, i32 2
  %287 = load i1, ptr %286, align 1
  br i1 %287, label %288, label %289

288:                                              ; preds = %285
  call void @free(ptr %53)
  br label %289

289:                                              ; preds = %288, %285
  %290 = getelementptr inbounds nuw i1, ptr %277, i32 3
  %291 = load i1, ptr %290, align 1
  br i1 %291, label %292, label %293

292:                                              ; preds = %289
  call void @free(ptr %47)
  br label %293

293:                                              ; preds = %292, %289
  %294 = getelementptr inbounds nuw i1, ptr %277, i32 4
  %295 = load i1, ptr %294, align 1
  br i1 %295, label %296, label %297

296:                                              ; preds = %293
  call void @free(ptr %231)
  br label %297

297:                                              ; preds = %296, %293
  %298 = getelementptr inbounds nuw i1, ptr %277, i32 5
  %299 = load i1, ptr %298, align 1
  br i1 %299, label %300, label %301

300:                                              ; preds = %297
  call void @free(ptr %59)
  br label %301

301:                                              ; preds = %300, %297
  %302 = getelementptr inbounds nuw i1, ptr %277, i32 6
  %303 = load i1, ptr %302, align 1
  br i1 %303, label %304, label %305

304:                                              ; preds = %301
  call void @free(ptr %91)
  br label %305

305:                                              ; preds = %304, %301
  %306 = getelementptr inbounds nuw i1, ptr %277, i32 7
  %307 = load i1, ptr %306, align 1
  br i1 %307, label %308, label %309

308:                                              ; preds = %305
  call void @free(ptr %233)
  br label %309

309:                                              ; preds = %308, %305
  %310 = getelementptr inbounds nuw i1, ptr %277, i32 8
  %311 = load i1, ptr %310, align 1
  br i1 %311, label %312, label %313

312:                                              ; preds = %309
  call void @free(ptr %98)
  br label %313

313:                                              ; preds = %312, %309
  %314 = getelementptr inbounds nuw i1, ptr %277, i32 9
  %315 = load i1, ptr %314, align 1
  br i1 %315, label %316, label %317

316:                                              ; preds = %313
  call void @free(ptr %130)
  br label %317

317:                                              ; preds = %316, %313
  %318 = getelementptr inbounds nuw i1, ptr %277, i32 10
  %319 = load i1, ptr %318, align 1
  br i1 %319, label %320, label %321

320:                                              ; preds = %317
  call void @free(ptr %235)
  br label %321

321:                                              ; preds = %320, %317
  %322 = getelementptr inbounds nuw i1, ptr %277, i32 11
  %323 = load i1, ptr %322, align 1
  br i1 %323, label %324, label %325

324:                                              ; preds = %321
  call void @free(ptr %137)
  br label %325

325:                                              ; preds = %324, %321
  %326 = getelementptr inbounds nuw i1, ptr %277, i32 12
  %327 = load i1, ptr %326, align 1
  call void @free(ptr %277)
  br i1 %327, label %328, label %329

328:                                              ; preds = %325
  call void @free(ptr %169)
  br label %329

329:                                              ; preds = %328, %325
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1) {
  %3 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, align 8
  %4 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 0
  %5 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 1
  %6 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 2
  %7 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 0
  %8 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 1
  %9 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 0
  %10 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 1
  %11 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %12 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 0
  %13 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 1
  %14 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 2
  %15 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 0
  %16 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 1
  %17 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 0
  %18 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 1
  call void @forward(ptr %4, ptr %5, i64 %6, i64 %7, i64 %8, i64 %9, i64 %10, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18)
  ret void
}

define private { ptr, ptr, i64, [1 x i64], [1 x i64] } @mx_prepare_a_fp8_m19_k37_pm32_pk64(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %17, i64 %5, 4, 0
  %19 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %18, i64 %4, 3, 1
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %19, i64 %6, 4, 1
  %21 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %21, align 8
  %22 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %7, 0
  %23 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %22, ptr %8, 1
  %24 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %23, i64 %9, 2
  %25 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %24, i64 %10, 3, 0
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %25, i64 %11, 4, 0
  %27 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_prepare_a_fp8_m19_k37_pm32_pk64(ptr %13, ptr %21, ptr %27)
  %28 = load { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [1 x i64], [1 x i64] } %28
}

declare void @_mlir_ciface_mx_prepare_a_fp8_m19_k37_pm32_pk64(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_0_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_0_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_0_prepared(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_1_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_1_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_1_prepared(ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @mx_dense_kernel_2_prepared(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11) {
  %13 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %14 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %15 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %14, ptr %1, 1
  %16 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %15, i64 %2, 2
  %17 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %16, i64 %3, 3, 0
  %18 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %17, i64 %4, 4, 0
  %19 = alloca { ptr, ptr, i64, [1 x i64], [1 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %18, ptr %19, align 8
  %20 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %5, 0
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %20, ptr %6, 1
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, i64 %7, 2
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 %8, 3, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 %10, 4, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %9, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %11, 4, 1
  %27 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, ptr %27, align 8
  call void @_mlir_ciface_mx_dense_kernel_2_prepared(ptr %13, ptr %19, ptr %27)
  %28 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %13, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %28
}

declare void @_mlir_ciface_mx_dense_kernel_2_prepared(ptr, ptr, ptr)

define void @dealloc_helper(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24) {
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %27 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, ptr %6, 1
  %28 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %27, i64 %7, 2
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %28, i64 %8, 3, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, ptr %1, 1
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %2, 2
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %3, 3, 0
  %34 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 3
  %35 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %34, ptr %35, align 8
  %36 = getelementptr [1 x i64], ptr %35, i32 0, i32 0
  %37 = load i64, ptr %36, align 8
  %38 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, 3
  %39 = alloca [1 x i64], i64 1, align 8
  store [1 x i64] %38, ptr %39, align 8
  %40 = getelementptr [1 x i64], ptr %39, i32 0, i32 0
  %41 = load i64, ptr %40, align 8
  br label %42

42:                                               ; preds = %45, %25
  %43 = phi i64 [ %47, %45 ], [ 0, %25 ]
  %44 = icmp slt i64 %43, %41
  br i1 %44, label %45, label %48

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i1, ptr %21, i64 %43
  store i1 false, ptr %46, align 1
  %47 = add i64 %43, 1
  br label %42

48:                                               ; preds = %42
  br label %49

49:                                               ; preds = %84, %48
  %50 = phi i64 [ %87, %84 ], [ 0, %48 ]
  %51 = icmp slt i64 %50, %37
  br i1 %51, label %52, label %88

52:                                               ; preds = %49
  %53 = getelementptr inbounds nuw i64, ptr %1, i64 %50
  %54 = load i64, ptr %53, align 8
  %55 = getelementptr inbounds nuw i1, ptr %11, i64 %50
  %56 = load i1, ptr %55, align 1
  br label %57

57:                                               ; preds = %69, %52
  %58 = phi i64 [ %72, %69 ], [ 0, %52 ]
  %59 = phi i1 [ %71, %69 ], [ true, %52 ]
  %60 = icmp slt i64 %58, %41
  br i1 %60, label %61, label %73

61:                                               ; preds = %57
  %62 = getelementptr inbounds nuw i64, ptr %6, i64 %58
  %63 = load i64, ptr %62, align 8
  %64 = icmp eq i64 %63, %54
  br i1 %64, label %65, label %69

65:                                               ; preds = %61
  %66 = getelementptr inbounds nuw i1, ptr %21, i64 %58
  %67 = load i1, ptr %66, align 1
  %68 = or i1 %67, %56
  store i1 %68, ptr %66, align 1
  br label %69

69:                                               ; preds = %65, %61
  %70 = icmp ne i64 %63, %54
  %71 = and i1 %59, %70
  %72 = add i64 %58, 1
  br label %57

73:                                               ; preds = %57
  br label %74

74:                                               ; preds = %78, %73
  %75 = phi i64 [ %83, %78 ], [ 0, %73 ]
  %76 = phi i1 [ %82, %78 ], [ %59, %73 ]
  %77 = icmp slt i64 %75, %50
  br i1 %77, label %78, label %84

78:                                               ; preds = %74
  %79 = getelementptr inbounds nuw i64, ptr %1, i64 %75
  %80 = load i64, ptr %79, align 8
  %81 = icmp ne i64 %80, %54
  %82 = and i1 %76, %81
  %83 = add i64 %75, 1
  br label %74

84:                                               ; preds = %74
  %85 = and i1 %76, %56
  %86 = getelementptr inbounds nuw i1, ptr %16, i64 %50
  store i1 %85, ptr %86, align 1
  %87 = add i64 %50, 1
  br label %49

88:                                               ; preds = %49
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #0

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
