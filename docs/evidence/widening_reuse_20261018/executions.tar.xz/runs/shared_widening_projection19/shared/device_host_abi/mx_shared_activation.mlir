builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_widening_projection19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<23x37xbf16>, %1: tensor<41x37xbf16>, %2: tensor<17x37xbf16>, %3: tensor<19x37xf32>) -> tensor<19x81xf32> {
    %4 = tensor.empty() : tensor<19x37xbf16>
    %5 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%3 : tensor<19x37xf32>) outs(%4 : tensor<19x37xbf16>) attrs =  {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "bfloat16"} {
    ^bb0(%6: f32, %7: bf16):
      %8 = arith.truncf %6 : f32 to bf16
      linalg.yield %8 : bf16
    } -> tensor<19x37xbf16>
    %9 = tensor.empty() : tensor<19x37xf32>
    %10 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<19x37xbf16>) outs(%9 : tensor<19x37xf32>) attrs =  {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} {
    ^bb1(%11: bf16, %12: f32):
      %13 = arith.extf %11 : bf16 to f32
      linalg.yield %13 : f32
    } -> tensor<19x37xf32>
    %14 = arith.constant {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} 0.000000e+00 : f32
    %15 = tensor.splat %14 {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : tensor<19x23xf32>
    %16 = tensor.empty() : tensor<37x23xf32>
    %17 = tensor.empty() : tensor<2112xi8>
    %18 = func.call @mx_prepare_a_fp8_m19_k37_pm32_pk64(%10, %17) : (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>
    %19 = func.call @mx_dense_kernel_0_prepared(%18, %15) : (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %20 = tensor.empty() : tensor<19x23xbf16>
    %21 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%19 : tensor<19x23xf32>) outs(%20 : tensor<19x23xbf16>) attrs =  {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} {
    ^bb2(%22: f32, %23: bf16):
      %24 = arith.truncf %22 : f32 to bf16
      linalg.yield %24 : bf16
    } -> tensor<19x23xbf16>
    %25 = tensor.empty() : tensor<19x37xf32>
    %26 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<19x37xbf16>) outs(%25 : tensor<19x37xf32>) attrs =  {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} {
    ^bb3(%27: bf16, %28: f32):
      %29 = arith.extf %27 : bf16 to f32
      linalg.yield %29 : f32
    } -> tensor<19x37xf32>
    %30 = arith.constant {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} 0.000000e+00 : f32
    %31 = tensor.splat %30 {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : tensor<19x41xf32>
    %32 = tensor.empty() : tensor<37x41xf32>
    %33 = func.call @mx_dense_kernel_1_prepared(%18, %31) : (tensor<2112xi8>, tensor<19x41xf32>) -> tensor<19x41xf32>
    %34 = tensor.empty() : tensor<19x41xbf16>
    %35 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%33 : tensor<19x41xf32>) outs(%34 : tensor<19x41xbf16>) attrs =  {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} {
    ^bb4(%36: f32, %37: bf16):
      %38 = arith.truncf %36 : f32 to bf16
      linalg.yield %38 : bf16
    } -> tensor<19x41xbf16>
    %39 = tensor.empty() : tensor<19x37xf32>
    %40 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%5 : tensor<19x37xbf16>) outs(%39 : tensor<19x37xf32>) attrs =  {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} {
    ^bb5(%41: bf16, %42: f32):
      %43 = arith.extf %41 : bf16 to f32
      linalg.yield %43 : f32
    } -> tensor<19x37xf32>
    %44 = arith.constant {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} 0.000000e+00 : f32
    %45 = tensor.splat %44 {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : tensor<19x17xf32>
    %46 = tensor.empty() : tensor<37x17xf32>
    %47 = func.call @mx_dense_kernel_2_prepared(%18, %45) : (tensor<2112xi8>, tensor<19x17xf32>) -> tensor<19x17xf32>
    %48 = tensor.empty() : tensor<19x17xbf16>
    %49 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%47 : tensor<19x17xf32>) outs(%48 : tensor<19x17xbf16>) attrs =  {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} {
    ^bb6(%50: f32, %51: bf16):
      %52 = arith.truncf %50 : f32 to bf16
      linalg.yield %52 : bf16
    } -> tensor<19x17xbf16>
    %53 = tensor.concat dim(1) %21, %35, %49 {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "bfloat16"} : (tensor<19x23xbf16>, tensor<19x41xbf16>, tensor<19x17xbf16>) -> tensor<19x81xbf16>
    %54 = tensor.empty() : tensor<19x81xf32>
    %55 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%53 : tensor<19x81xbf16>) outs(%54 : tensor<19x81xf32>) attrs =  {prov.region_id = "dtype_cast_1", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32"} {
    ^bb7(%56: bf16, %57: f32):
      %58 = arith.extf %56 : bf16 to f32
      linalg.yield %58 : f32
    } -> tensor<19x81xf32>
    func.return %55 : tensor<19x81xf32>
  }
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x41xf32>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<19x37xf32>, tensor<37x17xf32>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_prepare_a_fp8_m19_k37_pm32_pk64", function_type = (tensor<19x37xf32>, tensor<2112xi8>) -> tensor<2112xi8>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_0_prepared", function_type = (tensor<2112xi8>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_1_prepared", function_type = (tensor<2112xi8>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "mx_dense_kernel_2_prepared", function_type = (tensor<2112xi8>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}