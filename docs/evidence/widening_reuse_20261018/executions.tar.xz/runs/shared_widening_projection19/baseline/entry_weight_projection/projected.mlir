"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<19x37xf32>) -> tensor<19x81xf32>}> ({
  ^bb0(%0: tensor<19x37xf32>):
    %1 = "tensor.empty"() : () -> tensor<19x37xbf16>
    %2 = "linalg.generic"(%0, %1) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb1(%3: f32, %4: bf16):
      %5 = "arith.truncf"(%3) : (f32) -> bf16
      "linalg.yield"(%5) : (bf16) -> ()
    }) {prov.region_id = "dtype_cast_0", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "bfloat16"} : (tensor<19x37xf32>, tensor<19x37xbf16>) -> tensor<19x37xbf16>
    %6 = "tensor.empty"() : () -> tensor<19x37xf32>
    %7 = "linalg.generic"(%2, %6) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb2(%8: bf16, %9: f32):
      %10 = "arith.extf"(%8) : (bf16) -> f32
      "linalg.yield"(%10) : (f32) -> ()
    }) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : (tensor<19x37xbf16>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %11 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : () -> f32
    %12 = "tensor.splat"(%11) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : (f32) -> tensor<19x23xf32>
    %13 = "tensor.empty"() : () -> tensor<37x23xf32>
    %14 = "func.call"(%7, %13, %12) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>
    %15 = "tensor.empty"() : () -> tensor<19x23xbf16>
    %16 = "linalg.generic"(%14, %15) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb3(%17: f32, %18: bf16):
      %19 = "arith.truncf"(%17) : (f32) -> bf16
      "linalg.yield"(%19) : (bf16) -> ()
    }) {prov.region_id = "matmul_0", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.0"} : (tensor<19x23xf32>, tensor<19x23xbf16>) -> tensor<19x23xbf16>
    %20 = "tensor.empty"() : () -> tensor<19x37xf32>
    %21 = "linalg.generic"(%2, %20) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb4(%22: bf16, %23: f32):
      %24 = "arith.extf"(%22) : (bf16) -> f32
      "linalg.yield"(%24) : (f32) -> ()
    }) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : (tensor<19x37xbf16>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %25 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : () -> f32
    %26 = "tensor.splat"(%25) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : (f32) -> tensor<19x41xf32>
    %27 = "tensor.empty"() : () -> tensor<37x41xf32>
    %28 = "func.call"(%21, %27, %26) <{callee = @merlin_dev_mx_gemmini_1}> : (tensor<19x37xf32>, tensor<37x41xf32>, tensor<19x41xf32>) -> tensor<19x41xf32>
    %29 = "tensor.empty"() : () -> tensor<19x41xbf16>
    %30 = "linalg.generic"(%28, %29) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb5(%31: f32, %32: bf16):
      %33 = "arith.truncf"(%31) : (f32) -> bf16
      "linalg.yield"(%33) : (bf16) -> ()
    }) {prov.region_id = "matmul_1", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.1"} : (tensor<19x41xf32>, tensor<19x41xbf16>) -> tensor<19x41xbf16>
    %34 = "tensor.empty"() : () -> tensor<19x37xf32>
    %35 = "linalg.generic"(%2, %34) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb6(%36: bf16, %37: f32):
      %38 = "arith.extf"(%36) : (bf16) -> f32
      "linalg.yield"(%38) : (f32) -> ()
    }) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : (tensor<19x37xbf16>, tensor<19x37xf32>) -> tensor<19x37xf32>
    %39 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : () -> f32
    %40 = "tensor.splat"(%39) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : (f32) -> tensor<19x17xf32>
    %41 = "tensor.empty"() : () -> tensor<37x17xf32>
    %42 = "func.call"(%35, %41, %40) <{callee = @merlin_dev_mx_gemmini_2}> : (tensor<19x37xf32>, tensor<37x17xf32>, tensor<19x17xf32>) -> tensor<19x17xf32>
    %43 = "tensor.empty"() : () -> tensor<19x17xbf16>
    %44 = "linalg.generic"(%42, %43) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb7(%45: f32, %46: bf16):
      %47 = "arith.truncf"(%45) : (f32) -> bf16
      "linalg.yield"(%47) : (bf16) -> ()
    }) {prov.region_id = "matmul_2", prov.aten = "aten.mm.default", prov.orig_dtype = "bfloat16", prov.module = "projections", prov.fqn = "projections.2"} : (tensor<19x17xf32>, tensor<19x17xbf16>) -> tensor<19x17xbf16>
    %48 = "tensor.concat"(%16, %30, %44) <{dim = 1 : i64}> {prov.region_id = "cat_0", prov.family = "concat", prov._pattern_hint = "cat", prov.op = "cat", prov.aten = "aten.cat.default", prov.orig_dtype = "bfloat16"} : (tensor<19x23xbf16>, tensor<19x41xbf16>, tensor<19x17xbf16>) -> tensor<19x81xbf16>
    %49 = "tensor.empty"() : () -> tensor<19x81xf32>
    %50 = "linalg.generic"(%48, %49) <{indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb8(%51: bf16, %52: f32):
      %53 = "arith.extf"(%51) : (bf16) -> f32
      "linalg.yield"(%53) : (f32) -> ()
    }) {prov.region_id = "dtype_cast_1", prov._pattern_hint = "dtype_cast", prov.op = "dtype_cast", prov.family = "cast", prov.aten = "aten._to_copy.default", prov.orig_dtype = "float32"} : (tensor<19x81xbf16>, tensor<19x81xf32>) -> tensor<19x81xf32>
    "func.return"(%50) : (tensor<19x81xf32>) -> ()
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<19x37xf32>, tensor<37x23xf32>, tensor<19x23xf32>) -> tensor<19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_1", function_type = (tensor<19x37xf32>, tensor<37x41xf32>, tensor<19x41xf32>) -> tensor<19x41xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_2", function_type = (tensor<19x37xf32>, tensor<37x17xf32>, tensor<19x17xf32>) -> tensor<19x17xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/shared_widening_projection19/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()