; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_19x23xf32 = private constant [19 x [23 x float]] zeroinitializer, align 64
@__constant_19x41xf32 = private constant [19 x [41 x float]] zeroinitializer, align 64
@__constant_19x17xf32 = private constant [19 x [17 x float]] zeroinitializer, align 64

declare void @memrefCopy(i64, ptr, ptr)

declare void @free(ptr)

declare ptr @malloc(i64)

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13) {
  %15 = call ptr @malloc(i64 1470)
  %16 = ptrtoint ptr %15 to i64
  %17 = add i64 %16, 63
  %18 = urem i64 %17, 64
  %19 = sub i64 %17, %18
  %20 = inttoptr i64 %19 to ptr
  br label %21

21:                                               ; preds = %36, %14
  %22 = phi i64 [ %37, %36 ], [ 0, %14 ]
  %23 = icmp slt i64 %22, 19
  br i1 %23, label %24, label %38

24:                                               ; preds = %21
  br label %25

25:                                               ; preds = %28, %24
  %26 = phi i64 [ %35, %28 ], [ 0, %24 ]
  %27 = icmp slt i64 %26, 37
  br i1 %27, label %28, label %36

28:                                               ; preds = %25
  %29 = mul nuw nsw i64 %22, 37
  %30 = add nuw nsw i64 %29, %26
  %31 = getelementptr inbounds nuw float, ptr %1, i64 %30
  %32 = load float, ptr %31, align 4
  %33 = fptrunc float %32 to bfloat
  %34 = getelementptr inbounds nuw bfloat, ptr %20, i64 %30
  store bfloat %33, ptr %34, align 2
  %35 = add i64 %26, 1
  br label %25

36:                                               ; preds = %25
  %37 = add i64 %22, 1
  br label %21

38:                                               ; preds = %21
  %39 = call ptr @malloc(i64 2876)
  %40 = ptrtoint ptr %39 to i64
  %41 = add i64 %40, 63
  %42 = urem i64 %41, 64
  %43 = sub i64 %41, %42
  %44 = inttoptr i64 %43 to ptr
  br label %45

45:                                               ; preds = %60, %38
  %46 = phi i64 [ %61, %60 ], [ 0, %38 ]
  %47 = icmp slt i64 %46, 19
  br i1 %47, label %48, label %62

48:                                               ; preds = %45
  br label %49

49:                                               ; preds = %52, %48
  %50 = phi i64 [ %59, %52 ], [ 0, %48 ]
  %51 = icmp slt i64 %50, 37
  br i1 %51, label %52, label %60

52:                                               ; preds = %49
  %53 = mul nuw nsw i64 %46, 37
  %54 = add nuw nsw i64 %53, %50
  %55 = getelementptr inbounds nuw bfloat, ptr %20, i64 %54
  %56 = load bfloat, ptr %55, align 2
  %57 = fpext bfloat %56 to float
  %58 = getelementptr inbounds nuw float, ptr %44, i64 %54
  store float %57, ptr %58, align 4
  %59 = add i64 %50, 1
  br label %49

60:                                               ; preds = %49
  %61 = add i64 %46, 1
  br label %45

62:                                               ; preds = %45
  %63 = call ptr @malloc(i64 3468)
  %64 = ptrtoint ptr %63 to i64
  %65 = add i64 %64, 63
  %66 = urem i64 %65, 64
  %67 = sub i64 %65, %66
  %68 = inttoptr i64 %67 to ptr
  %69 = call ptr @malloc(i64 1812)
  %70 = ptrtoint ptr %69 to i64
  %71 = add i64 %70, 63
  %72 = urem i64 %71, 64
  %73 = sub i64 %71, %72
  %74 = inttoptr i64 %73 to ptr
  %75 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_0(ptr %39, ptr %44, i64 0, i64 19, i64 37, i64 37, i64 1, ptr %63, ptr %68, i64 0, i64 37, i64 23, i64 23, i64 1, ptr %69, ptr %74, i64 0, i64 19, i64 23, i64 23, i64 1)
  %76 = call ptr @malloc(i64 938)
  %77 = ptrtoint ptr %76 to i64
  %78 = add i64 %77, 63
  %79 = urem i64 %78, 64
  %80 = sub i64 %78, %79
  %81 = inttoptr i64 %80 to ptr
  %82 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %76, 0
  %83 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %82, ptr %81, 1
  %84 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %83, i64 0, 2
  %85 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %84, i64 19, 3, 0
  %86 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %85, i64 23, 3, 1
  %87 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %86, i64 23, 4, 0
  %88 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %87, i64 1, 4, 1
  br label %89

89:                                               ; preds = %105, %62
  %90 = phi i64 [ %106, %105 ], [ 0, %62 ]
  %91 = icmp slt i64 %90, 19
  br i1 %91, label %92, label %107

92:                                               ; preds = %89
  br label %93

93:                                               ; preds = %96, %92
  %94 = phi i64 [ %104, %96 ], [ 0, %92 ]
  %95 = icmp slt i64 %94, 23
  br i1 %95, label %96, label %105

96:                                               ; preds = %93
  %97 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %75, 1
  %98 = mul nuw nsw i64 %90, 23
  %99 = add nuw nsw i64 %98, %94
  %100 = getelementptr inbounds nuw float, ptr %97, i64 %99
  %101 = load float, ptr %100, align 4
  %102 = fptrunc float %101 to bfloat
  %103 = getelementptr inbounds nuw bfloat, ptr %81, i64 %99
  store bfloat %102, ptr %103, align 2
  %104 = add i64 %94, 1
  br label %93

105:                                              ; preds = %93
  %106 = add i64 %90, 1
  br label %89

107:                                              ; preds = %89
  call void @free(ptr %69)
  call void @free(ptr %63)
  br label %108

108:                                              ; preds = %123, %107
  %109 = phi i64 [ %124, %123 ], [ 0, %107 ]
  %110 = icmp slt i64 %109, 19
  br i1 %110, label %111, label %125

111:                                              ; preds = %108
  br label %112

112:                                              ; preds = %115, %111
  %113 = phi i64 [ %122, %115 ], [ 0, %111 ]
  %114 = icmp slt i64 %113, 37
  br i1 %114, label %115, label %123

115:                                              ; preds = %112
  %116 = mul nuw nsw i64 %109, 37
  %117 = add nuw nsw i64 %116, %113
  %118 = getelementptr inbounds nuw bfloat, ptr %20, i64 %117
  %119 = load bfloat, ptr %118, align 2
  %120 = fpext bfloat %119 to float
  %121 = getelementptr inbounds nuw float, ptr %44, i64 %117
  store float %120, ptr %121, align 4
  %122 = add i64 %113, 1
  br label %112

123:                                              ; preds = %112
  %124 = add i64 %109, 1
  br label %108

125:                                              ; preds = %108
  %126 = call ptr @malloc(i64 6132)
  %127 = ptrtoint ptr %126 to i64
  %128 = add i64 %127, 63
  %129 = urem i64 %128, 64
  %130 = sub i64 %128, %129
  %131 = inttoptr i64 %130 to ptr
  %132 = call ptr @malloc(i64 3180)
  %133 = ptrtoint ptr %132 to i64
  %134 = add i64 %133, 63
  %135 = urem i64 %134, 64
  %136 = sub i64 %134, %135
  %137 = inttoptr i64 %136 to ptr
  %138 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_1(ptr %39, ptr %44, i64 0, i64 19, i64 37, i64 37, i64 1, ptr %126, ptr %131, i64 0, i64 37, i64 41, i64 41, i64 1, ptr %132, ptr %137, i64 0, i64 19, i64 41, i64 41, i64 1)
  %139 = call ptr @malloc(i64 1622)
  %140 = ptrtoint ptr %139 to i64
  %141 = add i64 %140, 63
  %142 = urem i64 %141, 64
  %143 = sub i64 %141, %142
  %144 = inttoptr i64 %143 to ptr
  %145 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %139, 0
  %146 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %145, ptr %144, 1
  %147 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %146, i64 0, 2
  %148 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %147, i64 19, 3, 0
  %149 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %148, i64 41, 3, 1
  %150 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %149, i64 41, 4, 0
  %151 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %150, i64 1, 4, 1
  br label %152

152:                                              ; preds = %168, %125
  %153 = phi i64 [ %169, %168 ], [ 0, %125 ]
  %154 = icmp slt i64 %153, 19
  br i1 %154, label %155, label %170

155:                                              ; preds = %152
  br label %156

156:                                              ; preds = %159, %155
  %157 = phi i64 [ %167, %159 ], [ 0, %155 ]
  %158 = icmp slt i64 %157, 41
  br i1 %158, label %159, label %168

159:                                              ; preds = %156
  %160 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %138, 1
  %161 = mul nuw nsw i64 %153, 41
  %162 = add nuw nsw i64 %161, %157
  %163 = getelementptr inbounds nuw float, ptr %160, i64 %162
  %164 = load float, ptr %163, align 4
  %165 = fptrunc float %164 to bfloat
  %166 = getelementptr inbounds nuw bfloat, ptr %144, i64 %162
  store bfloat %165, ptr %166, align 2
  %167 = add i64 %157, 1
  br label %156

168:                                              ; preds = %156
  %169 = add i64 %153, 1
  br label %152

170:                                              ; preds = %152
  call void @free(ptr %132)
  call void @free(ptr %126)
  br label %171

171:                                              ; preds = %186, %170
  %172 = phi i64 [ %187, %186 ], [ 0, %170 ]
  %173 = icmp slt i64 %172, 19
  br i1 %173, label %174, label %188

174:                                              ; preds = %171
  br label %175

175:                                              ; preds = %178, %174
  %176 = phi i64 [ %185, %178 ], [ 0, %174 ]
  %177 = icmp slt i64 %176, 37
  br i1 %177, label %178, label %186

178:                                              ; preds = %175
  %179 = mul nuw nsw i64 %172, 37
  %180 = add nuw nsw i64 %179, %176
  %181 = getelementptr inbounds nuw bfloat, ptr %20, i64 %180
  %182 = load bfloat, ptr %181, align 2
  %183 = fpext bfloat %182 to float
  %184 = getelementptr inbounds nuw float, ptr %44, i64 %180
  store float %183, ptr %184, align 4
  %185 = add i64 %176, 1
  br label %175

186:                                              ; preds = %175
  %187 = add i64 %172, 1
  br label %171

188:                                              ; preds = %171
  call void @free(ptr %15)
  %189 = call ptr @malloc(i64 2580)
  %190 = ptrtoint ptr %189 to i64
  %191 = add i64 %190, 63
  %192 = urem i64 %191, 64
  %193 = sub i64 %191, %192
  %194 = inttoptr i64 %193 to ptr
  %195 = call ptr @malloc(i64 1356)
  %196 = ptrtoint ptr %195 to i64
  %197 = add i64 %196, 63
  %198 = urem i64 %197, 64
  %199 = sub i64 %197, %198
  %200 = inttoptr i64 %199 to ptr
  %201 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_2(ptr %39, ptr %44, i64 0, i64 19, i64 37, i64 37, i64 1, ptr %189, ptr %194, i64 0, i64 37, i64 17, i64 17, i64 1, ptr %195, ptr %200, i64 0, i64 19, i64 17, i64 17, i64 1)
  %202 = call ptr @malloc(i64 710)
  %203 = ptrtoint ptr %202 to i64
  %204 = add i64 %203, 63
  %205 = urem i64 %204, 64
  %206 = sub i64 %204, %205
  %207 = inttoptr i64 %206 to ptr
  %208 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %202, 0
  %209 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %208, ptr %207, 1
  %210 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %209, i64 0, 2
  %211 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %210, i64 19, 3, 0
  %212 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %211, i64 17, 3, 1
  %213 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %212, i64 17, 4, 0
  %214 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %213, i64 1, 4, 1
  br label %215

215:                                              ; preds = %231, %188
  %216 = phi i64 [ %232, %231 ], [ 0, %188 ]
  %217 = icmp slt i64 %216, 19
  br i1 %217, label %218, label %233

218:                                              ; preds = %215
  br label %219

219:                                              ; preds = %222, %218
  %220 = phi i64 [ %230, %222 ], [ 0, %218 ]
  %221 = icmp slt i64 %220, 17
  br i1 %221, label %222, label %231

222:                                              ; preds = %219
  %223 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %201, 1
  %224 = mul nuw nsw i64 %216, 17
  %225 = add nuw nsw i64 %224, %220
  %226 = getelementptr inbounds nuw float, ptr %223, i64 %225
  %227 = load float, ptr %226, align 4
  %228 = fptrunc float %227 to bfloat
  %229 = getelementptr inbounds nuw bfloat, ptr %207, i64 %225
  store bfloat %228, ptr %229, align 2
  %230 = add i64 %220, 1
  br label %219

231:                                              ; preds = %219
  %232 = add i64 %216, 1
  br label %215

233:                                              ; preds = %215
  call void @free(ptr %195)
  call void @free(ptr %189)
  call void @free(ptr %39)
  %234 = call ptr @malloc(i64 3142)
  %235 = ptrtoint ptr %234 to i64
  %236 = add i64 %235, 63
  %237 = urem i64 %236, 64
  %238 = sub i64 %236, %237
  %239 = inttoptr i64 %238 to ptr
  %240 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %234, 0
  %241 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %240, ptr %239, 1
  %242 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %241, i64 0, 2
  %243 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %242, i64 19, 3, 0
  %244 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %243, i64 81, 4, 0
  %245 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %244, i64 23, 3, 1
  %246 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %245, i64 1, 4, 1
  %247 = call ptr @llvm.stacksave.p0()
  %248 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %88, ptr %248, align 8
  %249 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %248, 1
  %250 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %246, ptr %250, align 8
  %251 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %250, 1
  %252 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %249, ptr %252, align 8
  %253 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %251, ptr %253, align 8
  call void @memrefCopy(i64 2, ptr %252, ptr %253)
  call void @llvm.stackrestore.p0(ptr %247)
  call void @free(ptr %76)
  %254 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %241, i64 23, 2
  %255 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %254, i64 19, 3, 0
  %256 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %255, i64 81, 4, 0
  %257 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %256, i64 41, 3, 1
  %258 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %257, i64 1, 4, 1
  %259 = call ptr @llvm.stacksave.p0()
  %260 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %151, ptr %260, align 8
  %261 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %260, 1
  %262 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %258, ptr %262, align 8
  %263 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %262, 1
  %264 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %261, ptr %264, align 8
  %265 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %263, ptr %265, align 8
  call void @memrefCopy(i64 2, ptr %264, ptr %265)
  call void @llvm.stackrestore.p0(ptr %259)
  call void @free(ptr %139)
  %266 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %241, i64 64, 2
  %267 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %266, i64 19, 3, 0
  %268 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %267, i64 81, 4, 0
  %269 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %268, i64 17, 3, 1
  %270 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %269, i64 1, 4, 1
  %271 = call ptr @llvm.stacksave.p0()
  %272 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %214, ptr %272, align 8
  %273 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %272, 1
  %274 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %270, ptr %274, align 8
  %275 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %274, 1
  %276 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %273, ptr %276, align 8
  %277 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %275, ptr %277, align 8
  call void @memrefCopy(i64 2, ptr %276, ptr %277)
  call void @llvm.stackrestore.p0(ptr %271)
  call void @free(ptr %202)
  br label %278

278:                                              ; preds = %293, %233
  %279 = phi i64 [ %294, %293 ], [ 0, %233 ]
  %280 = icmp slt i64 %279, 19
  br i1 %280, label %281, label %295

281:                                              ; preds = %278
  br label %282

282:                                              ; preds = %285, %281
  %283 = phi i64 [ %292, %285 ], [ 0, %281 ]
  %284 = icmp slt i64 %283, 81
  br i1 %284, label %285, label %293

285:                                              ; preds = %282
  %286 = mul nuw nsw i64 %279, 81
  %287 = add nuw nsw i64 %286, %283
  %288 = getelementptr inbounds nuw bfloat, ptr %239, i64 %287
  %289 = load bfloat, ptr %288, align 2
  %290 = fpext bfloat %289 to float
  %291 = getelementptr inbounds nuw float, ptr %8, i64 %287
  store float %290, ptr %291, align 4
  %292 = add i64 %283, 1
  br label %282

293:                                              ; preds = %282
  %294 = add i64 %279, 1
  br label %278

295:                                              ; preds = %278
  call void @free(ptr %234)
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1) {
  %3 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, align 8
  %4 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 0
  %5 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 1
  %6 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 2
  %7 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 0
  %8 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 1
  %9 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 0
  %10 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 1
  %11 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %12 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 0
  %13 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 1
  %14 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 2
  %15 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 0
  %16 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 3, 1
  %17 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 0
  %18 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, 4, 1
  call void @forward(ptr %4, ptr %5, i64 %6, i64 %7, i64 %8, i64 %9, i64 %10, ptr %12, ptr %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18)
  ret void
}

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_1(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_1(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_1(ptr, ptr, ptr, ptr)

define private { ptr, ptr, i64, [2 x i64], [2 x i64] } @merlin_dev_mx_gemmini_2(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr %7, ptr %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %14, ptr %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) {
  %22 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, ptr %1, 1
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 %2, 2
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 %3, 3, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 %5, 4, 0
  %28 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %27, i64 %4, 3, 1
  %29 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %28, i64 %6, 4, 1
  %30 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %29, ptr %30, align 8
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %7, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %8, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 %9, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 %10, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 %12, 4, 0
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 %11, 3, 1
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 %13, 4, 1
  %38 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %14, 0
  %40 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %39, ptr %15, 1
  %41 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %40, i64 %16, 2
  %42 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %41, i64 %17, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %42, i64 %19, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %43, i64 %18, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %44, i64 %20, 4, 1
  %46 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %45, ptr %46, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_2(ptr %22, ptr %30, ptr %38, ptr %46)
  %47 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %22, align 8
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %47
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_2(ptr, ptr, ptr, ptr)

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #0

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
