#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_prepare_a_fp8_m160_k5632_pm160_pk5632_kernel(const float *lhs, uint8_t *out) {
  if (!lhs || !out) __builtin_trap();
  if (mx_pack_activation_f32(lhs, 160u, 5632u,
      MX_RUNTIME_FP8, out, out+901120u)) __builtin_trap();
}
