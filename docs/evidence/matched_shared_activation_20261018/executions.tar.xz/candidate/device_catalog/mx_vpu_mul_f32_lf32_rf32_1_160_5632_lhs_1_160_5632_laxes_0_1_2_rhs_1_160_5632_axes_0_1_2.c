#include <stdint.h>
typedef struct { void *allocated, *aligned; intptr_t offset; intptr_t sizes[3], strides[3]; } mx_memref_3d;
extern void mx_vpu_mul_f32_lf32_rf32_1_160_5632_lhs_1_160_5632_laxes_0_1_2_rhs_1_160_5632_axes_0_1_2_kernel(const float *, const float *, float *);
mx_memref_3d mx_vpu_mul_f32_lf32_rf32_1_160_5632_lhs_1_160_5632_laxes_0_1_2_rhs_1_160_5632_axes_0_1_2(
    void *a_alloc,
    void *a_aligned,
    intptr_t a_off,
    intptr_t a_s0,
    intptr_t a_s1,
    intptr_t a_s2,
    intptr_t a_st0,
    intptr_t a_st1,
    intptr_t a_st2,
    void *b_alloc,
    void *b_aligned,
    intptr_t b_off,
    intptr_t b_s0,
    intptr_t b_s1,
    intptr_t b_s2,
    intptr_t b_st0,
    intptr_t b_st1,
    intptr_t b_st2,
    void *c_alloc,
    void *c_aligned,
    intptr_t c_off,
    intptr_t c_s0,
    intptr_t c_s1,
    intptr_t c_s2,
    intptr_t c_st0,
    intptr_t c_st1,
    intptr_t c_st2) {
  if (!a_aligned || !b_aligned || !c_aligned ||
      a_off < 0 || b_off < 0 || c_off < 0 ||
      a_s0 != 1 ||
      a_s1 != 160 ||
      a_s2 != 5632 ||
      b_s0 != 1 ||
      b_s1 != 160 ||
      b_s2 != 5632 ||
      c_s0 != 1 ||
      c_s1 != 160 ||
      c_s2 != 5632 ||
      a_st0 != 901120 ||
      a_st1 != 5632 ||
      a_st2 != 1 ||
      b_st0 != 901120 ||
      b_st1 != 5632 ||
      b_st2 != 1 ||
      c_st0 != 901120 ||
      c_st1 != 5632 ||
      c_st2 != 1) __builtin_trap();
  mx_vpu_mul_f32_lf32_rf32_1_160_5632_lhs_1_160_5632_laxes_0_1_2_rhs_1_160_5632_axes_0_1_2_kernel((const float *)a_aligned + a_off,
           (const float *)b_aligned + b_off,
           (float *)c_aligned + c_off);
  return (mx_memref_3d){c_alloc, c_aligned, c_off,
                                    {1, 160, 5632}, {901120, 5632, 1}};
}
void _mlir_ciface_mx_vpu_mul_f32_lf32_rf32_1_160_5632_lhs_1_160_5632_laxes_0_1_2_rhs_1_160_5632_axes_0_1_2(mx_memref_3d *result,
                          const mx_memref_3d *a,
                          const mx_memref_3d *b,
                          const mx_memref_3d *c) {
  if (!result || !a || !b || !c) __builtin_trap();
  mx_memref_3d returned = mx_vpu_mul_f32_lf32_rf32_1_160_5632_lhs_1_160_5632_laxes_0_1_2_rhs_1_160_5632_axes_0_1_2(
      a->allocated, a->aligned, a->offset, a->sizes[0], a->sizes[1], a->sizes[2], a->strides[0], a->strides[1], a->strides[2],
      b->allocated, b->aligned, b->offset, b->sizes[0], b->sizes[1], b->sizes[2], b->strides[0], b->strides[1], b->strides[2],
      c->allocated, c->aligned, c->offset, c->sizes[0], c->sizes[1], c->sizes[2], c->strides[0], c->strides[1], c->strides[2]);
  volatile mx_memref_3d *destination = (volatile mx_memref_3d *)result;
  destination->allocated = returned.allocated;
  destination->aligned = returned.aligned;
  destination->offset = returned.offset;
  destination->sizes[0] = returned.sizes[0];
  destination->sizes[1] = returned.sizes[1];
  destination->sizes[2] = returned.sizes[2];
  destination->strides[0] = returned.strides[0];
  destination->strides[1] = returned.strides[1];
  destination->strides[2] = returned.strides[2];
}
