#include <stdint.h>
    typedef struct {void *allocated,*aligned; intptr_t offset;
      intptr_t sizes[3],strides[3];} mx_chain_memref;
    extern void mx_vpu_mul_chain_f32_1_160_5632_kernel(const float *,const float *,const float *,float *);
    mx_chain_memref mx_vpu_mul_chain_f32_1_160_5632(void *a_alloc,void *a_aligned,intptr_t a_off,intptr_t a_s0,intptr_t a_s1,intptr_t a_s2,intptr_t a_st0,intptr_t a_st1,intptr_t a_st2,void *b_alloc,void *b_aligned,intptr_t b_off,intptr_t b_s0,intptr_t b_s1,intptr_t b_s2,intptr_t b_st0,intptr_t b_st1,intptr_t b_st2,void *c_alloc,void *c_aligned,intptr_t c_off,intptr_t c_s0,intptr_t c_s1,intptr_t c_s2,intptr_t c_st0,intptr_t c_st1,intptr_t c_st2,void *d_alloc,void *d_aligned,intptr_t d_off,intptr_t d_s0,intptr_t d_s1,intptr_t d_s2,intptr_t d_st0,intptr_t d_st1,intptr_t d_st2) {
      if(!a_aligned || a_off < 0 || a_s0 != 1 || a_s1 != 160 || a_s2 != 5632 || a_st0 != 901120 || a_st1 != 5632 || a_st2 != 1 || !b_aligned || b_off < 0 || b_s0 != 1 || b_s1 != 160 || b_s2 != 5632 || b_st0 != 901120 || b_st1 != 5632 || b_st2 != 1 || !c_aligned || c_off < 0 || c_s0 != 1 || c_s1 != 160 || c_s2 != 5632 || c_st0 != 901120 || c_st1 != 5632 || c_st2 != 1 || !d_aligned || d_off < 0 || d_s0 != 1 || d_s1 != 160 || d_s2 != 5632 || d_st0 != 901120 || d_st1 != 5632 || d_st2 != 1) __builtin_trap();
      mx_vpu_mul_chain_f32_1_160_5632_kernel((const float *)a_aligned+a_off,(const float *)b_aligned+b_off,
               (const float *)c_aligned+c_off,(float *)d_aligned+d_off);
      return (mx_chain_memref){d_alloc,d_aligned,d_off,
        {1,160,5632},{901120,5632,1}};
    }
    void _mlir_ciface_mx_vpu_mul_chain_f32_1_160_5632(mx_chain_memref *result,const mx_chain_memref *a,
      const mx_chain_memref *b,const mx_chain_memref *c,const mx_chain_memref *d) {
      if(!result || !a || !b || !c || !d) __builtin_trap();
      mx_chain_memref r=mx_vpu_mul_chain_f32_1_160_5632(a->allocated,a->aligned,a->offset,a->sizes[0],a->sizes[1],a->sizes[2],a->strides[0],a->strides[1],a->strides[2],b->allocated,b->aligned,b->offset,b->sizes[0],b->sizes[1],b->sizes[2],b->strides[0],b->strides[1],b->strides[2],c->allocated,c->aligned,c->offset,c->sizes[0],c->sizes[1],c->sizes[2],c->strides[0],c->strides[1],c->strides[2],d->allocated,d->aligned,d->offset,d->sizes[0],d->sizes[1],d->sizes[2],d->strides[0],d->strides[1],d->strides[2]); result->allocated=r.allocated;
result->aligned=r.aligned;
result->offset=r.offset;
result->sizes[0]=r.sizes[0];
result->sizes[1]=r.sizes[1];
result->sizes[2]=r.sizes[2];
result->strides[0]=r.strides[0];
result->strides[1]=r.strides[1];
result->strides[2]=r.strides[2];
    }
