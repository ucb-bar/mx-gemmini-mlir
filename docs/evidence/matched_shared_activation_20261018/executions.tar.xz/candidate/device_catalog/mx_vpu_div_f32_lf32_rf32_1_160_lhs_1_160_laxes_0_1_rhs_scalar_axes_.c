#include <stdint.h>
typedef struct { void *allocated, *aligned; intptr_t offset; } mx_memref_0d;
typedef struct { void *allocated, *aligned; intptr_t offset; intptr_t sizes[2], strides[2]; } mx_memref_2d;
extern void mx_vpu_div_f32_lf32_rf32_1_160_lhs_1_160_laxes_0_1_rhs_scalar_axes__kernel(const float *, const float *, float *);
mx_memref_2d mx_vpu_div_f32_lf32_rf32_1_160_lhs_1_160_laxes_0_1_rhs_scalar_axes_(
    void *a_alloc,
    void *a_aligned,
    intptr_t a_off,
    intptr_t a_s0,
    intptr_t a_s1,
    intptr_t a_st0,
    intptr_t a_st1,
    void *b_alloc,
    void *b_aligned,
    intptr_t b_off,
    void *c_alloc,
    void *c_aligned,
    intptr_t c_off,
    intptr_t c_s0,
    intptr_t c_s1,
    intptr_t c_st0,
    intptr_t c_st1) {
  if (!a_aligned || !b_aligned || !c_aligned ||
      a_off < 0 || b_off < 0 || c_off < 0 ||
      a_s0 != 1 ||
      a_s1 != 160 ||
      c_s0 != 1 ||
      c_s1 != 160 ||
      a_st0 != 160 ||
      a_st1 != 1 ||
      c_st0 != 160 ||
      c_st1 != 1) __builtin_trap();
  mx_vpu_div_f32_lf32_rf32_1_160_lhs_1_160_laxes_0_1_rhs_scalar_axes__kernel((const float *)a_aligned + a_off,
           (const float *)b_aligned + b_off,
           (float *)c_aligned + c_off);
  return (mx_memref_2d){c_alloc, c_aligned, c_off,
                                    {1, 160}, {160, 1}};
}
void _mlir_ciface_mx_vpu_div_f32_lf32_rf32_1_160_lhs_1_160_laxes_0_1_rhs_scalar_axes_(mx_memref_2d *result,
                          const mx_memref_2d *a,
                          const mx_memref_0d *b,
                          const mx_memref_2d *c) {
  if (!result || !a || !b || !c) __builtin_trap();
  mx_memref_2d returned = mx_vpu_div_f32_lf32_rf32_1_160_lhs_1_160_laxes_0_1_rhs_scalar_axes_(
      a->allocated, a->aligned, a->offset, a->sizes[0], a->sizes[1], a->strides[0], a->strides[1],
      b->allocated, b->aligned, b->offset,
      c->allocated, c->aligned, c->offset, c->sizes[0], c->sizes[1], c->strides[0], c->strides[1]);
  volatile mx_memref_2d *destination = (volatile mx_memref_2d *)result;
  destination->allocated = returned.allocated;
  destination->aligned = returned.aligned;
  destination->offset = returned.offset;
  destination->sizes[0] = returned.sizes[0];
  destination->sizes[1] = returned.sizes[1];
  destination->strides[0] = returned.strides[0];
  destination->strides[1] = returned.strides[1];
}
