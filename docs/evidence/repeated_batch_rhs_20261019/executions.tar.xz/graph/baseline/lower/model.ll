; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"

@__constant_6x19x23xf32 = private constant [6 x [19 x [23 x float]]] zeroinitializer, align 64

declare void @free(ptr)

declare ptr @malloc(i64)

define void @forward(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7, i64 %8, ptr %9, ptr %10, i64 %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, i64 %17, ptr %18, ptr %19, i64 %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26) {
  %28 = call ptr @malloc(i64 20488)
  %29 = ptrtoint ptr %28 to i64
  %30 = add i64 %29, 63
  %31 = urem i64 %30, 64
  %32 = sub i64 %30, %31
  %33 = inttoptr i64 %32 to ptr
  br label %34

34:                                               ; preds = %68, %27
  %35 = phi i64 [ %69, %68 ], [ 0, %27 ]
  %36 = icmp slt i64 %35, 2
  br i1 %36, label %37, label %70

37:                                               ; preds = %34
  br label %38

38:                                               ; preds = %66, %37
  %39 = phi i64 [ %67, %66 ], [ 0, %37 ]
  %40 = icmp slt i64 %39, 3
  br i1 %40, label %41, label %68

41:                                               ; preds = %38
  br label %42

42:                                               ; preds = %64, %41
  %43 = phi i64 [ %65, %64 ], [ 0, %41 ]
  %44 = icmp slt i64 %43, 23
  br i1 %44, label %45, label %66

45:                                               ; preds = %42
  br label %46

46:                                               ; preds = %49, %45
  %47 = phi i64 [ %63, %49 ], [ 0, %45 ]
  %48 = icmp slt i64 %47, 37
  br i1 %48, label %49, label %64

49:                                               ; preds = %46
  %50 = mul nuw nsw i64 %35, 851
  %51 = add nuw nsw i64 %50, 0
  %52 = mul nuw nsw i64 %43, 37
  %53 = add nuw nsw i64 %51, %52
  %54 = add nuw nsw i64 %53, %47
  %55 = getelementptr inbounds nuw float, ptr %10, i64 %54
  %56 = load float, ptr %55, align 4
  %57 = mul nuw nsw i64 %35, 2553
  %58 = mul nuw nsw i64 %39, 851
  %59 = add nuw nsw i64 %57, %58
  %60 = add nuw nsw i64 %59, %52
  %61 = add nuw nsw i64 %60, %47
  %62 = getelementptr inbounds nuw float, ptr %33, i64 %61
  store float %56, ptr %62, align 4
  %63 = add i64 %47, 1
  br label %46

64:                                               ; preds = %46
  %65 = add i64 %43, 1
  br label %42

66:                                               ; preds = %42
  %67 = add i64 %39, 1
  br label %38

68:                                               ; preds = %38
  %69 = add i64 %35, 1
  br label %34

70:                                               ; preds = %34
  %71 = call ptr @malloc(i64 20488)
  %72 = ptrtoint ptr %71 to i64
  %73 = add i64 %72, 63
  %74 = urem i64 %73, 64
  %75 = sub i64 %73, %74
  %76 = inttoptr i64 %75 to ptr
  br label %77

77:                                               ; preds = %110, %70
  %78 = phi i64 [ %111, %110 ], [ 0, %70 ]
  %79 = icmp slt i64 %78, 2
  br i1 %79, label %80, label %112

80:                                               ; preds = %77
  br label %81

81:                                               ; preds = %108, %80
  %82 = phi i64 [ %109, %108 ], [ 0, %80 ]
  %83 = icmp slt i64 %82, 3
  br i1 %83, label %84, label %110

84:                                               ; preds = %81
  br label %85

85:                                               ; preds = %106, %84
  %86 = phi i64 [ %107, %106 ], [ 0, %84 ]
  %87 = icmp slt i64 %86, 37
  br i1 %87, label %88, label %108

88:                                               ; preds = %85
  br label %89

89:                                               ; preds = %92, %88
  %90 = phi i64 [ %105, %92 ], [ 0, %88 ]
  %91 = icmp slt i64 %90, 23
  br i1 %91, label %92, label %106

92:                                               ; preds = %89
  %93 = mul nuw nsw i64 %78, 2553
  %94 = mul nuw nsw i64 %82, 851
  %95 = add nuw nsw i64 %93, %94
  %96 = mul nuw nsw i64 %90, 37
  %97 = add nuw nsw i64 %95, %96
  %98 = add nuw nsw i64 %97, %86
  %99 = getelementptr inbounds nuw float, ptr %33, i64 %98
  %100 = load float, ptr %99, align 4
  %101 = mul nuw nsw i64 %86, 23
  %102 = add nuw nsw i64 %95, %101
  %103 = add nuw nsw i64 %102, %90
  %104 = getelementptr inbounds nuw float, ptr %76, i64 %103
  store float %100, ptr %104, align 4
  %105 = add i64 %90, 1
  br label %89

106:                                              ; preds = %89
  %107 = add i64 %86, 1
  br label %85

108:                                              ; preds = %85
  %109 = add i64 %82, 1
  br label %81

110:                                              ; preds = %81
  %111 = add i64 %78, 1
  br label %77

112:                                              ; preds = %77
  call void @free(ptr %28)
  %113 = call ptr @malloc(i64 10552)
  %114 = ptrtoint ptr %113 to i64
  %115 = add i64 %114, 63
  %116 = urem i64 %115, 64
  %117 = sub i64 %115, %116
  %118 = inttoptr i64 %117 to ptr
  %119 = call { ptr, ptr, i64, [3 x i64], [3 x i64] } @merlin_dev_mx_gemmini_0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7, i64 %8, ptr %71, ptr %76, i64 0, i64 6, i64 37, i64 23, i64 851, i64 23, i64 1, ptr %113, ptr %118, i64 0, i64 6, i64 19, i64 23, i64 437, i64 23, i64 1)
  %120 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %119, 3, 0
  %121 = mul i64 %120, 1
  %122 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %119, 3, 1
  %123 = mul i64 %121, %122
  %124 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %119, 3, 2
  %125 = mul i64 %123, %124
  %126 = mul i64 %125, 4
  %127 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %119, 1
  %128 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %119, 2
  %129 = getelementptr float, ptr %127, i64 %128
  %130 = getelementptr float, ptr %19, i64 %20
  call void @llvm.memcpy.p0.p0.i64(ptr %130, ptr %129, i64 %126, i1 false)
  call void @free(ptr %113)
  call void @free(ptr %71)
  ret void
}

define void @_mlir_ciface_forward(ptr %0, ptr %1, ptr %2) {
  %4 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %0, align 8
  %5 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 0
  %6 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 1
  %7 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 2
  %8 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 3, 0
  %9 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 3, 1
  %10 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 3, 2
  %11 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 4, 0
  %12 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 4, 1
  %13 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %4, 4, 2
  %14 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %1, align 8
  %15 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 0
  %16 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 1
  %17 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 2
  %18 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 3, 0
  %19 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 3, 1
  %20 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 3, 2
  %21 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 4, 0
  %22 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 4, 1
  %23 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %14, 4, 2
  %24 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %2, align 8
  %25 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 0
  %26 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 1
  %27 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 2
  %28 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 3, 0
  %29 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 3, 1
  %30 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 3, 2
  %31 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 4, 0
  %32 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 4, 1
  %33 = extractvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %24, 4, 2
  call void @forward(ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, i64 %20, i64 %21, i64 %22, i64 %23, ptr %25, ptr %26, i64 %27, i64 %28, i64 %29, i64 %30, i64 %31, i64 %32, i64 %33)
  ret void
}

define private { ptr, ptr, i64, [3 x i64], [3 x i64] } @merlin_dev_mx_gemmini_0(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, i64 %7, i64 %8, ptr %9, ptr %10, i64 %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, i64 %17, ptr %18, ptr %19, i64 %20, i64 %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26) {
  %28 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  %29 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } poison, ptr %0, 0
  %30 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %29, ptr %1, 1
  %31 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %30, i64 %2, 2
  %32 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %31, i64 %3, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %32, i64 %6, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %33, i64 %4, 3, 1
  %35 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %34, i64 %7, 4, 1
  %36 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %35, i64 %5, 3, 2
  %37 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %36, i64 %8, 4, 2
  %38 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [3 x i64], [3 x i64] } %37, ptr %38, align 8
  %39 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } poison, ptr %9, 0
  %40 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %39, ptr %10, 1
  %41 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %40, i64 %11, 2
  %42 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %41, i64 %12, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %42, i64 %15, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %43, i64 %13, 3, 1
  %45 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %44, i64 %16, 4, 1
  %46 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %45, i64 %14, 3, 2
  %47 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %46, i64 %17, 4, 2
  %48 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [3 x i64], [3 x i64] } %47, ptr %48, align 8
  %49 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } poison, ptr %18, 0
  %50 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %49, ptr %19, 1
  %51 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %50, i64 %20, 2
  %52 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %51, i64 %21, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %52, i64 %24, 4, 0
  %54 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %53, i64 %22, 3, 1
  %55 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %54, i64 %25, 4, 1
  %56 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %55, i64 %23, 3, 2
  %57 = insertvalue { ptr, ptr, i64, [3 x i64], [3 x i64] } %56, i64 %26, 4, 2
  %58 = alloca { ptr, ptr, i64, [3 x i64], [3 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [3 x i64], [3 x i64] } %57, ptr %58, align 8
  call void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr %28, ptr %38, ptr %48, ptr %58)
  %59 = load { ptr, ptr, i64, [3 x i64], [3 x i64] }, ptr %28, align 8
  ret { ptr, ptr, i64, [3 x i64], [3 x i64] } %59
}

declare void @_mlir_ciface_merlin_dev_mx_gemmini_0(ptr, ptr, ptr, ptr)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
