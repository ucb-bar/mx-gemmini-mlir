"builtin.module"() ({
  "func.func"() <{sym_name = "forward", function_type = (tensor<6x19x37xf32>, tensor<2x23x37xf32>) -> tensor<6x19x23xf32>}> ({
  ^bb0(%0: tensor<6x19x37xf32>, %1: tensor<2x23x37xf32>):
    %2 = "tensor.collapse_shape"(%1) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]]}> {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : (tensor<2x23x37xf32>) -> tensor<1702xf32>
    %3 = "tensor.expand_shape"(%2) <{reassociation = [[0 : i64, 1 : i64, 2 : i64, 3 : i64]], static_output_shape = array<i64: 2, 1, 23, 37>}> {prov.region_id = "unsqueeze_0", prov._pattern_hint = "unsqueeze", prov.op = "unsqueeze", prov.family = "layout", prov.aten = "aten.unsqueeze.default", prov.orig_dtype = "float32"} : (tensor<1702xf32>) -> tensor<2x1x23x37xf32>
    %4 = "tensor.empty"() : () -> tensor<2x3x23x37xf32>
    %5 = "linalg.generic"(%3, %4) <{indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, 0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb1(%6: f32, %7: f32):
      "linalg.yield"(%6) : (f32) -> ()
    }) {prov.region_id = "expand_0", prov._pattern_hint = "expand", prov.op = "expand", prov.family = "layout", prov.aten = "aten.expand.default", prov.orig_dtype = "float32"} : (tensor<2x1x23x37xf32>, tensor<2x3x23x37xf32>) -> tensor<2x3x23x37xf32>
    %8 = "tensor.collapse_shape"(%5) <{reassociation = [[0 : i64, 1 : i64, 2 : i64, 3 : i64]]}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<2x3x23x37xf32>) -> tensor<5106xf32>
    %9 = "tensor.expand_shape"(%8) <{reassociation = [[0 : i64, 1 : i64, 2 : i64]], static_output_shape = array<i64: 6, 23, 37>}> {prov.region_id = "view_0", prov._pattern_hint = "view", prov.op = "view", prov.family = "layout", prov.aten = "aten.view.default", prov.orig_dtype = "float32"} : (tensor<5106xf32>) -> tensor<6x23x37xf32>
    %10 = "tensor.empty"() : () -> tensor<6x37x23xf32>
    %11 = "linalg.transpose"(%9, %10) <{permutation = array<i64: 0, 2, 1>}> ({
    ^bb2(%12: f32, %13: f32):
      "linalg.yield"(%12) : (f32) -> ()
    }) : (tensor<6x23x37xf32>, tensor<6x37x23xf32>) -> tensor<6x37x23xf32>
    %14 = "arith.constant"() <{value = 0.000000e+00 : f32}> {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : () -> f32
    %15 = "tensor.splat"(%14) {prov.region_id = "matmul_0", prov.family = "contraction", prov._pattern_hint = "batch_matmul", prov.op = "batch_matmul", prov.aten = "aten.bmm.default", prov.orig_dtype = "float32"} : (f32) -> tensor<6x19x23xf32>
    %16 = "func.call"(%0, %11, %15) <{callee = @merlin_dev_mx_gemmini_0}> : (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>
    "func.return"(%16) : (tensor<6x19x23xf32>) -> ()
  }) {llvm.emit_c_interface} : () -> ()
  "func.func"() <{sym_name = "merlin_dev_mx_gemmini_0", function_type = (tensor<6x19x37xf32>, tensor<6x37x23xf32>, tensor<6x19x23xf32>) -> tensor<6x19x23xf32>, sym_visibility = "private", arg_attrs = [{bufferization.access = "read"}, {bufferization.access = "read"}, {bufferization.access = "write"}]}> ({
  }) {llvm.emit_c_interface} : () -> ()
}) {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/repeated_batch_matmul_tail_capture/capture/weights.safetensors", prov.level = "linalg-on-tensors"} : () -> ()