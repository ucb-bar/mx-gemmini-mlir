import json
import os
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
task = base.parent.parent
role = sys.argv[1]
assert role in ('baseline', 'retained')
capture = base / 'repeated_batch_matmul_tail_capture'
template = json.loads((base / 'detached_full160_20261019/rms_reverse_control/spec.json').read_text())
env = os.environ.copy()
env.update(template['environment'])
command = [template['command'][0], '-m', 'tools.build_merlin_stage', '--stage', str(capture / 'capture'),
           '--workdir', str(base / ('repeated_batch_matmul_tail_' + role)),
           '--profile', template['command'][template['command'].index('--profile') + 1],
           '--merlin-src', str(task / 'merlin/src'), '--llvm-install', '/scratch/agustin/projects/oscar-merlin/third_party/llvm-install',
           '--riscv-root', '/scratch/agustin/projects/chipyard/.conda-env/riscv-tools',
           '--execution-policy', str(capture / 'policy.json'), '--integer-quant-groups', '--prepack-checkpoint-weights',
           '--structural-elf-admission', '--output-dump-cap', '2622', '--compile-timeout-s', '6000',
           '--spike-extlib', str(task / 'mx-gemmini-mlir/docs/evidence/nicolas_e4m3_lut_requant_public_74bceeb_266c593/physical/libgemmini.so'),
           '--spike-timeout', '600']
if role == 'retained':
    command += ['--reuse-batch-rhs']
(base / ('repeated_batch_matmul_tail_' + role + '.command.json')).write_text(json.dumps(command, indent=2) + '\n')
log = base / ('repeated_batch_matmul_tail_' + role + '.log')
with log.open('w') as output:
    result = subprocess.run(command, cwd=task / 'mx-gemmini-mlir', env=env, stdout=output, stderr=subprocess.STDOUT)
print(role, result.returncode, flush=True)
if result.returncode:
    print(log.read_text()[-7000:], flush=True)
sys.exit(result.returncode)
