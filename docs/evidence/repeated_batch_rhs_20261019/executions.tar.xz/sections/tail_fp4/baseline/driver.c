#include <stdint.h>
#include <stdio.h>
extern const unsigned char payload[];
void produce(const float *,const float *,float *);
void __attribute__((noreturn)) tohost_exit(uintptr_t);
static float a[4250],b[5138],out[2654] __attribute__((aligned(64)));
static unsigned run;
static float value(uint32_t u){union{float f;uint32_t u;}w;w.u=u;return w.f;}
static uint32_t bits(float f){union{float f;uint32_t u;}w;w.f=f;return w.u;}
static uint64_t cycle(void){uint64_t n;asm volatile("rdcycle %0":"=r"(n)::"memory");return n;}
static void dump(void){
 unsigned guard=0;
 for(unsigned i=0;i<16;++i)guard+=bits(a[i])!=0xa5a50000u||bits(a[4218+16+i])!=0xa5a50000u||bits(b[i])!=0xa5a50000u||bits(b[5106+16+i])!=0xa5a50000u||bits(out[i])!=0xa5a50000u||bits(out[2622+16+i])!=0xa5a50000u;
 for(unsigned i=0;i<2622;++i){if(i%16==0)printf("WORDS %u %u ",run,i);printf("%08x ",bits(out[16+i]));if(i%16==15||i==2621)printf("\n");}
 printf("STATUS run=%u guard=%u\n",run,guard);
}
uintptr_t handle_trap(uintptr_t cause,uintptr_t pc,uintptr_t regs[32]){
 (void)regs;dump();printf("TRAP cause=%lu pc=%lu\n",(unsigned long)cause,(unsigned long)pc);tohost_exit(77);
}
int main(void){
 for(run=0;run<3;++run){
  for(unsigned i=0;i<4250;++i)a[i]=value(0xa5a50000u);
  for(unsigned i=0;i<5138;++i)b[i]=value(0xa5a50000u);
  for(unsigned i=0;i<2654;++i)out[i]=value(0xa5a50000u);
  for(unsigned i=0;i<4218;++i)a[i+16]=((const float*)payload)[i];
  for(unsigned i=0;i<5106;++i)b[i+16]=((const float*)payload)[4218+i];
  if(!0)for(unsigned group=0;group<2;++group)if((run==1&&group==0)||(run==2&&group==1))for(unsigned r=0;r<3;++r)b[16+(group*3+r)*851]=-b[16+(group*3+r)*851];
  uint64_t t=cycle();produce(a+16,b+16,out+16);t=cycle()-t;
  printf("PERF run=%u cycles=%lu\n",run,(unsigned long)t);dump();
 }
 printf("DONE\n");return 0;
}
