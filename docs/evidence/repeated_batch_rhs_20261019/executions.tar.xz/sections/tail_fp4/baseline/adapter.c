/* MX dense f32 adapter: FP4, qualified 32x32x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void native_issue(const void *, const void *, const void *, const void *,
                     const void *, const void *);
static float padded_a[2048] __attribute__((aligned(64)));
static float padded_b[2048] __attribute__((aligned(64)));
static uint8_t activation[1024] __attribute__((aligned(64)));
static uint8_t activation_scales[64] __attribute__((aligned(64)));
static uint8_t weight[1024] __attribute__((aligned(64)));
static uint8_t weight_scales[64] __attribute__((aligned(64)));
static uint16_t output_bf16[1024] __attribute__((aligned(64)));
static uint8_t scratch_output_scales[2048] __attribute__((aligned(64)));

void produce_slice(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t i = 0; i < 2048u; ++i) padded_a[i] = 0;
  for (size_t row = 0; row < 19u; ++row)
    for (size_t col = 0; col < 37u; ++col)
      padded_a[row * 64u + col] = lhs[row * 37u + col];
  for (size_t i = 0; i < 2048u; ++i) padded_b[i] = 0;
  for (size_t row = 0; row < 37u; ++row)
    for (size_t col = 0; col < 23u; ++col)
      padded_b[row * 32u + col] = rhs[row * 23u + col];
  if (mx_pack_activation_f32(padded_a, 32u, 64u, MX_RUNTIME_FP4,
                             activation, activation_scales) ||
      mx_pack_weight_f32(padded_b, 64u, 32u, MX_RUNTIME_FP4,
                         weight, weight_scales)) __builtin_trap();
  native_issue(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 19u; ++row)
    for (uint32_t col = 0; col < 23u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 32u + col] << 16;
      out[(size_t)row * 23u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void produce(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 6u; ++batch)
    produce_slice(lhs + batch * 19u * 37u,
                   rhs + batch * 37u * 23u,
                   out + batch * 19u * 23u);
}
