/* MX dense f32 adapter: FP8, qualified 16x160x64 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void native_issue(const void *, const void *, const void *, const void *,
                     const void *, const void *);
static uint8_t activation[1024] __attribute__((aligned(64)));
static uint8_t activation_scales[32] __attribute__((aligned(64)));
static uint8_t weight[10240] __attribute__((aligned(64)));
static uint8_t weight_scales[320] __attribute__((aligned(64)));
static uint16_t output_bf16[2560] __attribute__((aligned(64)));
static uint8_t scratch_output_scales[2048] __attribute__((aligned(64)));

static void produce_slice(const float *lhs, const float *rhs, float *out, unsigned prepare_weight) {
  if (!lhs || !rhs || !out) __builtin_trap();
  if (mx_pack_activation_zero_rows_f32(lhs, 1u, 16u, 64u, MX_RUNTIME_FP8,
                             activation, activation_scales) ||
      (prepare_weight && mx_pack_weight_f32(rhs, 64u, 160u, MX_RUNTIME_FP8,
                         weight, weight_scales))) __builtin_trap();
  native_issue(activation, activation_scales, weight, weight_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 1u; ++row)
    for (uint32_t col = 0; col < 160u; ++col) {
      union { uint32_t bits; float value; } word;
      word.bits = (uint32_t)output_bf16[(size_t)row * 160u + col] << 16;
      out[(size_t)row * 160u + col] = word.value;
    }
}

/* Whole-batch Merlin ABI: each slice has independent dense row-major storage. */
void produce(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (size_t batch = 0; batch < 32u; ++batch)
    produce_slice(lhs + batch * 1u * 64u,
                   rhs + batch * 64u * 160u,
                   out + batch * 1u * 160u, batch % 8u == 0u);
}
