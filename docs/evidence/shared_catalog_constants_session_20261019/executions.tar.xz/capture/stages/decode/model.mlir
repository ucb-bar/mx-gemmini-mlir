builtin.module attributes {prov.weights_file = "/scratch/agustin/merlin/tasks/mx-vpu-four-model-e2e/.tmp/mx_model_goal_20261018/guarded_session_fixture_20261019/capture/stages/decode/weights.safetensors", prov.level = "linalg-on-tensors"} {
  func.func @forward(%0: tensor<32x32xf32>, %1: tensor<32xf32>, %2: tensor<16x32xf32>, %3: tensor<16x32xf32>) -> (tensor<16x32xf32>, tensor<16x32xf32>) {
    %4 = tensor.empty() : tensor<32x32xf32>
    %5 = linalg.transpose ins(%0:tensor<32x32xf32>) outs(%4:tensor<32x32xf32>) permutation = [1, 0]
    %6 = tensor.empty() : tensor<16x32xf32>
    %7 = arith.constant {prov.module = "linear"} 0.000000e+00 : f32
    %8 = linalg.fill {prov.op = "fill", prov.family = "fill", prov.module = "linear"} ins(%7 : f32) outs(%6 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %9 = linalg.matmul {prov.region_id = "matmul_0", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear", prov.transposed_b = "true"} ins(%2, %5 : tensor<16x32xf32>, tensor<32x32xf32>) outs(%8 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %10 = tensor.empty() : tensor<16x32xf32>
    %11 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%9, %1 : tensor<16x32xf32>, tensor<32xf32>) outs(%10 : tensor<16x32xf32>) attrs =  {prov.region_id = "add_0", prov._pattern_hint = "addmm", prov.op = "addmm", prov.family = "contraction", prov.aten = "aten.addmm.default", prov.orig_dtype = "float32", prov.module = "linear", prov.fqn = "linear"} {
    ^bb0(%12: f32, %13: f32, %14: f32):
      %15 = arith.addf %12, %13 : f32
      linalg.yield %15 : f32
    } -> tensor<16x32xf32>
    %16 = tensor.empty() : tensor<16x32xf32>
    %17 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%11, %3 : tensor<16x32xf32>, tensor<16x32xf32>) outs(%16 : tensor<16x32xf32>) attrs =  {prov.region_id = "add_1", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} {
    ^bb1(%18: f32, %19: f32, %20: f32):
      %21 = arith.addf %18, %19 : f32
      linalg.yield %21 : f32
    } -> tensor<16x32xf32>
    %22 = arith.constant {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} 1.250000e-01 : f32
    %23 = tensor.splat %22 {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} : tensor<16x32xf32>
    %24 = tensor.empty() : tensor<16x32xf32>
    %25 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%17, %23 : tensor<16x32xf32>, tensor<16x32xf32>) outs(%24 : tensor<16x32xf32>) attrs =  {prov.region_id = "mul_0", prov._pattern_hint = "mul", prov.op = "mul", prov.family = "elementwise", prov.aten = "aten.mul.Tensor", prov.orig_dtype = "float32"} {
    ^bb2(%26: f32, %27: f32, %28: f32):
      %29 = arith.mulf %26, %27 : f32
      linalg.yield %29 : f32
    } -> tensor<16x32xf32>
    %30 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0xff800000 : f32
    %31 = tensor.splat %30 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %32 = linalg.reduce ins(%25:tensor<16x32xf32>) outs(%31:tensor<16xf32>) dimensions = [1]
    (%33: f32, %34: f32) {
      %35 = arith.maximumf %33, %34 : f32
      linalg.yield %35 : f32
    }
    %36 = tensor.expand_shape %32 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %37 = tensor.empty() : tensor<16x32xf32>
    %38 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%25, %36 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%37 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb3(%39: f32, %40: f32, %41: f32):
      %42 = arith.subf %39, %40 : f32
      linalg.yield %42 : f32
    } -> tensor<16x32xf32>
    %43 = tensor.empty() : tensor<16x32xf32>
    %44 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%38 : tensor<16x32xf32>) outs(%43 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb4(%45: f32, %46: f32):
      %47 = math.exp %45 : f32
      linalg.yield %47 : f32
    } -> tensor<16x32xf32>
    %48 = arith.constant {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} 0.000000e+00 : f32
    %49 = tensor.splat %48 {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32>
    %50 = linalg.reduce ins(%44:tensor<16x32xf32>) outs(%49:tensor<16xf32>) dimensions = [1]
    (%51: f32, %52: f32) {
      %53 = arith.addf %51, %52 : f32
      linalg.yield %53 : f32
    }
    %54 = tensor.expand_shape %50 [[0 : i64, 1 : i64]] output_shape [16, 1] {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} : tensor<16xf32> into tensor<16x1xf32>
    %55 = tensor.empty() : tensor<16x32xf32>
    %56 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, 0)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%44, %54 : tensor<16x32xf32>, tensor<16x1xf32>) outs(%55 : tensor<16x32xf32>) attrs =  {prov.region_id = "softmax_0", prov.family = "normalization", prov._pattern_hint = "softmax", prov.op = "softmax", prov.aten = "aten._softmax.default", prov.orig_dtype = "float32"} {
    ^bb5(%57: f32, %58: f32, %59: f32):
      %60 = arith.divf %57, %58 : f32
      linalg.yield %60 : f32
    } -> tensor<16x32xf32>
    %61 = arith.constant {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} 5.000000e-01 : f32
    %62 = tensor.splat %61 {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} : tensor<16x32xf32>
    %63 = tensor.empty() : tensor<16x32xf32>
    %64 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%56, %62 : tensor<16x32xf32>, tensor<16x32xf32>) outs(%63 : tensor<16x32xf32>) attrs =  {prov.region_id = "add_2", prov._pattern_hint = "add", prov.op = "add", prov.family = "elementwise", prov.aten = "aten.add.Tensor", prov.orig_dtype = "float32"} {
    ^bb6(%65: f32, %66: f32, %67: f32):
      %68 = arith.addf %65, %66 : f32
      linalg.yield %68 : f32
    } -> tensor<16x32xf32>
    func.return %56, %64 : tensor<16x32xf32>, tensor<16x32xf32>
  }
}