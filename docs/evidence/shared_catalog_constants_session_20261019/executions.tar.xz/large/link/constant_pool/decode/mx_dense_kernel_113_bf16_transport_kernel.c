/* MX dense f32 adapter: FP8, qualified 16x256x2048 schedule. */
#include <stddef.h>
#include <stdint.h>
#include "runtime_quant.h"

void mx_issue_1(const void *, const void *, const void *, const void *,
                     const void *, const void *);
extern const uint8_t mx_dense_kernel_113_fixed_codes[];
extern const uint8_t mx_dense_kernel_113_fixed_scales[];
extern unsigned char mx_catalog_workspace[];

void mx_dense_kernel_113_bf16_transport_kernel(const float *lhs, const float *rhs, uint16_t *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  uint8_t *activation = (uint8_t *)(mx_catalog_workspace + 0);
  uint8_t *activation_scales = (uint8_t *)(mx_catalog_workspace + 32768);
  uint16_t *output_bf16 = (uint16_t *)(mx_catalog_workspace + 33792);
  uint8_t *scratch_output_scales = (uint8_t *)(mx_catalog_workspace + 41984);
  if (mx_pack_activation_zero_rows_f32(lhs, 1u, 16u, 2048u, MX_RUNTIME_FP8,
                             activation, activation_scales)) __builtin_trap();
  mx_issue_1(activation, activation_scales, mx_dense_kernel_113_fixed_codes, mx_dense_kernel_113_fixed_scales,
                  output_bf16, scratch_output_scales);
  for (uint32_t row = 0; row < 1u; ++row)
    for (uint32_t col = 0; col < 256u; ++col)
      out[(size_t)row * 256u + col] = output_bf16[(size_t)row * 256u + col];
}
