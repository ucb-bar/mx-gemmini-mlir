#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_mul_chain_f32_137_kernel_mul0_issue_137(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x00004a0004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0002001000002010)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul0_a[144] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul0_b[144] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul0_c[144] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul0_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_mul_chain_f32_137_kernel_mul0_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_mul_chain_f32_137_kernel_mul0(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 137; base += 137) {
    uint32_t count = 137 - base;
    if (count > 137) count = 137;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_mul_chain_f32_137_kernel_mul0_a[index] = mx_vpu_mul_chain_f32_137_kernel_mul0_b[index] = 0;
        continue;
      }
      uint32_t word = mx_vpu_mul_chain_f32_137_kernel_mul0_narrow(lhs[(base + index)]);
      mx_vpu_mul_chain_f32_137_kernel_mul0_a[index] = (uint16_t)word;
      mx_vpu_mul_chain_f32_137_kernel_mul0_b[index] = mx_vpu_mul_chain_f32_137_kernel_mul0_narrow(rhs[(base + index)]);
    }
    const void *a = mx_vpu_mul_chain_f32_137_kernel_mul0_a, *b = mx_vpu_mul_chain_f32_137_kernel_mul0_b, *c = mx_vpu_mul_chain_f32_137_kernel_mul0_c;
    switch (count) {
    case 137: mx_vpu_mul_chain_f32_137_kernel_mul0_issue_137(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_mul_chain_f32_137_kernel_mul0_widen(mx_vpu_mul_chain_f32_137_kernel_mul0_c[index]);
  }
}

#include <stdint.h>
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void mx_vpu_mul_chain_f32_137_kernel_mul1_issue_137(const void *lhs, const void *rhs, const void *result) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)lhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)rhs + UINT64_C(256))), "r"(UINT64_C(0x0002001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x00004a0004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(0))), "r"(UINT64_C(0x0010001000002000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)result + UINT64_C(256))), "r"(UINT64_C(0x0002001000002010)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul1_a[144] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul1_b[144] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul1_c[144] __attribute__((aligned(64)));
static uint16_t mx_vpu_mul_chain_f32_137_kernel_mul1_narrow(float value) {
  union {float f; uint32_t u;} word;
  word.f = value;
  if ((word.u & 0x7f800000u) == 0x7f800000u &&
      (word.u & 0x007fffffu)) __builtin_trap();
  word.u += 0x7fffu + ((word.u >> 16) & 1u);
  return (uint16_t)(word.u >> 16);
}
static float mx_vpu_mul_chain_f32_137_kernel_mul1_widen(uint16_t value) {
  union {float f; uint32_t u;} word;
  word.u = (uint32_t)value << 16;
  return word.f;
}
void mx_vpu_mul_chain_f32_137_kernel_mul1(const float *lhs, const float *rhs, float *out) {
  if (!lhs || !rhs || !out) __builtin_trap();
  for (uint32_t base = 0; base < 137; base += 137) {
    uint32_t count = 137 - base;
    if (count > 137) count = 137;
    for (uint32_t index = 0; index < (count + 7u) / 8u * 8u; ++index) {
      if (index >= count) {
        mx_vpu_mul_chain_f32_137_kernel_mul1_a[index] = mx_vpu_mul_chain_f32_137_kernel_mul1_b[index] = 0;
        continue;
      }
      uint32_t word = mx_vpu_mul_chain_f32_137_kernel_mul1_narrow(lhs[(base + index)]);
      mx_vpu_mul_chain_f32_137_kernel_mul1_a[index] = (uint16_t)word;
      mx_vpu_mul_chain_f32_137_kernel_mul1_b[index] = mx_vpu_mul_chain_f32_137_kernel_mul1_narrow(rhs[(base + index)]);
    }
    const void *a = mx_vpu_mul_chain_f32_137_kernel_mul1_a, *b = mx_vpu_mul_chain_f32_137_kernel_mul1_b, *c = mx_vpu_mul_chain_f32_137_kernel_mul1_c;
    switch (count) {
    case 137: mx_vpu_mul_chain_f32_137_kernel_mul1_issue_137(a, b, c); break;
      default: __builtin_trap();
    }
    for (uint32_t index = 0; index < count; ++index)
      out[base + index] = mx_vpu_mul_chain_f32_137_kernel_mul1_widen(mx_vpu_mul_chain_f32_137_kernel_mul1_c[index]);
  }
}

void mx_vpu_mul_chain_f32_137_kernel_materialized(const float *a, const float *b, const float *c,
            float *middle, float *output) {
          mx_vpu_mul_chain_f32_137_kernel_mul0(a,b,middle); mx_vpu_mul_chain_f32_137_kernel_mul1(middle,c,output);
        }
#include <stdint.h>

_Static_assert(sizeof(uintptr_t) == 8, "MX Rocket commands require RV64");

static void chain_issue_137(const void *a, const void *b, const void *c, const void *m, const void *o) {
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)a + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)a + UINT64_C(256))), "r"(UINT64_C(0x0002001000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)b + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)b + UINT64_C(256))), "r"(UINT64_C(0x0002001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x00004a0004000000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
  __asm__ volatile (".insn r 0x7b, 3, 7, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000000)), "r"(UINT64_C(0x0000000000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000100101)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 0, x0, %0, %1" : : "r"(UINT64_C(0x0000000000000002)), "r"(UINT64_C(0x0000000000000010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)c + UINT64_C(0))), "r"(UINT64_C(0x0010001000001000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 2, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)c + UINT64_C(256))), "r"(UINT64_C(0x0002001000001010)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 33, x0, %0, %1" : : "r"(UINT64_C(0x0000480004002000)), "r"(UINT64_C(0x0000000000000022)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)o + UINT64_C(0))), "r"(UINT64_C(0x0010001000000000)) : "memory");
  __asm__ volatile (".insn r 0x7b, 3, 3, x0, %0, %1" : : "r"(((uint64_t)(uintptr_t)o + UINT64_C(256))), "r"(UINT64_C(0x0002001000000010)) : "memory");
  __asm__ volatile ("fence" ::: "memory");
}

        static uint16_t aa[144] __attribute__((aligned(64)));
        static uint16_t bb[144] __attribute__((aligned(64)));
        static uint16_t cc[144] __attribute__((aligned(64)));
        static uint16_t rr[144] __attribute__((aligned(64)));
        static uint16_t chain_pack(float x, unsigned *safe) {
          union {float f; uint32_t u;} word; word.f=x;
          *safe &= (word.u & 0x7fffffffu) <= 1577058304u;
          word.u+=0x7fffu+((word.u>>16)&1u); return word.u>>16;
        }
        void mx_vpu_mul_chain_f32_137_kernel_run(const float *a,const float *b,const float *c,float *middle,float *output) {
          if(!a || !b || !c || !middle || !output) __builtin_trap();
          for(uint32_t base=0;base<137;base+=137) {
            uint32_t count=137-base;
            if(count>137) count=137;
            unsigned safe=1;
            for(uint32_t i=0;i<(count+7u)/8u*8u;++i) {
              aa[i]=i<count ? chain_pack(a[base+i],&safe) : 0;
              bb[i]=i<count ? chain_pack(b[base+i],&safe) : 0;
              cc[i]=i<count ? chain_pack(c[base+i],&safe) : 0;
            }
            if(!safe) { mx_vpu_mul_chain_f32_137_kernel_materialized(a,b,c,middle,output); return; }
            switch(count) { case 137: chain_issue_137(aa,bb,cc,rr,rr); break; default: __builtin_trap(); }
            for(uint32_t i=0;i<count;++i) {
              union {float f; uint32_t u;} word; word.u=(uint32_t)rr[i]<<16;
              output[base+i]=word.f;
            }
          }
        }

void mx_vpu_mul_chain_f32_137_kernel(const float *a, const float *b, const float *c, float *o) {
      static float middle[137] __attribute__((aligned(64)));
      mx_vpu_mul_chain_f32_137_kernel_run(a,b,c,middle,o);
    }
#include <stdint.h>
    typedef struct {void *allocated,*aligned; intptr_t offset;
      intptr_t sizes[1],strides[1];} mx_chain_memref;
    extern void mx_vpu_mul_chain_f32_137_kernel(const float *,const float *,const float *,float *);
    mx_chain_memref mx_vpu_mul_chain_f32_137(void *a_alloc,void *a_aligned,intptr_t a_off,intptr_t a_s0,intptr_t a_st0,void *b_alloc,void *b_aligned,intptr_t b_off,intptr_t b_s0,intptr_t b_st0,void *c_alloc,void *c_aligned,intptr_t c_off,intptr_t c_s0,intptr_t c_st0,void *d_alloc,void *d_aligned,intptr_t d_off,intptr_t d_s0,intptr_t d_st0) {
      if(!a_aligned || a_off < 0 || a_s0 != 137 || a_st0 != 1 || !b_aligned || b_off < 0 || b_s0 != 137 || b_st0 != 1 || !c_aligned || c_off < 0 || c_s0 != 137 || c_st0 != 1 || !d_aligned || d_off < 0 || d_s0 != 137 || d_st0 != 1) __builtin_trap();
      mx_vpu_mul_chain_f32_137_kernel((const float *)a_aligned+a_off,(const float *)b_aligned+b_off,
               (const float *)c_aligned+c_off,(float *)d_aligned+d_off);
      return (mx_chain_memref){d_alloc,d_aligned,d_off,
        {137},{1}};
    }
    void _mlir_ciface_mx_vpu_mul_chain_f32_137(mx_chain_memref *result,const mx_chain_memref *a,
      const mx_chain_memref *b,const mx_chain_memref *c,const mx_chain_memref *d) {
      if(!result || !a || !b || !c || !d) __builtin_trap();
      mx_chain_memref r=mx_vpu_mul_chain_f32_137(a->allocated,a->aligned,a->offset,a->sizes[0],a->strides[0],b->allocated,b->aligned,b->offset,b->sizes[0],b->strides[0],c->allocated,c->aligned,c->offset,c->sizes[0],c->strides[0],d->allocated,d->aligned,d->offset,d->sizes[0],d->strides[0]); result->allocated=r.allocated;
result->aligned=r.aligned;
result->offset=r.offset;
result->sizes[0]=r.sizes[0];
result->strides[0]=r.strides[0];
    }

    void run_chain(const float *a,const float *b,const float *c,float *middle,float *o) {
      mx_chain_memref aa={(void *)a,(void *)a,0,{137},{1}};
      mx_chain_memref bb={(void *)b,(void *)b,0,{137},{1}};
      mx_chain_memref cc={(void *)c,(void *)c,0,{137},{1}};
      mx_chain_memref oo={o,o,0,{137},{1}},result;
      _mlir_ciface_mx_vpu_mul_chain_f32_137(&result,&aa,&bb,&cc,&oo);
      if(result.aligned!=o || result.offset) __builtin_trap();
    }
