#include <stdint.h>
    typedef struct {void *allocated,*aligned; intptr_t offset;
      intptr_t sizes[2],strides[2];} mx_chain_memref;
    extern void mx_vpu_mul_chain_f32_32_32_kernel(const float *,const float *,const float *,float *);
    mx_chain_memref mx_vpu_mul_chain_f32_32_32(void *a_alloc,void *a_aligned,intptr_t a_off,intptr_t a_s0,intptr_t a_s1,intptr_t a_st0,intptr_t a_st1,void *b_alloc,void *b_aligned,intptr_t b_off,intptr_t b_s0,intptr_t b_s1,intptr_t b_st0,intptr_t b_st1,void *c_alloc,void *c_aligned,intptr_t c_off,intptr_t c_s0,intptr_t c_s1,intptr_t c_st0,intptr_t c_st1,void *d_alloc,void *d_aligned,intptr_t d_off,intptr_t d_s0,intptr_t d_s1,intptr_t d_st0,intptr_t d_st1) {
      if(!a_aligned || a_off < 0 || a_s0 != 32 || a_s1 != 32 || a_st0 != 32 || a_st1 != 1 || !b_aligned || b_off < 0 || b_s0 != 32 || b_s1 != 32 || b_st0 != 32 || b_st1 != 1 || !c_aligned || c_off < 0 || c_s0 != 32 || c_s1 != 32 || c_st0 != 32 || c_st1 != 1 || !d_aligned || d_off < 0 || d_s0 != 32 || d_s1 != 32 || d_st0 != 32 || d_st1 != 1) __builtin_trap();
      mx_vpu_mul_chain_f32_32_32_kernel((const float *)a_aligned+a_off,(const float *)b_aligned+b_off,
               (const float *)c_aligned+c_off,(float *)d_aligned+d_off);
      return (mx_chain_memref){d_alloc,d_aligned,d_off,
        {32,32},{32,1}};
    }
    void _mlir_ciface_mx_vpu_mul_chain_f32_32_32(mx_chain_memref *result,const mx_chain_memref *a,
      const mx_chain_memref *b,const mx_chain_memref *c,const mx_chain_memref *d) {
      if(!result || !a || !b || !c || !d) __builtin_trap();
      mx_chain_memref r=mx_vpu_mul_chain_f32_32_32(a->allocated,a->aligned,a->offset,a->sizes[0],a->sizes[1],a->strides[0],a->strides[1],b->allocated,b->aligned,b->offset,b->sizes[0],b->sizes[1],b->strides[0],b->strides[1],c->allocated,c->aligned,c->offset,c->sizes[0],c->sizes[1],c->strides[0],c->strides[1],d->allocated,d->aligned,d->offset,d->sizes[0],d->sizes[1],d->strides[0],d->strides[1]); result->allocated=r.allocated;
result->aligned=r.aligned;
result->offset=r.offset;
result->sizes[0]=r.sizes[0];
result->sizes[1]=r.sizes[1];
result->strides[0]=r.strides[0];
result->strides[1]=r.strides[1];
    }
